# -*- coding: utf-8 -*-
"""쇼츠컷 라이선스(모드 잠금). 판매자가 tools/license_keygen.py 로 서명한 키를 구매자가 홈 「라이선스」에 넣으면
쇼핑 쇼츠(shop) · 롱폼→쇼츠(long) · 가로 편집(wide) 가 열린다. 검증은 공개키(license_pub.json)로 이 PC 에서 하며
서버·인터넷이 필요 없다. 프로그램 안에는 비밀이 없다(공개키만).

키 형식: SCUT-<base64url(JSON)>.<base64url(RSA-2048 서명)>
JSON: {"v":1,"m":"shop,long,wide","to":"구매자","iat":"발급일","exp":"만료일 또는 빈칸","pc":"PC 코드 또는 빈칸","pl":"플랜 이름"}
개발 PC(.secrets/license_private.json 이 있는 곳)는 전부 열린다.
"""
import base64, hashlib, json, time, uuid
from pathlib import Path

BASE = Path(__file__).resolve().parent
PUB = BASE / "license_pub.json"
DEV_MARK = BASE / ".secrets" / "license_private.json"
MODES = {"shop": "쇼핑 쇼츠", "long": "롱폼 → 쇼츠", "wide": "가로 롱폼 편집"}
_cache = {"key": None, "st": None}


def machine_code():
    """이 PC 를 가리키는 8자리 코드(XXXX-XXXX). 윈도 MachineGuid, 없으면 MAC. 구매자가 판매자에게 보내 키를 PC 에 묶는다."""
    src = ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            src = winreg.QueryValueEx(k, "MachineGuid")[0]
    except Exception:
        src = ""
    if not src:
        src = "mac:%012x" % uuid.getnode()
    h = hashlib.sha256(("shortscut|" + src).encode("utf-8")).hexdigest()[:8].upper()
    return h[:4] + "-" + h[4:]


def _b64u_dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _em(payload: bytes, k: int) -> int:
    t = b"SCUT1:" + hashlib.sha256(payload).digest()
    return int.from_bytes(b"\x00\x01" + b"\xff" * (k - 3 - len(t)) + b"\x00" + t, "big")


def parse_key(key: str) -> dict:
    """서명·만료·PC 를 검사해 payload 를 돌려준다. 문제가 있으면 ValueError(한국어 메시지)."""
    key = (key or "").strip().replace("\n", "").replace(" ", "")
    if not key.startswith("SCUT-") or "." not in key:
        raise ValueError("키 형식이 아닙니다. SCUT- 로 시작하는 키 전체를 붙여 넣어 주세요.")
    try:
        pub = json.loads(PUB.read_text(encoding="utf-8"))
    except Exception:
        raise ValueError("공개키 파일(license_pub.json)이 없습니다. 프로그램을 다시 설치해 주세요.")
    body, sig = key[5:].split(".", 1)
    try:
        raw = _b64u_dec(body); s = int.from_bytes(_b64u_dec(sig), "big")
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        raise ValueError("키가 손상됐습니다. 복사할 때 앞뒤가 잘리지 않았는지 확인해 주세요.")
    k = (int(pub["n"]).bit_length() + 7) // 8
    if pow(s, int(pub["e"]), int(pub["n"])) != _em(raw, k):
        raise ValueError("서명이 맞지 않습니다. 이 프로그램용으로 발급된 키가 아닙니다.")
    exp = (payload.get("exp") or "").strip()
    if exp and time.strftime("%Y-%m-%d") > exp:
        if str(payload.get("pl") or "").startswith("체험"):
            raise ValueError("체험 기간이 %s 에 끝났습니다. 계속 쓰시려면 shortscut.kr 에서 구매해 주세요. 만든 프로젝트와 결과물은 그대로 남습니다." % exp)
        raise ValueError("만료된 키입니다(%s까지). 연장은 shortscut.kr 에서 1년 단위로 합니다." % exp)
    pc = (payload.get("pc") or "").strip().upper()
    if pc and pc != machine_code():
        raise ValueError("다른 PC 용 키입니다. 이 PC 의 코드는 %s 입니다. PC 를 바꾸셨으면 구매처에 알려 주세요." % machine_code())
    return payload


def status(cfg: dict) -> dict:
    """{ok, modes, plan, to, exp, pc, error, machine, dev}. config.json 의 license_key 를 본다."""
    if DEV_MARK.exists():
        return {"ok": True, "modes": list(MODES), "plan": "개발자 (전체)", "to": "", "exp": "", "pc": "", "error": "", "machine": machine_code(), "dev": True}
    key = (cfg.get("license_key") or "").strip()
    if _cache["key"] == key and _cache["st"] and _cache["st"].get("_day") == time.strftime("%Y-%m-%d"):
        return _cache["st"]
    st = {"ok": False, "modes": [], "plan": "", "to": "", "exp": "", "pc": "", "error": "", "machine": machine_code(), "dev": False, "_day": time.strftime("%Y-%m-%d")}
    if key:
        try:
            p = parse_key(key)
            st.update(ok=True, modes=[m for m in (p.get("m") or "").split(",") if m in MODES], plan=p.get("pl") or "", to=p.get("to") or "", exp=p.get("exp") or "", pc=p.get("pc") or "")
        except ValueError as e:
            st["error"] = str(e)
    _cache.update(key=key, st=st)
    return st


def require(cfg: dict, mode: str):
    """mode 가 열려 있으면 None, 아니면 사용자에게 보일 문장."""
    st = status(cfg)
    if mode in st["modes"]:
        return None
    name = MODES.get(mode, mode)
    if st["error"]:
        return "「%s」을(를) 쓰려면 라이선스가 필요합니다. 등록된 키: %s" % (name, st["error"])
    if not st["ok"]:
        return "「%s」은(는) 라이선스 키를 넣어야 열립니다. 홈 화면 「라이선스」에 구매한 키를 붙여 넣어 주세요." % name
    if mode == "wide":
        return "「가로 롱폼 편집」은 일괄 구매 라이선스에서만 열립니다. 지금 키: %s" % (st["plan"] or "단품")
    return "지금 라이선스(%s)에는 「%s」이(가) 들어 있지 않습니다." % (st["plan"] or "단품", name)
