@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "python\python.exe" (
  "python\python.exe" server.py
) else if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" server.py
) else (
  python server.py
)
pause
