# -*- coding: utf-8 -*-
"""쇼츠컷 파이프라인 — 롱폼 하나를 받아 세로 쇼츠 여러 개로.

단계
  fetch    yt-dlp 로 영상(≤1080p mp4)·자막(json3)·썸네일을 받고 필름스트립을 뽑는다
  analyze  자막을 문장 단위 큐로 묶고, `claude -p` 에 구간·훅 제목·업로드 문안을 맡긴다
  render   ffmpeg 로 1080x1920 을 만든다. 제목·채널명은 PIL 로 그린 PNG 한 장을 얹고,
           자막은 ASS 로 libass 가 그린다. 인코더는 NVENC, 없으면 libx264.

레이아웃 상수는 layout() 한 곳에만 있다. 브라우저 미리보기는 /api/layouts 로
이 값을 받아 같은 좌표에 그리므로, 여기서 고치면 미리보기와 결과물이 같이 움직인다.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

# 허깅페이스 캐시(faster-whisper 모델)는 윈도에서 심볼릭 링크를 못 만들어 WinError 1314 가 난다.
# huggingface_hub 는 import 시점에 이 값을 읽으므로, 어떤 경로로 모델을 올리든 그보다 먼저 여기서 정한다(2026-09-08 로컬 파일 자막 없음 → transcribe_local 에서 재발).
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

from PIL import Image, ImageDraw, ImageFont, ImageFilter

# 콘솔 없이(pythonw) 도는 서버가 ffmpeg·ffprobe 같은 콘솔 프로그램을 띄우면 윈도가 새 cmd 창을 만든다.
# 모든 자식 프로세스에 CREATE_NO_WINDOW 를 기본으로 준다(파일 선택 창 같은 GUI 자식은 영향 없음).
# 같은 자리에서 "ffmpeg"/"ffprobe" 라는 이름을 실제 경로로 바꾼다 — bin\ 에 내려받은 것이 있으면 그것, 없으면 PATH.
# 파이프라인·서버의 subprocess 호출은 전부 ["ffmpeg", ...] 로 쓰므로 여기 한 곳이면 된다.
_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_orig_run, _orig_popen = subprocess.run, subprocess.Popen
_FF_NAMES = {"ffmpeg", "ffprobe", "ffmpeg.exe", "ffprobe.exe"}


def _ff_resolve(a, k):
    args = k["args"] if "args" in k else (a[0] if a else None)
    if isinstance(args, (list, tuple)) and args and isinstance(args[0], str) and args[0].lower() in _FF_NAMES:
        exe = ffmpeg_exe(args[0].split(".")[0])
        if exe and exe != args[0]:
            args = [exe] + list(args[1:])
            if "args" in k:
                k["args"] = args
            else:
                a = (args,) + tuple(a[1:])
    return a, k


def _run_wrapped(*a, **k):
    a, k = _ff_resolve(a, k)
    if _CREATE_NO_WINDOW:
        k.setdefault("creationflags", _CREATE_NO_WINDOW)
    return _orig_run(*a, **k)


class _PopenWrapped(_orig_popen):
    def __init__(self, *a, **k):
        a, k = _ff_resolve(a, k)
        if _CREATE_NO_WINDOW:
            k.setdefault("creationflags", _CREATE_NO_WINDOW)
        super().__init__(*a, **k)


subprocess.run, subprocess.Popen = _run_wrapped, _PopenWrapped

BASE = Path(__file__).resolve().parent


def _data_root():
    """생성물(projects·uploads·cache·products)이 쌓이는 곳. config.json 의 data_root 가 있으면 거기(예: O:\\shortscut),
    없거나 못 만들면 프로그램 폴더. 2026-09-12: C: 는 시스템용이라 생성물을 다른 드라이브로 뺀다."""
    try:
        v = json.loads((BASE / "config.json").read_text(encoding="utf-8")).get("data_root")
    except Exception:
        v = None
    if v:
        p = Path(v)
        try:
            p.mkdir(parents=True, exist_ok=True)
            return p
        except Exception:
            pass
    return BASE


DATA = _data_root()
PROJECTS = DATA / "projects"
BIN = BASE / "bin"                                     # 자동으로 내려받은 ffmpeg/ffprobe 가 들어가는 곳(배포판은 비어 있음)
LOGS = BASE / "logs"


def app_version():
    try:
        return (BASE / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


VERSION = app_version()
FONTS = BASE / "fonts"
W, H = 1080, 1920                                      # 기본 캔버스(세로 쇼츠). 다른 캔버스는 CANVASES/canvas_size 로

CANVASES = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080)}   # 출력 형식(캔버스)
CANVAS_NAMES = {"9:16": "세로 쇼츠 (1080×1920)", "16:9": "가로 롱폼 (1920×1080)", "1:1": "정사각 (1080×1080)"}


def canvas_of(st):
    c = (st or {}).get("canvas") or "9:16"
    return c if c in CANVASES else "9:16"


def canvas_size(st):
    return CANVASES[canvas_of(st)]

SYS_FONTS = Path("C:/Windows/Fonts")
FONT_CANDIDATES = ["NotoSansKR-VF.ttf", "malgunbd.ttf", "malgun.ttf"]

# 1:1 이 곧 5:5, 4:5 가 곧 8:10 이다. "5:6" 은 UI 에서 뺐지만 옛 프로젝트가 들고 있을 수 있어 계산은 남긴다.
RATIOS = {"16:9": 16 / 9, "7:5": 7 / 5, "5:4": 5 / 4, "1:1": 1.0, "4:5": 4 / 5, "5:6": 5 / 6, "5:7": 5 / 7,
          "9:16": 9 / 16}
TEMPLATES = ["dark", "pop", "comment"]

TITLE_SIZE = 66
TITLE_MIN = 44
TITLE_MAXW = 980
SUB_SIZE = {"dark": 54, "pop": 72, "comment": 54}
CHAN_SIZE = 40


# ── 공통 ──────────────────────────────────────────────────────────────────────

def log(*a):
    print(*a, flush=True)


def ensure_fonts():
    """libass 와 PIL 이 같은 파일을 보도록 시스템 폰트를 fonts/ 로 복사해 둔다."""
    FONTS.mkdir(exist_ok=True)
    for name in FONT_CANDIDATES:
        src = SYS_FONTS / name
        dst = FONTS / name
        if src.exists() and not dst.exists():
            shutil.copy2(src, dst)
    for name in FONT_CANDIDATES:
        if (FONTS / name).exists():
            return FONTS / name
    raise RuntimeError("한글 폰트를 찾지 못했습니다: %s" % SYS_FONTS)


def font(size, bold=True):
    path = ensure_fonts()
    f = ImageFont.truetype(str(path), size)
    if "VF" in path.name:
        try:
            f.set_variation_by_name("Bold" if bold else "Regular")
        except Exception:
            pass
    return f


# 텍스트용 무료 글꼴. 전부 SIL OFL(구글 폰츠 ofl/ + 프리텐다드) — 상업 사용·재배포 가능해 배포판에 동봉한다.
# 파일은 fonts/ 에 두고, 없으면 목록에서 '없음'으로 표시된다. group 은 편집기 드롭다운의 묶음 이름(2026-09-12: 9종 → 38종, 묶음 없이는 못 고른다).
_G = lambda id, name, file, group: {"id": id, "name": name, "file": file, "bold_ok": False, "group": group}
TEXT_FONTS = [
    {"id": "noto", "name": "본고딕 (기본)", "file": None, "css": "'Noto Sans KR','Malgun Gothic',sans-serif", "bold_ok": True, "group": "고딕"},
    _G("pretendardxb", "프리텐다드 엑스트라볼드", "Pretendard-ExtraBold.otf", "고딕"),
    _G("pretendardblack", "프리텐다드 블랙", "Pretendard-Black.otf", "고딕"),
    _G("nanumgothic", "나눔고딕 볼드", "NanumGothic-Bold.ttf", "고딕"),
    _G("nanumgothicxb", "나눔고딕 엑스트라볼드", "NanumGothic-ExtraBold.ttf", "고딕"),
    _G("ibmplexkr", "IBM 플렉스 KR 볼드", "IBMPlexSansKR-Bold.ttf", "고딕"),
    _G("gowundodum", "고운돋움", "GowunDodum-Regular.ttf", "고딕"),
    _G("sunflower", "해바라기 볼드", "Sunflower-Bold.ttf", "고딕"),
    _G("nanumcoding", "나눔고딕코딩 볼드", "NanumGothicCoding-Bold.ttf", "고딕"),
    _G("blackhan", "블랙한산스", "BlackHanSans-Regular.ttf", "임팩트·제목"),
    _G("gothica1", "고딕 A1 블랙", "GothicA1-Black.ttf", "임팩트·제목"),
    _G("gasoek", "가석 원 (아주 두꺼움)", "GasoekOne-Regular.ttf", "임팩트·제목"),
    _G("bagelfat", "베이글 팻 원 (통통)", "BagelFatOne-Regular.ttf", "임팩트·제목"),
    _G("dohyeon", "도현", "DoHyeon-Regular.ttf", "임팩트·제목"),
    _G("jua", "주아", "Jua-Regular.ttf", "둥근"),
    _G("dongle", "동글 볼드", "Dongle-Bold.ttf", "둥근"),
    _G("cutefont", "큐트 폰트", "CuteFont-Regular.ttf", "둥근"),
    _G("nanumpen", "나눔손글씨 펜", "NanumPenScript-Regular.ttf", "손글씨"),
    _G("nanumbrush", "나눔손글씨 붓", "NanumBrushScript-Regular.ttf", "손글씨"),
    _G("gaegu", "개구 볼드", "Gaegu-Bold.ttf", "손글씨"),
    _G("himelody", "하이 멜로디", "HiMelody-Regular.ttf", "손글씨"),
    _G("singleday", "싱글 데이", "SingleDay-Regular.ttf", "손글씨"),
    _G("poorstory", "푸어 스토리", "PoorStory-Regular.ttf", "손글씨"),
    _G("gamjaflower", "감자꽃", "GamjaFlower-Regular.ttf", "손글씨"),
    _G("eastseadokdo", "동해독도 (붓)", "EastSeaDokdo-Regular.ttf", "손글씨"),
    _G("dokdo", "독도 (붓)", "Dokdo-Regular.ttf", "손글씨"),
    _G("kirang", "기랑해랑 (붓)", "KirangHaerang-Regular.ttf", "손글씨"),
    _G("yeonsung", "연성 (붓)", "YeonSung-Regular.ttf", "손글씨"),
    _G("nanummyeongjo", "나눔명조 볼드", "NanumMyeongjo-Bold.ttf", "명조"),
    _G("gowunbatang", "고운바탕 볼드", "GowunBatang-Bold.ttf", "명조"),
    _G("songmyung", "송명", "SongMyung-Regular.ttf", "명조"),
    _G("stylish", "스타일리시", "Stylish-Regular.ttf", "장식"),
    _G("gugi", "구기", "Gugi-Regular.ttf", "장식"),
    _G("bwpicture", "흑백사진", "BlackAndWhitePicture-Regular.ttf", "장식"),
    _G("orbit", "오르빗", "Orbit-Regular.ttf", "장식"),
    _G("moirai", "모이라이 원", "MoiraiOne-Regular.ttf", "장식"),
    _G("diphylleia", "디필레이아", "Diphylleia-Regular.ttf", "장식"),
]


CUSTOM_FONTS_PATH = FONTS / "custom.json"


def custom_fonts():
    try:
        return json.loads(CUSTOM_FONTS_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def all_fonts():
    return TEXT_FONTS + [dict(f, kind="user", bold_ok=False, group="내 글꼴") for f in custom_fonts()]


def text_fonts():
    """미리보기용 목록: 내장 + 사용자 등록 글꼴, 파일 유무와 URL 을 붙여 준다."""
    out = []
    for f in all_fonts():
        ok = f["file"] is None or (FONTS / f["file"]).exists()
        out.append(dict(f, available=ok, url=("/fonts/%s" % f["file"]) if f["file"] and ok else None))
    return out


def font_add(paths):
    """ttf/otf 를 fonts/ 로 복사해 사용자 글꼴로 등록한다. 이름은 파일 안의 글꼴 이름."""
    import uuid
    lst = custom_fonts()
    added = []
    for fp in paths:
        src = Path(fp)
        if not src.exists() or src.suffix.lower() not in (".ttf", ".otf"):
            continue
        try:
            probe = ImageFont.truetype(str(src), 40)
            fam, sty = probe.getname()
            name = fam if sty.lower() in ("regular", "normal", "book") else "%s %s" % (fam, sty)
        except Exception:
            name = src.stem
        fid = "u" + uuid.uuid4().hex[:6]
        dst = FONTS / ("user_%s%s" % (fid, src.suffix.lower()))
        shutil.copy2(src, dst)
        item = {"id": fid, "name": name, "file": dst.name}
        lst.append(item)
        added.append(item)
    CUSTOM_FONTS_PATH.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
    return added


def font_remove(fid):
    lst = custom_fonts()
    keep = [f for f in lst if f["id"] != fid]
    for f in lst:
        if f["id"] == fid:
            try:
                (FONTS / f["file"]).unlink()
            except OSError:
                pass
    CUSTOM_FONTS_PATH.write_text(json.dumps(keep, ensure_ascii=False, indent=1), encoding="utf-8")


def text_font(fid, size, bold=True):
    """텍스트 항목의 글꼴. 목록에 없거나 파일이 없으면 기본 글꼴."""
    for f in all_fonts():
        if f["id"] == fid and f["file"] and (FONTS / f["file"]).exists():
            return ImageFont.truetype(str(FONTS / f["file"]), size)
    return font(size, bold=bold)


# ── 효과음 라이브러리: 내장(자체 합성, 자유 사용) + 사용자가 등록한 파일. sfx/index.json 이 목록 ──
SFX_DIR = BASE / "sfx"


def sfx_index():
    try:
        return json.loads((SFX_DIR / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def sfx_save(lst):
    SFX_DIR.mkdir(exist_ok=True)
    (SFX_DIR / "index.json").write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")


def sfx_list():
    out = []
    for it in sfx_index():
        p = SFX_DIR / it["file"]
        if p.exists():
            out.append(dict(it, path=str(p), url="/sfx/%s" % it["file"]))
    return out


def sfx_add(paths):
    import uuid
    lst = sfx_index()
    added = []
    for fp in paths:
        src = Path(fp)
        if not src.exists():
            continue
        sid = "s" + uuid.uuid4().hex[:6]
        dst = SFX_DIR / ("user_%s%s" % (sid, src.suffix.lower()))
        shutil.copy2(src, dst)
        item = {"id": sid, "title": src.stem, "file": dst.name, "duration": audio_duration(dst), "kind": "user", "license": "내 파일"}
        lst.append(item)
        added.append(item)
    sfx_save(lst)
    return added


def sfx_remove(sid):
    lst = sfx_index()
    keep = []
    for it in lst:
        if it["id"] == sid and it.get("kind") == "user":
            try:
                (SFX_DIR / it["file"]).unlink()
            except OSError:
                pass
        else:
            keep.append(it)
    sfx_save(keep)


TEXT_ANIMS = {"none", "fade", "up", "down", "left", "right", "zoom"}
TEXT_ANIM_D = 0.45                                    # 나타나기·사라지기 길이(초)
SUB_FX_D = 0.3                                        # 자막 효과(나타나기·사라지기) 길이(초). 미리보기 CUE_FX_D 와 같은 값
SUB_FX_KINDS = {"none", "fade", "up", "zoom"}
SUB_EMPH_COLOR = {"yellow": (255, 225, 77, 255), "red": (255, 59, 59, 255)}


def cue_fx_of(short, cid):
    """자막 효과 short.cue_fx[cid] = {in, out, emph}. 모르는 값은 버린다."""
    f = (short.get("cue_fx") or {}).get(str(cid)) or {}
    out = {}
    if f.get("in") in SUB_FX_KINDS and f["in"] != "none":
        out["in"] = f["in"]
    if f.get("out") in SUB_FX_KINDS and f["out"] != "none":
        out["out"] = f["out"]
    if f.get("emph") in ("yellow", "red", "big"):
        out["emph"] = f["emph"]
    return out


def ass_fontname():
    path = ensure_fonts()
    return "Noto Sans KR" if "Noto" in path.name else "Malgun Gothic"


def hexrgb(s, a=255):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def ass_color(hexs, alpha=0):
    r, g, b, _ = hexrgb(hexs)
    return "&H%02X%02X%02X%02X" % (alpha, b, g, r)


def tc(v):
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if ":" not in s:
        return float(s)
    out = 0.0
    for p in s.split(":"):
        out = out * 60 + float(p)
    return out


def fmt_mmss(sec):
    sec = max(0, sec)
    m, s = divmod(int(sec), 60)
    return "%d:%02d" % (m, s)


def fmt_ass(sec):
    sec = max(0.0, sec)
    h = int(sec // 3600)
    m = int(sec % 3600 // 60)
    s = sec % 60
    return "%d:%02d:%05.2f" % (h, m, s)


def which(name):
    return shutil.which(name) or shutil.which(name + ".exe")


# ── ffmpeg 찾기·내려받기 ──────────────────────────────────────────
# 배포판에는 ffmpeg 를 동봉하지 않는다(GPL 빌드 동봉 시 소스 제공 의무). 첫 실행 때 사용자가 단추를 눌러
# 공식 빌드 배포처에서 직접 내려받아 bin\ 에 두고, 없으면 PATH 의 것을 쓴다.
FFMPEG_URLS = [
    ("gyan.dev essentials", "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"),
    ("BtbN GPL", "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"),
]
_ff_job = {"running": False, "pct": None, "message": "", "error": None, "done": False}


def ffmpeg_exe(name="ffmpeg"):
    cand = BIN / (name + (".exe" if sys.platform == "win32" else ""))
    if cand.exists():
        return str(cand)
    return shutil.which(name) or shutil.which(name + ".exe")


def ffmpeg_status():
    exe, probe = ffmpeg_exe("ffmpeg"), ffmpeg_exe("ffprobe")
    ver = ""
    if exe:
        try:
            r = _orig_run([exe, "-version"], capture_output=True, timeout=10, creationflags=_CREATE_NO_WINDOW)
            ver = r.stdout.decode("utf-8", "replace").split("\n")[0].replace("ffmpeg version ", "")[:60]
        except Exception:
            ver = "?"
    src = "bin" if exe and str(BIN) in exe else ("path" if exe else None)
    return {"found": bool(exe and probe), "ffmpeg": exe, "ffprobe": probe, "version": ver, "source": src, "job": dict(_ff_job)}


def ffmpeg_install():
    """공식 빌드 zip 을 받아 bin\ffmpeg.exe·ffprobe.exe 만 꺼낸다. 진행률은 _ff_job 에."""
    import urllib.request
    import zipfile
    if _ff_job["running"]:
        return False
    _ff_job.update(running=True, pct=0, message="내려받기 준비", error=None, done=False)

    def work():
        try:
            BIN.mkdir(exist_ok=True)
            tmp = BIN / "ffmpeg-download.zip"
            last_err = None
            for label, url in FFMPEG_URLS:
                try:
                    _ff_job.update(message="%s 에서 내려받는 중" % label, pct=0)
                    req = urllib.request.Request(url, headers={"User-Agent": "shortscut/1.0"})
                    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                        total = int(r.headers.get("Content-Length") or 0)
                        got = 0
                        while True:
                            chunk = r.read(1 << 18)
                            if not chunk:
                                break
                            f.write(chunk)
                            got += len(chunk)
                            if total:
                                _ff_job["pct"] = round(got / total * 95, 1)
                    _ff_job.update(message="압축 푸는 중", pct=96)
                    with zipfile.ZipFile(tmp) as z:
                        want = {"ffmpeg.exe": None, "ffprobe.exe": None}
                        for n in z.namelist():
                            base = n.rsplit("/", 1)[-1].lower()
                            if base in want and "/bin/" in n.replace("\\", "/"):
                                want[base] = n
                        if not all(want.values()):
                            raise RuntimeError("zip 안에서 ffmpeg.exe/ffprobe.exe 를 찾지 못했습니다")
                        for base, n in want.items():
                            with z.open(n) as src, open(BIN / base, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                    (BIN / "ffmpeg-출처.txt").write_text(
                        "이 폴더의 ffmpeg.exe / ffprobe.exe 는 쇼츠컷이 사용자의 요청으로 아래 배포처에서 내려받은 것입니다.\n"
                        "출처: %s\n받은 날: %s\n\nFFmpeg 는 LGPL/GPL 로 배포되는 자유 소프트웨어입니다(https://ffmpeg.org/legal.html). "
                        "이 빌드는 GPL 구성요소(libx264 등)를 포함하며, 소스는 배포처와 ffmpeg.org 에서 받을 수 있습니다. "
                        "쇼츠컷 설치본에는 ffmpeg 가 동봉되지 않습니다.\n" % (url, time.strftime("%Y-%m-%d")), encoding="utf-8")
                    last_err = None
                    break
                except Exception as e:
                    last_err = e
                    continue
            try:
                tmp.unlink()
            except Exception:
                pass
            if last_err:
                raise last_err
            st = ffmpeg_status()
            if not st["found"]:
                raise RuntimeError("내려받은 뒤에도 ffmpeg 를 찾지 못했습니다")
            _ff_job.update(message="완료: " + st["version"], pct=100, done=True)
        except Exception as e:
            _ff_job.update(error=str(e), message="실패")
        finally:
            _ff_job["running"] = False

    threading.Thread(target=work, daemon=True).start()
    return True


def safe_name(s, n=40):
    s = re.sub(r'[\\/:*?"<>|\r\n]+', " ", s).strip()
    s = re.sub(r"\s+", " ", s)
    return s[:n].strip() or "short"


# ── 레이아웃 (미리보기와 렌더의 단일 정본) ────────────────────────────────────

ZOOM_MAX = 3.0


def crop_rect(sw, sh, ratio, zoom=1.0, pan_x=0.0, pan_y=0.0):
    """원본 sw×sh 에서 ratio(가로/세로)에 맞는 크롭 영역. 전부 짝수.

    zoom  1.0 이면 그 비율로 담을 수 있는 최대 영역, 2.0 이면 그 절반(=2배 확대).
    pan   크롭 중심을 원본 중심에서 원본 픽셀 단위로 옮긴 값. 원본 밖으로 못 나가게 자른다.
    브라우저 app.js 의 cropRect 와 같은 계산이어야 미리보기와 결과가 맞는다."""
    r = RATIOS[ratio]
    zoom = min(max(1.0, float(zoom or 1.0)), ZOOM_MAX)
    cw = min(sw, int(round(sh * r)))
    ch = min(sh, int(round(sw / r)))
    cw = int(cw / zoom)
    ch = int(ch / zoom)
    cw -= cw % 2
    ch -= ch % 2
    cx = int(round((sw - cw) / 2 + float(pan_x or 0)))
    cy = int(round((sh - ch) / 2 + float(pan_y or 0)))
    cx = min(max(0, cx), sw - cw)
    cy = min(max(0, cy), sh - ch)
    cx -= cx % 2
    cy -= cy % 2
    return cw, ch, cx, cy


def apply_offsets(L, st):
    """사용자가 옮긴 훅 제목(title_dy)·영상 띠(band_dy) 위치를 레이아웃에 얹는다. 미리보기(app.js titleDy/bandDy)와 같은 한계값.
    자막은 sub_dy 로 따로 움직이므로 여기서 건드리지 않는다(띠를 옮겨도 자막은 제자리 — 자막도 옮기려면 자막 위치로). 2026-09-13."""
    L = dict(L)
    CH = L["H"]
    tdy = int(round(float(st.get("title_dy") or 0)))
    tdy = min(max(-L["title1_y"] + 10, tdy), CH - L["title2_y"] - 120)
    L["title1_y"] += tdy; L["title2_y"] += tdy
    if L["mode"] != "full":
        bdy = int(round(float(st.get("band_dy") or 0)))
        bdy = min(max(-L["band_top"], bdy), CH - L["band_top"] - L["band_h"])
        L["band_top"] += bdy - (bdy % 2)
    return L


def layout(ratio, template, canvas="9:16"):
    r = RATIOS[ratio]
    if canvas != "9:16" and canvas in CANVASES:
        # 세로 쇼츠가 아닌 캔버스(가로 롱폼·정사각): 원본 비율의 띠를 캔버스 안에 맞추고(좌우 또는 상하 여백), 글자 크기는 높이 비율로
        CW, CH = CANVASES[canvas]
        if CW / CH >= r:
            band_h, band_w = CH, int(round(CH * r))
        else:
            band_w, band_h = CW, int(round(CW / r))
        band_w += band_w % 2; band_h += band_h % 2
        full = band_w >= CW - 2 and band_h >= CH - 2
        k = CH / 1080.0
        return {"ratio": ratio, "template": template, "canvas": canvas, "W": CW, "H": CH, "band_w": band_w, "band_h": band_h,
                "band_left": (CW - band_w) // 2, "band_top": (CH - band_h) // 2, "mode": "full" if full else "band",
                "title_size": int(round(60 * k)), "title_min": int(round(40 * k)), "title_maxw": CW - 120,
                "sub_size": int(round(SUB_SIZE[template] * 0.95 * k)), "chan_size": int(round(36 * k)), "comment_y": None,
                "sub_maxw": min(CW - 160, int(1400 * k)),
                "title1_y": int(round(0.06 * CH)), "title2_y": int(round(0.06 * CH + 72 * k)),
                "sub_y": int(round(CH - 0.20 * CH)), "chan_y": int(round(CH - 0.075 * CH))}
    band_h = min(H, int(round(W / r)))
    band_h += band_h % 2
    L = {"ratio": ratio, "template": template, "canvas": "9:16", "W": W, "H": H, "band_left": 0, "band_w": W, "band_h": band_h,
         "title_size": TITLE_SIZE, "title_min": TITLE_MIN, "title_maxw": TITLE_MAXW,
         "sub_size": SUB_SIZE[template], "chan_size": CHAN_SIZE, "comment_y": None,
         "sub_maxw": 960}
    if band_h <= 900:
        L.update(mode="band", title1_y=330, title2_y=420, band_top=560)
        L["sub_y"] = L["band_top"] + band_h + 70
        L["chan_y"] = min(1840, max(1560, L["sub_y"] + 190))
        if template == "comment":
            # 5:4 처럼 영상 띠가 길면 자막 아래에 카드 자리가 모자라므로 위로 당기고,
            # 채널명은 화면 안(≤1840)에 남긴다. 카드 최대 높이는 3줄 254px.
            L["comment_y"] = min(L["sub_y"] + 180, 1560)
            L["chan_y"] = min(L["comment_y"] + 270, 1840)
    elif band_h < H:
        L.update(mode="tall", title1_y=110, title2_y=200, band_top=300)
        bottom = L["band_top"] + band_h
        L["sub_y"] = bottom - 200
        L["chan_y"] = min(1840, bottom + 40)
        if template == "comment":
            # 영상이 길어 아래 여백이 없으므로 카드를 영상 하단에 겹치고 자막은 그 위에 둔다
            L["comment_y"] = bottom - 290
            L["sub_y"] = L["comment_y"] - 180
    else:
        # 자막 y=1210(63%): 유튜브 쇼츠 하단 UI(제목·설명·채널)가 약 65% 아래를 덮고 틱톡은 76% — 그 사이(특가30초 편집규칙 §82 실측).
        # 예전 1480(77%)은 모바일에서 제목·설명 패널에 걸렸다(2026-09-12 사용자 지적). 폭 880 은 오른쪽 좋아요·댓글 단추 열을 피한다.
        L.update(mode="full", title1_y=260, title2_y=350, band_top=0,
                 sub_y=1210, chan_y=1700, sub_maxw=min(L["sub_maxw"], 880))
        if template == "comment":
            L["comment_y"] = 1420
            L["sub_y"] = 1180
    if template == "pop":
        # 자막 팝형: 영상 바로 아래 큰 자막, 줄 간격이 커서 채널명을 더 내린다
        if L["mode"] == "band":
            L["chan_y"] = max(L["chan_y"], L["sub_y"] + 230)
    return L


def all_layouts():
    out = {"%s|%s|%s" % (r, t, c): layout(r, t, c) for r in RATIOS for t in TEMPLATES for c in CANVASES}
    out.update({"%s|%s" % (r, t): layout(r, t) for r in RATIOS for t in TEMPLATES})   # 옛 키(세로 쇼츠)
    return out


# ── 프로젝트 저장 ─────────────────────────────────────────────────────────────

def pdir(pid):
    return PROJECTS / pid


def restore_media(pid, name):
    """프로젝트 폴더에 있어야 할 소재(source.mp4·src_*.mp4)가 없으면 project.json 의 original_path 에서 다시 복사한다.
    2026-09-12 data_root 를 O: 로 옮길 때 9/11~12 쇼핑 쇼츠 프로젝트의 소재 105개가 따라오지 않아 편집기가 검은 화면이 됐다(2026-09-14).
    되살렸으면 새 경로, 못 하면 None."""
    d = pdir(pid); dst = d / name
    if dst.exists():
        return dst
    try:
        j = json.loads((d / "project.json").read_text(encoding="utf-8"))
    except Exception:
        return None
    for it in [j.get("source") or {}] + list(j.get("extra_sources") or []):
        pth = it.get("path") or ""
        if pth and Path(pth).name == name:
            for cand in (it.get("original_path") or "", pth):
                c = Path(cand) if cand else None
                if c and c.exists() and c.is_file() and c.resolve() != dst.resolve():
                    try:
                        shutil.copy2(str(c), str(dst)); return dst
                    except Exception:
                        continue
    return None


def _relocate_paths(p):
    """프로젝트 폴더가 옮겨진 뒤(2026-09-12 data_root → O:) project.json 안의 절대 경로가 옛 위치를 가리키면
    같은 이름의 파일이 지금 폴더(또는 media/)에 있을 때 그 경로로 바꿔 준다. 렌더가 옛 경로로 ffmpeg 를 열다 죽던 원인(2026-09-14)."""
    d = pdir(p["id"])
    def fix(it):
        if not isinstance(it, dict):
            return
        for key in ("path", "thumb_path"):
            v = it.get(key)
            if not v or not isinstance(v, str):
                continue
            try:
                if Path(v).exists():
                    continue
            except Exception:
                continue
            name = Path(v).name
            for cand in (d / name, d / "media" / name):
                if cand.exists():
                    it[key] = str(cand); break
    try:
        fix(p.get("source")); fix(p.get("narration"))
        for x in p.get("extra_sources") or []: fix(x)
        for a in p.get("audio_lib") or []: fix(a)
        for s in p.get("shorts") or []:
            for a in s.get("audios") or []: fix(a)
    except Exception:
        pass
    return p


def load(pid):
    f = pdir(pid) / "project.json"
    for attempt in range(20):                        # 저장(os.replace) 순간과 겹치면 잠깐 없거나 잠길 수 있다 → 다시 읽는다
        try:
            return _relocate_paths(json.loads(f.read_text(encoding="utf-8")))
        except (PermissionError, FileNotFoundError, json.JSONDecodeError):
            if attempt == 19:
                raise
            time.sleep(0.05)


def save(p):
    d = pdir(p["id"])
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / ("project.json.%d.tmp" % threading.get_ident())
    tmp.write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")
    # 윈도에선 다른 스레드가 project.json 을 읽는 중이면 os.replace 가 '액세스 거부'로 튄다(화면 폴링과 작업 스레드가 겹칠 때).
    # 잠깐 쉬고 다시 시도한다. 스레드별 임시 파일 이름으로 임시 파일끼리의 충돌도 막는다.
    for attempt in range(20):
        try:
            os.replace(tmp, d / "project.json")
            return
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(0.05)


def set_progress(p, step, message, pct=None):
    p["progress"] = {"step": step, "message": message, "pct": pct, "at": time.time()}
    save(p)


# ── 1. fetch ─────────────────────────────────────────────────────────────────

def probe_url(url):
    import yt_dlp
    # lang=ko 가 없으면 채널명이 영문 표기(ScienceSseol)로 온다. 시청자가 보는 한국어 이름을 쓴다.
    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True,
                           "extractor_args": {"youtube": {"lang": ["ko"]}}}) as y:
        info = y.extract_info(url, download=False)
    subs = list((info.get("subtitles") or {}).keys())
    autos = list((info.get("automatic_captions") or {}).keys())
    logo = ""
    try:
        logo = channel_logo(info.get("channel_id"), info.get("channel_url")) or ""
    except Exception as e:
        log("채널 로고를 못 받았습니다:", e)
    return {
        "video_id": info.get("id"), "title": info.get("title"),
        "channel": info.get("channel") or info.get("uploader"),
        "channel_id": info.get("channel_id"), "channel_logo": logo,
        "duration": info.get("duration"), "thumbnail": info.get("thumbnail"),
        "url": info.get("webpage_url") or url,
        "has_ko_subs": any(k.startswith("ko") for k in subs),
        "has_ko_auto": any(k.startswith("ko") for k in autos),
    }


LOGOS = BASE / "logos"


def channel_logo(channel_id, channel_url):
    """채널 아바타를 logos/<channel_id>.jpg 로 받아 두고 경로를 돌려준다. 7일 안에 받은 것은 재사용."""
    import yt_dlp
    import urllib.request
    if not channel_id or not channel_url:
        return ""
    LOGOS.mkdir(exist_ok=True)
    dst = LOGOS / ("%s.jpg" % channel_id)
    if dst.exists() and time.time() - dst.stat().st_mtime < 7 * 86400:
        return str(dst)
    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True,
                           "playlist_items": "0", "extract_flat": True}) as y:
        ch = y.extract_info(channel_url, download=False)
    thumbs = ch.get("thumbnails") or []
    pick = next((t for t in thumbs if t.get("id") == "avatar_uncropped"), None)
    if not pick:
        sq = [t for t in thumbs if t.get("width") and t.get("height") and t["width"] == t["height"]]
        pick = max(sq, key=lambda t: t["width"]) if sq else None
    if not pick or not pick.get("url"):
        return ""
    req = urllib.request.Request(pick["url"], headers={"User-Agent": "Mozilla/5.0"})
    data = urllib.request.urlopen(req, timeout=20).read()
    im = Image.open(__import__("io").BytesIO(data)).convert("RGB")
    im.thumbnail((512, 512))
    im.save(dst, quality=92)
    return str(dst)


def ffprobe_video(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height:format=duration",
         "-of", "json", str(path)], capture_output=True, text=True, check=True).stdout
    j = json.loads(out)
    st = j["streams"][0]
    return int(st["width"]), int(st["height"]), float(j["format"]["duration"])


def make_filmstrip(src, dst, duration, interval=2.0, cols=20, fw=160):
    """2초마다 한 프레임을 뽑아 타일 한 장으로. 편집기 타임라인이 background-position 으로 쓴다."""
    n = max(1, int(duration // interval) + 1)
    rows = (n + cols - 1) // cols
    vf = "fps=1/%g,scale=%d:-2,tile=%dx%d" % (interval, fw, cols, rows)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-vf", vf,
                    "-frames:v", "1", "-q:v", "6", str(dst)], check=True)
    im = Image.open(dst)
    fh = im.height // rows
    return {"file": dst.name, "interval": interval, "cols": cols, "rows": rows,
            "fw": fw, "fh": fh, "count": n}


def fetch(p, hook=None):
    """유튜브 URL 이면 내려받고, 로컬 파일이면 그대로 쓴다. 자막·썸네일·필름스트립까지."""
    import yt_dlp
    d = pdir(p["id"])
    d.mkdir(parents=True, exist_ok=True)
    src = p["source"]

    if src["type"] == "youtube":
        set_progress(p, "fetch", "영상을 내려받는 중…", 0)

        def prog(st):
            if st.get("status") == "downloading":
                tot = st.get("total_bytes") or st.get("total_bytes_estimate") or 0
                done = st.get("downloaded_bytes") or 0
                pct = int(done * 100 / tot) if tot else None
                msg = "영상을 내려받는 중… %s" % (("%d%%" % pct) if pct is not None else "")
                if time.time() - p["progress"].get("at", 0) > 0.7:
                    set_progress(p, "fetch", msg, pct)

        opts = {
            "format": "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[height<=1080][ext=mp4]/b",
            "merge_output_format": "mp4",
            "outtmpl": str(d / "source.%(ext)s"),
            "writesubtitles": True, "writeautomaticsub": True,
            "subtitleslangs": ["ko", "ko-orig", "ko.*"], "subtitlesformat": "json3",
            "writethumbnail": True,
            "postprocessors": [{"key": "FFmpegThumbnailsConvertor", "format": "jpg"}],
            "quiet": True, "no_warnings": True, "noprogress": True,
            "extractor_args": {"youtube": {"lang": ["ko"]}},
            "progress_hooks": [prog],
        }
        with yt_dlp.YoutubeDL(opts) as y:
            info = y.extract_info(src["url"], download=True)
        src.update(video_id=info.get("id"), title=info.get("title"),
                   channel=info.get("channel") or info.get("uploader"),
                   url=info.get("webpage_url") or src["url"])
        mp4 = d / "source.mp4"
        if not mp4.exists():
            cands = [x for x in d.glob("source.*") if x.suffix in (".mkv", ".webm", ".mp4")]
            if not cands:
                raise RuntimeError("내려받은 영상 파일이 없습니다")
            set_progress(p, "fetch", "mp4 로 다시 담는 중…", None)
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(cands[0]),
                            "-c", "copy", str(mp4)], check=True)
        src["path"] = str(mp4)
        subs = sorted(d.glob("source.*.json3"))
        if subs:
            # 사람이 올린 자막(ko)이 자동 자막(ko-orig)보다 먼저 오도록. 자동 자막도 "ko" 로
            # 저장될 수 있으므로 수동 여부는 파일명이 아니라 info 의 subtitles 키로 판정한다.
            subs.sort(key=lambda x: (0 if x.name.endswith(".ko.json3") else 1, x.name))
            src["subs"] = str(subs[0])
            manual = any(k.startswith("ko") for k in (info.get("subtitles") or {}))
            src["subs_kind"] = "manual" if manual else "auto"
        thumb = d / "source.jpg"
        if thumb.exists():
            src["thumb"] = thumb.name
    else:
        set_progress(p, "fetch", "파일을 확인하는 중…", None)
        path = Path(src["path"])
        if not path.exists():
            raise RuntimeError("파일이 없습니다: %s" % path)
        src.setdefault("title", path.stem)
        src["original_path"] = str(path)
        # 편집기 미리보기는 브라우저가 재생한다. CapCut 등이 내보낸 mp4 는 moov(색인)가 파일 끝에 있어
        # 브라우저가 2GB 를 다 훑기 전엔 첫 프레임도 못 그린다. 색인을 앞으로 옮긴 사본을 프로젝트에 둔다.
        set_progress(p, "fetch", "브라우저가 바로 열 수 있게 영상 색인을 앞으로 옮기는 중… (복사, 1~2분)", None)
        local = d / "source.mp4"
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-c", "copy",
                            "-movflags", "+faststart", str(local)], capture_output=True, text=True)
        if r.returncode == 0 and local.exists():
            path = local
        else:
            log("faststart 복사 실패, 원본을 그대로 씁니다:", r.stderr[-300:])
        src["path"] = str(path)
        if not src.get("subs"):
            for ext in (".ko.json3", ".json3", ".srt", ".vtt"):
                c = path.with_suffix(ext)
                if c.exists():
                    src["subs"] = str(c)
                    break
        if not src.get("subs"):
            # 같은 폴더의 CapCut 프로젝트(…_capcut/<이름>/draft_info.json)에는 화면에 구운 자막이
            # 시각과 함께 그대로 들어 있다. 음성 인식보다 이게 정본이다.
            cands = list(path.parent.glob("*capcut*/*/draft_info.json")) + list(path.parent.glob("*/draft_info.json"))
            if cands:
                src["subs"] = str(cands[0])
                src["subs_kind"] = "capcut"
        if not src.get("subs"):
            src["subs"] = transcribe_local(p, path)
        thumb = d / "source.jpg"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "3", "-i", str(path),
                        "-frames:v", "1", "-q:v", "4", str(thumb)], check=False)
        if thumb.exists():
            src["thumb"] = thumb.name

    set_progress(p, "fetch", "영상 정보를 읽는 중…", None)
    w, h, dur = ffprobe_video(src["path"])
    src.update(width=w, height=h, duration=dur)
    set_progress(p, "fetch", "타임라인 필름스트립을 뽑는 중…", None)
    p["filmstrip"] = make_filmstrip(src["path"], d / "strip.jpg", dur)
    set_progress(p, "fetch", "문장 사이 무음 구간을 찾는 중…", None)
    p["silences"] = detect_silences(src["path"])
    save(p)


def transcribe_local(p, path):
    """자막 파일이 없는 로컬 영상. faster-whisper 가 깔려 있으면 쓰고, 없으면 명확히 멈춘다."""
    try:
        from faster_whisper import WhisperModel  # noqa
    except Exception:
        raise RuntimeError(
            "이 파일에는 자막이 없습니다. 같은 이름의 .srt/.vtt/.json3 을 옆에 두거나, "
            "유튜브에 올린 뒤 링크로 넣어 주세요(자동 자막을 씁니다). "
            "로컬 음성 인식을 쓰려면 .venv 에 faster-whisper 를 설치하면 자동으로 켜집니다.")
    set_progress(p, "fetch", "음성 인식 중(faster-whisper)…", None)
    cuda_dlls()                                              # cuBLAS·cuDNN 은 모델을 올릴 때가 아니라 transcribe 에서 처음 찾는다
    try:
        model = WhisperModel("large-v3", device="cuda", compute_type="float16")
        segments, _ = model.transcribe(str(path), language="ko", word_timestamps=True)
        segments = list(segments)                            # 제너레이터라 여기서 돌려야 DLL·GPU 오류가 잡힌다
    except Exception as e:                                   # GPU·large 가 안 되면 낭독 받아쓰기와 같은 사다리(medium cuda → int8 → cpu small)
        log("whisper large-v3/cuda 실패, 대체 모델로: %s" % str(e)[:160])
        model, desc = whisper_model()
        set_progress(p, "fetch", "음성 인식 중(faster-whisper %s)…" % desc, None)
        segments, _ = model.transcribe(str(path), language="ko", word_timestamps=True)
    out = pdir(p["id"]) / "source.whisper.json3"
    events = []
    for sg in segments:
        words = getattr(sg, "words", None) or []
        if words:
            events.append({"tStartMs": int(words[0].start * 1000),
                           "dDurationMs": int((words[-1].end - words[0].start) * 1000),
                           "segs": [{"utf8": w.word, "tOffsetMs": int((w.start - words[0].start) * 1000)}
                                    for w in words]})
        else:
            events.append({"tStartMs": int(sg.start * 1000), "dDurationMs": int((sg.end - sg.start) * 1000),
                           "segs": [{"utf8": sg.text, "tOffsetMs": 0}]})
    out.write_text(json.dumps({"events": events}, ensure_ascii=False), encoding="utf-8")
    return str(out)


# ── 2. 자막 → 큐 ─────────────────────────────────────────────────────────────

def words_from_json3(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    words = []
    for ev in data.get("events", []):
        segs = ev.get("segs")
        if not segs:
            continue
        t0 = ev.get("tStartMs", 0)
        for sg in segs:
            txt = (sg.get("utf8") or "").strip()
            if not txt:
                continue
            words.append(((t0 + sg.get("tOffsetMs", 0)) / 1000.0, txt))
    return words


def words_from_srt_vtt(path):
    t = Path(path).read_text(encoding="utf-8", errors="replace")
    words = []
    pat = re.compile(r"(\d+):(\d\d):(\d\d)[.,](\d{1,3})\s*-->\s*(\d+):(\d\d):(\d\d)[.,](\d{1,3})[^\n]*\n(.*?)(?=\n\s*\n|\Z)", re.S)
    for m in pat.finditer(t):
        g = m.groups()
        s = int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3].ljust(3, "0")) / 1000
        e = int(g[4]) * 3600 + int(g[5]) * 60 + int(g[6]) + int(g[7].ljust(3, "0")) / 1000
        txt = re.sub(r"<[^>]+>", "", g[8]).replace("\n", " ").strip()
        ws = txt.split()
        if not ws:
            continue
        step = (e - s) / len(ws)
        for i, w in enumerate(ws):
            words.append((s + i * step, w))
    return words


SENT_END = re.compile(r"(다|요|죠|까|니다|네요|군요|거든요|습니다)[.!?…]?$|[.!?…]$")


def build_cues(words, max_chars=22, max_gap=0.9, min_dur=0.8):
    """단어 시각 목록을 자막 한 줄(큐)로 묶는다. 문장 끝·긴 침묵·글자수에서 끊는다."""
    cues = []
    cur, cur_start = [], None
    for i, (t, w) in enumerate(words):
        nxt = words[i + 1][0] if i + 1 < len(words) else t + 1.5
        if not cur:
            cur_start = t
        cur.append(w)
        text = " ".join(cur)
        gap = nxt - t
        cut = (len(text) >= max_chars or gap > max_gap
               or (len(text) >= 10 and SENT_END.search(w))
               or (len(text) >= int(max_chars * 0.7) and _good_break(w)))     # 조사·연결어미 뒤면 조금 일찍 끊는다
        if cut or i == len(words) - 1:
            end = min(nxt, t + 2.5)
            end = max(end, cur_start + min_dur)
            cues.append({"s": round(cur_start, 3), "e": round(end, 3), "text": text})
            cur = []
    for k in range(len(cues) - 1):
        if cues[k]["e"] > cues[k + 1]["s"]:
            cues[k]["e"] = cues[k + 1]["s"]
    for k, c in enumerate(cues):
        c["id"] = k
    return cues


def cues_from_capcut(path):
    """CapCut 초안(draft_info.json)의 텍스트 트랙 → 큐. 시각은 마이크로초 단위 target_timerange."""
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    texts = {t.get("id"): t for t in (d.get("materials") or {}).get("texts", [])}
    cues = []
    for tr in d.get("tracks", []):
        if tr.get("type") != "text":
            continue
        for sg in tr.get("segments", []):
            t = texts.get(sg.get("material_id"))
            if not t:
                continue
            try:
                txt = json.loads(t.get("content") or "{}").get("text", "")
            except Exception:
                txt = t.get("base_content") or ""
            txt = re.sub(r"\s+", " ", txt or "").strip()
            rng = sg.get("target_timerange") or {}
            if not txt or not rng:
                continue
            s = rng.get("start", 0) / 1e6
            e = s + rng.get("duration", 0) / 1e6
            cues.append({"s": round(s, 3), "e": round(e, 3), "text": txt})
    cues.sort(key=lambda c: c["s"])
    for k in range(len(cues) - 1):
        if cues[k]["e"] > cues[k + 1]["s"]:
            cues[k]["e"] = cues[k + 1]["s"]
    cues = [c for c in cues if c["e"] - c["s"] > 0.05]
    for k, c in enumerate(cues):
        c["id"] = k
    if len(cues) < 5:
        raise RuntimeError("CapCut 초안에서 자막 트랙을 찾지 못했습니다: %s" % path)
    return cues


def load_cues(p):
    subs = p["source"].get("subs")
    if not subs:
        raise RuntimeError("자막이 없습니다. 유튜브 자동 자막이 아직 안 생긴 영상이면 몇 시간 뒤 다시 시도하세요.")
    if Path(subs).name == "draft_info.json":
        return cues_from_capcut(subs)
    words = words_from_json3(subs) if subs.endswith(".json3") else words_from_srt_vtt(subs)
    if len(words) < 20:
        raise RuntimeError("자막에서 읽은 단어가 너무 적습니다(%d개)." % len(words))
    return build_cues(words)


# ── 3. analyze (claude -p) ───────────────────────────────────────────────────

PROMPT = """당신은 유튜브 쇼츠 편집자입니다. 아래는 롱폼 영상의 자막입니다. 각 줄 앞의 [m:ss]는 그 줄이 시작하는 시각입니다.

영상 제목: {title}
채널: {channel}
분석 구간: {rs} ~ {re}
전체 영상 링크: {url}

이 구간에서 독립된 쇼츠로 잘라 낼 만한 구간을 정확히 {n}개 고르세요.

규칙
- 각 구간은 {min_len}~{max_len}초. 문장이 시작하는 줄에서 시작하고, 문장이 끝난 직후의 줄 시각에서 끝냅니다. 잘린 문장으로 시작하거나 끝내지 않습니다.
- 구간끼리 겹치지 않게 하고, 영상 전체에 고르게 퍼지게 고릅니다.
- 인사·채널 소개·구독 요청·마무리 인사·이전 편 언급 구간은 피합니다.
- 첫 5초 안에 시청자가 멈출 이유(반전·질문·의외의 숫자·통념 부정)가 있는 구간을 고릅니다.
- 열린 루프: 결론이나 나머지가 전체 영상에 있다는 느낌으로 끝나는 구간을 우선하되, 구간 자체로도 말이 되어야 합니다.
- 훅 제목은 두 줄. line1 은 흰 글자(상황·질문·통념), line2 는 강조색(반전·핵심). 각 줄 8~16자. 낚시 금지, 구간에 실제로 나오는 내용만 씁니다. 따옴표·이모지 금지.
- yt_title 은 40자 이내 한 문장 + 끝에 " #shorts". description 은 **첫 줄이 반드시 "전체 영상 ▶ {url}"** 이고, 빈 줄 하나 뒤에 2~3문장, 그다음 줄에 해시태그 5개(첫 번째는 #Shorts). tags 는 # 없이 6~8개(채널명 포함).
- reason 은 이 구간을 고른 이유 한 문장(시청자가 왜 멈추는지).
- score 는 이 구간이 쇼츠로 터질 가능성을 0~100 정수로(첫 5초의 훅, 구간 자체의 완결성, 의외성·반전, 열린 루프를 기준으로 구간끼리 차이가 나게).
- start/end 는 반드시 자막 줄 앞의 시각 표기를 그대로 씁니다(예: "12:34"). end 는 마지막 문장이 끝난 뒤 이어지는 줄의 시각입니다.
출력은 아래 JSON 하나만. 코드펜스·설명 없이 JSON 만 출력합니다.
{{"shorts":[{{"start":"m:ss","end":"m:ss","line1":"","line2":"","reason":"","score":0,"yt_title":"","description":"","tags":[""]}}]}}

=== 자막 ===
{transcript}
"""


def run_claude(prompt, model=None, effort=None, timeout=900):
    """도구를 전부 끄고 자막만 넘겨 JSON 만 받는다. effort 를 안 주면 sonnet 도 40KB 프롬프트에
    5분 넘게 생각한다(2026-09-05 실측) — 기본은 medium."""
    exe = which("claude")
    if not exe:
        raise RuntimeError("claude CLI 를 찾지 못했습니다(PATH). Claude Code 가 설치돼 있어야 합니다.")
    cmd = [exe, "-p", "--output-format", "text", "--disallowedTools", "*",
           "--effort", effort or "medium"]
    if model:
        cmd += ["--model", model]
    env = dict(os.environ)
    env.pop("CLAUDECODE", None)  # Claude Code 세션 안에서 띄워도 중첩으로 막히지 않게
    r = subprocess.run(cmd, input=prompt.encode("utf-8"), capture_output=True,
                       timeout=timeout, cwd=str(BASE), env=env)
    out = r.stdout.decode("utf-8", "replace")
    if r.returncode != 0 and not out.strip():
        raise RuntimeError("claude 실행 실패: %s" % r.stderr.decode("utf-8", "replace")[-500:])
    return out


def run_claude_vision(prompt, cwd, effort="medium", timeout=900):
    """이미지 검수용: Read 도구만 허용해 cwd 아래 그림 파일을 열어 보게 한다(다른 도구는 전부 차단).
    Claude Code 구독으로 돌아 API 키가 필요 없다. 6장 검수에 약 1분(2026-09-12 실측)."""
    exe = which("claude")
    if not exe:
        raise RuntimeError("claude CLI 를 찾지 못했습니다(PATH). 이미지 검수는 Claude Code 가 있어야 합니다.")
    cmd = [exe, "-p", "--output-format", "text", "--allowedTools", "Read",
           "--disallowedTools", "Bash,Edit,Write,MultiEdit,NotebookEdit,WebFetch,WebSearch,Agent,Task,Glob,Grep,LS",
           "--effort", effort]
    env = dict(os.environ)
    env.pop("CLAUDECODE", None)
    r = subprocess.run(cmd, input=prompt.encode("utf-8"), capture_output=True, timeout=timeout, cwd=str(cwd), env=env)
    out = r.stdout.decode("utf-8", "replace")
    if r.returncode != 0 and not out.strip():
        raise RuntimeError("claude 실행 실패: %s" % r.stderr.decode("utf-8", "replace")[-500:])
    return out


CONFIG_PATH = BASE / "config.json"
PROVIDERS = {
    "anthropic": {"label": "Claude (Anthropic API 키)", "default_model": "claude-sonnet-5", "needs_key": True},
    "claude": {"label": "Claude Code (구독 · CLI 가 설치돼 있을 때)", "default_model": "", "needs_key": False},
    "openai": {"label": "OpenAI (API 키)", "default_model": "gpt-4.1-mini", "needs_key": True},
    "gemini": {"label": "Google Gemini (API 키)", "default_model": "gemini-2.5-flash", "needs_key": True},
    "xai": {"label": "xAI Grok (API 키)", "default_model": "grok-4-3", "needs_key": True},
    "ollama": {"label": "Ollama (이 PC, 무료)", "default_model": "qwen2.5:14b", "needs_key": False},
}


def load_config():
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")


def _http_json(url, payload, headers=None, timeout=600):
    import urllib.request
    import urllib.error
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json", **(headers or {})}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:600]
        raise RuntimeError("API 오류 %s: %s" % (e.code, body))


def run_llm(prompt, provider="claude", model=None, effort=None):
    """공급자에 상관없이 프롬프트 → 응답 문자열. JSON 만 달라는 요청은 프롬프트에 이미 들어 있다."""
    cfg = load_config()
    provider = provider or "claude"
    model = model or PROVIDERS.get(provider, {}).get("default_model") or None
    if provider == "claude" and not which("claude") and cfg.get("anthropic_key"):
        provider, model = "anthropic", cfg.get("model_anthropic") or PROVIDERS["anthropic"]["default_model"]   # CLI 없으면 API 키로
    if provider == "claude":
        return run_claude(prompt, model=model, effort=effort)
    if provider == "anthropic":
        key = cfg.get("anthropic_key")
        if not key:
            raise RuntimeError("Anthropic API 키가 없습니다. 홈 화면 「AI 설정」에서 넣어 주세요.")
        out = _http_json("https://api.anthropic.com/v1/messages",
                         {"model": model or PROVIDERS["anthropic"]["default_model"], "max_tokens": 8192,
                          "messages": [{"role": "user", "content": prompt}]},
                         {"x-api-key": key, "anthropic-version": "2023-06-01"})
        return "".join(b.get("text", "") for b in out.get("content", []) if b.get("type") == "text")
    if provider == "openai":
        key = cfg.get("openai_key")
        if not key:
            raise RuntimeError("OpenAI API 키가 없습니다. 홈 화면 「AI 설정」에서 넣어 주세요.")
        out = _http_json("https://api.openai.com/v1/chat/completions",
                         {"model": model, "messages": [{"role": "user", "content": prompt}],
                          "response_format": {"type": "json_object"}},
                         {"Authorization": "Bearer " + key})
        return out["choices"][0]["message"]["content"]
    if provider == "xai":
        # xAI 는 OpenAI 호환이라 경로·본문이 같다. 다른 것은 주소와 키뿐.
        # SuperGrok·X Premium+ 구독으로는 못 쓴다 — console.x.ai 에서 따로 발급한 키가 필요하다.
        key = cfg.get("xai_key")
        if not key:
            raise RuntimeError("xAI API 키가 없습니다. 홈 화면 「AI 설정」에서 넣어 주세요.")
        out = _http_json("https://api.x.ai/v1/chat/completions",
                         {"model": model or PROVIDERS["xai"]["default_model"],
                          "messages": [{"role": "user", "content": prompt}],
                          "response_format": {"type": "json_object"}},
                         {"Authorization": "Bearer " + key})
        return out["choices"][0]["message"]["content"]
    if provider == "gemini":
        key = cfg.get("gemini_key")
        if not key:
            raise RuntimeError("Gemini API 키가 없습니다. 홈 화면 「AI 설정」에서 넣어 주세요.")
        out = _http_json("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, key),
                         {"contents": [{"parts": [{"text": prompt}]}],
                          "generationConfig": {"responseMimeType": "application/json"}})
        return out["candidates"][0]["content"]["parts"][0]["text"]
    if provider == "ollama":
        base = (cfg.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/")
        try:
            out = _http_json(base + "/api/generate", {"model": model, "prompt": prompt, "stream": False, "format": "json",
                                                    "options": {"num_ctx": 32768}}, timeout=1800)
        except Exception as e:
            raise RuntimeError("Ollama 에 연결하지 못했습니다(%s). Ollama 가 켜져 있고 모델(%s)이 받아져 있는지 확인하세요. %s"
                               % (base, model, e))
        return out.get("response", "")
    raise RuntimeError("모르는 AI 공급자: %s" % provider)


def extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S)
    i = text.find("{")
    j = text.rfind("}")
    if i < 0 or j < 0:
        raise RuntimeError("AI 응답에서 JSON 을 찾지 못했습니다: %s" % text[:300])
    body = text[i:j + 1]
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        pass
    # 흔한 깨짐: 한국어 입력기의 전각 구두점(，：)이 구분자로 섞임, 마지막 항목 뒤 쉼표
    fixed = (body.replace('"，"', '","').replace('}，{', '},{').replace('"，', '",').replace('，"', ',"')
             .replace('"：', '":').replace('："', ':"'))
    fixed = re.sub(r",\s*([}\]])", r"\1", fixed)
    try:
        return json.loads(fixed)
    except json.JSONDecodeError as e:
        raise JSONBroken("AI 응답 JSON 이 깨져 있습니다(%s)" % e, body)


class JSONBroken(RuntimeError):
    def __init__(self, msg, body):
        super().__init__(msg)
        self.body = body


def repair_json_with_llm(body, provider, model):
    """깨진 JSON 을 같은 모델에게 문법만 고쳐 달라고 한 번 더 부탁한다. 내용은 바꾸지 않게 한다."""
    prompt = ("아래 텍스트는 JSON 이어야 하는데 문법이 깨져 있습니다. 내용(값)은 하나도 바꾸지 말고 "
              "문법만 고쳐서 JSON 만 출력하세요. 코드펜스·설명 금지. 문자열 안의 큰따옴표는 \\\" 로 이스케이프하고, "
              "구분자는 반드시 반각 쉼표와 콜론을 씁니다.\n\n" + body)
    return run_llm(prompt, provider=provider, model=model, effort="low")


def fix_description(desc, url):
    """'전체 영상 ▶ URL' 줄을 설명 맨 위로 올린다. 쇼츠 설명은 첫 줄만 접히지 않고 보이므로
    롱폼 링크가 거기 있어야 한다. AI 가 지시를 어겨도 여기서 바로잡는다."""
    lines = [ln.rstrip() for ln in (desc or "").strip().splitlines()]
    link = None
    rest = []
    for ln in lines:
        if link is None and ("전체 영상" in ln or (url and url in ln)):
            link = ln.strip()
        else:
            rest.append(ln)
    if not link:
        link = "전체 영상 ▶ %s" % url if url else ""
    while rest and not rest[0]:
        rest.pop(0)
    body = "\n".join(rest).strip()
    return (link + ("\n\n" + body if body else "")).strip()


def mark_sentences(cues):
    """큐마다 문장 시작(ss)·문장 끝(se) 표시. 대본 정렬 큐는 문장 부호로, 자동 자막은 어미로 판정."""
    for c in cues:
        txt = (c.get("text") or "").strip()
        last = txt.split()[-1] if txt else ""
        c["se"] = bool(txt) and (bool(re.search(r"[.?!。]$", txt)) or bool(SENT_END.search(last)))
    for i, c in enumerate(cues):
        c["ss"] = i == 0 or bool(cues[i - 1].get("se"))
    return cues


def snap(cues, t, kind, window=6.0):
    """start 는 가까운 **문장 시작** 큐의 시작으로, end 는 가까운 **문장 끝** 큐의 끝으로.
    window 안에 문장 경계가 없을 때만 아무 큐 경계로 물러선다."""
    if kind == "start":
        cands = [c for c in cues if c.get("ss") and abs(c["s"] - t) <= window] or cues
        return min(cands, key=lambda c: abs(c["s"] - t))["s"]
    cands = [c for c in cues if c.get("se") and abs(c["e"] - t) <= window] or cues
    return min(cands, key=lambda c: abs(c["e"] - t))["e"]


# ── 무음 기준 경계 보정 ──────────────────────────────────────────────────────
# 자막 시각은 단어의 '시작'만 안다. 문장이 실제로 끝나는 순간과 다음 문장이 시작되는 순간은
# 오디오의 무음 구간에 있다. 낭독 영상은 문장 사이에 0.25초 이상 쉬므로 그 경계가 정확하다.

def detect_silences(path, noise="-35dB", min_d=0.25):
    r = subprocess.run(["ffmpeg", "-nostats", "-i", str(path), "-vn",
                        "-af", "silencedetect=noise=%s:d=%s" % (noise, min_d), "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    return [[round(s, 3), round(e, 3)] for s, e in zip(starts, ends)]


def ensure_silences(p):
    if p.get("silences") is None:
        p["silences"] = detect_silences(p["source"]["path"])
        save(p)
    return p["silences"]


def refine_start(sil, t, before=1.2, after=0.4, lead=0.06):
    """t 근처에서 끝나는 무음을 찾아 그 끝(=말이 시작되는 순간) 직전으로."""
    best = None
    for s, e in sil:
        if t - before <= e <= t + after and (best is None or abs(e - t) < abs(best - t)):
            best = e
    return round(max(0.0, best - lead), 3) if best is not None else round(t, 3)


def refine_end(sil, t, before=0.8, after=1.5, tail=0.15):
    """t 근처에서 시작하는 무음을 찾아 그 시작(=말이 끝난 순간) 직후로."""
    best = None
    for s, e in sil:
        if t - before <= s <= t + after and (best is None or abs(s - t) < abs(best - t)):
            best = s
    return round(best + tail, 3) if best is not None else round(t, 3)


def snap_bounds(p, start, end):
    """문장 경계로 옮긴 뒤 무음으로 다듬는다. 반환 (start, end, 메모)."""
    cues = mark_sentences(p["cues"])
    sil = ensure_silences(p)
    a = refine_start(sil, snap(cues, start, "start"))
    b = refine_end(sil, snap(cues, end, "end"))
    if b - a < 3:
        b = a + 3
    return a, b


def cues_in(cues, s, e):
    out = []
    for c in cues:
        if c["e"] <= s or c["s"] >= e:
            continue
        out.append({"id": c["id"], "s": max(c["s"], s), "e": min(c["e"], e), "text": c["text"]})
    return out


def _score(v):
    """AI 가 준 바이럴 점수 → 0~100 정수. 없거나 못 읽으면 None(결과 목록은 그때 길이를 대신 보여 준다)."""
    try:
        n = int(round(float(str(v).strip().rstrip("%"))))
    except Exception:
        return None
    return max(0, min(100, n))


def analyze(p):
    st = p["settings"]
    if p.get("cues_source") in ("script", "ocr") and p.get("cues"):
        cues = p["cues"]           # 대본으로 교정한 자막은 다시 분석해도 유지한다
    else:
        cues = load_cues(p)
        p["cues"] = cues
    mark_sentences(cues)
    sil = ensure_silences(p)
    rs, re_ = st["range"]
    inside = [c for c in cues if rs <= c["s"] < re_]
    if len(inside) < 10:
        raise RuntimeError("선택한 구간에 자막이 거의 없습니다(%d줄)." % len(inside))
    transcript = "\n".join("[%s] %s" % (fmt_mmss(c["s"]), c["text"]) for c in inside)
    n = int(st.get("count", 4))
    prompt = PROMPT.format(title=p["source"].get("title", ""), channel=p["source"].get("channel", ""),
                           rs=fmt_mmss(rs), re=fmt_mmss(re_), url=p["source"].get("url", ""),
                           n=n, min_len=st.get("min_len", 30), max_len=st.get("max_len", 58),
                           transcript=transcript)
    provider = st.get("provider") or "claude"
    set_progress(p, "analyze", "AI(%s)가 쇼츠 구간을 고르는 중… (자막 %d줄, 보통 1~3분)"
                 % (PROVIDERS.get(provider, {}).get("label", provider).split(" (")[0], len(inside)), None)
    (pdir(p["id"]) / "prompt.txt").write_text(prompt, encoding="utf-8")
    raw = run_llm(prompt, provider=provider, model=st.get("model") or None, effort=st.get("effort") or None)
    (pdir(p["id"]) / "ai_raw.txt").write_text(raw, encoding="utf-8")
    try:
        data = extract_json(raw)
    except JSONBroken as e:
        set_progress(p, "analyze", "AI 응답의 JSON 문법이 깨져 한 번 더 고쳐 받는 중…", None)
        raw2 = repair_json_with_llm(e.body, provider, st.get("model") or None)
        (pdir(p["id"]) / "ai_raw_repaired.txt").write_text(raw2, encoding="utf-8")
        data = extract_json(raw2)
    shorts = []
    for k, s in enumerate(data.get("shorts", [])[:n]):
        try:
            a = refine_start(sil, snap(cues, tc(s["start"]), "start"))
            b = refine_end(sil, snap(cues, tc(s["end"]), "end"))
        except Exception:
            continue
        if b - a < 8:
            continue
        # 쇼츠 하나 = 연속 구간 하나. (조각 편집·훅 앞으로 빼기는 2026-09-06 사용자 요청으로 UI 에서 뺐다.
        # 자료 구조(clips)는 남겨 두어 옛 프로젝트와 렌더 경로는 그대로 돈다.)
        clips = [{"s": round(a, 3), "e": round(b, 3)}]
        shorts.append({
            "id": "S%02d" % (k + 1), "start": round(a, 3), "end": round(b, 3),
            "clips": clips, "orig_clips": [dict(c) for c in clips],
            "orig_start": round(a, 3), "orig_end": round(b, 3),      # 「원래 구간으로」가 되돌아갈 값
            "line1": (s.get("line1") or "").strip(), "line2": (s.get("line2") or "").strip(),
            "reason": s.get("reason", ""),
            "score": _score(s.get("score")),
            "yt_title": s.get("yt_title", ""),
            "description": fix_description(s.get("description", ""), p["source"].get("url", "")),
            "tags": s.get("tags", []),
            "cue_edits": {}, "comment": {"name": "", "text": "", "likes": "128"},
            "output": None, "render": None,
        })
    if not shorts:
        raise RuntimeError("AI 가 쓸 만한 구간을 돌려주지 않았습니다. ai_raw.txt 를 확인하세요.")
    p["shorts"] = shorts
    save(p)


# ── 4. render ────────────────────────────────────────────────────────────────

def fit_font(draw, text, size, maxw, minsize, fid=None):
    """fid 는 TEXT_FONTS 의 id(제목 글꼴). 없거나 모르는 id 면 기본 글꼴(본고딕 Bold)."""
    while size > minsize:
        f = text_font(fid, size)
        l, t, r, b = draw.textbbox((0, 0), text, font=f)
        if r - l <= maxw:
            return f
        size -= 2
    return text_font(fid, minsize)


def draw_center(draw, text, y, fnt, fill, stroke=None, stroke_w=0, width=None):
    l, t, r, b = draw.textbbox((0, 0), text, font=fnt)
    x = ((width or W) - (r - l)) // 2 - l
    draw.text((x, y - t), text, font=fnt, fill=fill,
              stroke_width=stroke_w, stroke_fill=stroke)


def overlay_png(p, short, L, path, parts="all"):
    """제목 두 줄·채널명·(댓글 카드)를 1080x1920 투명 PNG 한 장에 그린다.
    parts: "all" 한 장 / "title" 제목(+위 그라데이션)만 / "rest" 제목 빼고 나머지 — 제목을 앞 N초만 보일 때 두 장으로 나눈다(2026-09-12)."""
    CW, CH = L["W"], L["H"]
    st = p["settings"]
    accent = st.get("accent", "#FF3B3B")
    img = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    if L["mode"] == "full" and parts != "rest":
        # 영상이 화면 전체라 제목 뒤에 어두운 그라데이션을 깐다
        grad = Image.new("RGBA", (CW, 620), (0, 0, 0, 0))
        gd = ImageDraw.Draw(grad)
        for y in range(620):
            a = int(200 * (1 - y / 620) ** 1.3)
            gd.line([(0, y), (CW, y)], fill=(0, 0, 0, a))
        img.alpha_composite(grad, (0, 0))
    if L["mode"] == "full" and parts != "title":
        grad2 = Image.new("RGBA", (CW, 520), (0, 0, 0, 0))
        gd2 = ImageDraw.Draw(grad2)
        for y in range(520):
            a = int(200 * (y / 520) ** 1.3)
            gd2.line([(0, y), (CW, y)], fill=(0, 0, 0, a))
        img.alpha_composite(grad2, (0, CH - 520))

    title_color = st.get("title_color") or "#FFFFFF"
    for key, y, color in (("line1", L["title1_y"], title_color), ("line2", L["title2_y"], accent)):
        text = (short.get(key) or "").strip()
        if not text or st.get("show_title") is False or parts == "rest":          # 훅 제목 숨김
            continue
        f = fit_font(d, text, L["title_size"], L["title_maxw"], L["title_min"], fid=st.get("title_font"))
        draw_center(d,  text, y, f, hexrgb(color),
                    stroke=(0, 0, 0, 200) if L["mode"] == "full" else None,
                    stroke_w=3 if L["mode"] == "full" else 0)

    if L.get("comment_y") is not None and st.get("template") == "comment" and parts != "title":
        c = short.get("comment") or {}
        name = c.get("name") or "시청자"
        text = c.get("text") or ""
        likes = str(c.get("likes") or "")
        cw, cx0, cy0 = 900, (CW - 900) // 2, L["comment_y"]
        f_name = font(30)
        f_text = font(36, bold=False)
        lines = wrap_text(d, text, f_text, cw - 150)[:3]
        ch = 110 + 48 * len(lines)
        d.rounded_rectangle([cx0, cy0, cx0 + cw, cy0 + ch], radius=28, fill=(22, 24, 30, 235),
                            outline=(60, 64, 74, 255), width=2)
        d.ellipse([cx0 + 32, cy0 + 30, cx0 + 92, cy0 + 90], fill=hexrgb(accent))
        draw_center_at(d, name[:1], cx0 + 62, cy0 + 60, font(30), (255, 255, 255, 255))
        d.text((cx0 + 112, cy0 + 28), "@" + name, font=f_name, fill=(210, 214, 222, 255))
        d.text((cx0 + 112 + d.textlength("@" + name, font=f_name) + 16, cy0 + 32), "방금 전",
               font=font(26, bold=False), fill=(140, 144, 154, 255))
        yy = cy0 + 82
        for ln in lines:
            d.text((cx0 + 112, yy), ln, font=f_text, fill=(245, 245, 247, 255))
            yy += 48
        d.text((cx0 + 112, yy + 6), "♡ " + likes + "    답글", font=font(26, bold=False),
               fill=(150, 154, 164, 255))

    name = (st.get("channel_name") or "").strip()
    if parts == "title":
        name = ""

    if st.get("show_chan") is False:

        name = ""                                   # 채널 숨김: 이름을 비우면 아래 블록이 그리지 않는다
    if name:
        f = font(L["chan_size"])
        tw = d.textlength(name, font=f)
        av = 56
        show_av = st.get("show_logo", True) is not False     # 로고 표시를 끄면 원 자체를 안 그린다
        total = (av + 18 if show_av else 0) + tw
        x0 = int((CW - total) // 2) + int(st.get("chan_dx") or 0)   # 사용자가 미리보기에서 끌어 옮긴 만큼
        y0 = L["chan_y"] + int(st.get("chan_dy") or 0)
        logo = st.get("channel_logo")
        if show_av:
            if logo and Path(logo).exists():
                lg = Image.open(logo).convert("RGBA").resize((av, av), Image.LANCZOS)
                mask = Image.new("L", (av, av), 0)
                ImageDraw.Draw(mask).ellipse([0, 0, av - 1, av - 1], fill=255)
                img.paste(lg, (x0, y0), mask)
            else:
                d.ellipse([x0, y0, x0 + av, y0 + av], fill=hexrgb(accent))
                draw_center_at(d, name[:1], x0 + av // 2, y0 + av // 2, font(28), (255, 255, 255, 255))
        l, t, r, b = d.textbbox((0, 0), name, font=f)
        d.text((x0 + (av + 18 if show_av else 0), y0 + (av - (b - t)) // 2 - t), name, font=f,
               fill=hexrgb(st.get("title_color") or "#FFFFFF"),
               stroke_width=2 if L["mode"] == "full" else 0, stroke_fill=(0, 0, 0, 180))
    img.save(path)


IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")


def _tk_pick_file(kind="image"):
    """윈도 파일 선택 창을 별도 프로세스로 띄운다(서버 스레드에서 tk 를 직접 만들면 죽는다).
    반환: 고른 경로 또는 ''"""
    code = (
        "import tkinter as tk\nfrom tkinter import filedialog\n"
        "r=tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
        "ft={'image':[('이미지','*.png *.jpg *.jpeg *.webp *.bmp *.gif'),('모든 파일','*.*')],"
        "'text':[('대본','*.md *.txt'),('모든 파일','*.*')],"
        "'audio':[('음악','*.mp3 *.wav *.m4a *.aac *.flac *.ogg'),('모든 파일','*.*')]}.get(%r, [('영상','*.mp4 *.mkv *.mov *.webm'),('모든 파일','*.*')])\n"
        "p=filedialog.askopenfilename(title='파일 선택', filetypes=ft)\n"
        "import sys; sys.stdout.buffer.write(p.encode('utf-8'))\n" % kind)
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, timeout=600)
    out = r.stdout.decode("utf-8", "replace").strip()
    log("pick_file(%s) rc=%s -> %r %s" % (kind, r.returncode, out[-60:], r.stderr.decode("utf-8", "replace")[-300:].strip()))
    return out


# ── 훅 낭독 TTS (Edge 무료 음성, 실패 시 윈도 내장 음성) ──────────────────────
# edge-TTS 의 **한국어 전용** 음성은 아래 셋뿐이다(2026-09-06 list_voices 확인).
# 다른 나라 음성 아홉 개도 한국어 문장을 읽기는 하고 낭독이 15~25% 빠르지만, 억양에 외국어
# 티가 남는다. 2026-09-09 사용자 판단으로 목록에서 뺐다 — 고를 수 있으면 결국 골라 보게 되고,
# 그때마다 발음을 다시 검사하는 비용이 속도 이득보다 컸다. 되살리려면 아래 KO_ONLY 를 끈다.
# label 뒤 성격 표현은 마이크로소프트가 음성에 붙여 둔 태그(VoicePersonalities)를 옮긴 것이다.
TTS_VOICES = [
    {"id": "ko-KR-InJoonNeural", "label": "인준 (남, 차분)", "group": "한국어 (무료)"},
    {"id": "ko-KR-HyunsuMultilingualNeural", "label": "현수 (남, 밝음)", "group": "한국어 (무료)"},
    {"id": "ko-KR-SunHiNeural", "label": "선히 (여)", "group": "한국어 (무료)"},
    # 수퍼토닉(Supertone, 한국) — 내 PC 에서 도는 무료 엔진. 인터넷·GPU 없이 CPU 로 9초 음성을 2초에 만든다(2026-09-14 실측 RTF 0.22).
    # ElevenLabs 를 못 쓰는 구매자용 기본 엔진(사용자 지시). 코드 MIT · 모델 OpenRAIL-M(상업 허용). 모델 385MB 는 처음 쓸 때 한 번 내려받는다.
    {"id": "st:F1", "label": "수퍼토닉 여1", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:F2", "label": "수퍼토닉 여2", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:F3", "label": "수퍼토닉 여3", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:F4", "label": "수퍼토닉 여4", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:F5", "label": "수퍼토닉 여5", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:M1", "label": "수퍼토닉 남1", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:M2", "label": "수퍼토닉 남2", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:M3", "label": "수퍼토닉 남3", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:M4", "label": "수퍼토닉 남4", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "st:M5", "label": "수퍼토닉 남5", "group": "수퍼토닉 (무료 · 오프라인)"},
    {"id": "windows", "label": "윈도 내장 음성 (오프라인)", "group": "기타"},
]

# ── 수퍼토닉 (로컬 ONNX · 선택 아님, 기본 제공) ───────────────────────────────
SUPERTONIC_PREFIX = "st:"
SUPERTONIC_MODEL_DIR = Path.home() / ".cache" / "supertonic3"
_ST = {"tts": None, "lock": threading.Lock()}


def supertonic_ready():
    """모델이 내려받아져 있는지(처음 한 번 385MB)."""
    return (SUPERTONIC_MODEL_DIR / "onnx" / "tts.json").exists()


def supertonic_tts():
    """엔진 싱글턴. 첫 호출에서 모델을 읽는다(약 10초, 처음이면 내려받기까지 1~3분)."""
    with _ST["lock"]:
        if _ST["tts"] is None:
            import supertonic
            log("수퍼토닉 준비 중" + ("" if supertonic_ready() else " — 모델 385MB 를 처음 내려받습니다"))
            _ST["tts"] = supertonic.TTS()
        return _ST["tts"]


def supertonic_synth(text, style_name, out_path, rate=0):
    """text 를 수퍼토닉 목소리(F1~F5·M1~M5)로 wav 에. 배속은 엔진의 speed 로 건다(기본 1.05 = 보통)."""
    import numpy as np
    tts = supertonic_tts()
    if style_name not in tts.voice_style_names:
        raise RuntimeError("수퍼토닉에 없는 목소리: %s" % style_name)
    pct = int(rate or 0)
    speed = max(0.7, min(2.0, 1.05 * (1.0 + pct / 100.0)))
    with _ST["lock"]:                                   # onnxruntime 세션을 여러 스레드가 동시에 돌리지 않게
        wav, _ = tts.synthesize(text, tts.get_voice_style(style_name), speed=speed, lang="ko")
    wav = np.asarray(wav, dtype=np.float32).squeeze()
    out = Path(out_path).with_suffix(".wav")
    import soundfile as sf
    sf.write(str(out), wav, int(tts.sample_rate))
    return out

# 뺀 다국어 음성들 — KO_ONLY 를 False 로 두면 목록에 다시 붙는다.
TTS_VOICES_MULTILINGUAL = [
    {"id": "en-US-AndrewMultilingualNeural", "label": "앤드류 (남, 따뜻·듬직)", "group": "다국어 (억양 확인 필요)"},
    {"id": "en-US-BrianMultilingualNeural", "label": "브라이언 (남, 편안·수더분)", "group": "다국어 (억양 확인 필요)"},
    {"id": "en-AU-WilliamMultilingualNeural", "label": "윌리엄 (남, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "it-IT-GiuseppeMultilingualNeural", "label": "주세페 (남, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "en-US-AvaMultilingualNeural", "label": "에이바 (여, 표현 풍부)", "group": "다국어 (억양 확인 필요)"},
    {"id": "en-US-EmmaMultilingualNeural", "label": "엠마 (여, 밝고 또렷)", "group": "다국어 (억양 확인 필요)"},
    {"id": "fr-FR-VivienneMultilingualNeural", "label": "비비안 (여, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "de-DE-SeraphinaMultilingualNeural", "label": "세라피나 (여, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "pt-BR-ThalitaMultilingualNeural", "label": "탈리타 (여, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "de-DE-FlorianMultilingualNeural", "label": "플로리안 (남, 친근)", "group": "다국어 (억양 확인 필요)"},
    {"id": "fr-FR-RemyMultilingualNeural", "label": "레미 (남, 친근)", "group": "다국어 (억양 확인 필요)"},
]

# ── ElevenLabs (유료 API · 선택) ────────────────────────────────────────────
# 목소리 id 는 `11:<voice_id>` 로 적어 위의 edge 음성과 한 목록에 섞는다. 접두가
# 곧 엔진 표시다. 목소리 표를 하드코딩하지 않고 계정에서 받아 오는 이유 — 기본
# 목소리 구성이 계정·플랜마다 다르고, 사용자가 복제해 둔 목소리도 그대로 골라
# 쓸 수 있어야 한다. 키가 없으면 목록이 비고, 화면에서 이 묶음 자체가 사라진다.
ELEVEN_PREFIX = "11:"
ELEVEN_API = "https://api.elevenlabs.io/v1"
ELEVEN_CRED = Path.home() / ".credentials" / "elevenlabs" / "config.json"
# 한국어를 읽는 모델 셋. v3 는 표현력이 가장 좋지만 앞뒤 문장을 같이 보내는 것을
# 지원하지 않아(2026-09-09 실측: 400 unsupported_model) 조각 경계에서 말투가 튈 수 있다.
# 그래서 v3 는 조각을 더 크게 잘라 경계 자체를 줄인다(ELEVEN_CHUNK 참고).
# 크레딧 소모는 2026-09-09 Creator 플랜에서 실측했다(같은 글자 수를 세 모델로 합성해
# character_count 변화를 잼). 문서에 적힌 1.0 / 0.5 는 정가이고, 실제로 찍힌 값은 그보다
# 낮다 — 그래서 정가가 아니라 실측값을 적는다. 정산이 30~60초 늦게 반영되니 다시 잴 때는
# 두 번 연속 같은 값이 나올 때까지 기다릴 것.
ELEVEN_MODELS = [
    {"id": "eleven_multilingual_v2", "label": "Multilingual v2 (기본 · 약 0.55크레딧/자)"},
    {"id": "eleven_v3", "label": "v3 (표현력 최고 · v2와 같은 값 · 조각 경계 주의)"},
    {"id": "eleven_flash_v2_5", "label": "Flash v2.5 (값 절반 · 약 0.27크레딧/자)"},
]
ELEVEN_V3 = "eleven_v3"
# 한 번에 보낼 글자 수. v3 는 앞뒤 문맥을 못 받으니 크게, 나머지는 기존대로.
ELEVEN_CHUNK = {ELEVEN_V3: 2500}
ELEVEN_GROUP = "ElevenLabs (유료 · 크레딧 차감)"
_eleven_cache = {"at": 0.0, "voices": []}


def eleven_key():
    """config.json 이 먼저, 없으면 ~/.credentials/elevenlabs, 그다음 환경변수."""
    k = (load_config().get("elevenlabs_key") or "").strip()
    if not k and ELEVEN_CRED.exists():
        try:
            k = (json.loads(ELEVEN_CRED.read_text(encoding="utf-8")).get("api_key") or "").strip()
        except (OSError, ValueError):
            k = ""
    return k or (os.environ.get("ELEVENLABS_API_KEY") or "").strip()


def eleven_model():
    return (load_config().get("elevenlabs_model") or "").strip() or ELEVEN_MODELS[0]["id"]


def _eleven_get(path, key, timeout=20):
    import urllib.request
    req = urllib.request.Request(ELEVEN_API + path, headers={"xi-api-key": key})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def ko_only():
    """한국어 음성만 보여 줄지. config 에 없으면 끔(기본값) — 2026-09-14 사용자: 판매용은 목소리가 많아야 한다,
    ElevenLabs 는 선택이라 기본 목소리로 주로 만든다. 다국어 음성 11개가 기본 목록에 붙는다(억양은 미리 듣기로 고르게)."""
    v = load_config().get("voices_korean_only")
    return False if v is None else bool(v)


def _is_korean_voice(v):
    """ElevenLabs 목소리가 한국어인지. 계정에 기본으로 딸려 오는 21개는 영어권 음성이고
    labels 에 language 가 아예 없다 — 이름이나 하드코딩 목록이 아니라 이 필드로 가른다."""
    lab = (v.get("labels") or {})
    return (lab.get("language") or "").lower() == "ko" or \
           (lab.get("locale") or "").lower().startswith("ko")


def eleven_voices(force=False):
    """계정의 목소리 목록. 키가 없거나 실패하면 빈 목록 — 조용히 빠진다.
    기본은 한국어 목소리만(ko_only). 계정 기본 음성 21개는 영어권이라 한국어를 읽히면
    억양이 남는다 — 골라 놓고 발음을 다시 검사하느니 목록에서 안 보이는 편이 낫다."""
    key = eleven_key()
    if not key:
        _eleven_cache.update(at=0.0, voices=[])
        return []
    kr = ko_only()
    if not force and _eleven_cache["voices"] and _eleven_cache.get("ko") == kr \
            and time.time() - _eleven_cache["at"] < 600:
        return _eleven_cache["voices"]
    try:
        data = _eleven_get("/voices", key)
    except Exception as e:                        # 네트워크·키 문제 — 화면은 edge 음성만 보여 준다
        log("ElevenLabs 목소리 목록 실패:", e)
        return []
    out = []
    for v in (data.get("voices") or []):
        vid = (v.get("voice_id") or "").strip()
        if not vid:
            continue
        if kr and not _is_korean_voice(v):
            continue
        lab = (v.get("labels") or {})
        name = (v.get("name") or vid).strip()
        # 이름에 이미 성별·성격을 적어 둔 목소리(직접 붙인 한글 이름)에는 꼬리표를 안 붙인다.
        # 붙이면 이름이 길어져 드롭다운이 넓어지고, 그것만으로 옆 칸들이 눌린다.
        tail = "" if ("남" in name or "여" in name) else \
            " · ".join(x for x in ((lab.get("description") or "").strip(),
                                   (lab.get("gender") or "").strip()) if x)
        out.append({"id": ELEVEN_PREFIX + vid,
                    "label": name + ((" (%s)" % tail) if tail else ""),
                    "group": ELEVEN_GROUP})
    out.sort(key=lambda x: x["label"])
    _eleven_cache.update(at=time.time(), voices=out, ko=kr)
    return out


def eleven_status():
    """키 여부와 남은 글자 수. 키 값 자체는 절대 돌려주지 않는다."""
    key = eleven_key()
    st = {"ready": bool(key), "model": eleven_model(), "models": ELEVEN_MODELS,
          "from_credentials": ELEVEN_CRED.exists(), "left": None, "limit": None, "tier": ""}
    if not key:
        return st
    try:
        r = _eleven_get("/user/subscription", key)
        used, lim = int(r.get("character_count") or 0), int(r.get("character_limit") or 0)
        st.update(left=max(0, lim - used), limit=lim, tier=(r.get("tier") or ""))
    except Exception as e:
        st["error"] = str(e)
    return st


def eleven_synth(text, voice_id, out_path, prev="", nxt=""):
    """한 문장을 mp3 로. 실패하면 예외 — 다른 음성으로 몰래 바꾸지 않는다.
    신마다 목소리가 달라진 영상을 만드는 것보다 멈추는 편이 낫다."""
    import urllib.error
    import urllib.parse
    import urllib.request
    key = eleven_key()
    if not key:
        raise RuntimeError("ElevenLabs API 키가 없습니다. 「🔑 ElevenLabs」에서 키를 넣어 주세요.")
    url = "%s/text-to-speech/%s?output_format=mp3_44100_128" % (ELEVEN_API, urllib.parse.quote(voice_id))
    model = eleven_model()
    payload = {"text": text, "model_id": model}
    if model != ELEVEN_V3:
        # 앞뒤 문장을 같이 보내면 조각 경계에서 말투가 튀는 것이 줄어든다.
        # 이 두 값은 읽지 않으므로 크레딧에 잡히지 않는다.
        # v3 는 이 필드를 받으면 400 unsupported_model 로 거절한다(2026-09-09 실측).
        payload["previous_text"] = prev or ""
        payload["next_text"] = nxt or ""
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg"})
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            audio = r.read()
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        if e.code == 401:
            raise RuntimeError("ElevenLabs 키가 거부됐습니다(401). 키를 다시 확인하세요. %s" % detail)
        if e.code == 429:
            raise RuntimeError("ElevenLabs 크레딧이 떨어졌거나 호출이 몰렸습니다(429). %s" % detail)
        raise RuntimeError("ElevenLabs 오류 %s: %s" % (e.code, detail))
    if len(audio) < 1000:
        raise RuntimeError("ElevenLabs 가 빈 음성을 돌려줬습니다")
    out_path = Path(out_path).with_suffix(".mp3")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(audio)
    return out_path


def _split_for_tts(text, limit):
    """문장 경계로 자른다. 한 문장이 limit 을 넘으면 쉼표에서, 그래도 넘으면 그냥 자른다."""
    out, cur = [], ""
    for sent in re.split(r"(?<=[.!?。…])\s+|(?<=[다요])\.\s+", text):
        sent = sent.strip()
        if not sent:
            continue
        while len(sent) > limit:                       # 한 문장이 통째로 너무 길 때
            cut = sent.rfind(",", 0, limit)
            cut = cut + 1 if cut > limit // 2 else limit
            if cur:
                out.append(cur.strip())
                cur = ""
            out.append(sent[:cut].strip())
            sent = sent[cut:].strip()
        if len(cur) + len(sent) + 1 > limit:
            out.append(cur.strip())
            cur = sent
        else:
            cur = (cur + " " + sent).strip()
    if cur.strip():
        out.append(cur.strip())
    return out or [text]


def tts_long(text, voice="ko-KR-InJoonNeural", rate=0, out_path=None, on_progress=None):
    """대본 한 편을 낭독 파일 하나로. 조각으로 나눠 만들고 이어 붙인다.

    조각으로 나누는 이유 — ElevenLabs 는 한 번에 보낼 글자 수에 상한이 있고, edge 도 긴
    글에서 자주 끊긴다. 배속은 조각마다 걸지 않고 **이어 붙인 뒤 한 번만** 건다(조각마다
    걸면 경계에서 길이 오차가 쌓인다). 반환 (경로, 길이 초)."""
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        raise RuntimeError("낭독할 대본이 비어 있습니다")
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    is11 = (voice or "").startswith(ELEVEN_PREFIX)
    limit = ELEVEN_CHUNK.get(eleven_model(), 1200) if is11 else 2000
    chunks = _split_for_tts(text, limit)
    work = out_path.parent / (out_path.stem + "_parts")
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    parts = []
    try:
        for i, c in enumerate(chunks):
            if on_progress:
                on_progress(i, len(chunks))
            pth = work / ("p%03d.mp3" % i)
            if is11:
                eleven_synth(c, voice[len(ELEVEN_PREFIX):], pth,
                             prev=(chunks[i - 1] if i else ""),
                             nxt=(chunks[i + 1] if i + 1 < len(chunks) else ""))
            else:
                got, _ = tts_synth(c, voice, 0, pth)
                pth = Path(got)                       # 윈도 음성으로 넘어가면 .wav 가 된다
            parts.append(pth)
        if len(parts) == 1:
            merged = parts[0]
        else:
            lst = work / "concat.txt"
            lst.write_text("".join("file '%s'\n" % str(x).replace("\\", "/") for x in parts),
                           encoding="utf-8")
            merged = work / ("merged" + parts[0].suffix)
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                            "-i", str(lst), "-c", "copy", str(merged)], check=True)
        pct = int(rate or 0)
        af = "aresample=44100"
        if pct:
            af = "atempo=%.4f,%s" % (max(0.5, min(2.0, 1.0 + pct / 100.0)), af)
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(merged), "-af", af,
                        "-c:a", "libmp3lame", "-b:a", "192k", "-ac", "1", str(out_path)], check=True)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    if on_progress:
        on_progress(len(chunks), len(chunks))
    return out_path, audio_duration(out_path)


def tts_voices():
    """화면 드롭다운이 쓰는 전체 목록. edge 표 + 계정에서 받아 온 ElevenLabs.
    config 의 voices_korean_only 를 False 로 두면 다국어 음성도 같이 나온다."""
    out = list(TTS_VOICES)
    if not ko_only():
        out += TTS_VOICES_MULTILINGUAL
    return out + eleven_voices()


TTS_CACHE = DATA / "cache" / "tts"        # 프로젝트 없이 듣는 미리 듣기 음성


def tts_preview(text, voice="ko-KR-InJoonNeural", rate=0):
    """프로젝트에 매이지 않는 미리 듣기. 같은 (문구·음성·배속)이면 다시 만들지 않는다."""
    import hashlib
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        raise RuntimeError("낭독할 문구가 비어 있습니다")
    TTS_CACHE.mkdir(parents=True, exist_ok=True)
    key = hashlib.md5(("%s|%s|%d" % (text, voice, int(rate or 0))).encode("utf-8")).hexdigest()[:12]
    for old in TTS_CACHE.glob("v_%s.*" % key):
        return old, audio_duration(old)
    return tts_synth(text, voice, int(rate or 0), TTS_CACHE / ("v_%s.mp3" % key))


def tts_synth(text, voice="ko-KR-InJoonNeural", rate=0, out_path=None):
    """text 를 음성 파일로. 반환 (경로, 길이 초). Edge 음성은 인터넷이 필요하고 비공식 경로라
    막힐 수 있어, 실패하면 윈도 내장 음성(SAPI)으로 wav 를 만든다."""
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        raise RuntimeError("낭독할 문구가 비어 있습니다")
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if (voice or "").startswith(ELEVEN_PREFIX):
        # ElevenLabs 는 배속 옵션이 없다. rate 는 만든 뒤 atempo 로 건다.
        p = eleven_synth(text, voice[len(ELEVEN_PREFIX):], out_path)
        pct = int(rate or 0)
        if pct:
            s = max(0.5, min(2.0, 1.0 + pct / 100.0))
            tmp = p.with_name(p.stem + "_r.mp3")
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(p),
                            "-af", "atempo=%.4f" % s, str(tmp)], check=True)
            tmp.replace(p)
        return p, audio_duration(p)
    if (voice or "").startswith(SUPERTONIC_PREFIX):
        p = supertonic_synth(text, voice[len(SUPERTONIC_PREFIX):], out_path, rate)
        return p, audio_duration(p)
    err = None
    if voice != "windows":
        try:
            import asyncio
            import edge_tts
            pct = int(rate or 0)
            rate_s = ("+%d%%" % pct) if pct >= 0 else ("%d%%" % pct)

            async def run():
                await edge_tts.Communicate(text, voice, rate=rate_s).save(str(out_path))
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(run())
            finally:
                loop.close()
            if out_path.exists() and out_path.stat().st_size > 1000:
                return out_path, audio_duration(out_path)
        except Exception as e:
            err = e
            log("Edge TTS 실패, 윈도 음성으로:", e)
    wav = out_path.with_suffix(".wav")
    ps = ("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
          "$s.Rate=%d; $s.SetOutputToWaveFile('%s'); $s.Speak([Console]::In.ReadToEnd()); $s.Dispose()"
          % (max(-10, min(10, int((rate or 0) / 10))), str(wav).replace("'", "''")))
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], input=text.encode("utf-8"),
                       capture_output=True, timeout=120)
    if r.returncode != 0 or not wav.exists():
        raise RuntimeError("TTS 를 만들지 못했습니다: %s / %s" % (err, r.stderr.decode("utf-8", "replace")[-200:]))
    return wav, audio_duration(wav)


def audio_duration(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True).stdout.strip()
    try:
        return float(out)
    except ValueError:
        return 0.0


def hook_text_for(short):
    return (short.get("hook_text") or "").strip() or " ".join(
        x for x in ((short.get("line1") or "").strip(), (short.get("line2") or "").strip()) if x)


def _tk_pick_files(kind="video"):
    """여러 파일 선택. 반환: 경로 목록."""
    code = (
        "import tkinter as tk\nfrom tkinter import filedialog\n"
        "r=tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
        "ft={'video':[('영상','*.mp4 *.mkv *.mov *.webm *.avi'),('모든 파일','*.*')],"
        "'media':[('영상·이미지','*.mp4 *.mkv *.mov *.webm *.avi *.jpg *.jpeg *.png *.webp *.bmp *.gif'),('영상','*.mp4 *.mkv *.mov *.webm *.avi'),('이미지','*.jpg *.jpeg *.png *.webp *.bmp *.gif'),('모든 파일','*.*')],"
        "'audio':[('음성','*.mp3 *.wav *.m4a *.aac *.flac *.ogg'),('모든 파일','*.*')],"
        "'font':[('글꼴','*.ttf *.otf'),('모든 파일','*.*')]}.get(%r, [('모든 파일','*.*')])\n"
        "p=filedialog.askopenfilenames(title='파일 선택 (여러 개 가능)', filetypes=ft)\n"
        "import sys; sys.stdout.buffer.write('\\n'.join(p).encode('utf-8'))\n" % kind)
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, timeout=600)
    paths = [x for x in r.stdout.decode("utf-8", "replace").split("\n") if x.strip()]
    log("pick_files(%s) rc=%s -> %d개 %s" % (kind, r.returncode, len(paths), r.stderr.decode("utf-8", "replace")[-300:].strip()))
    return paths


# ── 낭독 mp3 → 자막 (faster-whisper, GPU 우선) ────────────────────────────────
_WHISPER = {}


def cuda_dlls():
    """.venv 의 nvidia/*/bin(cuBLAS·cuDNN)을 DLL 검색 경로에 넣는다. 한 번만."""
    if _WHISPER.get("dll"):
        return
    _WHISPER["dll"] = True
    site = Path(sys.executable).parent.parent / "Lib" / "site-packages" / "nvidia"
    for d in site.glob("*/bin"):
        try:
            os.add_dll_directory(str(d))
        except Exception:
            pass
        os.environ["PATH"] = str(d) + os.pathsep + os.environ.get("PATH", "")


def whisper_model():
    """모델은 한 번만 올린다. cuda(medium, float16) → cuda(int8) → cpu(small) 순으로 시도."""
    if "m" in _WHISPER:
        return _WHISPER["m"], _WHISPER["desc"]
    cuda_dlls()
    from faster_whisper import WhisperModel
    last = None
    for dev, ct, size in (("cuda", "float16", "medium"), ("cuda", "int8_float16", "medium"), ("cpu", "int8", "small")):
        try:
            m = WhisperModel(size, device=dev, compute_type=ct)
            _WHISPER.update(m=m, desc="%s/%s/%s" % (size, dev, ct))
            return m, _WHISPER["desc"]
        except Exception as e:
            last = e
            log("whisper %s %s 실패: %s" % (size, dev, str(e)[:120]))
    raise RuntimeError("음성 인식 모델을 올리지 못했습니다: %s" % last)


def sub_max_chars(st):
    """자막 큐 한 개의 글자 수 상한. 한 줄 모드(sub_one_line)면 12자 — 1.5배 글자(약 80px)로 폭 880 안에 든다(2026-09-12 사용자: 자막이 작고 두 줄로 갈린다)."""
    st = st or {}
    v = st.get("sub_max_chars")
    if v:
        return max(6, int(v))
    return 14 if st.get("sub_one_line") else 22      # 12 는 「풀라스 핸디 스팀다리미는」(12자) 같은 제품명이 갈라진다 → 14


def transcribe_audio(path, language="ko", max_chars=22):
    """낭독 파일을 단어 시각으로 받아써 자막 큐(결과 영상 시간 기준)로 묶는다."""
    m, desc = whisper_model()
    segs, info = m.transcribe(str(path), language=language, word_timestamps=True, vad_filter=True,
                              vad_parameters={"min_silence_duration_ms": 300})
    words = []
    for sg in segs:
        for w in (sg.words or []):
            txt = (w.word or "").strip()
            if txt:
                words.append((float(w.start), txt))
        if not sg.words and sg.text.strip():
            words.append((float(sg.start), sg.text.strip()))
    if len(words) < 2:
        raise RuntimeError("낭독 파일에서 말을 거의 인식하지 못했습니다(%s)" % desc)
    cues = build_cues(words, max_chars=max_chars, max_gap=0.8)
    return cues, desc


def _tk_pick_folder(initial=""):
    code = (
        "import tkinter as tk\nfrom tkinter import filedialog\n"
        "r=tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
        "p=filedialog.askdirectory(title='내보낼 폴더 선택', initialdir=%r or None, mustexist=False)\n"
        "import sys; sys.stdout.buffer.write((p or '').encode('utf-8'))\n" % initial)
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, timeout=600)
    return r.stdout.decode("utf-8", "replace").strip().replace("/", "\\")


def default_export_dir(p):
    """로컬 원본이면 그 옆의 '쇼츠' 폴더(P 드라이브 회차 폴더 관례), 아니면 프로젝트 output."""
    src = p["source"]
    orig = src.get("original_path") or (src.get("path") if src.get("type") == "file" else None)
    if orig:
        return str(Path(orig).parent / "쇼츠")
    return str(pdir(p["id"]) / "output")


def draw_center_at(d, text, cx, cy, fnt, fill):
    l, t, r, b = d.textbbox((0, 0), text, font=fnt)
    d.text((cx - (r - l) / 2 - l, cy - (b - t) / 2 - t), text, font=fnt, fill=fill)


def wrap_text(d, text, fnt, maxw):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if d.textlength(trial, font=fnt) <= maxw:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
            while d.textlength(cur, font=fnt) > maxw and len(cur) > 1:
                k = len(cur)
                while k > 1 and d.textlength(cur[:k], font=fnt) > maxw:
                    k -= 1
                lines.append(cur[:k])
                cur = cur[k:]
    if cur:
        lines.append(cur)
    return lines


def spd_of(v):
    """조각 속도 배율. 1 = 그대로, 0.5 = 절반 속도(두 배 길이). 0.1~8 밖이면 1."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return 1.0
    return v if 0.1 <= v <= 8.0 else 1.0


def hold_of(v):
    try:
        return max(0.0, float(v or 0))
    except (TypeError, ValueError):
        return 0.0


def clip_out(c):
    """조각의 결과 길이(초) = 원본 구간 / 속도 + 마지막 장면 멈춤."""
    return (float(c["e"]) - float(c["s"])) / spd_of(c.get("speed")) + hold_of(c.get("hold"))


def atempo_chain(spd):
    """atempo 는 한 단에 0.5~100 배만 받는다 → 0.5 보다 느리면 여러 단으로 나눈다. 1 이면 빈 문자열."""
    if abs(spd - 1.0) < 1e-6:
        return ""
    parts = []
    while spd < 0.5:
        parts.append("atempo=0.5")
        spd /= 0.5
    parts.append("atempo=%.4f" % spd)
    return "," + ",".join(parts)


def clips_of(short):
    """쇼츠의 조각 목록. 옛 프로젝트(start/end 만 있는 것)는 조각 하나로 본다."""
    clips = short.get("clips")
    if not clips:
        clips = [{"s": float(short["start"]), "e": float(short["end"])}]
    # 키를 **명시해서 다시 만들기** 때문에 여기 없는 필드는 렌더까지 못 간다.
    # 조각에 새 속성을 더할 때는 이 목록에도 반드시 넣을 것(2026-09-10 에 flip 이 여기서 사라졌다).
    return [{"s": float(c["s"]), "e": float(c["e"]), "src": c.get("src") or "main", "mute": bool(c.get("mute")),
             "tr_in": c.get("tr_in") if isinstance(c.get("tr_in"), dict) else None,
             "speed": spd_of(c.get("speed")), "hold": hold_of(c.get("hold")),
             "flip": bool(c.get("flip"))}
            for c in clips if float(c["e"]) > float(c["s"])]


def source_by_id(p, sid):
    """'main' 또는 삽입 영상 id → 소스 정보(path/width/height/duration/has_audio)."""
    if not sid or sid == "main":
        return p["source"]
    for x in p.get("extra_sources") or []:
        if x["id"] == sid:
            return x
    raise RuntimeError("삽입 영상을 찾을 수 없습니다: %s" % sid)


def needs_faststart(path):
    """mp4 인데 moov 가 mdat 뒤에 있으면 브라우저가 첫 화면을 못 그린다. 그 외 컨테이너도 True."""
    import struct
    path = Path(path)
    if path.suffix.lower() not in (".mp4", ".m4v", ".mov"):
        return True
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            pos, seen = 0, []
            while pos < size and len(seen) < 8:
                f.seek(pos)
                hdr = f.read(8)
                if len(hdr) < 8:
                    break
                n, typ = struct.unpack(">I4s", hdr)
                if n == 1:
                    n = struct.unpack(">Q", f.read(8))[0]
                if n <= 0:
                    break
                seen.append(typ)
                pos += n
        return b"mdat" in seen and (b"moov" not in seen or seen.index(b"mdat") < seen.index(b"moov"))
    except Exception:
        return True


def has_audio(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=codec_type",
                          "-of", "csv=p=0", str(path)], capture_output=True, text=True).stdout
    return "audio" in out


IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}
IMAGE_SECONDS = 10


# ── Google Flow 이미지 생성 연동(2026-09-12). autoworker-script 의 flow_generate.py(로컬 크롬 CDP + Playwright)를 부른다.
#    API 가 없는 서비스라 브라우저를 조종하는 방식이고, 전용 크롬 프로필에 구글 로그인이 한 번 돼 있어야 한다.
FLOW_SCRIPT = Path(r"C:\dev\autoworker-script\scripts\flow_generate.py")
FLOW_PY = Path(r"C:\dev\autoworker-script\.venv\Scripts\python.exe")
FLOW_OUT = DATA / "cache" / "flow"


def flow_paths():
    cfg = load_config()
    return Path(cfg.get("flow_python") or FLOW_PY), Path(cfg.get("flow_script") or FLOW_SCRIPT)


def flow_available():
    py, sc = flow_paths()
    if not sc.exists():
        return False, "미연결 — flow_generate.py 없음 (%s)" % sc
    if not py.exists():
        return False, "미연결 — 파이썬 없음 (%s)" % py
    return True, "autoworker-script 연동 · 로그인은 실행 때 확인"


def flow_generate(items, refs=(), ratio="9:16", on_progress=None, out=None, model=None):
    """프롬프트 [{name, prompt}] (+참조 이미지) → {"items": [{name, prompt, file}], "sheet": 콘택트시트}.
    장당 25~40초. 진행은 자식의 로그 줄 '[i/n]' 을 읽어 on_progress(i, n, line) 로 올린다."""
    ok, why = flow_available()
    if not ok:
        raise RuntimeError("Flow " + why)
    py, sc = flow_paths()
    out = Path(out) if out else FLOW_OUT / time.strftime("%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    pf = out / "prompts.json"
    pf.write_text(json.dumps(list(items), ensure_ascii=False, indent=1), encoding="utf-8")
    cmd = [str(py), "-u", str(sc), "--prompts", str(pf), "--out", str(out), "--ratio", ratio, "--seq"] + (["--model", model] if model else [])   # -u: 파이프면 자식 stdout 이 버퍼링돼 진행률이 끝나서야 한꺼번에 왔다(2026-09-12 실측)
    for r in refs:
        cmd += ["--ref", str(r)]
    proc = subprocess.Popen(cmd, cwd=str(sc.parent.parent), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace")
    lines = []
    n = max(1, len(items))
    for line in proc.stdout:
        line = line.rstrip()
        if not line:
            continue
        lines.append(line)
        m = re.search(r"\[(\d+)/(\d+)\]", line)
        if on_progress:
            if m:
                on_progress(int(m.group(1)), int(m.group(2)), line)
            elif "참조 올림" in line or "생성 설정" in line or "로그인 확인" in line:
                on_progress(0, n, line)
    proc.wait()
    res = out / "result.json"
    if not res.exists():
        tail = " / ".join(x.split("] ", 1)[-1] for x in lines[-4:])
        if "로그인돼 있지" in tail or "로그인이 안" in tail:                      # '로그인 확인됨' 뒤에 다른 이유로 죽은 것을 로그인 문제로 오판하지 않게(2026-09-13)
            raise RuntimeError("Flow 에 로그인돼 있지 않습니다. 「Flow 로그인 창 열기」로 한 번 로그인한 뒤 다시 하세요.")
        raise RuntimeError("Flow 이미지 생성 실패: " + tail[-500:])
    r = json.loads(res.read_text(encoding="utf-8"))
    r["out"] = str(out)
    return r


def flow_login():
    """로그인용 크롬 창을 띄운다(전용 프로필). 사용자가 그 창에서 구글 로그인을 한 번 하면 다음부터 무인으로 돈다."""
    ok, why = flow_available()
    if not ok:
        raise RuntimeError("Flow " + why)
    py, sc = flow_paths()
    subprocess.Popen([str(py), str(sc), "--login"], cwd=str(sc.parent.parent))


# ── 그록 Imagine 이미지→영상 연동(2026-09-12). API 대신 구독 계정의 웹 화면을 조종한다(autoworker-script/scripts/grok_video.py, Flow 와 같은 크롬).
GROK_SCRIPT = Path(r"C:\\dev\\autoworker-script\\scripts\\grok_video.py")
GROK_OUT = DATA / "cache" / "grok"


def grok_available():
    py, _ = flow_paths()
    sc = Path(load_config().get("grok_script") or GROK_SCRIPT)
    if not sc.exists():
        return False, "미연결 — grok_video.py 없음 (%s)" % sc
    if not py.exists():
        return False, "미연결 — 파이썬 없음 (%s)" % py
    return True, "autoworker-script 연동 · 로그인은 실행 때 확인"


def grok_videos(items, res="480p", length=6, ratio="9:16", on_progress=None, out=None):
    """[{name, image, prompt}] → {"items": [{name, image, prompt, file|null, error}]}. 클립당 1~3분."""
    ok, why = grok_available()
    if not ok:
        raise RuntimeError("그록 " + why)
    py, _ = flow_paths()
    sc = Path(load_config().get("grok_script") or GROK_SCRIPT)
    out = Path(out) if out else GROK_OUT / time.strftime("%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    pf = out / "items.json"
    pf.write_text(json.dumps(list(items), ensure_ascii=False, indent=1), encoding="utf-8")
    cmd = [str(py), "-u", str(sc), "--items", str(pf), "--out", str(out), "--res", res, "--len", str(int(length)), "--ratio", ratio]
    proc = subprocess.Popen(cmd, cwd=str(sc.parent.parent), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace")
    lines = []
    n = max(1, len(items))
    for line in proc.stdout:
        line = line.rstrip()
        if not line:
            continue
        lines.append(line)
        m = re.search(r"\[(\d+)/(\d+)\]", line)
        if on_progress:
            if m:
                on_progress(int(m.group(1)), int(m.group(2)), line)
            elif "로그인 확인" in line:
                on_progress(0, n, line)
    proc.wait()
    resf = out / "result.json"
    if not resf.exists():
        tail = " / ".join(x.split("] ", 1)[-1] for x in lines[-4:])
        if "로그인" in tail:
            raise RuntimeError("grok.com 에 로그인돼 있지 않습니다. Flow 크롬 창의 grok.com 탭에서 한 번 로그인한 뒤 다시 하세요.")
        raise RuntimeError("그록 영상 생성 실패: " + tail[-500:])
    r = json.loads(resf.read_text(encoding="utf-8"))
    r["out"] = str(out)
    return r


FLOW_VIDEO_SCRIPT = Path(r"C:\dev\autoworker-script\scripts\flow_video.py")


def flow_videos(items, on_progress=None, out=None):
    """Flow(Veo 3.1 Fast) 이미지→영상. 그록과 같은 입출력: [{name, image, prompt}] → {"items": [{name, file|null}], "out"}.
    그록 주간 한도의 대안(2026-09-13). 720x1280·8초. Flow 한도에 걸리면 QUOTA 줄이 찍히고 남은 신은 file=null."""
    py, _ = flow_paths()
    sc = Path(load_config().get("flow_video_script") or FLOW_VIDEO_SCRIPT)
    if not sc.exists():
        raise RuntimeError("Flow 영상 스크립트가 없습니다: %s" % sc)
    out = Path(out) if out else GROK_OUT / ("flow-" + time.strftime("%Y%m%d-%H%M%S"))
    out.mkdir(parents=True, exist_ok=True)
    pf = out / "items.json"
    pf.write_text(json.dumps([{"name": it["name"], "image": it["image"], "prompt": it["prompt"]} for it in items], ensure_ascii=False, indent=1), encoding="utf-8")
    cmd = [str(py), "-u", str(sc), "--items", str(pf), "--out", str(out)]
    proc = subprocess.Popen(cmd, cwd=str(sc.parent.parent), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    lines = []
    n = max(1, len(items))
    for line in proc.stdout:
        line = line.rstrip()
        if not line:
            continue
        lines.append(line)
        m = re.search(r"\[(\d+)/(\d+)\]", line)
        if on_progress:
            if m:
                on_progress(int(m.group(1)), int(m.group(2)), "Flow " + line)
            elif "로그인 확인" in line or "생성 설정" in line or "QUOTA" in line:
                on_progress(0, n, "Flow " + line)
    proc.wait()
    resf = out / "result.json"
    if not resf.exists():
        tail = " / ".join(x.split("] ", 1)[-1] for x in lines[-4:])
        raise RuntimeError("Flow 영상 생성 실패: " + tail[-500:])
    r = json.loads(resf.read_text(encoding="utf-8"))
    r["out"] = str(out)
    return r


def path_thumb(path):
    """아무 로컬 영상·이미지의 작은 썸네일(jpg) 경로. 홈 업로드 목록용(2026-09-12). 영상은 1초 지점 한 프레임을
    cache/thumbs/ 에 두고 재사용한다(키 = 경로+크기+수정시각). 이미지는 원본을 그대로 돌려준다(브라우저가 줄인다)."""
    import hashlib
    path = Path(path)
    if not path.exists():
        return None
    st = path.stat()
    if path.suffix.lower() in IMAGE_EXT and st.st_size < 300_000:
        return path                                   # 작은 이미지는 원본 그대로(브라우저가 줄인다)
    if path.suffix.lower() in IMAGE_EXT:
        # Flow 결과 같은 1~2MB PNG 를 목록마다 통째로 보내지 않게 320px jpg 로 줄여 캐시한다
        import hashlib
        key = hashlib.md5(("%s|%d|%d" % (str(path).lower(), st.st_size, int(st.st_mtime))).encode("utf-8")).hexdigest()
        d = DATA / "cache" / "thumbs"
        d.mkdir(parents=True, exist_ok=True)
        out = d / (key + ".jpg")
        if not out.exists():
            try:
                im = Image.open(path).convert("RGB")
                im.thumbnail((320, 320))
                im.save(out, "JPEG", quality=82)
            except Exception:
                return path
        return out
    key = hashlib.md5(("%s|%d|%d" % (str(path).lower(), st.st_size, int(st.st_mtime))).encode("utf-8")).hexdigest()
    d = DATA / "cache" / "thumbs"
    d.mkdir(parents=True, exist_ok=True)
    out = d / (key + ".jpg")
    if out.exists():
        return out
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", str(path), "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", str(out)],
                   capture_output=True, timeout=60)
    if not out.exists():      # 1초보다 짧은 영상
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", str(out)],
                       capture_output=True, timeout=60)
    return out if out.exists() else None


def image_to_clip(path, out, seconds=None):
    """이미지 한 장을 정지 영상(mp4, 소리 없음)으로. 첫 파일이 이미지일 때(가로 롱폼 업로드, 2026-09-12)와 삽입 소스가 같이 쓴다."""
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-framerate", "30", "-i", str(path), "-t", str(seconds or IMAGE_SECONDS),
                        "-vf", "scale='min(1920,iw)':-2:flags=lanczos,scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p",
                        "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-movflags", "+faststart", str(out)],
                       capture_output=True, text=True)
    if r.returncode != 0 or not Path(out).exists():
        raise RuntimeError("이미지를 프로젝트에 담지 못했습니다: %s" % r.stderr[-300:])


BLACK_PATH = BASE / "assets" / "black_1080p.mp4"     # 10분짜리 검정 화면(무음). 주 트랙이 비게 될 때 바탕으로 깐다


def black_source(p):
    """프로젝트에 '빈 화면(검정)' 소스를 (없으면 만들어) 돌려준다."""
    for x in p.get("extra_sources") or []:
        if x.get("kind") == "black":
            return x
    if not BLACK_PATH.exists():
        BLACK_PATH.parent.mkdir(exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=1920x1080:r=30:d=600", "-c:v", "libx264",
                        "-preset", "veryfast", "-crf", "35", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(BLACK_PATH)], check=True)
    # add_source 를 거치지 않는다: 600초짜리 검정 영상의 필름스트립(프레임 300장 추출)이 몇 초씩 걸려
    # 끌기 직후 반응이 없어 보였고, 그 사이 다시 끌면 조각이 두 번 옮겨졌다(2026-09-06). 메타는 손으로 만든다.
    import uuid
    d = pdir(p["id"])
    sid = "x" + uuid.uuid4().hex[:6]
    local = d / ("src_%s.mp4" % sid)
    shutil.copy2(BLACK_PATH, local)
    strip_path = d / ("strip_%s.jpg" % sid)
    Image.new("RGB", (160, 90), (0, 0, 0)).save(strip_path, quality=60)
    thumb = d / ("thumb_%s.jpg" % sid)
    Image.new("RGB", (320, 180), (0, 0, 0)).save(thumb, quality=60)
    src = {"id": sid, "path": str(local), "original_path": str(BLACK_PATH), "title": "빈 화면 (검정)", "kind": "black",
           "width": 1920, "height": 1080, "duration": 600.0, "has_audio": False,
           "filmstrip": {"file": strip_path.name, "interval": 600.0, "count": 1, "cols": 1, "rows": 1, "fw": 160, "fh": 90},
           "thumb": thumb.name}
    p.setdefault("extra_sources", []).append(src)
    save(p)
    return src


def add_source(p, path):
    """삽입용 영상을 프로젝트에 등록한다. 브라우저가 열 수 있게 프로젝트 폴더에 색인 앞당긴 mp4 사본을 두고,
    타임라인용 필름스트립과 썸네일을 만든다."""
    import uuid
    path = Path(path)
    if not path.exists():
        raise RuntimeError("파일이 없습니다: %s" % path)
    d = pdir(p["id"])
    sid = "x" + uuid.uuid4().hex[:6]
    local = d / ("src_%s.mp4" % sid)
    is_img = path.suffix.lower() in IMAGE_EXT
    if is_img:
        # 이미지는 10초짜리 정지 영상으로 담는다(트랙에서 양끝을 끌어 줄이거나 반복해 쓴다). 소리 없음
        image_to_clip(path, local)
    else:
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-c", "copy", "-movflags", "+faststart", str(local)],
                           capture_output=True, text=True)
    if not is_img and (r.returncode != 0 or not local.exists()):
        # 코덱이 mp4 에 못 들어가는 컨테이너(webm 등)는 H.264 로 바꿔 담는다
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-c:v", "libx264", "-preset", "veryfast",
                            "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                            str(local)], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("영상을 프로젝트에 담지 못했습니다: %s" % r.stderr[-300:])
    w, h, dur = ffprobe_video(local)
    strip = make_filmstrip(local, d / ("strip_%s.jpg" % sid), dur)
    thumb = d / ("thumb_%s.jpg" % sid)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", str(local), "-frames:v", "1", "-vf", "scale=320:-2",
                    "-q:v", "5", str(thumb)], check=False)
    src = {"id": sid, "path": str(local), "original_path": str(path), "title": path.stem, "kind": "image" if is_img else "video",
           "width": w, "height": h, "duration": dur, "has_audio": False if is_img else has_audio(local),
           "filmstrip": strip, "thumb": thumb.name if thumb.exists() else None}
    p.setdefault("extra_sources", []).append(src)
    save(p)
    return src


MUSIC_DIR = BASE / "music"


def music_presets():
    """동봉한 무료 음악 목록(music/index.json). Kevin MacLeod CC BY 4.0 — 설명에 출처 한 줄이 조건."""
    try:
        data = json.loads((MUSIC_DIR / "index.json").read_text(encoding="utf-8"))
        return [it for it in data.get("items", []) if (MUSIC_DIR / it["file"]).exists()]
    except Exception:
        return []


def set_bgm(p, path=None, preset=None):
    """배경음악 등록. preset 이면 동봉 음악(복사 없이 music/ 경로), path 면 프로젝트 폴더에 복사."""
    d = pdir(p["id"])
    for old in d.glob("bgm.*"):
        old.unlink()
    bgm = p["settings"].setdefault("bgm", {})
    vol = bgm.get("volume", 0.15)
    if preset:
        it = next((x for x in music_presets() if x["id"] == preset), None)
        if not it:
            raise RuntimeError("동봉 음악을 찾을 수 없습니다: %s" % preset)
        src = MUSIC_DIR / it["file"]
        bgm.clear()
        bgm.update(path=str(src), file=None, preset=it["id"], title=it["title"], artist=it.get("artist", ""),
                   credit=it.get("credit", ""), url="/music/" + it["file"], enabled=True, volume=vol,
                   duration=it.get("duration") or audio_duration(src))
    else:
        path = Path(path)
        if not path.exists():
            raise RuntimeError("파일이 없습니다: %s" % path)
        dst = d / ("bgm" + path.suffix.lower())
        shutil.copy2(path, dst)
        bgm.clear()
        bgm.update(path=str(dst), file=dst.name, preset=None, title=path.stem, artist="", credit="",
                   url="/media/%s/%s" % (p["id"], dst.name), enabled=True, volume=vol, duration=audio_duration(dst))
    save(p)
    return bgm


def bgm_credit_line(p, short):
    """이 쇼츠에 동봉 음악이 실제로 들어가면 설명에 붙일 출처 한 줄, 아니면 ''."""
    bgm = (p.get("settings") or {}).get("bgm") or {}
    if bgm.get("enabled") and bgm.get("credit") and not short.get("bgm_off"):
        return bgm["credit"]
    return ""


def stock_credit_lines(p, short):
    """이 쇼츠의 조각·위층이 무료 소재(Pexels·Pixabay)를 쓰면 설명에 붙일 출처 줄들(표기 의무는 없지만 붙여 준다 — 2026-09-14)."""
    used = set(c.get("src") for c in (short.get("clips") or [])) | set(o.get("src") for o in (short.get("overlays") or []))
    lines = []
    for x in p.get("extra_sources") or []:
        st = x.get("stock") or {}
        if x.get("id") in used and st.get("src"):
            who = (st.get("author") or "").strip(); site = "Pexels" if st.get("src") == "pexels" else "Pixabay"
            ln = "%s: %s%s" % ("영상" if x.get("kind") != "image" else "사진", (who + " · ") if who else "", site) + ((" " + st["page_url"]) if st.get("page_url") else "")
            if ln not in lines:
                lines.append(ln)
    return "\n".join(lines)


def remove_source(p, sid):
    for s in p.get("shorts", []):
        if any((c.get("src") or "main") == sid for c in (s.get("clips") or [])):
            raise RuntimeError("이 영상을 쓰는 조각이 있어 지울 수 없습니다(%s). 조각을 먼저 지우세요." % s["id"])
    keep = [x for x in p.get("extra_sources") or [] if x["id"] != sid]
    gone = [x for x in p.get("extra_sources") or [] if x["id"] == sid]
    p["extra_sources"] = keep
    save(p)
    for x in gone:
        for f in (x.get("path"), str(pdir(p["id"]) / (x.get("filmstrip") or {}).get("file", "")),
                  str(pdir(p["id"]) / (x.get("thumb") or ""))):
            try:
                if f and Path(f).is_file() and Path(f).parent == pdir(p["id"]):
                    Path(f).unlink()
            except Exception:
                pass


# 씬 전환 카탈로그(2026-09-14 확장, 캡컷 유료 전환을 참고한 이름). 전부 ffmpeg xfade 내장이라 빠르다.
# 커스텀 표현식(gl-transitions 이식본)은 1080p 에서 조각당 1~4분이 걸려 뺐다(fx/gl-transitions.json 에 MIT 원본만 보관).
TRANSITION_GROUPS = [
    ("기본", [("fade", "디졸브"), ("dissolve", "입자 디졸브"), ("fadefast", "빠른 디졸브"), ("fadeslow", "느린 디졸브"),
              ("fadeblack", "블랙 플래시"), ("fadewhite", "화이트 플래시"), ("fadegrays", "흑백 거쳐")]),
    ("줌·밀착", [("zoomin", "줌 인"), ("distance", "줌 거리"), ("squeezeh", "가로 눌림"), ("squeezev", "세로 눌림"),
               ("smoothleft", "스무스 왼쪽"), ("smoothright", "스무스 오른쪽"), ("smoothup", "스무스 위"), ("smoothdown", "스무스 아래")]),
    ("밀기", [("slideleft", "밀기 왼쪽"), ("slideright", "밀기 오른쪽"), ("slideup", "밀기 위"), ("slidedown", "밀기 아래"),
             ("coverleft", "덮기 왼쪽"), ("coverright", "덮기 오른쪽"), ("coverup", "덮기 위"), ("coverdown", "덮기 아래"),
             ("revealleft", "드러내기 왼쪽"), ("revealright", "드러내기 오른쪽"), ("revealup", "드러내기 위"), ("revealdown", "드러내기 아래")]),
    ("닦기", [("wipeleft", "와이프 왼쪽"), ("wiperight", "와이프 오른쪽"), ("wipeup", "와이프 위"), ("wipedown", "와이프 아래"),
             ("wipetl", "와이프 ↖"), ("wipetr", "와이프 ↗"), ("wipebl", "와이프 ↙"), ("wipebr", "와이프 ↘"),
             ("diagtl", "대각 ↖"), ("diagtr", "대각 ↗"), ("diagbl", "대각 ↙"), ("diagbr", "대각 ↘"), ("radial", "회전 닦기")]),
    ("모양", [("circleopen", "원 열림"), ("circleclose", "원 닫힘"), ("circlecrop", "원 크롭"), ("rectcrop", "사각 크롭"),
             ("vertopen", "세로 열림"), ("vertclose", "세로 닫힘"), ("horzopen", "가로 열림"), ("horzclose", "가로 닫힘")]),
    ("조각·질감", [("hlslice", "슬라이스 →"), ("hrslice", "슬라이스 ←"), ("vuslice", "슬라이스 ↑"), ("vdslice", "슬라이스 ↓"),
                ("hlwind", "바람 →"), ("hrwind", "바람 ←"), ("vuwind", "바람 ↑"), ("vdwind", "바람 ↓"),
                ("pixelize", "픽셀"), ("hblur", "블러")]),
]
TRANSITIONS = {"none": "없음"}
for _g, _items in TRANSITION_GROUPS:
    TRANSITIONS.update(dict(_items))
TRANSITIONS["random"] = "무작위(씬마다 다르게)"
RANDOM_POOL_DEFAULT = ["fade", "fadeblack", "fadewhite", "zoomin", "distance", "slideleft", "slideright", "wipeleft", "circleopen", "pixelize", "hblur", "smoothleft"]

# 위층 조각(영상 2~5) 들어오기·나가기 효과 — 필터 조각으로 건다(2026-09-14)
OVERLAY_FX = [("none", "없음"), ("fade", "페이드"), ("black", "검정에서"), ("white", "흰색에서"), ("zoom", "줌"),
              ("slideleft", "왼쪽에서"), ("slideright", "오른쪽에서"), ("slideup", "아래에서"), ("slidedown", "위에서")]
OVERLAY_FX_NAMES = dict(OVERLAY_FX)


def random_transition(p, clips, i, tr):
    """「무작위」 전환: 경계마다 다른 전환을 고르되, 같은 프로젝트·같은 경계면 렌더할 때마다 같은 결과(시드 고정)."""
    import hashlib
    pool = [t for t in (tr.get("pool") or RANDOM_POOL_DEFAULT) if t in TRANSITIONS and t not in ("none", "random")] or RANDOM_POOL_DEFAULT
    key = "%s|%s|%d" % (p.get("id"), clips[i].get("src") or "main", i)
    h = int(hashlib.md5(key.encode("utf-8")).hexdigest()[:8], 16)
    return pool[h % len(pool)]


def transition_at(p, clips, i):
    """조각 i 앞(조각 i-1 과 i 사이)의 전환 (type, dur). 조각에 tr_in 이 있으면 그것, 없으면 프로젝트 전체 설정. type 이 random 이면 경계별로 고른다."""
    tr = clips[i].get("tr_in") or (p.get("settings") or {}).get("transition") or {}
    ttype = tr.get("type") or "none"
    for k in (i - 1, i):                              # 빈 구간(검정 소스) 앞뒤엔 전환을 걸지 않는다(화면 표시와 같게)
        if (source_by_id(p, clips[k].get("src")) or {}).get("kind") == "black":
            return "none", 0.0
    if ttype == "random":
        ttype = random_transition(p, clips, i, tr)
    if ttype == "none" or ttype not in TRANSITIONS:
        return "none", 0.0
    d = float(tr.get("dur") or 0.5)
    a = clip_out(clips[i - 1]); b = clip_out(clips[i])
    return ttype, max(0.0, min(d, a / 2 - 0.05, b / 2 - 0.05))   # 양쪽 조각의 절반(결과 길이 기준)을 넘지 못한다


def xfade_of(p, clips):
    """조각 사이 전환 길이 목록(초, 길이 n-1). 전환이 없으면 0. 조각이 하나면 []."""
    return [transition_at(p, clips, i)[1] for i in range(1, len(clips))]


def overlay_fx_chain(o, o_len, bw, bh, bx, by):
    """위층 조각 들어오기(fx_in)·나가기(fx_out) 효과 → (필터 조각, 포맷 조각, overlay x 식, overlay y 식).
    페이드는 알파(뒤가 비침), 검정/흰색은 그 색에서, 줌은 크롭으로 1.25배→1배, 밀기는 overlay 위치 식(결과 시각 t 기준).
    필터는 조각 로컬 시각(setpts=PTS-STARTPTS 뒤, 결과 시각으로 옮기기 전)에 걸린다."""
    def fx(k):
        f = o.get(k) or {}
        t = f.get("type") or "none"
        if t == "none" or t not in OVERLAY_FX_NAMES:
            return None, 0.0
        d = max(0.1, min(float(f.get("dur") or 0.5), o_len / 2))
        return t, d
    ti, di = fx("fx_in"); to, do = fx("fx_out")
    parts, alpha = [], False
    at = float(o["at"])
    ox, oy = str(bx), str(by)
    for which, t, d in (("in", ti, di), ("out", to, do)):
        if not t:
            continue
        st = 0.0 if which == "in" else max(0.0, o_len - d)
        if t == "fade":
            alpha = True; parts.append("fade=t=%s:st=%.3f:d=%.3f:alpha=1" % (which, st, d))
        elif t == "black":
            parts.append("fade=t=%s:st=%.3f:d=%.3f" % (which, st, d))
        elif t == "white":
            parts.append("fade=t=%s:st=%.3f:d=%.3f:color=white" % (which, st, d))
        elif t == "zoom":
            # 들어오기: 1.25배 확대 상태에서 1배로 / 나가기: 1배에서 1.25배로. 크롭 창을 시간 식으로 줄였다 늘리고 다시 띠 크기로
            if which == "in":
                z = "(1+0.25*max(0,1-t/%.3f))" % d
            else:
                z = "(1+0.25*max(0,(t-%.3f)/%.3f))" % (st, d)
            # crop 의 w/h 는 프레임마다 못 바뀌므로 scale(eval=frame) 로 키운 뒤 가운데를 띠 크기로 잘라낸다
            parts.append("scale=w='trunc(%d*%s/2)*2':h='trunc(%d*%s/2)*2':eval=frame:flags=bicubic,crop=%d:%d:'(iw-ow)/2':'(ih-oh)/2'" % (bw, z, bh, z, bw, bh))
        elif t.startswith("slide"):
            # overlay 의 x/y 식: 결과 시각 t 로 계산(조각 시작 at, 길이 o_len)
            if which == "in":
                prog = "max(0,1-(t-%.3f)/%.3f)" % (at, d)          # 1→0
            else:
                prog = "max(0,(t-%.3f)/%.3f)" % (at + st, d)       # 0→1
            if t == "slideleft":
                ox = "%d-%d*%s" % (bx, bw, prog)
            elif t == "slideright":
                ox = "%d+%d*%s" % (bx, bw, prog)
            elif t == "slideup":
                oy = "%d+%d*%s" % (by, bh, prog)
            else:
                oy = "%d-%d*%s" % (by, bh, prog)
    fxc = ("," + ",".join(parts)) if parts else ""
    fmt = "format=yuva420p," if alpha else ""
    return fxc, fmt, ox, oy


def overlays_of(short):
    """덧영상(B-roll) 목록: 원본 구간 s~e 를 결과 시각 at 부터 본편 위에 얹는다. 소리는 넣지 않는다."""
    out = []
    for o in short.get("overlays") or []:
        try:
            s, e, at = float(o["s"]), float(o["e"]), float(o.get("at") or 0)
        except (KeyError, TypeError, ValueError):
            continue
        if e > s:
            out.append({"id": o.get("id"), "src": o.get("src") or "main", "s": s, "e": e, "at": max(0.0, at),
                        "layer": max(1, int(o.get("layer") or 1)), "audio": o.get("audio") is not False,
                        "speed": spd_of(o.get("speed")), "hold": hold_of(o.get("hold"))})
    out.sort(key=lambda o: (o["layer"], o["at"]))       # 낮은 층부터 얹어야 높은 층이 위에 온다
    return out


def nar_place(p, short):
    """낭독 배치 (at, in, out): at=결과 영상에서 시작 시각, in/out=낭독 파일 안의 구간. 없으면 (0, 0, 길이)."""
    dur = float((p.get("narration") or {}).get("duration") or 0)
    n = short.get("nar") or {}
    at = max(0.0, float(n.get("at") or 0))
    i = min(max(0.0, float(n.get("in") or 0)), dur)
    o = n.get("out")
    o = dur if o is None else min(max(i, float(o)), dur)
    return at, i, o


SHORTS_LIMIT = 180.0                                  # 쇼츠 한계(3분) — 트랙의 노란 선과 경고에만 쓴다. 편집 길이 자체는 제한하지 않는다
MAX_OUT = SHORTS_LIMIT                                # (옛 이름 호환)


def out_len(p, short):
    """결과 영상 길이: 본편(주 트랙)과 위층·낭독·음악 끝 중 가장 늦은 시각. 본편보다 길면 렌더가 검정·무음으로 늘린다. 상한 없음(3분은 표시만)."""
    clips = clips_of(short)
    _, end = clip_offsets(clips, xfade_of(p, clips))
    for o in overlays_of(short):
        end = max(end, o["at"] + clip_out(o))
    if p.get("kind") == "shop" and (p.get("narration") or {}).get("path"):
        at, i, o = nar_place(p, short)
        end = max(end, at + (o - i))
    b = (p.get("settings") or {}).get("bgm") or {}
    if b.get("enabled") and b.get("until") is not None and not short.get("bgm_off"):
        end = max(end, float(b["until"]))
    for a in audios_of(short):
        end = max(end, a["at"] + (a["out"] - a["in"]))
    for t in texts_of(short):
        end = max(end, t["at"] + t["dur"])
    return round(end, 3)


def audios_of(short):
    """추가 오디오 트랙: 파일의 in~out 을 결과 at 부터, volume 배로. out 이 없으면 파일 끝까지."""
    out = []
    for a in short.get("audios") or []:
        try:
            dur = float(a.get("duration") or 0)
            at = max(0.0, float(a.get("at") or 0))
            i = min(max(0.0, float(a.get("in") or 0)), dur)
            o = a.get("out")
            o = dur if o is None else min(max(i, float(o)), dur)
            vol = float(a.get("volume") if a.get("volume") is not None else 1.0)
        except (TypeError, ValueError):
            continue
        if o - i > 0.05 and a.get("path"):
            out.append({"id": a.get("id"), "path": a["path"], "title": a.get("title", ""), "at": at, "in": i, "out": o, "volume": vol, "duration": dur})
    return out


def clip_offsets(clips, xfade=0.0):
    """조각마다 결과 영상에서의 시작 시각과 총 길이. 전환(xfade)이 있으면 그만큼 겹쳐 짧아진다."""
    offs, t = [], 0.0
    for i, c in enumerate(clips):
        if i > 0:
            t -= (xfade[i - 1] if isinstance(xfade, (list, tuple)) else xfade)   # 조각 사이마다 다른 전환 길이
        offs.append(t)
        t += clip_out(c)
    return offs, t


def short_cues(p, short):
    """마스터 큐를 조각별로 자르고 결과 영상 시간(out_s/out_e)을 붙인다. cue_edits 로 문장을 덮어쓴다."""
    clips = clips_of(short)
    if p.get("kind") == "shop" and (p.get("narration") or {}).get("path"):
        # 쇼핑 쇼츠(낭독 있음): 자막은 낭독(결과 영상 시간) 기준이라 조각과 무관하게 그대로 쓴다. 낭독이 없으면 아래 조각 기준(영상 소리 받아쓰기)
        total = out_len(p, short)
        at, ni, no = nar_place(p, short)                # 낭독을 트랙에서 옮기거나 잘랐으면 자막도 따라간다
        shift = at - ni
        edits = short.get("cue_edits") or {}
        out = []
        for c in p.get("cues") or []:
            if c["e"] <= ni or c["s"] >= no:
                continue
            cs, ce = max(c["s"], ni) + shift, min(c["e"], no) + shift
            if cs >= total:
                continue
            c = dict(c)
            k = str(c["id"])
            if k in edits:
                c["text"] = edits[k]
            if not c["text"].strip():
                continue
            c["out_s"] = round(cs, 3)
            c["out_e"] = round(min(ce, total), 3)
            out.append(c)
        return out
    xf = xfade_of(p, clips)
    offs, _ = clip_offsets(clips, xf)
    edits = short.get("cue_edits") or {}
    out = []
    n = len(clips)
    for i, (clip, off) in enumerate(zip(clips, offs)):
        if clip.get("src", "main") != "main":
            continue                           # 삽입 영상 조각에는 자막이 없다(원본 자막은 본편 것)
        spd = spd_of(clip.get("speed"))
        clen = (clip["e"] - clip["s"]) / spd          # 멈춤(hold) 구간엔 원본 시각이 없어 자막을 두지 않는다
        # 전환이 겹치는 동안은 두 조각의 자막이 동시에 보이므로, 그 구간에서는 자막을 비운다
        lo = off + (xf[i - 1] if i > 0 else 0)
        hi = off + clen - (xf[i] if i < n - 1 else 0)
        for c in cues_in(p["cues"], clip["s"], clip["e"]):
            k = str(c["id"])
            if k in edits:
                c["text"] = edits[k]
            if not c["text"].strip():
                continue
            a = max(lo, off + (c["s"] - clip["s"]) / spd)
            b = min(hi, off + (c["e"] - clip["s"]) / spd)
            if b - a < 0.1:
                continue
            c["out_s"] = round(a, 3)
            c["out_e"] = round(b, 3)
            out.append(c)
    return out


def sub_pngs(p, short, L, work):
    """자막 한 줄마다 투명 PNG 하나. libass 대신 PIL 로 그리는 이유: 제목과 같은 폰트·같은 굵기가
    보장되고(가변 폰트의 Bold 를 libass 가 못 고른다), 미리보기와 좌표가 1:1 로 맞는다.
    반환: [(png_path, start_rel, end_rel), ...]"""
    CW, CH = L["W"], L["H"]
    st = p["settings"]
    if st.get("show_subs") is False:
        return []   # 원본에 자막이 구워져 있는 채널은 겹치므로 끈다
    accent = st.get("accent", "#FF3B3B")
    pop = st.get("template") == "pop"
    scale = min(max(0.5, float(st.get("sub_scale") or 1.0)), 2.0)   # 사용자 자막 크기 배율(미리보기와 동일)
    size = int(round(L["sub_size"] * scale))
    fnt = text_font(st.get("sub_font"), size)          # 자막 글꼴(설정, 기본 본고딕 Bold). 미리보기 #stSub 와 같은 id
    lh = int(size * 1.3)
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    # 자막 색은 제목 강조색과 완전히 따로 간다. 외곽선 '' = 검정(기본), 'accent' = 강조색을 따라감(선택), 'none' = 없음
    fill_c = hexrgb(st.get("sub_fill") or "#FFFFFF")
    stroke_v = st.get("sub_stroke") or ""
    if stroke_v == "none":
        stroke_w, stroke_c = 0, (0, 0, 0, 0)
    else:
        stroke_w = 5 if pop else 4
        stroke_c = (hexrgb(accent) if stroke_v == "accent"
                    else hexrgb(stroke_v) if stroke_v.startswith("#") else (0, 0, 0, 255))
    out = []
    one_line = bool(st.get("sub_one_line"))
    for k, c in enumerate(short_cues(p, short)):
        f_use, lh_use = fnt, lh
        fx = cue_fx_of(short, c.get("id"))
        fill_use = SUB_EMPH_COLOR.get(fx.get("emph"), fill_c)
        if fx.get("emph") == "big":                       # 크게: 글자 1.25배(미리보기는 scale(1.25))
            f_use = text_font(st.get("sub_font"), int(round(size * 1.25))); lh_use = int(size * 1.25 * 1.3)
        if one_line:
            # 한 줄: 줄바꿈 대신 글자를 줄여 폭에 맞춘다(최소 60%). 미리보기(showSub)와 같은 규칙
            txt = " ".join((c["text"] or "").split())
            lines = [txt] if txt else []
            sz = int(round(size * 1.25)) if fx.get("emph") == "big" else size
            while sz > int(sz * 0.6):
                l_, t_, r_, b_ = probe.textbbox((0, 0), txt, font=f_use)
                if r_ - l_ <= L["sub_maxw"]:
                    break
                sz -= 2
                f_use = text_font(st.get("sub_font"), sz)
            lh_use = int(sz * 1.3)
        else:
            lines = wrap_text(probe, c["text"], f_use, L["sub_maxw"])[:2]
        if not lines:
            continue
        img = Image.new("RGBA", (CW, lh_use * len(lines) + 20), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        for i, ln in enumerate(lines):
            draw_center(d,  ln, 10 + i * lh_use, f_use, fill_use, stroke=stroke_c, stroke_w=stroke_w, width=CW)
        path = work / ("%s_sub%02d.png" % (short["id"], k))
        img.save(path)
        fx["h"] = img.size[1]                             # 줌 때 세로 가운데 맞춤용
        out.append((path, c["out_s"], c["out_e"], fx))
    # 자막 구간이 1~2프레임씩 물려 **두 줄이 동시에 그려지는 순간**이 생긴다.
    # 자막이 화면 아래에 있을 때는 잘 안 보였는데, 위로 올리면(§73) 바로 티가 난다.
    # 앞 자막의 끝을 다음 자막 시작 직전으로 잘라 준다.
    for i in range(len(out) - 1):
        pth, a, b, fx = out[i]
        nxt = out[i + 1][1]
        if b > nxt - 0.02:
            out[i] = (pth, a, max(a + 0.10, nxt - 0.02), fx)
    return out


def sub_anim_chain(fx, a, b, idx, label, sub_x, sub_y):
    """자막 PNG 에 나타나기·사라지기(페이드·아래서 위로·확대). text_anim_filters 와 같은 방식.
    반환 (입력 옵션, 필터 문자열, overlay x 식, y 식)."""
    D = SUB_FX_D
    dur = max(0.05, b - a)
    d_ = min(D, dur / 2)
    ai, ao = fx.get("in", "none"), fx.get("out", "none")
    pre = ["-loop", "1", "-framerate", "30", "-t", "%.3f" % dur]
    chain = "[%d:v]format=rgba" % idx
    if ai != "none":
        chain += ",fade=t=in:st=0:d=%.3f:alpha=1" % d_
    if ao != "none":
        chain += ",fade=t=out:st=%.3f:d=%.3f:alpha=1" % (max(0, dur - d_), d_)
    pi = "clip((t-%.3f)/%.3f,0,1)" % (a, D)
    po = "clip((%.3f-t)/%.3f,0,1)" % (b, D)
    ys = []
    if ai == "up":
        ys.append("(40*(1-%s))" % pi)
    if ao == "up":
        ys.append("(-40*(1-%s))" % po)
    x = "%d" % sub_x
    y = "%d" % sub_y + ("+" + "+".join(ys) if ys else "")
    if ai == "zoom" or ao == "zoom":
        zi = "(0.6+0.4*%s)" % pi if ai == "zoom" else "1"
        zo = "(0.6+0.4*%s)" % po if ao == "zoom" else "1"
        chain += ",setpts=PTS+%.3f/TB,scale=w='iw*%s*%s':h='ih*%s*%s':eval=frame%s" % (a, zi, zo, zi, zo, label)
        x = "%d+(W-w)/2" % sub_x
        y = "(%s)+(%d-h)/2" % (y, int(fx.get("h") or 0))
    else:
        chain += ",setpts=PTS+%.3f/TB%s" % (a, label)
    return pre, chain, x, y


def texts_of(short):
    """자유 위치 텍스트: 결과 시각 at 부터 dur 초, 스테이지(1080×1920) 좌표 (x, y) 가운데 기준."""
    out = []
    for t in short.get("texts") or []:
        try:
            txt = str(t.get("text") or "").strip()
            at = max(0.0, float(t.get("at") or 0)); dur = max(0.2, float(t.get("dur") or 3))
            if not txt:
                continue
            out.append({"id": t.get("id"), "text": txt, "at": at, "dur": dur,
                        "x": float(t.get("x", 540)), "y": float(t.get("y", 960)), "size": int(t.get("size") or 72),
                        "color": t.get("color") or "#FFFFFF", "stroke": t.get("stroke") if t.get("stroke") is not None else "#000000",
                        "bold": t.get("bold", True) is not False, "bg": bool(t.get("bg")), "align": t.get("align") or "center",
                        "font": t.get("font") or "noto",
                        "shadow": t.get("shadow") if t.get("shadow") in ("none", "soft", "hard") else "none",
                        "w": int(t.get("w") or 0), "lane": max(1, int(t.get("lane") or 1)),
                        # 커버용: 배경판 불투명도(0~255)와 **고정 높이**. 소재에 구워진 중국어
                        # 판넬을 한국어로 덮을 때 쓴다 — 반투명(160)이면 밑의 글자가 비친다.
                        # `or` 로 받는다 — 키가 있는데 값이 None 인 경우가 있고(shop_edit 의
                        # 스타일 기본값), int(None) 은 TypeError 라 **그 텍스트가 통째로 버려진다.**
                        "bg_alpha": max(0, min(255, int(t.get("bg_alpha") or 160))),
                        "h": int(t.get("h") or 0),
                        # 덮개는 **낭독 자막 밑**으로 깔린다 — 위에 얹으면 자막이 잘린다.
                        "under_sub": bool(t.get("under_sub")),
                        "anim_in": t.get("anim_in") if t.get("anim_in") in TEXT_ANIMS else "none",
                        "anim_out": t.get("anim_out") if t.get("anim_out") in TEXT_ANIMS else "none",
                        # 깜빡임: {"period": 1.2, "on": 0.7} — 주기마다 앞 on 초만 보인다(상품명 팝업, 2026-09-13)
                        "blink": t.get("blink") if isinstance(t.get("blink"), dict) and float(t["blink"].get("period") or 0) > 0 else None})
        except (TypeError, ValueError):
            continue
    out.sort(key=lambda t: t["lane"])                 # 낮은 트랙부터 얹어야 위 트랙이 위에 보인다(미리보기 z-index 와 같은 순서)
    return out


def text_pngs(p, short, work):
    """텍스트 항목마다 스테이지 크기 투명 PNG 하나(미리보기 CSS 와 같은 규칙: 가운데 기준 좌표, 외곽선 = 크기/12, 배경 상자).
    반환 [(png, start, end)]"""
    CW, CH = canvas_size(p["settings"])
    out = []
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    for k, t in enumerate(texts_of(short)):
        size = max(16, min(300, t["size"]))
        fnt = text_font(t["font"], size, bold=t["bold"])
        boxw = t["w"] if 120 <= t["w"] <= CW - 20 else 0          # 너비를 정했으면 그 폭으로 줄바꿈·정렬, 아니면 내용 폭(최대 960)
        lines = []
        for para in t["text"].split("\n"):
            lines += wrap_text(probe, para, fnt, boxw or min(960, CW - 120)) or [""]
        lines = lines[:8]
        lh = int(size * 1.25)
        widths = [probe.textlength(ln, font=fnt) for ln in lines]
        bw = boxw or (max(widths) if widths else 0)
        bh = lh * len(lines)
        if 40 <= t["h"] <= CH:            # 높이를 정했으면 그 상자를 그대로 쓴다(덮개)
            bh = t["h"]
        pad = int(size * 0.35)
        img = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        left = t["x"] - bw / 2; top = t["y"] - bh / 2
        if t["bg"]:
            d.rounded_rectangle((left - pad, top - pad * 0.6, left + bw + pad, top + bh + pad * 0.6), radius=int(size * 0.25), fill=(0, 0, 0, t["bg_alpha"]))
        fill = hexrgb(t["color"])
        stroke_w = 0 if (t["stroke"] in (None, "", "none")) else max(1, int(round(size / 12)))
        stroke_c = hexrgb(t["stroke"]) if stroke_w else None
        def line_pos(i):
            lx = left if t["align"] == "left" else (left + bw - widths[i]) if t["align"] == "right" else left + (bw - widths[i]) / 2
            l, tt, r, b = d.textbbox((0, 0), lines[i], font=fnt)
            return lx - l, top + i * lh + (lh - (b - tt)) / 2 - tt
        if t["shadow"] != "none":                              # 그림자: 미리보기 CSS(text-shadow)와 같은 비율. 부드럽게 = 흐림, 진하게 = 또렷한 오프셋
            sh = Image.new("RGBA", (CW, CH), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
            ox, oy = (size * 0.05, size * 0.07) if t["shadow"] == "soft" else (size * 0.06, size * 0.06)
            sc = (0, 0, 0, 190) if t["shadow"] == "soft" else (0, 0, 0, 230)
            for i, ln in enumerate(lines):
                px, py = line_pos(i)
                sd.text((px + ox, py + oy), ln, font=fnt, fill=sc, stroke_width=stroke_w, stroke_fill=sc)
            if t["shadow"] == "soft":
                sh = sh.filter(ImageFilter.GaussianBlur(max(1, size * 0.08)))
            img.alpha_composite(sh); d = ImageDraw.Draw(img)
        for i, ln in enumerate(lines):
            px, py = line_pos(i)
            d.text((px, py), ln, font=fnt, fill=fill, stroke_width=stroke_w, stroke_fill=stroke_c)
        path = work / ("%s_txt%02d.png" % (short["id"], k))
        img.save(path)
        out.append((path, t["at"], t["at"] + t["dur"], t))
    return out


def text_anim_filters(t, a, b, idx, label):
    """텍스트 PNG 를 애니메이션 입력으로: 페이드는 알파 fade, 슬라이드·줌은 overlay 의 x/y 식과 scale 로.
    반환 (입력 옵션, 필터 문자열(라벨 붙임), overlay 의 x 식, y 식). 입력은 -loop 1 로 dur 길이 영상으로 만든다."""
    D = TEXT_ANIM_D
    dur = max(0.05, b - a)
    ai, ao = t["anim_in"], t["anim_out"]
    pre = ["-loop", "1", "-framerate", "30", "-t", "%.3f" % dur]
    chain = "[%d:v]format=rgba" % idx
    if ai != "none":
        chain += ",fade=t=in:st=0:d=%.3f:alpha=1" % min(D, dur / 2)
    if ao != "none":
        chain += ",fade=t=out:st=%.3f:d=%.3f:alpha=1" % (max(0, dur - min(D, dur / 2)), min(D, dur / 2))
    chain += ",setpts=PTS+%.3f/TB%s" % (a, label)
    # 진행도: pi = 나타나는 중 0→1, po = 사라지는 중 1→0 (overlay 의 t 는 결과 시각)
    pi = "clip((t-%.3f)/%.3f,0,1)" % (a, D)
    po = "clip((%.3f-t)/%.3f,0,1)" % (b, D)
    off = 140
    x, y = "0", "0"
    dx_in = {"left": "(-%d*(1-%s))" % (off, pi), "right": "(%d*(1-%s))" % (off, pi)}.get(ai)
    dy_in = {"up": "(%d*(1-%s))" % (off, pi), "down": "(-%d*(1-%s))" % (off, pi)}.get(ai)
    dx_out = {"left": "(-%d*(1-%s))" % (off, po), "right": "(%d*(1-%s))" % (off, po)}.get(ao)
    dy_out = {"up": "(-%d*(1-%s))" % (off, po), "down": "(%d*(1-%s))" % (off, po)}.get(ao)
    xs = [e for e in (dx_in, dx_out) if e]
    ys = [e for e in (dy_in, dy_out) if e]
    if xs:
        x = "+".join(xs)
    if ys:
        y = "+".join(ys)
    return pre, chain, x, y


_ENCODER = None


_ENCODER = None


def pick_encoder():
    """NVENC 가 실제로 도는지 1프레임 인코딩으로 확인한다. 목록에 있는 것과 되는 것은 다르다."""
    global _ENCODER
    if _ENCODER:
        return _ENCODER
    for enc, args in (("h264_nvenc", ["-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0",
                                      "-maxrate", "14M", "-bufsize", "28M"]),
                      ("libx264", ["-preset", "medium", "-crf", "20"])):
        r = subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=black:s=256x256:d=0.1",
                            "-c:v", enc, "-f", "null", "-"], capture_output=True)
        if r.returncode == 0:
            _ENCODER = (enc, args)
            return _ENCODER
    raise RuntimeError("쓸 수 있는 H.264 인코더가 없습니다")


def _mask_px(r, sw, sh):
    """비율 사각형 하나 → 원본 픽셀 사각형(짝수·경계 안). 못 쓰면 None."""
    try:
        x = int(round(float(r.get("x", 0)) * sw)); y = int(round(float(r.get("y", 0)) * sh))
        w = int(round(float(r.get("w", 0)) * sw)); h = int(round(float(r.get("h", 0)) * sh))
    except (TypeError, ValueError, AttributeError):
        return None
    x = max(0, min(sw - 4, x)); y = max(0, min(sh - 4, y))
    w = max(4, min(sw - x, w)); h = max(4, min(sh - y, h))
    x -= x % 2; y -= y % 2; w -= w % 2; h -= h % 2
    if w < 4 or h < 4:
        return None
    return x, y, w, h


def mask_rects(st, sw, sh):
    """가리기 영역들(원본 비율 0~1 저장)을 원본 픽셀 사각형 목록으로. rects 가 없으면 옛 x/y/w/h 하나를 쓴다(2026-09-13 여러 영역)."""
    m = st.get("mask") or {}
    if not m.get("enabled"):
        return []
    rs = m.get("rects")
    if not isinstance(rs, list):
        rs = [m] if m.get("w") else []
    out = []
    for r in rs:
        p = _mask_px(r, sw, sh)
        if p:
            def _f(k):
                try:
                    v = r.get(k) if isinstance(r, dict) else None
                    return None if v in (None, "") else float(v)
                except (TypeError, ValueError):
                    return None
            out.append(p + ((r.get("type") if isinstance(r, dict) else None) or m.get("type") or "mosaic",
                            (r.get("block") if isinstance(r, dict) else None) or m.get("block") or 16,
                            _f("at"), _f("until")))   # 영역별 종류·세기(2026-09-13) · 구간 at/until(결과 초, 없으면 전체 — 2026-09-14)
    return out


def mask_rect(st, sw, sh):
    """(호환) 첫 영역 하나. 없으면 None."""
    rs = mask_rects(st, sw, sh)
    return rs[0][:4] if rs else None


def mask_filter(st, sw, sh, px_scale=1.0, t_off=None, dur=None):
    """원본 프레임 위 사각형들을 모자이크·흐림·검정으로 덮는 필터 조각(앞에 ',' 포함). 크롭보다 먼저 건다. 영역마다 이어 붙인다.
    px_scale = 결과 화면 1px 당 원본 px(cw/band_w). 블록 크기는 결과 화면 기준이라 4K 원본에서도 같은 굵기로 보인다(2026-09-13)."""
    rs = mask_rects(st, sw, sh)
    if not rs:
        return ""
    parts = []
    for i, (x, y, w, h, kind, block, at, until) in enumerate(rs):
        # 구간 지정 영역(2026-09-14): 결과 시각 at~until 을 이 조각의 시각(t_off 부터 dur 동안)으로 바꿔 enable 로 건다.
        # 조각 밖이면 필터 자체를 뺀다. t_off 를 모르면(호환) 전체에 건다.
        en = ""
        if at is not None or until is not None:
            if t_off is None:
                pass
            else:
                a = (at if at is not None else 0.0) - float(t_off); b = (until if until is not None else 1e9) - float(t_off)
                d = float(dur) if dur else None
                if b <= 0 or (d is not None and a >= d):
                    continue
                a = max(0.0, a); b = min(b, d) if d is not None else b
                en = ":enable='between(t,%.3f,%.3f)'" % (a, b)
        px = max(2, int(round(float(block or 16) * max(0.1, float(px_scale or 1.0)))))   # 이 영역의 블록 크기·흐림 반경(원본 px)
        if kind == "black":
            parts.append(",drawbox=x=%d:y=%d:w=%d:h=%d:color=black:t=fill%s" % (x, y, w, h, en))
        elif kind == "blur":
            lr = max(2, min(px, min(w, h) // 2 - 1))              # 흐림 반경 = 세기 선택(결과 px → 원본 px). boxblur 는 반경이 변 절반보다 작아야 한다
            parts.append(",split=2[mb%d][mm%d];[mm%d]crop=%d:%d:%d:%d,boxblur=luma_radius=%d:luma_power=2:chroma_radius=%d[mz%d];[mb%d][mz%d]overlay=%d:%d%s"
                         % (i, i, i, w, h, x, y, lr, max(1, lr // 2), i, i, i, x, y, en))
        else:
            bw, bh = max(1, w // px), max(1, h // px)
            parts.append(",split=2[mb%d][mm%d];[mm%d]crop=%d:%d:%d:%d,scale=%d:%d:flags=area,scale=%d:%d:flags=neighbor[mz%d];[mb%d][mz%d]overlay=%d:%d%s"
                         % (i, i, i, w, h, x, y, bw, bh, w, h, i, i, i, x, y, en))
    return "".join(parts)


def render_short(p, short, on_progress=None):
    st = p["settings"]
    src = p["source"]
    L = apply_offsets(layout(st.get("ratio", "16:9"), st.get("template", "dark"), canvas_of(st)), st)
    CW, CH = L["W"], L["H"]                      # 캔버스 크기(레이아웃이 정한다)
    d = pdir(p["id"])
    work = d / "work"
    out = d / "output"
    work.mkdir(exist_ok=True)
    out.mkdir(exist_ok=True)

    idx = short["id"]
    for old in work.glob(idx + "_*.png"):
        old.unlink()
    png = work / ("%s_overlay.png" % idx)
    title_secs = float(st.get("title_secs") or 0)
    split_title = title_secs > 0 and st.get("show_title") is not False and any((short.get(k) or "").strip() for k in ("line1", "line2"))
    overlay_png(p, short, L, png, parts="rest" if split_title else "all")
    png_t = work / ("%s_title.png" % idx)
    if split_title:
        overlay_png(p, short, L, png_t, parts="title")       # 제목은 마지막 입력으로 붙여 앞 title_secs 초만 보인다
    subs = sub_pngs(p, short, L, work)

    # 조각마다 입력 탐색(-ss/-to)으로 따로 열어 concat 으로 잇는다. trim 필터로 자르면 앞부분을 전부
    # 디코딩해야 해서 20분 뒤 조각 하나에 몇 분이 걸린다. 입력 탐색은 키프레임으로 바로 간다.
    # 조각의 출처 영상이 서로 달라도(해상도·음성 유무) concat 전에 같은 크기·같은 오디오 형식으로 맞춘다.
    clips = clips_of(short)
    n_clips = len(clips)
    ratio = st.get("ratio", "16:9")
    band_w, band_h = (CW, CH) if L["mode"] == "full" else (L["band_w"], L["band_h"])
    band_left = 0 if L["mode"] == "full" else int(L.get("band_left", 0))
    clip_inputs, parts, labels = [], [], ""
    _offs, _ = clip_offsets(clips, xfade_of(p, clips))              # 가리기 구간 지정용 조각 시작 시각(결과 초)
    for i, c in enumerate(clips):
        sinfo = source_by_id(p, c.get("src"))
        clip_inputs += ["-ss", "%.3f" % c["s"], "-to", "%.3f" % c["e"], "-i", str(sinfo["path"])]
        sw, sh = sinfo["width"], sinfo["height"]
        if c.get("src", "main") == "main":
            cw, ch, cx, cy = crop_rect(sw, sh, ratio, st.get("zoom", 1.0), st.get("pan_x", 0), st.get("pan_y", 0))
        else:
            cw, ch, cx, cy = crop_rect(sw, sh, ratio, st.get("zoom", 1.0), 0, 0)   # 삽입 영상은 가운데 기준
        # 가리기: 본편 조각에만. 쇼핑 쇼츠는 영상마다 중국어 자막 자리가 비슷하므로 모든 조각에 건다
        mask_chain = mask_filter(st, sw, sh, cw / float(band_w), t_off=_offs[i], dur=clip_out(c)) if (c.get("src", "main") == "main" or p.get("kind") == "shop") else ""
        spd, hold = spd_of(c.get("speed")), hold_of(c.get("hold"))
        # 좌우 반전. **crop·가리기 뒤에** 건다 — 그 둘은 원본 좌표계를 쓰므로 먼저 뒤집으면
        # 흐림 띠·delogo 상자가 엉뚱한 자리를 덮는다. 같은 소스를 여러 번 쓰는 편집에서
        # 반복이 반복처럼 안 보이게 하는 장치다(구운 글자가 남아 있는 조각에는 걸지 말 것 —
        # 뒤집힌 글자는 한눈에 티가 난다).
        vflip = ",hflip" if c.get("flip") else ""
        vpts = "setpts=(PTS-STARTPTS)/%.4f" % spd if abs(spd - 1) > 1e-6 else "setpts=PTS-STARTPTS"     # 느리게 = pts 를 늘린다
        vhold = ",tpad=stop_mode=clone:stop_duration=%.3f" % hold if hold > 0 else ""                    # 마지막 프레임 멈춤
        ahold = ",apad=pad_dur=%.3f" % hold if hold > 0 else ""
        parts.append("[%d:v]%s%s,crop=%d:%d:%d:%d,scale=%d:%d:flags=lanczos%s,fps=30,format=yuv420p,setsar=1%s[v%d]"
                     % (i, vpts, mask_chain, cw, ch, cx, cy, band_w, band_h, vflip, vhold, i))
        if sinfo.get("has_audio", True) and not c.get("mute"):   # 조각별 무음(🔇)은 무음 소스로 대신한다
            parts.append("[%d:a]asetpts=PTS-STARTPTS%s,aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo%s[a%d]"
                         % (i, atempo_chain(spd), ahold, i))
        else:
            parts.append("anullsrc=r=44100:cl=stereo,atrim=0:%.3f,asetpts=PTS-STARTPTS[a%d]" % (clip_out(c), i))
        labels += "[v%d][a%d]" % (i, i)
    xf = xfade_of(p, clips)
    trs = [transition_at(p, clips, i) for i in range(1, n_clips)]
    if n_clips == 1:
        pre = ";".join(parts) + ";[v0]null[vc];[a0]anull[ac];"
    elif all(d <= 0 for _, d in trs):
        pre = ";".join(parts) + ";" + labels + "concat=n=%d:v=1:a=1[vc][ac];" % n_clips
    else:
        # 조각 사이마다: 전환이 있으면 xfade(영상)·acrossfade(소리), 없으면 그 자리만 concat. offset 은 겹쳐 짧아진 누적 길이
        vprev, aprev, acc = "[v0]", "[a0]", clip_out(clips[0])
        for i in range(1, n_clips):
            ttype, d = trs[i - 1]
            if d > 0:
                off = acc - d
                parts.append("%s[v%d]xfade=transition=%s:duration=%.3f:offset=%.3f[vx%d]" % (vprev, i, ttype, d, off, i))
                parts.append("%s[a%d]acrossfade=d=%.3f[ax%d]" % (aprev, i, d, i))
                acc = off + clip_out(clips[i])
            else:
                parts.append("%s[v%d]concat=n=2:v=1:a=0[vx%d]" % (vprev, i, i))
                parts.append("%s[a%d]concat=n=2:v=0:a=1[ax%d]" % (aprev, i, i))
                acc += clip_out(clips[i])
            vprev, aprev = "[vx%d]" % i, "[ax%d]" % i
        pre = ";".join(parts) + ";%snull[vc];%sanull[ac];" % (vprev, aprev)
    _, main_dur = clip_offsets(clips, xf)
    dur = out_len(p, short)
    if dur > main_dur + 0.02:              # 위층·낭독·음악이 본편보다 길면 검정 화면·무음으로 늘린다(캡컷과 같음)
        pre += "[vc]tpad=stop_mode=add:stop_duration=%.3f:color=black[vcp];[ac]apad=whole_dur=%.3f[acp];" % (dur - main_dur, dur)
        vlab, alab = "[vcp]", "[acp]"
    else:
        vlab, alab = "[vc]", "[ac]"
    bg_img = Path(st.get("bg_image") or "")
    if L["mode"] == "full":
        fit = "null"
    elif st.get("bg_image") and bg_img.exists() and bg_img.suffix.lower() in IMAGE_EXTS:
        # 배경 이미지(2026-09-13): 추가 -i 없이 movie 소스로 읽어 캔버스를 cover 로 채우고(무한 반복), 영상 띠를 그 위에 얹는다.
        # 입력 번호를 바꾸지 않으려고 movie 필터를 쓴다(뒤의 제목·자막·덧영상 입력 번호가 n_clips 기준으로 고정돼 있다).
        mp = str(bg_img.resolve()).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
        fit = None
        pre += ("movie='%s',scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,format=yuv420p,setsar=1,"
                "loop=loop=-1:size=1:start=0,setpts=N/(30*TB),fps=30[bgimg];" % (mp, CW, CH, CW, CH))
    else:
        bg = (st.get("bg_color") or "#000000").lstrip("#")
        fit = "pad=%d:%d:%d:%d:color=0x%s" % (CW, CH, band_left, L["band_top"], bg)
    # 자막 PNG 는 단일 프레임 입력. overlay 의 repeatlast(기본 1)가 마지막 프레임을 유지하므로
    # -loop 없이도 enable 구간 내내 보인다(-loop 1 은 무한 입력이라 -shortest 가 따로 필요하다).
    inputs = ["-i", str(png)]
    ov_base = n_clips                      # 제목 PNG 입력 번호. 자막 PNG 는 그 뒤로, 덧영상·소리 입력은 그 뒤로
    for sp, a, b, fx in subs:
        if fx.get("in") or fx.get("out"):
            inputs += ["-loop", "1", "-framerate", "30", "-t", "%.3f" % max(0.05, b - a), "-i", str(sp)]
        else:
            inputs += ["-i", str(sp)]
    n_in = ov_base + 1 + len(subs)
    if fit is None:
        graph = pre + "[bgimg]%soverlay=%d:%d:shortest=1[vb]" % (vlab, band_left, L["band_top"])
    else:
        graph = pre + "%s%s[vb]" % (vlab, fit)
    cur = "[vb]"
    # 덧영상(B-roll): 결과 시각 at 부터 본편 위에 얹는다(제목·자막보다 아래층). 소리는 없다.
    # setpts 로 at 만큼 늦추고, enable 창 밖·스트림 끝(eof_action=pass)에서는 본편이 그대로 지나간다.
    band_top = 0 if L["mode"] == "full" else L["band_top"]
    ov_audio = []                          # 소리를 켠 위층 조각: (입력 번호, 조각) — 아래 소리 섞기에서 얹는다
    for k, o in enumerate(overlays_of(short)):
        if o["at"] >= dur - 0.05:
            continue
        sinfo = source_by_id(p, o["src"])
        ow, oh = sinfo["width"], sinfo["height"]
        ospd, ohold = spd_of(o.get("speed")), hold_of(o.get("hold"))
        oe = min(o["e"], o["s"] + (dur - o["at"]) * ospd)
        inputs += ["-ss", "%.3f" % o["s"], "-to", "%.3f" % oe, "-i", str(sinfo["path"])]
        cw, ch, cx, cy = crop_rect(ow, oh, ratio, st.get("zoom", 1.0), 0, 0)
        mchain = mask_filter(st, ow, oh, cw / float(band_w), t_off=o["at"], dur=(oe - o["s"]) / ospd + ohold) if p.get("kind") == "shop" else ""
        ovpts = "setpts=(PTS-STARTPTS)/%.4f" % ospd if abs(ospd - 1) > 1e-6 else "setpts=PTS-STARTPTS"
        ovhold = ",tpad=stop_mode=clone:stop_duration=%.3f" % ohold if ohold > 0 else ""
        o_len = (oe - o["s"]) / ospd + ohold                       # 이 조각이 결과에 보이는 길이
        fxc, fmt, ox, oy = overlay_fx_chain(o, o_len, band_w, band_h, band_left, band_top)   # 들어오기·나가기 효과(2026-09-14)
        graph += (";[%d:v]%s%s,crop=%d:%d:%d:%d,scale=%d:%d:flags=lanczos,fps=30,format=yuv420p,setsar=1%s%s,%s"
                  "setpts=PTS+%.3f/TB[bv%d]" % (n_in, ovpts, mchain, cw, ch, cx, cy, band_w, band_h, ovhold, fxc, fmt, o["at"], k))
        nxt = "[ob%d]" % k
        graph += ";%s[bv%d]overlay=x='%s':y='%s':eof_action=pass:enable='between(t,%.3f,%.3f)'%s" % (
            cur, k, ox, oy, o["at"], min(dur, o["at"] + o_len), nxt)
        cur = nxt
        if o.get("audio") and sinfo.get("has_audio", True):
            ov_audio.append((n_in, o))
        n_in += 1
    graph += ";%s[%d:v]overlay=0:0[o0]" % (cur, ov_base)
    cur = "[o0]"
    # 사용자가 미리보기에서 끌어 옮긴 자막 위치(스테이지 px). 화면 밖으로는 못 나간다.
    sub_x = int(st.get("sub_dx") or 0)
    sub_y = min(max(-L["sub_y"] + 20, int(st.get("sub_dy") or 0)), CH - L["sub_y"] - 120) + L["sub_y"] - 10
    # 자유 위치 텍스트는 보통 자막 **위**에 얹는다. 다만 `under_sub` 인 것(덮개)은
    # 자막보다 **먼저** 깔아야 한다 — 불투명한 판이라 위에 얹으면 자막을 잘라 먹는다.
    _all_txt = list(enumerate(text_pngs(p, short, work)))
    _under = [x for x in _all_txt if x[1][3].get("under_sub")]
    _over = [x for x in _all_txt if not x[1][3].get("under_sub")]

    for k, (tp, a, b, tinfo) in _under:
        if a >= dur:
            continue
        b = min(b, dur)
        nxt = "[ou%d]" % k
        inputs += ["-i", str(tp)]
        graph += ";%s[%d:v]overlay=0:0:enable='between(t,%.3f,%.3f)'%s" % (cur, n_in, a, b, nxt)
        cur = nxt
        n_in += 1
    for j, (sp, a, b, fx) in enumerate(subs):
        nxt = "[o%d]" % (j + 1)
        if fx.get("in") or fx.get("out"):                                 # 자막 효과: 나타나기·사라지기(§자막 효과)
            _, chain, xe, ye = sub_anim_chain(fx, a, b, ov_base + 1 + j, "[sx%d]" % j, sub_x, sub_y)
            graph += ";%s;%s[sx%d]overlay=x='%s':y='%s':eof_action=pass:enable='between(t,%.3f,%.3f)'%s" % (
                chain, cur, j, xe, ye, a, b, nxt)
        else:
            graph += ";%s[%d:v]overlay=%d:%d:enable='between(t,%.3f,%.3f)'%s" % (
                cur, ov_base + 1 + j, sub_x, sub_y, a, b, nxt)
        cur = nxt
    for k, (tp, a, b, tinfo) in _over:                                   # 자유 위치 텍스트(제목·자막보다 위층) + 나타나기·사라지기
        if a >= dur:
            continue
        b = min(b, dur)
        nxt = "[ot%d]" % k
        if tinfo["anim_in"] == "none" and tinfo["anim_out"] == "none":
            inputs += ["-i", str(tp)]
            en = "between(t,%.3f,%.3f)" % (a, b)
            if tinfo.get("blink"):                                            # 깜빡이는 팝업(상품명): 주기마다 앞 on 초만
                per = float(tinfo["blink"].get("period") or 1.2); on = min(per, float(tinfo["blink"].get("on") or per * 0.6))
                en += "*lt(mod(t-%.3f\\,%.3f)\\,%.3f)" % (a, per, on)
            graph += ";%s[%d:v]overlay=0:0:enable='%s'%s" % (cur, n_in, en, nxt)
        else:
            pre, chain, xe, ye = text_anim_filters(tinfo, a, b, n_in, "[tx%d]" % k)
            inputs += pre + ["-i", str(tp)]
            zoom_in, zoom_out = tinfo["anim_in"] == "zoom", tinfo["anim_out"] == "zoom"
            if zoom_in or zoom_out:
                # 줌: 프레임마다 크기를 바꾼다(scale 식). 커진 만큼 가운데를 맞추려 overlay 위치를 -(w-1080)/2 로 둔다
                D = TEXT_ANIM_D
                zi = "(0.6+0.4*clip((t-%.3f)/%.3f,0,1))" % (a, D) if zoom_in else "1"
                zo = "(0.6+0.4*clip((%.3f-t)/%.3f,0,1))" % (b, D) if zoom_out else "1"
                chain = chain.replace("[tx%d]" % k, ",scale=w='iw*%s*%s':h='ih*%s*%s':eval=frame[tx%d]" % (zi, zo, zi, zo, k))
                # scale 식의 t 는 입력 스트림 시각(setpts 뒤라 결과 시각과 같다)
                xe = "(%s)+(W-w)/2" % xe
                ye = "(%s)+(H-h)/2" % ye
            en = "between(t,%.3f,%.3f)" % (a, b)
            if tinfo.get("blink"):
                per = float(tinfo["blink"].get("period") or 1.2); on = min(per, float(tinfo["blink"].get("on") or per * 0.6))
                en += "*lt(mod(t-%.3f\\,%.3f)\\,%.3f)" % (a, per, on)          # 필터그래프 안의 쉼표는 \, 로 escape
            graph += ";%s;%s[tx%d]overlay=x='%s':y='%s':eof_action=pass:enable='%s'%s" % (
                chain, cur, k, xe, ye, en, nxt)
        cur = nxt
        n_in += 1
    if split_title:
        inputs += ["-i", str(png_t)]
        graph += ";%s[%d:v]overlay=0:0:enable='between(t,0,%.3f)'[ottl]" % (cur, n_in, title_secs)
        cur = "[ottl]"
        n_in += 1
    tr = st.get("transition") or {}
    if tr.get("edges"):                     # 시작·끝 페이드(제목까지 포함해 마지막에 건다)
        graph += ";%sfade=t=in:st=0:d=0.3,fade=t=out:st=%.3f:d=0.4[vf]" % (cur, max(0, dur - 0.4))
        cur = "[vf]"
    graph += ";%sformat=yuv420p[vout]" % cur

    # 소리 섞기: 본편(훅 낭독 중엔 줄임) + 훅 낭독 + 배경음악 → amix(normalize=0 로 원래 음량 유지)
    main_a = alab
    if tr.get("edges"):
        graph += ";%safade=t=in:d=0.3,afade=t=out:st=%.3f:d=0.4[ace]" % (main_a, max(0, dur - 0.4))
        main_a = "[ace]"
    mix = []
    nar = p.get("narration") or {}
    if p.get("kind") == "shop" and nar.get("path") and Path(nar["path"]).exists():
        # 쇼핑 쇼츠: 낭독을 얹고 원본 소리는 src_volume(기본 1.0 = 그대로)만큼 남긴다
        at, ni, no = nar_place(p, short)                # 트랙에서 정한 배치: 파일의 ni~no 구간을 at 부터
        # adelay 가 앞에 넣는 무음은 pts 가 NOPTS 로 나와(ffmpeg 8.1) 뒤의 atrim 이 잘라 버린다 → asetpts=N/SR/TB 로 표본 수 기준 pts 를 다시 매긴다
        inputs += ["-i", str(nar["path"])]
        graph += (";[%d:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,atrim=%.3f:%.3f,asetpts=PTS-STARTPTS,"
                  "adelay=%d:all=1,asetpts=N/SR/TB,apad=whole_dur=%.3f,atrim=0:%.3f[nar]"
                  % (n_in, ni, max(no, ni + 0.05), int(round(at * 1000)), dur, dur))
        n_in += 1
        sv = float(st.get("src_volume") if st.get("src_volume") is not None else 1.0)
        if sv > 0.005:
            graph += ";%svolume=%.3f[srcq]" % (main_a, sv)
            mix.append("[srcq]")
        else:
            graph += ";%sanullsink" % main_a          # 원본 소리를 안 쓰면 출력 단자를 명시적으로 닫아야 한다
        main_a = "[nar]"
    hk = st.get("hook_tts") or {}
    if hk.get("enabled") and hook_text_for(short):
        try:
            tts_path, tdur = tts_synth(hook_text_for(short), hk.get("voice") or "ko-KR-InJoonNeural",
                                       hk.get("rate") or 0, work / ("%s_hook.mp3" % idx))
            duck = float(hk.get("duck") if hk.get("duck") is not None else 0.25)
            delay_ms = 150
            inputs += ["-i", str(tts_path)]
            graph += (";%svolume=enable='between(t,0,%.2f)':volume=%.2f[a0d];[%d:a]adelay=%d|%d,asetpts=N/SR/TB[tv]"
                      % (main_a, tdur + delay_ms / 1000 + 0.2, duck, n_in, delay_ms, delay_ms))
            main_a = "[a0d]"
            mix.append("[tv]")
            n_in += 1
        except Exception as e:
            log("훅 낭독 건너뜀(%s): %s" % (idx, e))
    bgm = st.get("bgm") or {}
    if bgm.get("enabled") and bgm.get("path") and Path(bgm["path"]).exists() and not short.get("bgm_off"):
        vol = float(bgm.get("volume") if bgm.get("volume") is not None else 0.15)
        # 트랙 배치: 파일의 b_in 부터를 결과 b_at~b_end 구간에 깐다(부족하면 반복). until 이 없으면 끝까지
        b_at = max(0.0, float(bgm.get("at") or 0))
        b_in = max(0.0, float(bgm.get("in") or 0))
        b_end = dur if bgm.get("until") is None else min(dur, float(bgm["until"]))
        span = b_end - b_at
        if span > 0.2:
            inputs += ["-i", str(bgm["path"])]
            graph += (";[%d:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,atrim=start=%.3f,asetpts=PTS-STARTPTS,"
                      "aloop=loop=-1:size=2147483647,atrim=0:%.3f,asetpts=PTS-STARTPTS,volume=%.3f,afade=t=in:d=0.6,afade=t=out:st=%.3f:d=1.2,"
                      "adelay=%d:all=1,asetpts=N/SR/TB,apad=whole_dur=%.3f,atrim=0:%.3f[bg]"
                      % (n_in, b_in, span, vol, max(0, span - 1.2), int(round(b_at * 1000)), dur, dur))
            mix.append("[bg]")
            n_in += 1
    for k, (ii, o) in enumerate(ov_audio):        # 위층 조각의 소리: 입력 탐색으로 이미 잘려 있으니 at 만큼 늦춰 얹는다
        graph += (";[%d:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,asetpts=PTS-STARTPTS%s,"
                  "adelay=%d:all=1,asetpts=N/SR/TB,apad=whole_dur=%.3f,atrim=0:%.3f[ova%d]"
                  % (ii, atempo_chain(spd_of(o.get("speed"))), int(round(o["at"] * 1000)), dur, dur, k))
        mix.append("[ova%d]" % k)
    for k, a in enumerate(audios_of(short)):      # 추가 오디오 트랙(효과음·다른 낭독 등): 파일의 in~out 을 at 부터, volume 배
        if not Path(a["path"]).exists():
            continue
        inputs += ["-i", a["path"]]
        graph += (";[%d:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,atrim=%.3f:%.3f,asetpts=PTS-STARTPTS,volume=%.3f,"
                  "adelay=%d:all=1,asetpts=N/SR/TB,apad=whole_dur=%.3f,atrim=0:%.3f[aud%d]"
                  % (n_in, a["in"], a["out"], a["volume"], int(round(a["at"] * 1000)), dur, dur, k))
        mix.append("[aud%d]" % k)
        n_in += 1
    if mix:
        graph += ";%s%samix=inputs=%d:duration=first:normalize=0[aout]" % (main_a, "".join(mix), 1 + len(mix))
        audio_map = "[aout]"
    else:
        audio_map = main_a
    mv = float(st.get("master_volume") if st.get("master_volume") is not None else 1.0)   # 전체 음량(마지막에 한 번)
    if abs(mv - 1.0) > 0.005:
        graph += ";%svolume=%.3f[amaster]" % (audio_map, mv)
        audio_map = "[amaster]"
    name = "%s_%s.mp4" % (idx, safe_name(short.get("line1") or short.get("yt_title") or idx))
    dst = out / name
    for old in out.glob(idx + "_*.mp4"):
        if old != dst:
            old.unlink()
    enc, enc_args = pick_encoder()
    cmd = (["ffmpeg", "-y", "-v", "error", "-nostats", "-progress", "pipe:1"]
           + clip_inputs + inputs + ["-filter_complex", graph, "-map", "[vout]", "-map", audio_map,
            "-r", "30", "-c:v", enc] + enc_args
           + ["-pix_fmt", "yuv420p", "-profile:v", "high", "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
              "-movflags", "+faststart", str(dst)])
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=str(BASE))
    for line in proc.stdout:
        line = line.decode("utf-8", "replace").strip()
        if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
            try:
                t = int(line.split("=")[1]) / 1e6
                if on_progress:
                    on_progress(min(99, int(t * 100 / max(dur, 0.1))))
            except ValueError:
                pass
    proc.wait()
    if proc.returncode != 0:
        err = proc.stderr.read().decode("utf-8", "replace")[-800:]
        raise RuntimeError("ffmpeg 실패(%s): %s" % (idx, err))
    short["output"] = name
    short["render"] = {"at": time.time(), "encoder": enc, "size": dst.stat().st_size,
                       "duration": round(dur, 2)}
    return dst


def preview_frame(p, short, at=None):
    """편집기 카드용 스틸 한 장(구간 시작 지점)."""
    d = pdir(p["id"])
    work = d / "work"
    work.mkdir(exist_ok=True)
    dst = work / ("%s_poster.jpg" % short["id"])
    first = clips_of(short)[0]
    t = first["s"] + 1.0 if at is None else at
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "%.3f" % t, "-i", source_by_id(p, first.get("src"))["path"],
                    "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", str(dst)], check=False)
    return dst.name if dst.exists() else None


# ── 내보내기 ─────────────────────────────────────────────────────────────────

def export(p, dest, ids=None):
    """렌더된 mp4 와 shorts-upload.json(업로드 도구 입력)을 dest 폴더로. ids 를 주면 그 쇼츠만 복사하고
    목록(json)은 렌더된 전체로 쓴다."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    out = pdir(p["id"]) / "output"
    manifest = {"long_video_id": p["source"].get("video_id"), "long_title": p["source"].get("title"),
                "schedule_order_note": "예약 순서 = 이 배열 순서", "shorts": []}
    copied = []
    for s in p.get("shorts", []):
        if not s.get("output"):
            continue
        src = out / s["output"]
        if not src.exists():
            continue
        if ids is None or s["id"] in ids:
            target = dest / s["output"]
            if target.resolve() != src.resolve():      # 저장 폴더가 output 자체면 복사할 게 없다
                shutil.copy2(src, target)
            copied.append(s["output"])
        desc = s.get("description", "")
        credit = bgm_credit_line(p, s)
        if credit and credit not in desc:
            desc = desc.rstrip() + "\n\n" + credit          # CC BY 조건: 출처 표기를 설명에 넣는다
        sc = stock_credit_lines(p, s)
        if sc and sc not in desc:
            desc = desc.rstrip() + "\n\n무료 소재 출처\n" + sc          # Pexels·Pixabay: 표기 의무 없음, 예의로 붙인다
        manifest["shorts"].append({"file": s["output"], "title": s.get("yt_title", ""),
                                   "description": desc, "tags": s.get("tags", [])})
    (dest / "shorts-upload.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                             encoding="utf-8")
    return copied


# ── 자막 교정: 대본 정렬 / 영상 속 자막 OCR ─────────────────────────────────
# 자동 자막(음성 인식)은 시간은 맞지만 글자가 틀리고, 대본은 글자는 맞지만 시간이 없다.
# 둘을 붙이면 둘 다 맞는 자막이 된다. 대본이 없으면 영상에 박힌 자막을 OCR 로 읽는다.

def _norm(s):
    return re.sub(r"[\s,.!?·…\"'“”‘’\-—–()\[\]:;~<>『』「」]", "", s or "")


def split_sentences(text):
    """마크다운 대본을 낭독 문장 목록으로. 제목·지시문·서식은 버린다."""
    text = text.replace("\r", "")
    text = re.sub(r"^#.*$", "", text, flags=re.M)
    text = re.sub(r"^\s*[\(（\[【].*?[\)）\]】]\s*$", "", text, flags=re.M)   # (효과음) 같은 지시 줄
    text = re.sub(r"\*\*|__|`|^>\s?", "", text, flags=re.M)
    text = re.sub(r"^\s*[-*]\s+", "", text, flags=re.M)
    parts = re.split(r"(?<=[.?!。])\s+|\n+", text)
    return [p.strip() for p in parts if len(_norm(p)) >= 2]


def build_char_index(cues):
    """자동 자막을 이어 붙인 정규화 문자열과 글자마다의 시각. 큐 안에서는 선형 보간."""
    buf, times = [], []
    for c in cues:
        n = _norm(c["text"])
        if not n:
            continue
        dur = max(0.05, c["e"] - c["s"])
        for k in range(len(n)):
            times.append(c["s"] + dur * k / len(n))
        buf.append(n)
    return "".join(buf), times


_GOOD_BREAK = re.compile(r"[,、]$|(에서|으로|까지|부터|처럼|보다|이라|라서|니까|지만|는데|면서|은|는|이|가|을|를|에|로|도|의|와|과|고|면|서|만|랑)$")


def _good_break(w):
    """이 어절 뒤에서 자막을 끊어도 어색하지 않은가 — 쉼표나 조사·연결어미로 끝나면 그렇다."""
    if len(w) <= 1:
        return False              # 「가」「안」「잘」 같은 한 글자 어절은 조사가 아니라 동사·부사일 때가 많다 — 뒤에서 끊지 않는다
    return bool(_GOOD_BREAK.search(w))


def chunk_sentence(sent, max_chars=24):
    """한 문장을 자막 한 줄 분량으로. 쉼표 경계에서 먼저 끊고, 그 안에서는 **어절 경계**에서만 끊되
    조사·연결어미 뒤를 우선하고 조각 길이를 고르게 나눈다(2026-09-12: 12자 단위로 자르니
    「주름이 이렇게 가 / 있으면」처럼 어절 사이가 아니라 뜻이 갈라지는 자리에서 끊겨 눈에 걸렸다)."""
    sent = sent.strip()
    if len(sent) <= max_chars:
        return [sent]
    out = []
    for piece in re.split(r"(?<=[,、])\s+", sent):     # 공백 없는 쉼표(10,000)는 숫자라 안 끊는다
        piece = piece.strip()
        if not piece:
            continue
        if len(piece) <= max_chars:
            out.append(piece)
            continue
        words = piece.split()
        k = max(1, -(-len(piece) // max_chars))           # 필요한 조각 수(올림)
        target = len(piece) / k                             # 조각당 목표 글자 수 — 고르게
        pieces, cur, curlen = [], [], 0
        for i, w in enumerate(words):
            trial = curlen + (1 if cur else 0) + len(w)
            if cur and trial > max_chars:                  # 넘치면 어절 앞에서 끊는다(어절 중간 금지)
                pieces.append(" ".join(cur)); cur, curlen = [w], len(w)
            else:
                cur.append(w); curlen = trial
            rest = words[i + 1:]
            if cur and rest and curlen >= target * 0.75 and _good_break(w) and len(" ".join(rest)) >= 4:
                pieces.append(" ".join(cur)); cur, curlen = [], 0   # 목표 길이에 닿았고 끊기 좋은 자리
        if cur:
            pieces.append(" ".join(cur))
        # 꼬리가 너무 짧으면 앞에 붙이거나 앞 조각의 마지막 어절을 넘겨 받는다
        if len(pieces) >= 2 and len(pieces[-1]) <= 5:
            if len(pieces[-2]) + 1 + len(pieces[-1]) <= max_chars + 2:
                pieces[-2] = pieces[-2] + " " + pieces[-1]; pieces.pop()
            else:
                pw = pieces[-2].split()
                if len(pw) > 1:
                    moved = pw.pop(); pieces[-2] = " ".join(pw); pieces[-1] = moved + " " + pieces[-1]
        out.extend(pieces)
    merged = []   # 너무 짧은 꼬리는 앞 조각에 붙인다
    for piece in out:
        if merged and len(piece) <= 5 and len(merged[-1]) + 1 + len(piece) <= max_chars + 2:
            merged[-1] = merged[-1] + " " + piece
        else:
            merged.append(piece)
    return merged


def script_even_cues(p, short, text, min_dur=0.8):
    """낭독·자막이 없을 때: 대본 문장을 글자 수 비례로 이 쇼츠의 본편 조각 시간(원본 시각)에 고르게 깐다.
    조각 경계를 넘는 문장은 그대로 걸쳐 두고(양쪽 조각에서 각자 보임), 큐는 원본 시각 기준이라 shortCues 가 결과 시각으로 옮긴다."""
    sents = [s for s in split_sentences(text) if s.strip()]
    if not sents:
        raise RuntimeError("대본에서 문장을 찾지 못했습니다")
    segs = [(float(c["s"]), float(c["e"])) for c in clips_of(short) if (c.get("src") or "main") == "main" and float(c["e"]) > float(c["s"])]
    total = sum(e - s for s, e in segs)
    if total <= 0:
        raise RuntimeError("본편 조각이 없습니다")
    weights = [max(1, len(s.replace(" ", ""))) for s in sents]
    W = float(sum(weights))
    # 가상 시간(0~total) → 원본 시각
    def to_src(t):
        acc = 0.0
        for s, e in segs:
            if t <= acc + (e - s) + 1e-6:
                return s + (t - acc)
            acc += e - s
        return segs[-1][1]
    cues = []
    t = 0.0
    for i, (sent, w) in enumerate(zip(sents, weights)):
        d = total * w / W
        a, b = to_src(t), to_src(min(total, t + d))
        if b - a < min_dur and i < len(sents) - 1:
            b = min(to_src(total), a + min_dur)
        cues.append({"id": i, "s": round(a, 3), "e": round(max(b, a + 0.2), 3), "text": sent.strip(), "ss": i == 0, "se": True})
        t += d
    for k in range(1, len(cues)):                      # 겹침 방지: 앞 큐가 늘어나 다음 큐 시작을 넘으면 밀어 준다
        if cues[k]["s"] < cues[k - 1]["e"]:
            cues[k]["s"] = cues[k - 1]["e"]
            if cues[k]["e"] < cues[k]["s"] + 0.2:
                cues[k]["e"] = cues[k]["s"] + 0.2
    return cues


def align_script(cues, text, min_score=0.55, max_chars=24):
    """대본 문장을 자동 자막 시간축에 붙인다. 반환 (새 큐 목록, 통계)."""
    import difflib
    sents = split_sentences(text)
    hay, times = build_char_index(cues)
    n = len(hay)
    if n < 20 or not sents:
        raise RuntimeError("정렬할 자막이나 대본 문장이 부족합니다")
    sm = difflib.SequenceMatcher(autojunk=False)
    pos = 0
    hits = []            # (start_t, end_t, sentence)
    matched = 0
    for sent in sents:
        q = _norm(sent)
        L = len(q)
        if L < 2:
            continue
        win_end = min(n, pos + max(6 * L, 600))
        sm.set_seq2(q)
        best, bi = 0.0, -1
        step = 3 if L >= 12 else 1
        for i in range(pos, max(pos + 1, win_end - L + 1), step):
            sm.set_seq1(hay[i:i + L])
            if sm.real_quick_ratio() < best or sm.quick_ratio() < best:
                continue
            r = sm.ratio()
            if r > best:
                best, bi = r, i
        if bi >= 0 and step > 1:
            for i in range(max(pos, bi - step), min(win_end - L + 1, bi + step + 1)):
                sm.set_seq1(hay[i:i + L])
                r = sm.ratio()
                if r > best:
                    best, bi = r, i
        if bi < 0 or best < min_score:
            continue
        matched += 1
        s_t = times[bi]
        e_t = times[min(n - 1, bi + L - 1)]
        hits.append((s_t, max(e_t, s_t + 0.4), sent))
        pos = bi + int(L * 0.85)

    new = []   # 문장 → 자막 조각. 시간은 글자 수 비례로 나눈다
    for k, (s_t, e_t, sent) in enumerate(hits):
        nxt = hits[k + 1][0] if k + 1 < len(hits) else e_t + 1.2
        e_t = min(max(e_t, s_t + 0.6), nxt)
        pieces = chunk_sentence(sent, max_chars)
        total = sum(len(_norm(x)) or 1 for x in pieces)
        t = s_t
        for piece in pieces:
            share = (len(_norm(piece)) or 1) / total
            pe = t + (e_t - s_t) * share
            new.append({"s": round(t, 3), "e": round(pe, 3), "text": piece})
            t = pe
    filled = []   # 대본에 없는 구간(4초 넘게 빈 곳)은 자동 자막을 그대로 둔다
    for i, c in enumerate(new):
        filled.append(c)
        gap_s = c["e"]
        gap_e = new[i + 1]["s"] if i + 1 < len(new) else None
        if gap_e is not None and gap_e - gap_s > 4:
            filled += [{"s": a["s"], "e": min(a["e"], gap_e), "text": a["text"]}
                       for a in cues if a["s"] >= gap_s and a["e"] <= gap_e]
    if new:
        head = [dict(a) for a in cues if a["e"] <= new[0]["s"] - 2]
        tail = [dict(a) for a in cues if a["s"] >= new[-1]["e"] + 2]
        filled = head + filled + tail
    filled.sort(key=lambda c: c["s"])
    for k in range(len(filled) - 1):
        if filled[k]["e"] > filled[k + 1]["s"]:
            filled[k]["e"] = filled[k + 1]["s"]
    filled = [c for c in filled if c["e"] - c["s"] > 0.05 and c["text"].strip()]
    for k, c in enumerate(filled):
        c["id"] = k
    return filled, {"sentences": len(sents), "matched": matched, "cues": len(filled)}


SHOP_PROMPT = """당신은 쇼핑 쇼츠(상품 소개 세로 영상) 편집자입니다. 아래는 이 쇼츠의 낭독 대본입니다.

{script}

이 낭독에 어울리는 훅 제목과 업로드 문안을 만드세요.
- line1(흰 글자, 8~16자): 상황·질문·통념. line2(강조색, 8~16자): 반전·핵심 혜택·숫자. 낚시 금지, 낭독에 실제로 있는 내용만.
- yt_title 40자 이내 + 끝에 " #shorts". description 은 2~3문장, 그다음 줄에 해시태그 5개(첫 번째는 #Shorts). tags 는 # 없이 6~8개.
- 상품명·가격·수치는 낭독에 있는 것만 씁니다.

출력은 아래 JSON 하나만. 코드펜스·설명 없이 JSON 만 출력합니다.
{{"line1":"","line2":"","yt_title":"","description":"","tags":[""]}}
"""


def shop_copy(script, provider="claude", model=None):
    raw = run_llm(SHOP_PROMPT.format(script=script.strip()[:6000]), provider=provider, model=model, effort="low")
    try:
        return extract_json(raw)
    except JSONBroken as e:
        return extract_json(repair_json_with_llm(e.body, provider, model))


def split_even(total, lengths):
    """낭독 길이(total)를 영상 개수만큼 나누되, 짧은 영상은 제 길이까지만 쓰고 나머지를 다른 영상에 넘긴다."""
    n = len(lengths)
    share = [0.0] * n
    remaining = total
    order = sorted(range(n), key=lambda i: lengths[i])
    left = n
    for i in order:
        want = remaining / left
        share[i] = min(lengths[i], want)
        remaining -= share[i]
        left -= 1
    return share


def script_roots():
    """「대본으로 교정」이 대본을 찾는 폴더. 홈 「AI 설정」의 대본 폴더(config.json script_root). 비어 있으면 자동 찾기를 하지 않는다.
    폴더 구조는 <채널>/projects/<회차>/output/03_업로드정보.md + 01_대본.md 를 기대한다."""
    v = (load_config().get("script_root") or "").strip().strip('"')
    return [Path(v)] if v else []


def find_script(p):
    """저장소에서 이 영상의 대본(01_대본.md)을 찾는다. 업로드정보의 제목·영상 id 와 대조한다."""
    title = _norm(p["source"].get("title") or "")[:24]
    vid = p["source"].get("video_id") or ""
    if not title and not vid:
        return None
    for root in script_roots():
        if not root.exists():
            continue
        for info in root.glob("*/projects/*/output/03_업로드정보.md"):
            try:
                t = info.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if not ((vid and vid in t) or (title and title in _norm(t))):
                continue
            for name in ("01_대본.md", "01_대본.txt"):
                script = info.parent / name
                if script.exists():
                    return str(script)
    return None


def ocr_status():
    """(가능 여부, 설명). winsdk 모듈이 없는 것(파이썬 환경 문제)과 윈도에 한국어 OCR 팩이 없는 것(윈도 설정 문제)을
    구분한다 — 고치는 곳이 다르다. 예전엔 둘 다 '한국어가 없다'로 안내해 엉뚱한 곳을 찾게 했다(2026-09-12)."""
    try:
        from winsdk.windows.media.ocr import OcrEngine
        from winsdk.windows.globalization import Language
    except Exception:
        return False, "winsdk 모듈 없음 — 쇼츠컷을 .venv(또는 배포판 python) 으로 띄워야 합니다 (지금: %s)" % sys.executable
    try:
        if OcrEngine.is_language_supported(Language("ko")):
            return True, "윈도 OCR · 한국어"
        return False, "윈도에 한국어 OCR 팩이 없음 — 설정 > 시간 및 언어 > 언어 > 한국어 > 선택적 기능(OCR) 설치"
    except Exception as e:
        return False, "윈도 OCR 오류: %s" % e


def ocr_available():
    return ocr_status()[0]


def ocr_burned_subs(p, on_progress=None, band=0.30, fps=2.0, t0=None, t1=None):
    """영상 아래쪽 band 비율 영역을 fps 로 잘라 윈도 OCR(한국어)로 읽고, 같은 글이 이어지는
    프레임을 큐 하나로 묶는다. 프레임은 ffmpeg image2pipe(BMP)로 바로 받아 디스크에 안 쓴다."""
    import asyncio
    import difflib
    import struct
    from winsdk.windows.media.ocr import OcrEngine
    from winsdk.windows.globalization import Language
    from winsdk.windows.graphics.imaging import BitmapDecoder
    from winsdk.windows.storage.streams import InMemoryRandomAccessStream, DataWriter

    src = p["source"]
    dur = float(src.get("duration") or 0)
    a = 0.0 if t0 is None else max(0.0, float(t0))
    b = dur if t1 is None else min(dur, float(t1))
    total = max(1, int((b - a) * fps))
    vf = "fps=%g,crop=iw:ih*%g:0:ih*%g,scale=1280:-2" % (fps, band, 1 - band)
    cmd = ["ffmpeg", "-v", "error", "-ss", "%.3f" % a, "-to", "%.3f" % b, "-i", src["path"],
           "-vf", vf, "-f", "image2pipe", "-vcodec", "bmp", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    engine = OcrEngine.try_create_from_language(Language("ko"))
    if engine is None:
        raise RuntimeError("윈도 한국어 OCR 을 만들 수 없습니다")

    async def ocr_one(data):
        stream = InMemoryRandomAccessStream()
        w = DataWriter(stream.get_output_stream_at(0))
        w.write_bytes(data)
        await w.store_async()
        await w.flush_async()
        stream.seek(0)
        dec = await BitmapDecoder.create_async(stream)
        bmp = await dec.get_software_bitmap_async()
        res = await engine.recognize_async(bmp)
        # 자막은 잘라 낸 띠 안에서도 맨 아래쪽에 있다. 위쪽 줄(화면 속 표지판·라벨)은 버린다.
        h = bmp.pixel_height or 1
        keep = []
        for ln in res.lines:
            ys = [w.bounding_rect.y for w in ln.words] if ln.words else []
            if ys and min(ys) >= h * 0.35:
                keep.append(ln.text)
        return " ".join(keep).strip()

    def read_bmp(f):
        hdr = f.read(14)
        if len(hdr) < 14:
            return None
        size = struct.unpack("<I", hdr[2:6])[0]
        rest = f.read(size - 14)
        if len(rest) < size - 14:
            return None
        return hdr + rest

    loop = asyncio.new_event_loop()
    cues, cur = [], None
    idx = 0
    try:
        while True:
            data = read_bmp(proc.stdout)
            if data is None:
                break
            t = a + idx / fps
            idx += 1
            text = loop.run_until_complete(ocr_one(data))
            text = re.sub(r"\s+", " ", text).strip()
            n = _norm(text)
            if len(n) < 2:
                if cur:
                    cur["e"] = t
                    cues.append(cur)
                    cur = None
            elif cur and difflib.SequenceMatcher(None, _norm(cur["text"]), n).ratio() >= 0.7:
                cur["e"] = t + 1.0 / fps
                if len(n) > len(_norm(cur["text"])):
                    cur["text"] = text          # 더 온전히 읽힌 프레임의 글을 남긴다
            else:
                if cur:
                    cur["e"] = t
                    cues.append(cur)
                cur = {"s": t, "e": t + 1.0 / fps, "text": text}
            if on_progress and idx % 10 == 0:
                on_progress(min(99, int(idx * 100 / total)))
        if cur:
            cues.append(cur)
    finally:
        proc.stdout.close()
        proc.wait()
        loop.close()
    out = [c for c in cues if c["e"] - c["s"] >= 0.4]
    for k in range(len(out) - 1):
        if out[k]["e"] > out[k + 1]["s"]:
            out[k]["e"] = out[k + 1]["s"]
    for k, c in enumerate(out):
        c["id"] = k
        c["s"] = round(c["s"], 3)
        c["e"] = round(c["e"], 3)
    if len(out) < 5:
        raise RuntimeError("영상 아래쪽에서 읽어 낸 자막이 거의 없습니다(%d줄). 자막이 화면 아래 30%% 안에 있는지 확인하세요." % len(out))
    return out


# ── 파일·폴더 선택 창: tkinter 가 있으면 tk, 없으면(임베디드 파이썬 배포판) PowerShell WinForms ──────
_TK_OK = None
_PS_FILTERS = {
    "image": "이미지|*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif|모든 파일|*.*",
    "text": "대본|*.md;*.txt|모든 파일|*.*",
    "audio": "오디오|*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg|모든 파일|*.*",
    "font": "글꼴|*.ttf;*.otf|모든 파일|*.*",
    "media": "영상·이미지|*.mp4;*.mkv;*.mov;*.webm;*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif|모든 파일|*.*",
    "video": "영상|*.mp4;*.mkv;*.mov;*.webm|모든 파일|*.*",
}


def has_tk():
    global _TK_OK
    if _TK_OK is None:
        try:
            r = subprocess.run([sys.executable, "-c", "import tkinter"], capture_output=True, timeout=30)
            _TK_OK = r.returncode == 0
        except Exception:
            _TK_OK = False
    return _TK_OK


def _ps_dialog(script):
    ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; Add-Type -AssemblyName System.Windows.Forms; " + script)
    r = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps],
                       capture_output=True, timeout=600)
    out = r.stdout.decode("utf-8", "replace").strip().replace("\r", "")
    log("ps_dialog rc=%s -> %r %s" % (r.returncode, out[-80:], r.stderr.decode("utf-8", "replace")[-200:].strip()))
    return [x for x in out.split("\n") if x.strip()]


def _ps_pick(kind, multi):
    flt = _PS_FILTERS.get(kind, _PS_FILTERS["video"])
    lines = _ps_dialog("$d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = '파일 선택'; $d.Filter = '%s'; "
                       "$d.Multiselect = $%s; if ($d.ShowDialog() -eq 'OK') { $d.FileNames | ForEach-Object { $_ } }"
                       % (flt, "true" if multi else "false"))
    return lines


def pick_file(kind="image"):
    if has_tk():
        return _tk_pick_file(kind)
    r = _ps_pick(kind, False)
    return r[0] if r else ""


def pick_files(kind="video"):
    if has_tk():
        return _tk_pick_files(kind)
    return _ps_pick(kind, True)


def pick_folder(initial=""):
    if has_tk():
        return _tk_pick_folder(initial)
    init = (initial or "").replace("'", "''")
    r = _ps_dialog("$d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = '폴더 선택'; "
                   "$d.ShowNewFolderButton = $true; if ('%s') { $d.SelectedPath = '%s' }; "
                   "if ($d.ShowDialog() -eq 'OK') { $d.SelectedPath }" % (init, init))
    return r[0] if r else ""


# ── 첫 실행 점검(doctor) · 문제 신고 zip · 자동 업데이트 ─────────────────────────────────
def gpu_info():
    exe = shutil.which("nvidia-smi")
    if not exe:
        return ""
    try:
        r = subprocess.run([exe, "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
                           capture_output=True, timeout=15)
        line = r.stdout.decode("utf-8", "replace").strip().splitlines()[0] if r.stdout.strip() else ""
        return "" if (r.returncode != 0 or "Failed" in line or "NVML" in line) else line
    except Exception:
        return ""

def _mod_ok(name):
    try:
        r = subprocess.run([sys.executable, "-c", "import %s" % name], capture_output=True, timeout=120)
        return r.returncode == 0, r.stderr.decode("utf-8", "replace").strip()[-200:]
    except Exception as e:
        return False, str(e)


def doctor():
    """홈 화면 상단 점검 띠. 각 항목 {id, ok, label, detail, action}. action: ffmpeg → 자동 받기 단추, ai → AI 설정으로."""
    cfg = load_config()
    ff = ffmpeg_status()
    items = [{"id": "ffmpeg", "ok": ff["found"], "label": "ffmpeg",
              "detail": ("bin 폴더" if ff["source"] == "bin" else "PATH") + " · " + ff["version"].split(" Copyright")[0] if ff["found"] else "없음 — 렌더에 필요",
              "action": None if ff["found"] else "ffmpeg"}]
    prov = cfg.get("default_provider") or ("claude" if which("claude") else "anthropic")
    ai_ok = (prov == "claude" and bool(which("claude"))) or (prov == "anthropic" and bool(cfg.get("anthropic_key"))) \
        or (prov == "openai" and bool(cfg.get("openai_key"))) or (prov == "gemini" and bool(cfg.get("gemini_key"))) or prov == "ollama"
    if prov == "claude" and not which("claude") and cfg.get("anthropic_key"):
        ai_ok = True
    items.append({"id": "ai", "ok": ai_ok, "label": "AI", "detail": PROVIDERS.get(prov, {}).get("label", prov).split(" (")[0] + ("" if ai_ok else " · 키 없음"),
                  "action": None if ai_ok else "ai"})
    font_ok = any((FONTS / n).exists() for n in FONT_CANDIDATES) or any((SYS_FONTS / n).exists() for n in FONT_CANDIDATES)
    items.append({"id": "font", "ok": font_ok, "label": "한글 글꼴", "detail": "Noto Sans KR / 맑은 고딕" if font_ok else "없음", "action": None})
    wh_ok, wh_err = _mod_ok("faster_whisper")
    gpu = gpu_info()
    items.append({"id": "whisper", "ok": wh_ok, "label": "받아쓰기", "detail": ("GPU · " + gpu.split(",")[0] if gpu else "CPU") if wh_ok else "faster-whisper 없음(낭독 자막 불가)", "action": None})
    # 아래 둘은 모듈이 빠져도 서버는 멀쩡히 떠서 해당 단추를 눌러야만 실패가 드러났다(2026-09-12). 홈 띠에서 미리 보이게 한다.
    ocr_ok, ocr_detail = ocr_status()
    items.append({"id": "ocr", "ok": ocr_ok, "label": "영상 속 자막(OCR)", "detail": ocr_detail, "action": None})
    tts_ok, _tts_err = _mod_ok("edge_tts")
    items.append({"id": "tts", "ok": tts_ok, "label": "무료 낭독(TTS)", "detail": "엣지 TTS" if tts_ok else "edge-tts 모듈 없음 — 훅 낭독·무료 목소리 불가", "action": None})
    fl_ok, fl_detail = flow_available()      # 선택 기능이라 없어도 빨간불은 아니다. 있으면 홈 「Flow로 이미지 뽑기」가 산다
    items.append({"id": "flow", "ok": True, "label": "Flow 이미지", "detail": fl_detail if fl_ok else "미연결(선택) — 손으로 만든 이미지를 올리면 된다", "action": None})
    gk_ok, gk_detail = grok_available()
    items.append({"id": "grok", "ok": True, "label": "그록 영상", "detail": gk_detail if gk_ok else "미연결(선택) — 영상은 손으로 올리면 된다", "action": None})
    try:
        free = shutil.disk_usage(str(DATA)).free / 1e9
    except Exception:
        free = None
    items.append({"id": "disk", "ok": free is None or free > 5, "label": "디스크", "detail": ("%.0f GB 남음" % free) if free is not None else "?", "action": None})
    return {"version": VERSION, "python": sys.version.split()[0], "embedded": (BASE / "python" / "python.exe").exists(),
            "tk": has_tk(), "gpu": gpu, "items": items, "ok": all(i["ok"] for i in items)}


def report_zip():
    """logs/report-<시각>.zip — 서버 로그 꼬리·설정(키 가림)·시스템 정보·프로젝트 상태 목록. 미디어는 넣지 않는다."""
    import zipfile
    import platform
    LOGS.mkdir(exist_ok=True)
    out = LOGS / ("report-%s.zip" % time.strftime("%Y%m%d-%H%M%S"))
    cfg = {k: (("•••" + v[-4:]) if isinstance(v, str) and k.endswith("_key") and v else v) for k, v in load_config().items()}
    info = {"version": VERSION, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "os": platform.platform(), "python": sys.version,
            "executable": sys.executable, "base": str(BASE), "ffmpeg": ffmpeg_status(), "gpu": gpu_info(), "claude_cli": which("claude"),
            "doctor": doctor(), "config": cfg}
    projs = []
    for pj in sorted(PROJECTS.glob("*/project.json"))[-30:]:
        try:
            p = json.loads(pj.read_text(encoding="utf-8"))
            projs.append({"id": p.get("id"), "kind": p.get("kind"), "status": p.get("status"), "error": p.get("error"),
                          "created": p.get("created"), "shorts": len(p.get("shorts") or []), "canvas": (p.get("settings") or {}).get("canvas")})
        except Exception as e:
            projs.append({"id": pj.parent.name, "error": "읽기 실패 %s" % e})
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("info.json", json.dumps(info, ensure_ascii=False, indent=1, default=str))
        z.writestr("projects.json", json.dumps(projs, ensure_ascii=False, indent=1, default=str))
        lg = LOGS / "server.log"
        if lg.exists():
            data = lg.read_bytes()
            z.writestr("server.log", data[-2_000_000:])
        for extra in sorted(LOGS.glob("*.log")):
            if extra.name != "server.log" and extra.stat().st_size < 2_000_000:
                z.write(extra, extra.name)
    return out


# 업데이트: 매니페스트(json) 주소는 config.json update_url, 없으면 아래 기본값. 매니페스트 = {"version","url","notes","date"}
UPDATE_URL_DEFAULT = ""
_upd = {"running": False, "pct": None, "message": "", "error": None, "done": False, "latest": None}
UPDATE_KEEP = ("projects", "logs", "bin", "python", "config.json", "fonts/custom.json", "sfx/index.json", "logos", "music/custom", "uploads")


def update_url():
    return (load_config().get("update_url") or UPDATE_URL_DEFAULT or "").strip()


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3]) or (0,)



# ── 원본 영상 정리(2026-09-14) ─────────────────────────────────────────────
# 완성본 12MB 를 만들려고 원본 737MB 를 계속 쥐고 있는 프로젝트가 쌓인다.
# 실측(188개 26.5GB)에서 mp4 가 98.4%, 그중 90% 가 프로젝트 루트의 원본이었다.
# 목록을 줄이는 것으로는 1바이트도 안 준다 — 파일을 지워야 준다.
CLEAN_DAYS_DEFAULT = 30


def _clean_targets(pdir):
    """그 프로젝트에서 지워도 되는 원본 파일들. output/ work/ 안은 절대 보지 않는다."""
    out = []
    for f in pdir.glob("*.mp4"):
        n = f.name
        if n == "source.mp4" or n.startswith("src_"):
            out.append(f)
    return out


def _has_render(pdir):
    """렌더 결과가 실제 파일로 있는가. project.json 의 기록이 아니라 파일을 본다."""
    o = pdir / "output"
    return o.is_dir() and any(o.rglob("*.mp4"))


def cleanup_scan(days=None):
    """지울 수 있는 원본을 훑는다. 지우지는 않는다."""
    days = CLEAN_DAYS_DEFAULT if days is None else max(0, int(days))
    cutoff = time.time() - days * 86400
    items, total = [], 0
    used = 0
    if not PROJECTS.exists():
        return {"days": days, "items": [], "total": 0, "count": 0, "used": 0, "projects": 0}
    nproj = 0
    for d in sorted(PROJECTS.iterdir()):
        if not d.is_dir():
            continue
        nproj += 1
        for f in d.rglob("*"):
            if f.is_file():
                try:
                    used += f.stat().st_size
                except OSError:
                    pass
        try:
            p = load(d.name)
        except Exception:
            continue
        created = p.get("created") or 0
        if created > cutoff:
            continue
        if not _has_render(d):
            continue
        files = _clean_targets(d)
        if not files:
            continue
        size = 0
        for f in files:
            try:
                size += f.stat().st_size
            except OSError:
                pass
        if not size:
            continue
        title = ((p.get("shorts") or [{}])[0].get("line1") or "").strip() or d.name
        items.append({"id": d.name, "title": title[:40], "files": len(files),
                      "size": size, "created": created})
        total += size
    items.sort(key=lambda x: -x["size"])
    return {"days": days, "items": items, "total": total, "count": len(items),
            "used": used, "projects": nproj}


def cleanup_apply(ids):
    """스캔이 돌려준 id 만 지운다. 목록에 없는 것은 건드리지 않는다."""
    ids = [i for i in (ids or []) if isinstance(i, str) and i]
    if not ids:
        return {"freed": 0, "removed": 0, "projects": 0}
    freed = removed = done = 0
    for pid in ids:
        d = PROJECTS / pid
        if not d.is_dir() or d.parent != PROJECTS:      # 경로 탈출 방지
            continue
        if not _has_render(d):                          # 스캔 뒤 상태가 바뀌었으면 건너뛴다
            continue
        hit = False
        for f in _clean_targets(d):
            try:
                sz = f.stat().st_size
                f.unlink()
                freed += sz
                removed += 1
                hit = True
            except OSError:
                pass
        if hit:
            done += 1
    return {"freed": freed, "removed": removed, "projects": done}


# ── 대본 AI 생성(2026-09-14) ──────────────────────────────────────────────
# 낭독으로 바로 넘어가는 글이라 **읽을 문장만** 나와야 한다. 제목·소제목·번호·
# 괄호 지시문이 섞이면 TTS 가 「1장」 「밝게」 같은 걸 그대로 읽는다.
SCRIPT_KINDS = {
    "info":    "정보 전달. 사실과 이유를 차분히 설명한다",
    "review":  "제품·서비스 사용 안내. 쓰임새와 주의점을 알려 준다",
    "story":   "이야기. 사건을 시간 순으로 풀되 담백하게",
    "howto":   "방법 안내. 순서대로 따라 할 수 있게",
}
CHARS_PER_MIN = 350          # 한국어 낭독 대략치. 실제는 목소리·속도에 따라 다르다


def write_script_ai(topic, kind="info", minutes=3, keywords="", audience="", provider=None, model=None):
    """주제 몇 줄 → 낭독용 대본. 연결해 둔 AI 를 그대로 쓴다."""
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("무엇에 대한 영상인지 한 줄이라도 적어 주세요.")
    try:
        minutes = max(1, min(20, float(minutes or 3)))
    except Exception:
        minutes = 3
    target = int(minutes * CHARS_PER_MIN)
    cfg = load_config()
    provider = provider or cfg.get("default_provider") or "claude"
    model = model or cfg.get("default_model") or None

    tone = SCRIPT_KINDS.get(kind, SCRIPT_KINDS["info"])
    extra = []
    if keywords.strip():
        extra.append("다음 낱말을 자연스럽게 넣습니다: " + keywords.strip())
    if audience.strip():
        extra.append("보는 사람: " + audience.strip())

    prompt = "\n".join([
        "영상 낭독용 한국어 대본을 씁니다.",
        "",
        "주제: " + topic,
        "성격: " + tone,
        "분량: 공백 포함 %d자 이상 %d자 안팎 (낭독 약 %g분). 짧게 끝내지 말고 이 분량을 채웁니다." % (int(target * 0.9), int(target * ASK_FACTOR), minutes),
    ] + extra + [
        "",
        "지켜야 할 것",
        "1. 소리 내어 읽을 문장만 씁니다. 제목·소제목·장 번호·괄호 안 지시문·말머리 기호를 넣지 않습니다.",
        "2. 첫 두 문장 안에 무엇에 대한 이야기인지 드러냅니다.",
        "3. 한 문장을 길게 늘이지 않습니다. 읽다가 숨이 차면 나눕니다.",
        "4. 확인되지 않은 수치나 통계를 지어내지 않습니다. 꼭 필요하면 '알려진 바로는' 처럼 여지를 둡니다.",
        "5. 마지막은 정리 한두 문장으로 닫습니다. 구독·좋아요 요청은 넣지 않습니다.",
        "",
        "대본 본문만 출력합니다. 설명이나 머리말을 붙이지 마세요.",
    ])

    out = (run_llm(prompt, provider=provider, model=model) or "").strip()
    # 모델이 코드블록으로 감싸는 경우가 있다
    if out.startswith("```"):
        out = out.split("\n", 1)[-1]
        if out.rstrip().endswith("```"):
            out = out.rstrip()[:-3]
    out = out.strip()
    if not out:
        raise RuntimeError("AI 가 빈 응답을 돌려줬습니다. 「AI 설정」을 확인해 주세요.")
    n = len(out)
    return {"script": out, "chars": n, "minutes": round(n / CHARS_PER_MIN, 1), "target": target}


# ── 긴 대본은 나눠 쓴다(2026-09-14) ───────────────────────────────────────
SECTION_CHARS = 900           # 한 조각의 목표 자수. 작을수록 요청한 길이에 가깝게 나온다
ASK_FACTOR = 1.25             # 모델이 요청보다 짧게 쓴다(실측 ~83%). 그만큼 더 달라고 한다
SINGLE_MAX = 2200             # 이보다 짧으면 한 번에 쓴다(나눌 이유가 없다)


def _outline(topic, kind, n, keywords, audience, provider, model):
    """소제목 n개. 낭독에는 안 들어가고, 조각을 나누는 뼈대로만 쓴다."""
    tone = SCRIPT_KINDS.get(kind, SCRIPT_KINDS["info"])
    extra = []
    if (keywords or "").strip():
        extra.append("이 낱말들이 어딘가에 들어가야 합니다: " + keywords.strip())
    if (audience or "").strip():
        extra.append("보는 사람: " + audience.strip())
    prompt = "\n".join([
        "영상 대본의 뼈대를 짭니다.",
        "",
        "주제: " + (topic or "").strip(),
        "성격: " + tone,
        "",
        "이야기가 흘러갈 순서를 %d 토막으로 나누고, 각 토막에서 무엇을 말할지" % n,
        "한 줄씩 적습니다. 앞 토막이 뒤 토막의 바탕이 되도록 순서를 정합니다.",
    ] + extra + [
        "",
        "%d 줄만 출력합니다. 번호·기호·설명을 붙이지 마세요." % n,
    ])
    out = (run_llm(prompt, provider=provider, model=model) or "").strip()
    lines = []
    for ln in out.split("\n"):
        t = ln.strip().lstrip("-•*0123456789.) ").strip()
        if t:
            lines.append(t)
    return lines[:n] or ["%s 에 대하여" % topic] * n


def _section(topic, kind, head, idx, total, target, prev_tail, keywords, audience, provider, model):
    """한 토막의 본문. 앞 토막 끝을 받아 이어 쓴다."""
    where = ("여는 부분입니다. 무엇에 대한 이야기인지 첫 두 문장 안에 드러냅니다."
             if idx == 0 else
             "마지막 부분입니다. 정리 한두 문장으로 닫습니다. 구독·좋아요 요청은 넣지 않습니다."
             if idx == total - 1 else
             "가운데 부분입니다. 인사나 새로운 도입 없이 앞 이야기를 이어서 씁니다.")
    extra = []
    if prev_tail:
        extra += ["", "바로 앞 문장은 이렇게 끝났습니다. 자연스럽게 이어 주세요:", '"' + prev_tail + '"']
    if (keywords or "").strip() and idx == 0:
        extra.append("이 낱말을 자연스럽게 넣습니다: " + keywords.strip())
    prompt = "\n".join([
        "영상 낭독용 한국어 대본의 한 토막을 씁니다. 전체 %d 토막 중 %d 번째입니다." % (total, idx + 1),
        "",
        "전체 주제: " + (topic or "").strip(),
        "이 토막에서 말할 것: " + head,
        "분량: 공백 포함 %d자 이상 %d자 안팎. 짧게 끝내지 말고 이 분량을 채웁니다." % (int(target * 0.9), int(target * ASK_FACTOR)),
        where,
    ] + extra + [
        "",
        "지켜야 할 것",
        "1. 소리 내어 읽을 문장만 씁니다. 제목·소제목·번호·괄호 지시문·말머리 기호를 넣지 않습니다.",
        "2. 한 문장을 길게 늘이지 않습니다. 읽다가 숨이 차면 나눕니다.",
        "3. 확인되지 않은 수치나 통계를 지어내지 않습니다.",
        "4. 앞 토막에서 한 말을 되풀이하지 않습니다.",
        "",
        "본문만 출력합니다.",
    ])
    out = (run_llm(prompt, provider=provider, model=model) or "").strip()
    if out.startswith("```"):
        out = out.split("\n", 1)[-1]
        if out.rstrip().endswith("```"):
            out = out.rstrip()[:-3]
    return out.strip()


def write_script_long(topic, kind="info", minutes=12, keywords="", audience="",
                      provider=None, model=None, on_progress=None):
    """긴 대본 — 개요를 짜고 토막마다 써서 이어붙인다."""
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("무엇에 대한 영상인지 한 줄이라도 적어 주세요.")
    try:
        minutes = max(1, min(60, float(minutes or 12)))
    except Exception:
        minutes = 12
    target = int(minutes * CHARS_PER_MIN)
    cfg = load_config()
    provider = provider or cfg.get("default_provider") or "claude"
    model = model or cfg.get("default_model") or None

    def prog(pct, msg):
        if on_progress:
            try:
                on_progress(pct, msg)
            except Exception:
                pass

    if target <= SINGLE_MAX:                       # 짧으면 나눌 이유가 없다
        prog(10, "대본을 쓰는 중…")
        r = write_script_ai(topic, kind, minutes, keywords, audience, provider, model)
        prog(100, "")
        return r

    n = max(2, min(12, round(target / SECTION_CHARS)))
    per = int(target / n)
    prog(5, "뼈대를 짜는 중… (%d 토막)" % n)
    heads = _outline(topic, kind, n, keywords, audience, provider, model)

    parts, tail = [], ""
    for i, h in enumerate(heads):
        prog(int(10 + 85 * i / n), "%d/%d 토막 쓰는 중… — %s" % (i + 1, n, h[:24]))
        try:
            body = _section(topic, kind, h, i, n, per, tail, keywords, audience, provider, model)
        except Exception as e:
            raise RuntimeError("%d번째 토막에서 실패했습니다: %s" % (i + 1, e))
        if body:
            parts.append(body)
            tail = body.strip().split("\n")[-1][-60:]
    out = "\n\n".join(parts).strip()
    if not out:
        raise RuntimeError("AI 가 빈 응답을 돌려줬습니다. 「AI 설정」을 확인해 주세요.")
    prog(100, "")
    nchars = len(out)
    return {"script": out, "chars": nchars, "minutes": round(nchars / CHARS_PER_MIN, 1),
            "target": target, "sections": n}

def update_check(timeout=15):
    import urllib.request
    url = update_url()
    if not url:
        return {"configured": False, "current": VERSION}
    req = urllib.request.Request(url + ("&" if "?" in url else "?") + "t=%d" % int(time.time()), headers={"User-Agent": "shortscut/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        m = json.loads(r.read().decode("utf-8"))
    latest = str(m.get("version") or "")
    import urllib.parse
    m["url"] = urllib.parse.urljoin(url, m.get("url") or "")        # 매니페스트 옆의 상대 경로도 허용
    avail = _ver_tuple(latest) > _ver_tuple(VERSION)
    _upd["latest"] = m
    return {"configured": True, "current": VERSION, "latest": latest, "available": avail, "notes": m.get("notes", ""),
            "date": m.get("date", ""), "url": m.get("url", ""), "size": m.get("size")}


def _keep(rel):
    rel = rel.replace("\\", "/")
    return any(rel == k or rel.startswith(k + "/") for k in UPDATE_KEEP)


def update_apply(url=None, restart=True):
    """zip 을 받아 프로젝트·설정·bin·python 을 빼고 덮어쓴 뒤 서버를 다시 띄운다. 진행은 _upd 에."""
    import urllib.request
    import zipfile
    if _upd["running"]:
        return False
    url = url or (_upd.get("latest") or {}).get("url") or ""
    if not url:
        raise RuntimeError("업데이트 주소가 없습니다. 먼저 「업데이트 확인」을 하세요.")
    _upd.update(running=True, pct=0, message="내려받는 중", error=None, done=False)

    def work():
        try:
            LOGS.mkdir(exist_ok=True)
            tmp = LOGS / "update.zip"
            req = urllib.request.Request(url, headers={"User-Agent": "shortscut/" + VERSION})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    chunk = r.read(1 << 18)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    if total:
                        _upd["pct"] = round(got / total * 90, 1)
            _upd.update(message="파일 바꾸는 중", pct=92)
            with zipfile.ZipFile(tmp) as z:
                names = z.namelist()
                # zip 맨 위에 폴더 하나가 있으면(shortscut-1.2.0/...) 그 아래를 루트로 본다
                root = ""
                tops = {n.split("/")[0] for n in names if "/" in n}
                if "server.py" not in names and len(tops) == 1:
                    root = tops.pop() + "/"
                if root + "server.py" not in names:
                    raise RuntimeError("업데이트 zip 에 server.py 가 없습니다")
                new_ver = ""
                for n in names:
                    if not n.startswith(root) or n.endswith("/"):
                        continue
                    rel = n[len(root):]
                    if _keep(rel) or rel.startswith("__pycache__") or "/__pycache__/" in rel:
                        continue
                    dst = BASE / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(n) as src, open(dst, "wb") as f:
                        shutil.copyfileobj(src, f)
                    if rel == "VERSION":
                        new_ver = z.read(n).decode("utf-8").strip()
            try:
                tmp.unlink()
            except Exception:
                pass
            _upd.update(message="완료 · %s → %s. 다시 시작합니다" % (VERSION, new_ver or "?"), pct=100, done=True)
            log("업데이트 적용 %s → %s" % (VERSION, new_ver))
            if restart:
                threading.Timer(1.0, restart_server).start()
        except Exception as e:
            _upd.update(error=str(e), message="실패")
            log("업데이트 실패: %s" % e)
        finally:
            _upd["running"] = False

    threading.Thread(target=work, daemon=True).start()
    return True


def update_state():
    return dict(_upd)


def restart_server():
    """3초 뒤 같은 파이썬으로 server.py 를 다시 띄우고 이 프로세스는 끝낸다(포트가 비어야 새 것이 뜬다).
    cmd 의 timeout/ping 은 콘솔 없는 프로세스에서 멈추는 일이 있어(2026-09-06 실측) 파이썬 자신을 지연 실행기로 쓴다."""
    exe = sys.executable
    pyw = Path(exe).with_name("pythonw.exe")
    if pyw.exists():
        exe = str(pyw)
    args = [a for a in sys.argv[1:] if a != "--no-browser"] + ["--no-browser"]     # --port 같은 인자를 그대로 물려준다
    flags = (0x00000008 | 0x00000200) if sys.platform == "win32" else 0            # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    code = ("import time,subprocess;time.sleep(3);"
            "subprocess.Popen(%r,cwd=%r,creationflags=%d,close_fds=True)" % ([exe, str(BASE / "server.py")] + args, str(BASE), flags))
    subprocess.Popen([exe, "-c", code], cwd=str(BASE), creationflags=flags, close_fds=True)
    log("재시작 예약: %s %s" % (exe, " ".join(args)))
    threading.Timer(0.5, lambda: os._exit(0)).start()


# ── 폰에서 쓰기(LAN) ────────────────────────────────────────────────
UPLOADS = DATA / "uploads"


def lan_ips():
    """이 PC 의 IPv4 주소들(루프백 제외). 기본 경로로 나가는 주소를 앞에 둔다."""
    import socket
    out = []
    try:
        sck = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sck.connect(("8.8.8.8", 80))
        out.append(sck.getsockname()[0])
        sck.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in out and not ip.startswith("127."):
                out.append(ip)
    except Exception:
        pass
    return out


def gen_pin():
    import random
    return "%04d" % random.randint(0, 9999)


def lan_state(port=8796):
    cfg = load_config()
    ips = lan_ips()
    return {"enabled": bool(cfg.get("lan_enabled")), "pin": cfg.get("lan_pin") or "", "ips": ips, "port": port,
            "urls": ["http://%s:%d/m" % (ip, port) for ip in ips]}


def safe_upload_name(name):
    name = re.sub(r"[\\/:*?\"<>|\x00-\x1f]+", "_", (name or "file").strip())[-120:] or "file"
    return name

# ───────── 무료 소재(Pexels · Pixabay) — 2026-09-14. 키는 config.json pexels_key / pixabay_key(사용자 본인 무료 키)
STOCK_UA = "shortscut/1.0 (https://shortscut.kr)"


def _has_hangul(s):
    return any("가" <= ch <= "힣" for ch in (s or ""))


def stock_query_en(q):
    """한글 검색어를 영어 스톡 검색어로. AI 가 없거나 실패하면 원문 그대로(픽사베이는 lang=ko 로 어차피 된다)."""
    q = (q or "").strip()
    if not q or not _has_hangul(q):
        return q
    try:
        cfg = load_config()
        out = run_llm("Translate this Korean stock-footage search into 2-4 English keywords. Output only the keywords, no quotes, no punctuation: " + q,
                      provider=cfg.get("default_provider") or "claude", effort="low")
        out = " ".join(str(out or "").strip().splitlines()[0].split())[:80]
        return out if out and not _has_hangul(out) else q
    except Exception:
        return q


def _http_json(url, headers=None, timeout=20):
    import urllib.request
    req = urllib.request.Request(url, headers=dict({"User-Agent": STOCK_UA}, **(headers or {})))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def stock_search(q, kind="video", src="pexels", page=1, per_page=24):
    """→ {"items":[{id,src,kind,thumb,preview,url,w,h,duration,author,page_url,title}], "query_en", "total"} 또는 {"error"}"""
    import urllib.parse
    cfg = load_config(); q = (q or "").strip(); page = max(1, int(page or 1)); items = []
    if not q:
        return {"items": [], "query_en": "", "total": 0}
    if src == "pixabay":
        key = (cfg.get("pixabay_key") or "").strip()
        if not key:
            return {"error": "픽사베이 키가 없습니다. 홈 「무료 소재 키」에 넣어 주세요(pixabay.com/api/docs 에서 무료 발급)."}
        base = "https://pixabay.com/api/videos/" if kind == "video" else "https://pixabay.com/api/"
        qs = {"key": key, "q": q[:100], "page": page, "per_page": per_page, "safesearch": "true"}
        if _has_hangul(q):
            qs["lang"] = "ko"
        if kind != "video":
            qs["image_type"] = "photo"
        d = _http_json(base + "?" + urllib.parse.urlencode(qs))
        for h in d.get("hits") or []:
            if kind == "video":
                vs = h.get("videos") or {}; best = vs.get("large") or vs.get("medium") or vs.get("small") or {}
                small = vs.get("tiny") or vs.get("small") or best
                items.append({"id": "pixabay-v%s" % h.get("id"), "src": "pixabay", "kind": "video", "thumb": (small.get("thumbnail") or ""),
                              "preview": small.get("url") or "", "url": best.get("url") or "", "w": best.get("width"), "h": best.get("height"),
                              "duration": h.get("duration"), "author": h.get("user") or "", "page_url": h.get("pageURL") or "",
                              "title": (h.get("tags") or "")[:60]})
            else:
                items.append({"id": "pixabay-p%s" % h.get("id"), "src": "pixabay", "kind": "photo", "thumb": h.get("previewURL") or "",
                              "preview": "", "url": h.get("largeImageURL") or h.get("webformatURL") or "", "w": h.get("imageWidth"), "h": h.get("imageHeight"),
                              "duration": None, "author": h.get("user") or "", "page_url": h.get("pageURL") or "", "title": (h.get("tags") or "")[:60]})
        return {"items": items, "query_en": q, "total": d.get("totalHits") or 0}
    key = (cfg.get("pexels_key") or "").strip()
    if not key:
        return {"error": "Pexels 키가 없습니다. 홈 「무료 소재 키」에 넣어 주세요(pexels.com/api 에서 무료 발급)."}
    qe = stock_query_en(q)
    if kind == "video":
        d = _http_json("https://api.pexels.com/videos/search?" + urllib.parse.urlencode({"query": qe, "per_page": per_page, "page": page}), {"Authorization": key})
        for v in d.get("videos") or []:
            files = sorted([f for f in (v.get("video_files") or []) if (f.get("file_type") or "").startswith("video/mp4")], key=lambda f: (f.get("width") or 0) * (f.get("height") or 0))
            best = next((f for f in reversed(files) if max(f.get("width") or 0, f.get("height") or 0) <= 1920), files[-1] if files else {})
            small = next((f for f in files if max(f.get("width") or 0, f.get("height") or 0) >= 480), files[0] if files else {})
            items.append({"id": "pexels-v%s" % v.get("id"), "src": "pexels", "kind": "video", "thumb": v.get("image") or "", "preview": small.get("link") or "",
                          "url": best.get("link") or "", "w": best.get("width"), "h": best.get("height"), "duration": v.get("duration"),
                          "author": (v.get("user") or {}).get("name") or "", "page_url": v.get("url") or "", "title": ""})
    else:
        d = _http_json("https://api.pexels.com/v1/search?" + urllib.parse.urlencode({"query": qe, "per_page": per_page, "page": page}), {"Authorization": key})
        for ph in d.get("photos") or []:
            srcs = ph.get("src") or {}
            items.append({"id": "pexels-p%s" % ph.get("id"), "src": "pexels", "kind": "photo", "thumb": srcs.get("medium") or srcs.get("small") or "",
                          "preview": "", "url": srcs.get("large2x") or srcs.get("large") or srcs.get("original") or "", "w": ph.get("width"), "h": ph.get("height"),
                          "duration": None, "author": ph.get("photographer") or "", "page_url": ph.get("url") or "", "title": (ph.get("alt") or "")[:60]})
    return {"items": items, "query_en": qe, "total": d.get("total_results") or 0}


def stock_get(p, item):
    """고른 소재를 프로젝트 media/ 에 내려받아 add_source 로 등록한다. → source 항목(제목·출처 포함)"""
    import urllib.request
    import re as _re
    url = (item.get("url") or "").strip()
    if not url.startswith("http"):
        raise RuntimeError("내려받을 주소가 없습니다")
    d = pdir(p["id"]) / "media"; d.mkdir(exist_ok=True)
    sid = _re.sub(r"[^A-Za-z0-9_-]", "", str(item.get("id") or "x"))[:40] or "x"
    ext = ".mp4" if item.get("kind") == "video" else (".png" if ".png" in url.lower() else ".jpg")
    dst = d / ("stock_%s%s" % (sid, ext))
    if not dst.exists():
        tmp = dst.with_suffix(dst.suffix + ".part")
        req = urllib.request.Request(url, headers={"User-Agent": STOCK_UA})
        with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f, 1 << 20)
        tmp.replace(dst)
    src = add_source(p, dst)
    src["title"] = (item.get("title") or "").strip() or ("%s %s" % (item.get("src") or "stock", item.get("kind") or ""))
    src["stock"] = {"src": item.get("src"), "author": item.get("author") or "", "page_url": item.get("page_url") or "", "id": item.get("id")}
    src["original_path"] = str(dst)
    return src


def audio_lib_add(p, paths):
    """오디오 파일을 프로젝트 media/ 에 복사해 p['audio_lib'] 에 둔다(트랙에는 아직 안 놓음 — 소재함용). → 추가된 항목들"""
    import uuid
    d = pdir(p["id"]) / "media"; d.mkdir(exist_ok=True)
    lib = p.setdefault("audio_lib", []); added = []
    for fp in paths:
        src = Path(str(fp).strip().strip('"'))
        if not src.exists():
            continue
        aid = "a" + uuid.uuid4().hex[:6]
        dst = d / ("aud_%s%s" % (aid, src.suffix.lower() or ".mp3"))
        shutil.copy2(str(src), str(dst))
        try:
            dur = float(audio_duration(dst) or 0)
        except Exception:
            dur = 0.0
        it = {"id": aid, "kind": "audio", "path": str(dst), "file": dst.name, "url": "/media/%s/media/%s" % (p["id"], dst.name),
              "title": src.stem[:40], "duration": round(dur, 2), "original_path": str(src)}
        lib.append(it); added.append(it)
    return added


# ───────── 효과 미리보기(왼쪽 「효과」 탭) — 두 장의 샘플 그림으로 270×480 짧은 mp4 를 만들어 cache/fxprev/ 에 둔다(2026-09-14)
FX_DIR = BASE / "fx"


def fx_preview(kind, name):
    """kind: tr(씬 전환) · in(들어오기) · out(나가기). 없으면 만들고 경로를 돌려준다. 못 만들면 None."""
    import re as _re
    name = _re.sub(r"[^a-z]", "", (name or "").lower())
    if not name or (kind == "tr" and name not in TRANSITIONS) or (kind in ("in", "out") and name not in OVERLAY_FX_NAMES):
        return None
    d = DATA / "cache" / "fxprev"; d.mkdir(parents=True, exist_ok=True)
    out = d / ("%s_%s.mp4" % (kind, name))
    if out.exists() and out.stat().st_size > 1000:
        return out
    a, b = FX_DIR / "sample_a.jpg", FX_DIR / "sample_b.jpg"
    if not (a.exists() and b.exists()):
        return None
    W, H, fps = 270, 480, 24
    if kind == "tr":
        if name == "random":
            name = "fade"
        if name == "none":
            fc = "[0:v][1:v]concat=n=2:v=1:a=0[v]"
        else:
            fc = "[0:v][1:v]xfade=transition=%s:duration=0.8:offset=0.5[v]" % name
        cmd = ["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", "1.3", "-framerate", str(fps), "-i", str(a),
               "-loop", "1", "-t", "1.3", "-framerate", str(fps), "-i", str(b), "-filter_complex", fc + ";[v]format=yuv420p[o]", "-map", "[o]"]
    else:
        o = {"at": 0.4, "s": 0.0, "e": 1.6, "fx_in": {"type": name, "dur": 0.6} if kind == "in" else {}, "fx_out": {"type": name, "dur": 0.6} if kind == "out" else {}}
        fxc, fmt, ox, oy = overlay_fx_chain(o, 1.6, W, H, 0, 0)
        fc = ("[1:v]setpts=PTS-STARTPTS,scale=%d:%d,fps=%d,format=yuv420p,setsar=1%s,%ssetpts=PTS+0.4/TB[bv];"
              "[0:v][bv]overlay=x='%s':y='%s':eof_action=pass:enable='between(t,0.4,2.0)',format=yuv420p[o]" % (W, H, fps, fxc, fmt, ox, oy))
        cmd = ["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", "2.2", "-framerate", str(fps), "-i", str(a),
               "-loop", "1", "-t", "1.6", "-framerate", str(fps), "-i", str(b), "-filter_complex", fc, "-map", "[o]"]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not out.exists():
        return None
    return out

