# -*- coding: utf-8 -*-
"""상품 쇼츠 — 상품 URL(또는 붙여넣은 상품 정보) 하나로 세로 쇼츠 한 편.

단계
  new       작업 폴더를 만든다
  research  상품 페이지에서 이름·가격·특징을 긁는다(막히면 --text 로 붙여넣기)
  script    AI 가 신 단위 대본을 쓴다 (product = 6신 광고 / faction = 8신 썰)
  voice     edge-TTS 로 신마다 낭독을 만들고 이어 붙인다. 배속은 음높이를 지킨다
  align     faster-whisper 로 낭독을 받아써 자막 큐를 만든다
  sheet     신 3개를 한 장에 담는 이미지 시트 프롬프트와 영상 프롬프트를 쓴다
  split     받아 온 시트 이미지를 3등분해 신 이미지로 자른다
  stills    신 이미지를 느린 확대 영상으로 (플로우 크레딧이 없을 때)
  render    신 영상(없으면 신 이미지)에 낭독·자막을 얹어 1080x1920 mp4 를 만든다

  auto      new → research → script → voice → align → sheet 까지 한 번에

pipeline.py 의 TTS·음성 인식·자막 그리기·ffmpeg 경로 해결을 그대로 쓴다.
작업물은 products/<id>/ 아래에 남는다.

이미지·영상 생성만 사람 손이 필요하다(구글 플로우). sheet 가 써 준
prompts.md 를 그대로 붙여 넣고, 받은 파일을 sheets/ · clips/ 에 넣은 뒤
split → render 로 이어 간다.
"""
import argparse
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw

import pipeline as P

BASE = Path(__file__).resolve().parent
PRODUCTS = P.DATA / "products"          # 생성물은 data_root(O:\\shortscut 등) 아래

W, H = 1080, 1920
SUB_SIZE = 74               # 자막 글자 크기(1080 폭 기준)
SUB_MAXW = 900
SUB_CY = 1180               # 자막 첫 줄 윗변 y — 가운데보다 조금 아래
GAP = 0.35                  # 신과 신 사이 숨 쉬는 간격(초). 0.18 은 문장이 붙어 들려 0.35 로(2026-09-12 사용자)
TAIL = 1.2                  # 마지막 문장 뒤 여운(초). 없으면 낭독이 끝나자마자 영상이 끊긴다

LANES = {
    "product": {
        "scenes": 6,
        "name": "상품 광고",
        "brief": (
            "6개 신으로 30~35초짜리 상품 광고 쇼츠를 쓴다. 낭독 전체 240~280자(8자/초), 신마다 35~50자 — 짧으면 제품이 뭔지 알기 전에 끝난다(특가30초 편집규칙 §54).\n"
            "1신 훅(문제 상황이나 반전 한 문장, 3초 안에 끝난다) / 2신 공감·확대 / "
            "3신 상품 등장 / 4신 핵심 장점 / 5신 사용 장면·후기 근거 / 6신 마무리 행동 유도.\n"
        ),
    },
    "faction": {
        "scenes": 8,
        "name": "썰",
        "brief": (
            "8개 신으로 30~35초짜리 이야기형 쇼츠를 쓴다.\n"
            "1~2신 발단(안 믿기는 사실 한 줄로 시작) / 3~4신 전개 / 5~6신 절정·반전 / "
            "7신 그래서 지금 이 제품 / 8신 마무리.\n"
            "이야기는 확인된 사실만 쓴다. 확인 못 한 일화는 아예 빼고, "
            "'~라고 전해진다'처럼 전승임을 밝힐 수 있는 것만 남긴다. "
            "지어낸 사실을 사실처럼 말하지 않는다.\n"
        ),
    },
}


try:                    # 윈도 콘솔 기본값 cp949 는 —·… 같은 글자에서 죽는다
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, OSError):
    pass


def log(*a):
    print(*a, flush=True)


# ── 작업 폴더 ──────────────────────────────────────────────────────────────

def pdir(pid):
    return PRODUCTS / pid


def load(pid):
    return json.loads((pdir(pid) / "meta.json").read_text(encoding="utf-8"))


def save(m):
    d = pdir(m["id"])
    d.mkdir(parents=True, exist_ok=True)
    (d / "meta.json").write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
    return m


def latest_pid():
    ds = sorted((d.name for d in PRODUCTS.glob("*") if (d / "meta.json").exists()), reverse=True)
    if not ds:
        raise SystemExit("작업 폴더가 없습니다. 먼저 new 로 만드세요.")
    return ds[0]


def new_project(lane="product", url="", note=""):
    pid = datetime.now().strftime("%Y%m%d-%H%M%S")
    m = {"id": pid, "lane": lane, "url": url, "note": note,
         "created": datetime.now().isoformat(timespec="seconds"), "speed": 1.0}
    d = pdir(pid)
    for sub in ("sheets", "scenes", "clips", "audio", "work", "output"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    save(m)
    log("작업 폴더:", d)
    return m


# ── 1. 상품 조사 ───────────────────────────────────────────────────────────

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/140.0.0.0 Safari/537.36")


def fetch_html(url, timeout=20):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.8",
        "Referer": "https://www.google.com/",
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    enc = "utf-8"
    mt = re.search(rb'charset=["\']?([\w-]+)', raw[:4000], re.I)
    if mt:
        enc = mt.group(1).decode("ascii", "ignore")
    return raw.decode(enc, "replace")


def meta_of(html, *names):
    for n in names:
        m = re.search(r'<meta[^>]+(?:property|name)=["\']%s["\'][^>]*content=["\'](.*?)["\']' % re.escape(n),
                      html, re.I | re.S)
        if not m:
            m = re.search(r'<meta[^>]+content=["\'](.*?)["\'][^>]*(?:property|name)=["\']%s["\']' % re.escape(n),
                          html, re.I | re.S)
        if m:
            return unescape(m.group(1)).strip()
    return ""


def unescape(s):
    import html as _h
    return _h.unescape(re.sub(r"<[^>]+>", " ", s or ""))


def visible_text(html, limit=6000):
    body = re.sub(r"(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", html)
    body = re.sub(r"(?s)<[^>]+>", " ", body)
    body = unescape(body)
    body = re.sub(r"[ \t ]+", " ", body)
    body = re.sub(r"\n\s*\n+", "\n", body)
    return body.strip()[:limit]


def research(pid, text="", images=()):
    """상품 정보를 모아 research.md 로 남긴다. 페이지가 막히면 붙여넣은 --text 를 쓴다."""
    m = load(pid)
    d = pdir(pid)
    parts, imgs = [], []
    if text:
        parts.append("## 붙여넣은 정보\n" + text.strip())
    url = m.get("url") or ""
    if url:
        try:
            html = fetch_html(url)
            title = meta_of(html, "og:title", "twitter:title") or ""
            desc = meta_of(html, "og:description", "description") or ""
            og = meta_of(html, "og:image")
            if og:
                imgs.append(og)
            body = visible_text(html)
            parts.append("## 페이지에서 읽은 것\n- 제목: %s\n- 설명: %s\n\n%s" % (title, desc, body))
            log("페이지 %d자 읽음" % len(body))
        except (urllib.error.URLError, urllib.error.HTTPError, OSError) as e:
            log("페이지를 읽지 못했습니다(%s). 쿠팡·네이버처럼 봇을 막는 곳은 정상입니다." % e)
            log("→ 브라우저에서 상품 정보를 복사해 --text 로 넘기거나, ChatGPT·제미나이에")
            log("   URL 을 주고 '효과·효능·홍보 포인트 정리해 줘' 한 결과를 붙여 넣으세요.")
    for p in images:
        q = Path(p)
        if q.exists():
            dst = d / "scenes" / ("ref%02d%s" % (len(imgs) + 1, q.suffix.lower()))
            dst.write_bytes(q.read_bytes())
            imgs.append(str(dst))
    if not parts:
        raise SystemExit("상품 정보가 없습니다. --text 로 붙여 넣어 주세요.")
    (d / "research.md").write_text("\n\n".join(parts), encoding="utf-8")
    m["images"] = imgs
    save(m)
    log("research.md 저장 (%d자)" % sum(len(x) for x in parts))
    return m


# ── 2. 대본 ────────────────────────────────────────────────────────────────

SCRIPT_PROMPT = """너는 한국어 쇼핑 쇼츠 대본을 쓰는 작가다. 아래 상품 정보로 세로 쇼츠 대본을 쓴다.

[레인] {lane_name}
{brief}
[규칙]
- 낭독 문장은 입말로. 한 신은 한 문장에서 두 문장. 글자 수는 [레인] 브리프의 지시를 따른다(없으면 신마다 12~28자).
- 1신 첫 문장은 3초 안에 끝나고, 그 자체로 궁금하게 만든다. 인사·자기소개로 시작하지 않는다.
- 상품 정보에 없는 수치·효능·인증은 절대 지어내지 않는다. 근거가 없으면 그 신을 다른 각도로 쓴다.
- 의학적 효과를 단정하지 않는다("치료된다" 금지, "~에 쓰인다" 정도).
- 과장 광고 표현(최고, 1위, 유일)은 상품 정보에 근거가 있을 때만 쓴다.
- image 는 영어 한 문장 이미지 프롬프트. **사람이 그 제품을 실제로 쓰는 장면**으로 쓴다 — 손·팔·반신이 제품을 잡고 시연·사용하는
  모습, 실제 집·일상 배경(제품만 덩그러니 놓인 정물 사진 금지, 얼굴 클로즈업은 피함). 신마다 다른 동작·장소.
  6개(또는 8개) 이미지의 화풍·조명·색감을 같은 문구로 통일한다.
- video 는 그 이미지를 6초 영상으로 만들 때의 영어 한 줄. 카메라 지시가 아니라 **사람의 동작과 제품의 움직임**을 쓴다
  (예: "the hand pushes the mop forward across the tiles, the pad spins and leaves a clean wet trail, subtle handheld camera").
  확대·줌 같은 카메라 효과만 쓰는 지시는 금지.
- product 는 그 신의 그림에 이 제품이 보이면 true, 제품 없이 상황만 보여 주면 false(문제 상황을 보여 주는 훅·공감 신은 보통 false).
- 마지막 신의 끝 문장은 반드시 「구매 링크는 프로필 링크에 있습니다.」 로 끝낸다. '댓글'·'설명란' 이라고 쓰지 않는다
  (쇼츠 화면에서는 설명·댓글의 주소가 눌리지 않고 채널 프로필 링크만 눌린다 — 특가30초 편집규칙 §47·§56).
- keyword 는 검색어 형태 6글자 이내 한글 핵심 키워드 하나.

[상품 정보]
{research}

[출력] 아래 JSON 만. 설명·코드펜스 없이.
{{"product":{{"name":"상품명","one_liner":"한 줄 설명"}},
 "keyword":"핵심키워드",
 "style":"모든 이미지에 공통으로 붙일 영어 화풍 문구",
 "scenes":[{{"n":1,"beat":"훅","narration":"낭독 문장","image":"english image prompt","video":"english action description","product":false}}],
 "title":"유튜브 제목(키워드를 앞 15자 안에)",
 "description":"설명 3~4줄. 첫 줄은 키워드로 시작",
 "tags":["태그","목록","# 없이"],
 "caption":"고정 댓글 한 줄"}}
신은 정확히 {n}개."""


def write_script(pid, provider="claude", model=None):
    m = load(pid)
    d = pdir(pid)
    lane = LANES[m.get("lane", "product")]
    research_txt = (d / "research.md").read_text(encoding="utf-8")
    prompt = SCRIPT_PROMPT.format(lane_name=lane["name"], brief=lane["brief"],
                                  research=research_txt[:8000], n=lane["scenes"])
    log("AI 에게 대본을 맡깁니다 (%s, 신 %d개)…" % (provider, lane["scenes"]))
    out = P.run_llm(prompt, provider=provider, model=model)
    try:
        data = P.extract_json(out)
    except P.JSONBroken as e:
        data = P.extract_json(P.repair_json_with_llm(e.body, provider, model))
    scenes = data.get("scenes") or []
    if len(scenes) != lane["scenes"]:
        log("경고: 신이 %d개 왔습니다(%d개 기대). 그대로 씁니다." % (len(scenes), lane["scenes"]))
    for i, s in enumerate(scenes):
        s["n"] = i + 1
        s["narration"] = re.sub(r"\s+", " ", str(s.get("narration") or "")).strip()
    data["scenes"] = scenes
    (d / "script.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# %s\n" % (data.get("product", {}).get("name") or ""),
             "키워드: %s\n" % data.get("keyword", "")]
    for s in scenes:
        lines.append("**%d. %s** — %s" % (s["n"], s.get("beat", ""), s["narration"]))
    (d / "script.md").write_text("\n".join(lines), encoding="utf-8")
    m["keyword"] = data.get("keyword", "")
    save(m)
    log("script.json 저장. 낭독 글자수 %d자" % sum(len(s["narration"]) for s in scenes))
    for s in scenes:
        log("  %d. %s" % (s["n"], s["narration"]))
    return data


# ── 3. 낭독 ────────────────────────────────────────────────────────────────

def atempo_chain(speed):
    """atempo 는 0.5~2.0 만 받으므로 곱으로 쪼갠다. 음높이는 유지된다."""
    out, s = [], float(speed)
    while s > 2.0:
        out.append("atempo=2.0")
        s /= 2.0
    while s < 0.5:
        out.append("atempo=0.5")
        s /= 0.5
    if abs(s - 1.0) > 1e-3:
        out.append("atempo=%.4f" % s)
    return ",".join(out)


def make_voice(pid, voice="ko-KR-InJoonNeural", speed=None):
    """신마다 따로 합성해 길이를 알고, 사이에 GAP 초를 넣어 하나로 잇는다."""
    m = load(pid)
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    speed = float(speed if speed is not None else m.get("speed") or 1.0)
    if m.get("lane") == "faction" and speed == 1.0:
        speed = 1.5                      # 썰은 빠른 낭독이 기본
    parts, t = [], 0.0
    for s in data["scenes"]:
        raw = d / "audio" / ("s%02d_raw.mp3" % s["n"])
        P.tts_synth(s["narration"], voice=voice, rate=0, out_path=raw)
        cur = d / "audio" / ("s%02d.wav" % s["n"])
        chain = atempo_chain(speed)
        af = ("%s,aresample=48000" % chain) if chain else "aresample=48000"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-af", af,
                        "-ac", "1", "-ar", "48000", str(cur)], check=True)
        dur = P.audio_duration(cur)
        s["start"] = round(t, 3)
        s["dur"] = round(dur, 3)
        t += dur + GAP
        parts.append(cur)
        log("  %d신 %.2f초  %s" % (s["n"], dur, s["narration"][:24]))
    # 이어 붙이기 — 신 사이에 무음 GAP
    sil = d / "audio" / "gap.wav"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                    "anullsrc=r=48000:cl=mono", "-t", "%.3f" % GAP, str(sil)], check=True)
    tail = d / "audio" / "tail.wav"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                    "anullsrc=r=48000:cl=mono", "-t", "%.3f" % TAIL, str(tail)], check=True)
    lst = d / "audio" / "concat.txt"
    seq = []
    for i, pth in enumerate(parts):
        seq.append(pth)
        if i < len(parts) - 1:
            seq.append(sil)
    seq.append(tail)                                   # 꼬리 무음: 마지막 장면이 낭독 뒤에도 잠깐 이어진다
    lst.write_text("".join("file '%s'\n" % str(x).replace("\\", "/") for x in seq), encoding="utf-8")
    out = d / "audio" / "voice.wav"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "1", str(out)], check=True)
    total = P.audio_duration(out)
    (d / "script.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    m["speed"] = speed
    m["voice"] = voice
    m["duration"] = round(total, 3)
    save(m)
    log("voice.wav %.2f초 (배속 %.2fx, 목소리 %s)" % (total, speed, voice))
    return out


# ── 4. 자막 정렬 ───────────────────────────────────────────────────────────

NORM = re.compile(r"[^0-9A-Za-z가-힣]+")


def word_times(wav, narration, dur):
    """낭독 파일의 단어 시각을 얻되, **글자는 대본 것을 쓴다.**

    음성 인식은 '재료만'을 '료료만', '12,900원'을 '12 ,900원'으로 흘린다. 우리는 정답
    문장을 이미 갖고 있으므로 인식 결과는 시각만 쓰고, 대본 어절에 difflib 로 붙인다.
    맞물리지 않은 어절은 앞뒤 사이를 균등하게 나눠 채운다. 반환 [(시각, 대본 어절)]."""
    import difflib
    m, _ = P.whisper_model()
    segs, _info = m.transcribe(str(wav), language="ko", word_timestamps=True, vad_filter=True,
                               vad_parameters={"min_silence_duration_ms": 300})
    heard = []
    for sg in segs:
        for w in (sg.words or []):
            t = (w.word or "").strip()
            if t:
                heard.append((float(w.start), t))
    want = [w for w in narration.split() if w]
    if not want:
        return []
    if not heard:
        step = dur / len(want)
        return [(round(i * step, 3), w) for i, w in enumerate(want)]

    a = [NORM.sub("", t).lower() for _, t in heard]
    b = [NORM.sub("", w).lower() for w in want]
    times = [None] * len(want)
    for i, j, n in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_matching_blocks():
        for k in range(n):
            times[j + k] = heard[i + k][0]
    # 못 붙은 어절은 앞뒤 앵커 사이를 균등 분할. 양 끝은 0 과 낭독 길이로 막는다.
    known = [k for k, t in enumerate(times) if t is not None]
    if not known:
        step = dur / len(want)
        return [(round(i * step, 3), w) for i, w in enumerate(want)]
    for k in range(known[0]):
        times[k] = times[known[0]] * (k + 1) / (known[0] + 1)
    for k in range(known[-1] + 1, len(times)):
        span = max(0.2, dur - times[known[-1]])
        times[k] = times[known[-1]] + span * (k - known[-1]) / (len(times) - known[-1])
    for x, y in zip(known, known[1:]):
        if y - x > 1:
            for k in range(x + 1, y):
                times[k] = times[x] + (times[y] - times[x]) * (k - x) / (y - x)
    return [(round(t, 3), w) for t, w in zip(times, want)]


def chunk_cues(words, max_chars, end_t):
    """어절+시각 목록 → 자막 줄. 쇼츠는 침묵마다 끊으면 한 단어짜리 자막이 쏟아지므로
    글자수와 문장 끝으로만 끊고, 시각은 다음 어절이 시작하는 순간까지 붙인다."""
    cues, cur, start = [], [], None
    for i, (t, w) in enumerate(words):
        if not cur:
            start = t
        cur.append(w)
        text = " ".join(cur)
        nxt = words[i + 1][0] if i + 1 < len(words) else end_t
        if len(text) >= max_chars or (len(text) >= 6 and P.SENT_END.search(w)) or i == len(words) - 1:
            cues.append({"s": round(start, 3), "e": round(nxt, 3), "text": text})
            cur = []
    if len(cues) >= 2 and len(cues[-1]["text"]) < 5:      # 꼬리 한 단어는 앞줄에 붙인다
        last = cues.pop()
        cues[-1]["text"] += " " + last["text"]
        cues[-1]["e"] = last["e"]
    return cues


def align(pid, max_chars=16):
    """신마다 따로 받아써 신 시작 시각을 더한다. 신 경계에서 자막이 섞이지 않는다."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    cues = []
    for s in data["scenes"]:
        wav = d / "audio" / ("s%02d.wav" % s["n"])
        try:
            words = word_times(wav, s["narration"], s["dur"])
            cc = chunk_cues(words, max_chars, s["dur"]) if words else []
        except RuntimeError as e:
            log("  %d신 인식 실패(%s) — 낭독 문장을 통째로 한 큐로." % (s["n"], e))
            cc = [{"s": 0.0, "e": s["dur"], "text": s["narration"]}]
        for c in cc:
            cues.append({"s": round(s["start"] + c["s"], 3),
                         "e": round(min(s["start"] + c["e"], s["start"] + s["dur"]), 3),
                         "text": c["text"], "scene": s["n"]})
    for k, c in enumerate(cues):
        c["id"] = k
    (d / "scene_data.json").write_text(json.dumps(
        {"scenes": [{"n": s["n"], "start": s["start"], "dur": s["dur"]} for s in data["scenes"]],
         "cues": cues}, ensure_ascii=False, indent=2), encoding="utf-8")
    log("자막 큐 %d개" % len(cues))
    for c in cues[:6]:
        log("  %6.2f  %s" % (c["s"], c["text"]))
    return cues


# ── 5. 이미지 시트 프롬프트 ────────────────────────────────────────────────

def sheet_prompt(grp, style, with_ref=False):
    """신 묶음 하나 → 시트 한 장 프롬프트. with_ref 면 참조 이미지(제품 사진)의 그 제품을 모든 패널에 쓰라고 못 박는다."""
    panels = "  ".join("Panel %d (leftmost is 1): %s." % (j + 1, s["image"].rstrip("."))
                       for j, s in enumerate(grp))
    ref = "Use the exact product shown in the reference image in every panel, keeping its shape, colors and label. " if with_ref else ""
    return ("A single wide image split into %d equal vertical panels side by side, "
            "each panel is a separate 9:16 vertical scene with no border or gap between panels. "
            "%s%s All panels share one consistent look: %s. No text, no watermark, no letterbox."
            % (len(grp), ref, panels, style))


# 실사 이미지 고정 프롬프트(2026-09-13 사용자 지정). 장면 설명은 넣지 않고 앞·뒤 문구만 붙인다.
PHOTOREAL_PREFIX = ("neutral photorealistic render, natural lighting, true-to-life colors, detailed feature textures, "
                    "clear focus on characters, realistic depth of field, natural facial structure:")
PHOTOREAL_SUFFIX = "No text, no watermark, no letterbox."      # 사용자가 고정한 것은 앞 문구뿐(2026-09-13). 뒤는 원래 쓰던 금지 문구


def scene_prompts(pid, with_ref=False):
    """Flow 자동 생성용(신마다 9:16 한 장): [{name: '1', prompt}, …]. 시트로 묶어 자르던 방식(sheet_prompts)은 손으로 만들 때만."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    style = (data.get("style") or "cinematic product photography, soft studio light, muted palette").strip()
    ref = " Use the exact product shown in the reference image, keeping its shape, colors and label." if with_ref else ""
    out = []
    for s in data["scenes"]:
        use_ref = with_ref and s.get("product", True) is not False          # 제품이 안 나오는 신(훅·공감)에 참조를 주면 제품이 끼어든다(2026-09-12 1신 실측)
        out.append({"name": str(s["n"]), "ref": use_ref,
                    "prompt": "%s %s.%s Vertical 9:16 composition, %s. %s" % (PHOTOREAL_PREFIX, s["image"].rstrip("."), ref if use_ref else "", style, PHOTOREAL_SUFFIX)})
    return out


CHECK_PROMPT = """너는 쇼핑 쇼츠 이미지 검수자다. 아래 신마다 Read 도구로 이미지 파일을 열어 보고, 낭독 문장과 의도한 그림에 맞는지 판정한다.
{ref_line}

판정 기준(하나라도 어긋나면 ok=false):
1) 낭독이 말하는 상황·동작이 그림에 있는가 (예: '로봇청소기가 지나간 자리'인데 로봇청소기가 없으면 불합격)
2) 제품이 나와야 하는 신(product=true)이면 제품이 참조 사진과 같은 모양인가 (다른 제품·색·구성이면 불합격). 제품이 없어야 하는 신(product=false)에 이 제품이 보이면 불합격
3) 사람이 제품을 쓰는 장면이어야 하는 신에 사람 손·몸이 없으면 불합격 (제품만 정물이면 불합격)
4) 글자·워터마크·손가락 6개·물건이 겹쳐 두 개로 보이는 것 같은 AI 오류가 눈에 띄면 불합격
합격이면 ok=true. 불합격이면 무엇이 틀렸는지 한국어 한 줄과, 그 문제를 고친 영어 이미지 프롬프트(원래 의도와 화풍 유지, 틀린 점을 명시적으로 금지·지정)를 쓰고,
고친 그림에 이 제품이 보여야 하면 product=true, 제품이 없어야 하면 product=false 로 적는다(참조 사진을 줄지 말지 결정에 쓴다).

{scene_lines}

[출력] JSON 배열 하나만. 배열 앞뒤에 설명·코드펜스·요약 문장을 절대 쓰지 않는다.
[{{"n":1,"ok":true,"reason":"","prompt":"","product":true}}, ...]
"""


def _parse_json_array(text):
    """응답에서 첫 '[' 부터 짝이 맞는 ']' 까지만 읽는다. CLI 가 배열 뒤에 한 줄 설명을 붙이는 일이 있어(2026-09-12) 'Extra data' 로 깨졌다."""
    i = text.find("[")
    if i < 0:
        return None
    depth = 0; in_str = False; esc = False
    for j in range(i, len(text)):
        ch = text[j]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[i:j + 1])
                except ValueError:
                    return None
    return None


def check_scenes(pid, only=None):
    """scenes/N.png 를 대본과 대조해 [{n, ok, reason, prompt}] 를 돌려준다. Claude Code CLI 가 그림을 직접 본다(pipeline.run_claude_vision)."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    refs = sorted((d / "scenes").glob("ref*.*"))
    ref_line = ("제품 참조 사진은 scenes\\%s 이다. 먼저 이 파일을 열어 제품 모양(색·형태·구성)을 기억한다." % refs[0].name) if refs else "참조 사진은 없다. 제품 모양은 신 사이에서 서로 같은지 본다."
    lines = []
    for s in data["scenes"]:
        n = s["n"]
        if only is not None and n not in only:
            continue
        if not (d / "scenes" / ("%d.png" % n)).exists():
            continue
        lines.append("- 신 %d (product=%s): 낭독 「%s」 / 의도한 그림: %s / 파일: scenes\\%d.png"
                     % (n, "true" if s.get("product", True) is not False else "false", s["narration"], s["image"], n))
    if not lines:
        return []
    out = P.run_claude_vision(CHECK_PROMPT.format(ref_line=ref_line, scene_lines="\n".join(lines)), cwd=d)
    res = _parse_json_array(out)
    if res is None:
        try:
            res = P.extract_json(out)
        except P.JSONBroken as e:
            res = P.extract_json(P.repair_json_with_llm(e.body, "claude", None))
    if isinstance(res, dict):
        res = res.get("items") or res.get("scenes") or []
    clean = []
    for r in res:
        try:
            clean.append({"n": int(r.get("n")), "ok": bool(r.get("ok")), "reason": str(r.get("reason") or "").strip(), "prompt": str(r.get("prompt") or "").strip(),
                          "product": r.get("product") is not False})
        except Exception:
            pass
    (d / "check.json").write_text(json.dumps(clean, ensure_ascii=False, indent=1), encoding="utf-8")
    return clean


def sheet_prompts(pid, per=3, with_ref=False):
    """Flow 자동 생성용: [{name: 'sheet1', prompt}, …]. prompts.md 와 같은 문구(참조가 있으면 그 문장만 더한다)."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    style = (data.get("style") or "cinematic product photography, soft studio light, muted palette").strip()
    sc = data["scenes"]
    return [{"name": "sheet%d" % (i // per + 1), "prompt": sheet_prompt(sc[i:i + per], style, with_ref)}
            for i in range(0, len(sc), per)]


def sheets(pid, per=3):
    """신 per 개를 한 장에 담는 시트 프롬프트를 쓴다. 크레딧이 1/per 로 준다."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    style = (data.get("style") or "cinematic product photography, soft studio light, muted palette").strip()
    sc = data["scenes"]
    out = ["# 이미지·영상 프롬프트",
           "",
           "## 1) 이미지 시트 — 아래 프롬프트를 이미지 생성기(제미나이·플로우)에 그대로",
           "한 장에 신 %d개가 들어간다. 시트 %d장이면 신 %d개가 전부 나온다." % (per, (len(sc) + per - 1) // per, len(sc)),
           ""]
    n_sheet = 0
    for i in range(0, len(sc), per):
        grp = sc[i:i + per]
        n_sheet += 1
        out += ["### 시트 %d — 신 %s" % (n_sheet, ", ".join(str(s["n"]) for s in grp)),
                "```",
                sheet_prompt(grp, style),
                "```",
                "→ 받은 파일을 `sheets/sheet%d.png` 로 저장" % n_sheet,
                ""]
    out += ["## 2) 영상 프롬프트 — 구글 플로우에서 신 이미지마다", ""]
    for s in sc:
        out += ["**신 %d** (%s초) — `clips/%d.mp4` 로 저장" % (s["n"], round(s.get("dur", 4), 1), s["n"]),
                "```", "%s. %s" % (s["video"].rstrip("."), style), "```", ""]
    tot = len(sc)
    out += ["## 크레딧",
            "4초 %d개 = %d크레딧 (6초면 %d크레딧). 제미나이 프로 무료분 하루 50크레딧 안." % (tot, tot * 7, tot * 10),
            ""]
    (d / "prompts.md").write_text("\n".join(out), encoding="utf-8")
    log("prompts.md 저장 — 시트 %d장, 영상 %d개" % (n_sheet, tot))
    log(str(d / "prompts.md"))


def split_sheets(pid, per=3, axis="h"):
    """시트 이미지를 per 등분해 scenes/1.png … 로 자른다."""
    d = pdir(pid)
    # sheets/ 에는 만드는 과정에서 생긴 파일(콘택트 시트 등)이 같이 떨어진다. 그것까지 자르면
    # 신 번호가 밀려 엉뚱한 그림이 붙으므로, 시트로 쓸 파일만 고른다.
    skip = ("contact", "thumb", "preview")
    files = sorted((q for q in (d / "sheets").iterdir()
                    if q.is_file() and q.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")
                    and not any(q.stem.lower().startswith(s) for s in skip)),
                   key=lambda q: (len(q.stem), q.stem))
    if not files:
        raise SystemExit("sheets/ 에 이미지가 없습니다. prompts.md 의 시트 프롬프트로 만든 파일을 넣어 주세요.")
    want = len(json.loads((d / "script.json").read_text(encoding="utf-8"))["scenes"])
    if len(files) * per != want:
        log("주의: 시트 %d장 × %d = %d컷인데 대본은 신 %d개입니다. 파일을 확인하세요."
            % (len(files), per, len(files) * per, want))
    n = 0
    for f in files:
        im = Image.open(f).convert("RGB")
        w, h = im.size
        for k in range(per):
            if axis == "h":
                box = (w * k // per, 0, w * (k + 1) // per, h)
            else:
                box = (0, h * k // per, w, h * (k + 1) // per)
            n += 1
            im.crop(box).save(d / "scenes" / ("%d.png" % n))
        log("%s → %d등분" % (f.name, per))
    log("scenes/1.png … %d.png" % n)


# ── 6. 렌더 ────────────────────────────────────────────────────────────────

def sub_pngs(pid, cues, work):
    fnt = P.font(SUB_SIZE)
    lh = int(SUB_SIZE * 1.32)
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    out = []
    for k, c in enumerate(cues):
        lines = P.wrap_text(probe, c["text"], fnt, SUB_MAXW)[:2]
        if not lines:
            continue
        img = Image.new("RGBA", (W, lh * len(lines) + 24), (0, 0, 0, 0))
        dr = ImageDraw.Draw(img)
        for i, ln in enumerate(lines):
            P.draw_center(dr, ln, 12 + i * lh, fnt, (255, 255, 255, 255),
                          stroke=(0, 0, 0, 255), stroke_w=6, width=W)
        pth = work / ("sub%03d.png" % k)
        img.save(pth)
        out.append((pth, img.size[1], float(c["s"]), float(c["e"])))
    return out


def stills_to_clips(pid):
    """신 이미지를 낭독 길이에 맞춘 느린 확대 영상으로 만든다.
    플로우 크레딧이 없거나 급할 때 — 이걸로도 쇼츠 한 편이 끝까지 나온다."""
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    (d / "clips").mkdir(exist_ok=True)
    made = []
    zw, zh = int(W * 1.4), int(H * 1.4)
    for s in data["scenes"]:
        img = None
        for ext in (".png", ".jpg", ".jpeg", ".webp"):
            q = d / "scenes" / ("%d%s" % (s["n"], ext))
            if q.exists():
                img = q
                break
        if img is None:
            continue
        dur = float(s.get("dur") or 3.0) + GAP
        out = d / "clips" / ("%d.mp4" % s["n"])
        vf = ("scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,fps=30,"
              "zoompan=z='min(1.001+0.0009*on,1.12)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
              "s=%dx%d:fps=30,setsar=1" % (zw, zh, zw, zh, W, H))
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", "%.3f" % dur,
                        "-i", str(img), "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
                        "-crf", "20", "-pix_fmt", "yuv420p", "-r", "30", str(out)], check=True)
        made.append(str(out))
        log("  %d신 → %s (%.1f초)" % (s["n"], out.name, dur))
    if not made:
        raise SystemExit("scenes/ 에 신 이미지가 없습니다. 먼저 split 을 돌리세요.")
    return made


def scene_source(d, n):
    """신 n 의 화면 재료. 영상이 있으면 영상, 없으면 이미지."""
    for ext in (".mp4", ".mov", ".webm"):
        q = d / "clips" / ("%d%s" % (n, ext))
        if q.exists():
            return q, "video"
    for ext in (".png", ".jpg", ".jpeg", ".webp"):
        q = d / "scenes" / ("%d%s" % (n, ext))
        if q.exists():
            return q, "image"
    return None, None


def render(pid, out_path=None):
    m = load(pid)
    d = pdir(pid)
    data = json.loads((d / "script.json").read_text(encoding="utf-8"))
    sd = json.loads((d / "scene_data.json").read_text(encoding="utf-8"))
    work = d / "work"
    work.mkdir(exist_ok=True)
    voice = d / "audio" / "voice.wav"
    if not voice.exists():
        raise SystemExit("낭독이 없습니다. voice 를 먼저 돌리세요.")

    scenes = data["scenes"]
    inputs, filters, labels = [], [], []
    missing = []
    for i, s in enumerate(scenes):
        src, kind = scene_source(d, s["n"])
        dur = float(s.get("dur") or 3.0) + (GAP if i < len(scenes) - 1 else 0.4)
        if src is None:
            missing.append(s["n"])
            inputs += ["-f", "lavfi", "-t", "%.3f" % dur, "-i",
                       "color=c=0x141821:s=%dx%d:r=30" % (W, H)]
            filters.append("[%d:v]fps=30,setsar=1,format=yuv420p[v%d]" % (i, i))
            labels.append("[v%d]" % i)
            continue
        if kind == "video":
            inputs += ["-i", str(src)]
            # 모자라면 마지막 프레임을 붙여 늘리고(tpad), 남으면 자른다
            filters.append(
                "[%d:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
                "fps=30,tpad=stop_mode=clone:stop_duration=%.3f,trim=0:%.3f,setpts=PTS-STARTPTS,setsar=1[v%d]"
                % (i, W, H, W, H, dur, dur, i))
        else:
            inputs += ["-loop", "1", "-t", "%.3f" % dur, "-i", str(src)]
            # 느린 확대(켄 번즈). 정지 화면 나열은 유튜브 정책에서도 손해라 항상 움직인다.
            # zoompan 은 d=1 로 두어 입력 프레임 하나당 출력 하나. on(출력 프레임 번호)으로 확대가 자란다.
            filters.append(
                "[%d:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,fps=30,"
                "zoompan=z='min(1.001+0.0009*on,1.12)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                "s=%dx%d:fps=30,setsar=1[v%d]"
                % (i, int(W * 1.4), int(H * 1.4), int(W * 1.4), int(H * 1.4), W, H, i))
        labels.append("[v%d]" % i)
    if missing:
        log("화면 재료가 없는 신: %s — 단색으로 채웁니다(clips/ 나 scenes/ 에 파일을 넣으면 대체됩니다)"
            % ", ".join(map(str, missing)))

    graph = ";".join(filters)
    graph += ";%sconcat=n=%d:v=1:a=0[base]" % ("".join(labels), len(scenes))

    n_in = len(scenes)
    inputs += ["-i", str(voice)]
    audio_idx = n_in
    n_in += 1

    subs = sub_pngs(pid, sd["cues"], work)
    cur = "[base]"
    for k, (pth, ph, s0, s1) in enumerate(subs):
        inputs += ["-i", str(pth)]
        y = SUB_CY
        nxt = "[o%d]" % k
        graph += ";%s[%d:v]overlay=0:%d:enable='between(t,%.3f,%.3f)'%s" % (cur, n_in, y, s0, s1, nxt)
        cur = nxt
        n_in += 1
    if cur != "[base]":
        graph += ";%sformat=yuv420p[vout]" % cur
    else:
        graph += ";[base]format=yuv420p[vout]"

    out_path = Path(out_path) if out_path else (d / "output" / ("%s.mp4" % P.safe_name(
        data.get("title") or m["id"], 40)))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    enc = ["-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p"]
    cmd = (["ffmpeg", "-y", "-v", "error", "-stats"] + inputs +
           ["-filter_complex", graph, "-map", "[vout]", "-map", "%d:a" % audio_idx,
            "-shortest"] + enc + ["-c:a", "aac", "-b:a", "192k", "-r", "30", str(out_path)])
    (work / "ffmpeg_cmd.txt").write_text(" ".join(cmd), encoding="utf-8")
    log("렌더 중… (신 %d개, 자막 %d줄)" % (len(scenes), len(subs)))
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        (work / "ffmpeg_err.txt").write_text(r.stderr or "", encoding="utf-8")
        raise SystemExit("렌더 실패:\n" + (r.stderr or "")[-1500:])
    log("완성 %.1f초 걸림 → %s" % (time.time() - t0, out_path))

    # 업로드 문안 — shorts_upload.py 가 그대로 먹는 형식
    up = {"shorts": [{"file": str(out_path),
                      "title": data.get("title") or "",
                      "description": data.get("description") or "",
                      "tags": data.get("tags") or []}]}
    (d / "shorts-upload.json").write_text(json.dumps(up, ensure_ascii=False, indent=2), encoding="utf-8")
    log("shorts-upload.json 같이 저장")
    return out_path


# ── CLI ────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="상품 쇼츠 파이프라인")
    ap.add_argument("cmd", choices=["new", "research", "script", "voice", "align",
                                    "sheet", "split", "stills", "render", "auto", "list"])
    ap.add_argument("--id", default="")
    ap.add_argument("--url", default="")
    ap.add_argument("--text", default="")
    ap.add_argument("--textfile", default="")
    ap.add_argument("--image", action="append", default=[])
    ap.add_argument("--lane", default="product", choices=list(LANES))
    ap.add_argument("--provider", default="claude")
    ap.add_argument("--model", default=None)
    ap.add_argument("--voice", default="ko-KR-InJoonNeural")
    ap.add_argument("--speed", type=float, default=None)
    ap.add_argument("--per", type=int, default=3, help="이미지 한 장에 담을 신 개수")
    ap.add_argument("--axis", default="h", choices=["h", "v"])
    ap.add_argument("--subchars", type=int, default=16, help="자막 한 줄 최대 글자수")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    PRODUCTS.mkdir(exist_ok=True)
    if a.cmd == "list":
        for d in sorted(PRODUCTS.glob("*")):
            if (d / "meta.json").exists():
                m = json.loads((d / "meta.json").read_text(encoding="utf-8"))
                log("%s  %-8s %s" % (m["id"], m.get("lane"), (m.get("url") or m.get("note") or "")[:60]))
        return

    text = a.text
    if a.textfile:
        text = Path(a.textfile).read_text(encoding="utf-8")

    if a.cmd == "new":
        new_project(a.lane, a.url, a.text)
        return

    if a.cmd == "auto":
        m = new_project(a.lane, a.url, "")
        pid = m["id"]
        research(pid, text, a.image)
        write_script(pid, a.provider, a.model)
        make_voice(pid, a.voice, a.speed)
        align(pid, a.subchars)
        sheets(pid, a.per)
        log("")
        log("여기까지 자동. 다음은 사람 손:")
        log("  1) %s 의 시트 프롬프트로 이미지를 만들어 sheets/ 에 넣고" % (pdir(pid) / "prompts.md"))
        log("  2) python product.py split --id %s" % pid)
        log("  3) 구글 플로우에서 scenes/*.png 를 영상으로 만들어 clips/1.mp4 … 로 넣고")
        log("  4) python product.py render --id %s" % pid)
        return

    pid = a.id or latest_pid()
    if a.cmd == "research":
        research(pid, text, a.image)
    elif a.cmd == "script":
        write_script(pid, a.provider, a.model)
    elif a.cmd == "voice":
        make_voice(pid, a.voice, a.speed)
    elif a.cmd == "align":
        align(pid, a.subchars)
    elif a.cmd == "sheet":
        sheets(pid, a.per)
    elif a.cmd == "split":
        split_sheets(pid, a.per, a.axis)
    elif a.cmd == "stills":
        stills_to_clips(pid)
    elif a.cmd == "render":
        render(pid, a.out or None)


if __name__ == "__main__":
    main()
