# -*- coding: utf-8 -*-
"""쇼츠컷 — 로컬 웹 서버.

실행:  실행.cmd  또는  .venv\\Scripts\\python.exe server.py
       → http://127.0.0.1:8796  (8790 은 SceneReport 가 쓴다)

표준 라이브러리 http.server 만 쓴다. 외부 의존성은 yt-dlp·pillow 둘뿐이고 ffmpeg·claude 는 PATH 에서 찾는다.
"""
import argparse
import json
import mimetypes
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse, unquote

_HERE = os.path.dirname(os.path.abspath(__file__))
if sys.stdout is None or sys.stderr is None:
    # pythonw(콘솔 없음)로 뜬 경우: 출력을 logs/server.log 로 돌린다. 안 그러면 첫 print 에서 죽는다.
    os.makedirs(os.path.join(_HERE, "logs"), exist_ok=True)
    _log = open(os.path.join(_HERE, "logs", "server.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = _log
else:
    sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, _HERE)
import pipeline as pl
import license as lic  # noqa: E402
import product as pr  # noqa: E402   상품 정보 → 대본·낭독·프롬프트 (쇼핑 쇼츠의 앞단)
import affiliate as af  # noqa: E402  쿠팡 파트너스 · 토스 쉐어링크 + 공정위 고지 문구

BASE = pl.BASE
WEB = BASE / "web"
pl.PROJECTS.mkdir(exist_ok=True)

_jobs = {}
_jlock = threading.Lock()
_plocks = {}


def plock(pid):
    with _jlock:
        return _plocks.setdefault(pid, threading.Lock())


def job_get(pid):
    with _jlock:
        j = _jobs.get(pid)
        return dict(j) if j else None


def job_set(pid, **kw):
    with _jlock:
        _jobs.setdefault(pid, {})
        _jobs[pid].update(kw)


def start_job(pid, kind, fn):
    with _jlock:
        j = _jobs.get(pid)
        if j and j.get("running"):
            return False
        _jobs[pid] = {"kind": kind, "running": True, "pct": None, "current": None,
                      "message": "", "errors": [], "started": time.time()}

    def wrap():
        try:
            fn()
        except Exception as e:
            traceback.print_exc()
            with plock(pid):
                try:
                    p = pl.load(pid)
                    p["status"] = "error"
                    p["error"] = str(e)
                    pl.save(p)
                except Exception:
                    pass
            job_set(pid, errors=[str(e)])
        finally:
            job_set(pid, running=False, finished=time.time())

    threading.Thread(target=wrap, daemon=True).start()
    return True


# ── 작업 정의 ─────────────────────────────────────────────────────────────────

def run_create(pid):
    with plock(pid):
        p = pl.load(pid)
        p["status"] = "fetching"
        pl.save(p)
    pl.fetch(p)
    # 사용자가 준 범위가 실제 길이를 넘으면 잘라 준다
    dur = p["source"]["duration"]
    rs, re_ = p["settings"]["range"]
    if re_ <= 0 or re_ > dur:
        re_ = dur
    rs = max(0, min(rs, re_ - 60))
    p["settings"]["range"] = [rs, re_]
    # 저장소에 이 영상의 대본이 있으면 분석 전에 자막 글자를 대본으로 바꿔 둔다(오타 없는 자막으로 AI 가 읽는다)
    try:
        script = pl.find_script(p)
        if script:
            pl.set_progress(p, "fetch", "저장소 대본을 자막 시간축에 맞추는 중…", None)
            base = pl.load_cues(p)
            new_cues, stats = pl.align_script(base, Path(script).read_text(encoding="utf-8", errors="replace"), max_chars=pl.sub_max_chars(p.get("settings")))
            if stats["matched"] >= max(5, stats["sentences"] * 0.6):
                p["cues_auto"] = base
                p["cues"] = new_cues
                p["cues_source"] = "script"
                p["script_path"] = script
                pl.save(p)
    except Exception as e:
        traceback.print_exc()
        print("대본 자동 정렬 건너뜀:", e)
    with plock(pid):
        p["status"] = "analyzing"
        pl.save(p)
    run_analyze_inner(p)


def run_analyze_inner(p):
    pid = p["id"]
    pl.analyze(p)
    pl.set_progress(p, "poster", "미리보기 스틸을 뽑는 중…", None)
    for s in p["shorts"]:
        s["poster"] = pl.preview_frame(p, s)
    with plock(pid):
        cur = pl.load(pid)
        cur["cues"] = p["cues"]
        cur["shorts"] = p["shorts"]
        cur["source"] = p["source"]
        cur["settings"] = p["settings"]
        cur["status"] = "ready"
        cur["error"] = None
        cur["progress"] = {"step": "done", "message": "%d개의 쇼츠 구간을 찾았습니다" % len(p["shorts"]),
                           "pct": 100, "at": time.time()}
        pl.save(cur)


def auto_sfx(p, short, reveal=None):
    """조각 시각에 맞춰 효과음 트랙(audios)을 넣는다. 소리는 sfx/ 라이브러리(자체 합성·Kenney CC0)에서 프로젝트 폴더로 복사.
       reveal: 제품이 처음 나오는 조각 번호(1부터). 없으면 조각 4개 이상일 때 3, 아니면 2."""
    import uuid
    lib = {it["id"]: it for it in pl.sfx_list()}
    clips = short["clips"]
    offs, total = pl.clip_offsets(clips, 0.0)
    n = len(clips)
    try:
        reveal = int(reveal or 0)
    except (TypeError, ValueError):
        reveal = 0
    if not (1 <= reveal <= n):
        reveal = 3 if n >= 4 else 2
    base = float(p["settings"].get("sfx_volume") or 0.6)
    # whoosh·swipe 는 총소리로 들려 뺐다(편집규칙 §36: 평탄도 0.15↑·어택 0.06↓ 소리 금지, 2026-09-13 사용자 재지적).
    # 남는 것은 음정이 있는 둘 — 제품 등장에 반짝, 마지막 조각(구매 안내)에 성공음. 장면 전환은 소리 없이 간다.
    plan = []
    for i in range(1, n):
        t = offs[i]
        if i + 1 == reveal:
            plan.append(("sparkle", t, 1.0))                                        # 제품 등장
        elif i == n - 1:
            plan.append(("success", t, 0.8))                                        # 마지막 조각(구매 안내)
    d = pl.pdir(p["id"])
    items = []
    for sid, at, k in plan:
        it = lib.get(sid)
        if not it or at >= total:
            continue
        src = Path(it["path"]); aid = "a" + uuid.uuid4().hex[:6]
        dst = d / ("aud_%s%s" % (aid, src.suffix.lower()))
        shutil.copy2(src, dst)
        items.append({"id": aid, "path": str(dst), "file": dst.name, "url": "/media/%s/%s" % (p["id"], dst.name), "title": it.get("title") or sid,
                      "duration": float(it.get("duration") or pl.audio_duration(dst)), "at": round(at, 3), "in": 0.0, "out": None,
                      "volume": round(min(2.0, base * k), 2), "lane": 2, "sfx": True})
    short["audios"] = (short.get("audios") or []) + items
    return items


def run_create_shop(pid):
    """쇼핑 쇼츠: 영상 여러 개 + 낭독 mp3 (+대본) → 프로젝트 하나, 쇼츠 하나(조각 = 영상 순서대로)."""
    with plock(pid):
        p = pl.load(pid)
        p["status"] = "fetching"
        pl.save(p)
    d = pl.pdir(pid)
    videos = list(p["shop"]["videos"])
    if p["shop"].get("empty") and not videos:
        # 빈 프로젝트: 캔버스 크기의 5초 검정(무음) 클립을 본편으로 깐다. 사용자는 편집기 미디어에서 파일을 더한다
        cw, ch = pl.canvas_size(p["settings"])
        blank = d / "blank_5s.mp4"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=%dx%d:r=30:d=5" % (cw, ch),
                        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", "5", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
                        "-c:a", "aac", "-shortest", str(blank)], check=True)
        videos = [str(blank)]
        p["shop"]["videos"] = videos
    # 1) 첫 영상은 본편(source), 나머지는 삽입 영상으로 등록
    pl.set_progress(p, "fetch", "영상 1/%d 을 프로젝트에 담는 중…" % len(videos), None)
    first = Path(videos[0])
    local = d / "source.mp4"
    if first.suffix.lower() in pl.IMAGE_EXT:
        pl.image_to_clip(first, local)                       # 가로 롱폼 업로드는 이미지도 받는다(2026-09-12). 삽입 소스와 같은 10초 정지 영상
        r = subprocess.CompletedProcess([], 0)
    else:
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(first), "-c", "copy", "-movflags", "+faststart", str(local)],
                           capture_output=True, text=True)
    if r.returncode != 0 or not local.exists():
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(first), "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(local)], check=True)
    w, h, dur = pl.ffprobe_video(local)
    p["source"].update(type="file", path=str(local), original_path=str(first), title=p["source"].get("title") or first.stem,
                       width=w, height=h, duration=dur, has_audio=pl.has_audio(local))
    thumb = d / "source.jpg"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", str(local), "-frames:v", "1", "-q:v", "4", str(thumb)], check=False)
    if thumb.exists():
        p["source"]["thumb"] = thumb.name
    p["filmstrip"] = pl.make_filmstrip(local, d / "strip.jpg", dur)
    p["silences"] = []
    pl.save(p)
    lengths = [dur]
    for i, v in enumerate(videos[1:], start=2):
        pl.set_progress(p, "fetch", "영상 %d/%d 을 프로젝트에 담는 중…" % (i, len(videos)), None)
        src = pl.add_source(p, v)
        lengths.append(src["duration"])
    # 2) 낭독 파일(선택) 복사 + 받아쓰기. 없으면 원본 소리를 살리고 자막 없이 시작한다
    script = (p["shop"].get("script") or "").strip()
    tts = (p["shop"].get("tts") or "").strip()
    nar_dur = None
    if tts:
        pl.set_progress(p, "fetch", "낭독 파일을 담는 중…", None)
        nar_dur = attach_narration(p, tts, script)
    else:
        p["narration"] = None
        p["cues"], p["cues_auto"], p["cues_source"] = [], [], "none"
        if p["settings"].get("src_volume") in (None, 0, 0.0):
            p["settings"]["src_volume"] = 1.0           # 낭독이 없으면 원본 소리를 그대로 쓴다
        pl.save(p)
    # 4) 조각: 영상 순서대로. 낭독이 있으면 그 길이를, 없으면 최대 60초를 나눠 갖는다
    ids = ["main"] + [x["id"] for x in p.get("extra_sources", [])]
    target = nar_dur if nar_dur else sum(lengths)
    shares = pl.split_even(target, lengths)
    clips = [{"s": 0.0, "e": round(min(L, max(1.0, sh)), 3), "src": sid} for sid, L, sh in zip(ids, lengths, shares) if sh > 0.3]
    sh = p["shop"]
    reason = ("낭독 길이 %.1f초에 맞춰 영상 %d개를 순서대로 배치" % (nar_dur, len(clips)) if nar_dur
              else "빈 프로젝트. 왼쪽 「미디어」의 「＋ 파일 추가」로 영상·이미지를 넣고 트랙에 놓으세요" if p["shop"].get("empty")
              else "낭독 없이 영상 %d개를 순서대로 배치. 편집기에서 「낭독 넣기」로 음성·자막을 붙일 수 있습니다" % len(clips))
    short = {"id": "S01", "start": 0.0, "end": target, "clips": clips, "orig_clips": [dict(c) for c in clips],
             "orig_start": 0.0, "orig_end": target,
             "line1": sh.get("line1", ""), "line2": sh.get("line2", ""), "reason": reason,
             "yt_title": sh.get("title") or "", "description": "", "tags": [], "cue_edits": {}, "comment": {}, "output": None, "render": None}
    # 5) 제목·문안이 비어 있고 대본이 있으면 AI 로 채운다(실패해도 진행)
    if script and not (short["line1"] and short["yt_title"]):
        try:
            pl.set_progress(p, "analyze", "AI 가 훅 제목과 업로드 문안을 쓰는 중…", None)
            c = pl.shop_copy(script, provider=p["settings"].get("provider") or "claude", model=p["settings"].get("model") or None)
            short["line1"] = short["line1"] or c.get("line1", "")
            short["line2"] = short["line2"] or c.get("line2", "")
            short["yt_title"] = short["yt_title"] or c.get("yt_title", "")
            short["description"] = c.get("description", "")
            short["tags"] = c.get("tags", [])
        except Exception as e:
            print("쇼핑 문안 AI 건너뜀:", e)
    # 5.4) 깜빡이는 상품명 팝업(popup_text): 제목 아래에 1.2초 주기로 0.7초씩 보인다(2026-09-13 사용자: 아이폰·애플워치 편)
    pt = (p["shop"].get("popup_text") or "").strip()
    if pt:
        CW, CH = pl.canvas_size(p["settings"])
        short["texts"] = (short.get("texts") or []) + [{
            "id": "popup_name", "text": pt, "at": 0.0, "dur": round(target + 0.5, 2), "x": CW / 2, "y": round(CH * 0.30),
            "size": max(40, int(CW * 0.052)), "color": "#FFE600", "stroke": "#000000", "bold": True, "bg": True, "bg_alpha": 200,
            "align": "center", "font": "noto", "shadow": "none", "w": 0, "lane": 8, "anim_in": "none", "anim_out": "none",
            "blink": {"period": 1.2, "on": 0.7}}]
    # 5.5) 효과음 자동 배치(auto_sfx, 세로 쇼핑 기본 켬). 편집기 「효과음」 트랙에서 지우거나 옮길 수 있다
    if p["settings"].get("auto_sfx") is not False and pl.canvas_of(p["settings"]) != "16:9" and len(clips) >= 2:
        try:
            auto_sfx(p, short, reveal=p["settings"].get("sfx_reveal"))
        except Exception as e:
            print("효과음 자동 배치 건너뜀:", e)
    # 6) 제휴 링크를 쓰면 고지 문구를 설명 앞에, 화면에는 자막 한 줄로 — 앞 aff_secs 초(기본 5, 0 이면 영상 내내).
    #    설명란만으로는 심사지침의 요건을 못 채운다(affiliate.py 참고).
    aff = p.get("affiliate")
    if aff:
        short["description"] = af.apply_to_description(short.get("description") or "", aff)
        t = af.onscreen_text(aff, target, pl.canvas_size(p["settings"]), secs=p["settings"].get("aff_secs"))
        if t:
            short["texts"] = [x for x in (short.get("texts") or []) if x.get("id") != "aff_notice"] + [t]
    p["shorts"] = [short]
    pl.set_progress(p, "poster", "미리보기 스틸을 뽑는 중…", None)
    short["poster"] = pl.preview_frame(p, short)
    with plock(pid):
        cur = pl.load(pid)
        for k in ("source", "extra_sources", "filmstrip", "silences", "narration", "cues", "cues_auto", "cues_source", "asr_model", "shorts"):
            if k in p:
                cur[k] = p[k]
        cur["status"] = "ready"
        cur["error"] = None
        cur["progress"] = {"step": "done", "message": "쇼핑 쇼츠 초안이 준비됐습니다 (%s영상 %d개)" % (("낭독 %.0f초, " % nar_dur) if nar_dur else "", len(clips)),
                           "pct": 100, "at": time.time()}
        pl.save(cur)


def attach_narration(p, tts_path, script=""):
    """낭독 파일을 프로젝트에 담고 받아써 자막을 만든다(대본이 있으면 글자 교정). 반환: 낭독 길이."""
    pid = p["id"]
    d = pl.pdir(pid)
    nar_src = Path(tts_path)
    for old in d.glob("narration.*"):
        old.unlink()
    nar_dst = d / ("narration" + nar_src.suffix.lower())
    shutil.copy2(nar_src, nar_dst)
    nar_dur = pl.audio_duration(nar_dst)
    p["narration"] = {"path": str(nar_dst), "file": nar_dst.name, "duration": nar_dur, "url": "/media/%s/%s" % (pid, nar_dst.name)}
    pl.save(p)
    pl.set_progress(p, "analyze", "낭독을 받아쓰는 중… (첫 실행은 모델 로딩 30초)", None)
    cues, desc = pl.transcribe_audio(nar_dst, max_chars=pl.sub_max_chars(p.get("settings")))
    p["cues_auto"] = cues
    p["cues"] = cues
    p["cues_source"] = "whisper"
    p["asr_model"] = desc
    if script:
        try:
            new_cues, stats = pl.align_script(cues, script, max_chars=pl.sub_max_chars(p.get("settings")))
            if stats["matched"] >= max(2, stats["sentences"] * 0.5):
                p["cues"] = new_cues
                p["cues_source"] = "script"
        except Exception as e:
            print("대본 정렬 건너뜀:", e)
    pl.save(p)
    return nar_dur


# ── 상품 쇼츠 앞단 ─────────────────────────────────────────────────────────
# product.py 가 상품 정보 하나에서 대본·낭독·이미지 프롬프트까지 만든다. 화면(이미지·영상)은
# 구글 플로우에서 사람이 받아 오고, 이어 붙이기·자막·편집·렌더는 아래 「쇼핑 쇼츠」가 그대로 맡는다.
# 그래서 여기서는 자막을 만들지 않는다 — attach_narration 의 받아쓰기 + align_script 가 한다.

def run_tts_make(key, text, voice, rate):
    """조각마다 진행률을 올린다. 실패하면 그대로 오류로 남긴다 — 다른 목소리로 바꾸지 않는다."""
    try:
        pl.TTS_CACHE.mkdir(parents=True, exist_ok=True)
        out = pl.TTS_CACHE / ("narr_%s.mp3" % key.split(":")[1])

        def prog(i, n):
            job_set(key, pct=int(i * 100 / max(1, n)),
                    message="낭독을 만드는 중… %d/%d 조각" % (min(i + 1, n), n))
        p, dur = pl.tts_long(text, voice, rate, out, on_progress=prog)
        job_set(key, running=False, pct=100, message="",
                result={"path": str(p), "url": "/tts/%s" % p.name,
                        "duration": round(dur, 2), "chars": len(text)})
    except Exception as e:
        traceback.print_exc()
        job_set(key, running=False, pct=None, message="", errors=[str(e)])


def run_flow_job(key, items, refs, ratio, copy_to=None):
    """Flow 로 이미지를 만들고 결과 파일 목록을 job.result 에 넣는다. copy_to 가 있으면 이름.png 로 그 폴더에 복사한다(상품 시트)."""
    try:
        n = max(1, len(items))

        def prog(i, total, line):
            msg = line.split("] ", 1)[-1] if "] " in line else line
            job_set(key, pct=int(i * 100 / max(1, total)), message=msg[:120])
        job_set(key, message="Flow 를 여는 중… (장당 30초쯤, 그동안 Flow 크롬 창을 건드리지 마세요)")
        r = pl.flow_generate(items, refs=refs, ratio=ratio, on_progress=prog)
        files = []
        for it in r.get("items") or []:
            f = it.get("file")
            if not f or not Path(f).exists():
                continue
            if copy_to:
                Path(copy_to).mkdir(parents=True, exist_ok=True)
                dst = Path(copy_to) / ("%s.png" % it["name"])
                shutil.copy2(f, dst)
                f = str(dst)
            files.append({"name": it["name"], "file": f, "prompt": it.get("prompt", "")})
        missing = [it["name"] for it in (r.get("items") or []) if not it.get("file")]
        job_set(key, running=False, pct=100, message="",
                result={"images": files, "sheet": r.get("sheet"), "out": r.get("out"), "missing": missing, "n": n})
    except Exception as e:
        traceback.print_exc()
        job_set(key, running=False, pct=None, message="", errors=[str(e)])


def _flow_batch(key, items, refs, ratio, copy_to):
    """Flow 한 번 돌려 copy_to 에 name.png 로 넣는다. 돌려주는 값: (저장된 이름들, 실패한 이름들)."""
    if not items:
        return [], []
    def prog(i, total, line):
        msg = line.split("] ", 1)[-1] if "] " in line else line
        job_set(key, pct=int(i * 100 / max(1, total)), message=msg[:120])
    try:
        r = pl.flow_generate(items, refs=refs, ratio=ratio, on_progress=prog)
    except RuntimeError as e:
        if "한도" not in str(e) and "QUOTA" not in str(e):
            raise
        job_set(key, message="Nano Banana Pro 한도 — Nano Banana 로 다시 시도합니다")      # 모델별로 한도가 따로다(2026-09-12 실측)
        r = pl.flow_generate(items, refs=refs, ratio=ratio, on_progress=prog, model="Nano Banana")
    made, missing = [], []
    for it in r.get("items") or []:
        f = it.get("file")
        if f and Path(f).exists():
            Path(copy_to).mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, Path(copy_to) / ("%s.png" % it["name"]))
            made.append(it["name"])
        else:
            missing.append(it["name"])
    return made, missing


def run_product_flow_job(key, pid, refs, initial=True, rounds=2):
    """상품 신 이미지: (initial 이면) 없는 신을 Flow 로 만들고 → AI 검수 → 불합격 신만 고친 프롬프트로 다시(최대 rounds 회).
    제품이 안 나오는 신(product=false)은 참조 없이 그린다. 결과: images(현재 scenes 의 파일들), check(마지막 검수), regenerated, still_bad."""
    try:
        d = pr.pdir(pid)
        scenes_dir = d / "scenes"
        regenerated, still_bad, check = [], [], []
        overrides = {}
        for rnd in range(rounds + 1):
            if rnd == 0 and not initial:
                pass                                           # 검수부터
            else:
                items = pr.scene_prompts(pid, with_ref=bool(refs))
                todo = []
                for it in items:
                    n = it["name"]
                    if n in overrides:
                        it = dict(it, prompt=overrides[n]["prompt"], ref=bool(refs) and overrides[n]["product"])   # 검수가 '제품 없어야' 하면 참조 없이
                    elif (scenes_dir / ("%s.png" % n)).exists():
                        continue
                    todo.append(it)
                if not todo and rnd == 0:
                    job_set(key, message="신 이미지가 이미 다 있어 검수만 합니다")
                elif todo:
                    job_set(key, message="신 이미지 %d장 만드는 중… (%d회차)" % (len(todo), rnd + 1), pct=0)
                    with_ref = [it for it in todo if it.get("ref")]
                    no_ref = [it for it in todo if not it.get("ref")]
                    for n in [it["name"] for it in todo]:
                        (scenes_dir / ("%s.png" % n)).unlink(missing_ok=True)
                    _flow_batch(key, with_ref, refs, "9:16", scenes_dir)
                    _flow_batch(key, no_ref, [], "9:16", scenes_dir)
                    regenerated += [it["name"] for it in todo] if rnd > 0 else []
            job_set(key, message="AI 가 그림을 대본과 대조하는 중… (약 1분)", pct=None)
            try:
                check = pr.check_scenes(pid)
            except Exception as e:
                traceback.print_exc()
                job_set(key, message="검수를 못 했습니다(%s) — 그림은 그대로 둡니다" % str(e)[:80])
                check = []
                break
            bad = [c for c in check if not c["ok"] and c.get("prompt")]
            if not bad:
                break
            if rnd >= rounds:
                still_bad = bad
                break
            overrides = {str(c["n"]): {"prompt": c["prompt"], "product": c.get("product", True)} for c in bad}
            job_set(key, message="불합격 %d장(신 %s) 다시 그리는 중…" % (len(bad), ",".join(str(c["n"]) for c in bad)))
        files = [{"name": p.stem, "file": str(p)} for p in sorted(scenes_dir.glob("*.png"), key=lambda p: int(p.stem) if p.stem.isdigit() else 999) if p.stem.isdigit()]
        job_set(key, running=False, pct=100, message="",
                result={"images": files, "check": check, "regenerated": sorted(set(regenerated), key=int), "still_bad": still_bad, "missing": []})
    except Exception as e:
        traceback.print_exc()
        job_set(key, running=False, pct=None, message="", errors=[str(e)])



def run_script_job(key, body):
    """대본 생성 작업. 토막마다 진행률을 올린다."""
    try:
        def prog(pct, msg):
            job_set(key, pct=int(pct), message=msg)
        r = pl.write_script_long(
            body.get("topic"), body.get("kind"), body.get("minutes"),
            body.get("keywords") or "", body.get("audience") or "", on_progress=prog)
        job_set(key, running=False, pct=100, message="", result=r, errors=[])
    except Exception as e:
        traceback.print_exc()
        job_set(key, running=False, pct=None, message="", errors=[str(e)])

def run_grok_job(key, items, res, length, ratio, copy_to=None, engine="auto"):
    """이미지→영상. engine: grok | flow | auto(그록 먼저, 예외·실패 신은 Flow 로). copy_to 가 있으면 name.mp4 로 그 폴더에 복사(상품 clips/)."""
    try:
        def prog(i, total, line):
            msg = line.split("] ", 1)[-1] if "] " in line else line
            job_set(key, pct=int(i * 100 / max(1, total)), message=msg[:120])
        got = {}                                                     # name → 결과 item
        if engine in ("grok", "auto"):
            try:
                job_set(key, message="그록을 여는 중… (클립당 1~3분, 그동안 그 크롬 창을 건드리지 마세요)")
                r = pl.grok_videos(items, res=res, length=length, ratio=ratio, on_progress=prog)
                for it in r.get("items") or []:
                    got[it.get("name")] = it
            except Exception as e:
                if engine == "grok":
                    raise
                job_set(key, message="그록 실패(%s) — Flow 로 넘어갑니다" % str(e)[:60])
        rest = [it for it in items if not ((got.get(it["name"]) or {}).get("file") and Path(got[it["name"]]["file"]).exists())]
        if rest and engine in ("flow", "auto"):
            job_set(key, message="Flow(Veo)로 %d개 만드는 중… (클립당 1~3분)" % len(rest))
            r2 = pl.flow_videos(rest, on_progress=prog)
            for it in r2.get("items") or []:
                if it.get("file") or it.get("name") not in got:
                    got[it.get("name")] = dict(it, image=next((x["image"] for x in items if x["name"] == it.get("name")), None))
        r = {"items": [got.get(it["name"], {"name": it["name"], "file": None}) for it in items], "out": ""}
        files, failed = [], []
        for it in r.get("items") or []:
            f = it.get("file")
            if not f or not Path(f).exists():
                failed.append({"name": it.get("name"), "error": it.get("error")})
                continue
            if copy_to:
                Path(copy_to).mkdir(parents=True, exist_ok=True)
                dst = Path(copy_to) / ("%s.mp4" % it["name"])
                shutil.copy2(f, dst)
                f = str(dst)
            files.append({"name": it["name"], "file": f, "image": it.get("image")})
        job_set(key, running=False, pct=100, message="",
                result={"videos": files, "failed": failed, "out": r.get("out"), "n": len(items)})
    except Exception as e:
        traceback.print_exc()
        job_set(key, running=False, pct=None, message="", errors=[str(e)])


def prod_key(pid):
    return "prod:" + pid


def run_product(pid, opts):
    key = prod_key(pid)
    try:
        job_set(key, pct=5, message="상품 정보를 정리하는 중…")
        pr.research(pid, opts.get("text") or "", opts.get("images") or [])
        job_set(key, pct=15, message="AI 가 대본을 쓰는 중… (1~2분)")
        pr.write_script(pid, opts.get("provider") or "claude", opts.get("model") or None)
        job_set(key, pct=55, message="낭독을 만드는 중…")
        pr.make_voice(pid, opts.get("voice") or "ko-KR-InJoonNeural", opts.get("speed"))
        job_set(key, pct=85, message="이미지·영상 프롬프트를 쓰는 중…")
        pr.sheets(pid, int(opts.get("per") or 3))
        job_set(key, pct=100, message="대본·낭독·프롬프트가 준비됐습니다")
    except Exception as e:
        traceback.print_exc()
        job_set(key, errors=[str(e)], message="실패: %s" % e)
    finally:
        job_set(key, running=False, finished=time.time())


def _numstem(q):
    return (0, int(q.stem)) if q.stem.isdigit() else (1, 0)


def product_result(pid):
    d = pr.pdir(pid)
    if not (d / "meta.json").exists():
        raise RuntimeError("상품 작업이 없습니다: %s" % pid)
    out = {"id": pid, "dir": str(d), "job": job_get(prod_key(pid))}
    sj = d / "script.json"
    if sj.exists():
        data = json.loads(sj.read_text(encoding="utf-8"))
        scenes = data.get("scenes") or []
        out.update(script=" ".join(s.get("narration") or "" for s in scenes),
                   yt_title=data.get("title") or "", description=data.get("description") or "",
                   tags=data.get("tags") or [], keyword=data.get("keyword") or "", scenes=len(scenes))
    v = d / "audio" / "voice.wav"
    out["tts"] = str(v) if v.exists() else ""
    out["duration"] = round(pl.audio_duration(v), 2) if v.exists() else 0
    pm = d / "prompts.md"
    out["prompts"] = str(pm) if pm.exists() else ""
    out["sheet_files"] = len([q for q in (d / "sheets").iterdir()
                              if q.suffix.lower() in pl.IMAGE_EXTS]) if (d / "sheets").exists() else 0
    out["panels"] = len([q for q in (d / "scenes").glob("*.png") if q.stem.isdigit()])
    out["clips"] = [str(q) for q in sorted((d / "clips").glob("*.*"), key=_numstem)
                    if q.suffix.lower() in (".mp4", ".mov", ".webm", ".mkv")] if (d / "clips").exists() else []
    return out


def run_reanalyze(pid):
    with plock(pid):
        p = pl.load(pid)
        p["status"] = "analyzing"
        p["error"] = None
        pl.save(p)
    run_analyze_inner(p)


def run_render(pid, ids):
    with plock(pid):
        p = pl.load(pid)
        p["status"] = "rendering"
        pl.save(p)
    errors = []
    try:
        for k, sid in enumerate(ids):
            with plock(pid):
                p = pl.load(pid)
            short = next((s for s in p["shorts"] if s["id"] == sid), None)
            if not short:
                continue
            job_set(pid, current=sid, pct=0, message="%s 렌더링 중 (%d/%d)" % (sid, k + 1, len(ids)))
            try:
                pl.render_short(p, short, on_progress=lambda pct: job_set(pid, pct=pct))
            except Exception as e:
                traceback.print_exc()
                errors.append("%s: %s" % (sid, e))
                continue
            with plock(pid):
                cur = pl.load(pid)
                for s in cur["shorts"]:
                    if s["id"] == sid:
                        s["output"] = short["output"]
                        s["render"] = short["render"]
                pl.save(cur)
            job_set(pid, pct=100)
    finally:
        with plock(pid):
            p = pl.load(pid)
            p["status"] = "ready"
            pl.save(p)
        job_set(pid, current=None, errors=errors, message="완료" if not errors else "일부 실패")


# ── HTTP ─────────────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if args and isinstance(args[0], str) and "/api/projects/" in args[0] and "GET" in args[0]:   # send_error 는 HTTPStatus 를 넘긴다(2026-09-14 로그 예외)
            return  # 폴링 로그는 시끄럽다
        sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))

    # -- helpers
    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, msg, code=400):
        self._json({"error": msg}, code)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def _file(self, path: Path, download=False):
        if not path.exists() or not path.is_file():
            return self._err("not found", 404)
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        if path.suffix in (".html", ".js", ".css"):
            ctype += "; charset=utf-8"
        size = path.stat().st_size
        start, end = 0, size - 1
        rng = self.headers.get("Range")
        partial = False
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            try:
                if a:
                    start = int(a)
                    if b:
                        end = min(int(b), size - 1)
                elif b:
                    start = max(0, size - int(b))
                partial = True
            except ValueError:
                partial = False
        if partial and start > end:
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % size)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if partial:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        if path.suffix in (".html", ".js", ".css", ".json"):
            self.send_header("Cache-Control", "no-store")
        if download:
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''%s"
                             % path.name.encode("utf-8").decode("latin-1", "replace"))
        self.end_headers()
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def _project_view(self, pid):
        p = pl.load(pid)
        p["job"] = job_get(pid)
        return p

    # -- 폰(LAN) 게이트: 이 PC(루프백)는 그대로, 다른 기기는 lan_enabled + PIN 쿠키가 있어야 한다
    _LAN_OPEN = ("/m", "/m/", "/api/m/login", "/favicon.ico")

    def _is_local(self):
        ip = self.client_address[0]
        return ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def _gate(self, path):
        if self._is_local():
            return True
        cfg = pl.load_config()
        if not cfg.get("lan_enabled"):
            self._err("이 PC 에서만 쓸 수 있습니다. PC 쇼츠컷 홈의 「폰에서 쓰기」를 켜세요.", 403)
            return False
        if path in self._LAN_OPEN or path.startswith("/static/"):
            return True
        pin = str(cfg.get("lan_pin") or "")
        cookie = (self.headers.get("Cookie") or "").replace(" ", "")
        if pin and ("scpin=" + pin) in cookie.split(";"):
            return True
        self._err("PIN 이 필요합니다", 401)
        return False

    def m_login(self, body):
        cfg = pl.load_config()
        pin = str(cfg.get("lan_pin") or "")
        if not pin or str(body.get("pin") or "").strip() != pin:
            time.sleep(0.8)                                   # 무차별 대입을 늦춘다
            return self._err("PIN 이 맞지 않습니다", 401)
        data = json.dumps({"ok": True}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Set-Cookie", "scpin=%s; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax" % pin)
        self.end_headers()
        self.wfile.write(data)

    def m_upload(self, u):
        """폰에서 올린 파일 본문을 uploads/<날짜>/ 에 그대로 쓴다(멀티파트 아님, 파일당 요청 하나)."""
        q = parse_qs(u.query)
        name = pl.safe_upload_name((q.get("name") or ["file"])[0])
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return self._err("빈 파일입니다")
        d = pl.UPLOADS / time.strftime("%Y%m%d")
        d.mkdir(parents=True, exist_ok=True)
        dst = d / name
        i = 1
        while dst.exists():
            dst = d / ("%s_%d%s" % (Path(name).stem, i, Path(name).suffix))
            i += 1
        left = n
        with open(dst, "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(1 << 20, left))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        print("폰 업로드 %s (%.1f MB) from %s" % (dst.name, n / 1e6, self.client_address[0]))
        return self._json({"ok": True, "path": str(dst), "size": n})

    def m_projects(self):
        out = []
        for p in self.list_projects():
            d = pl.pdir(p["id"])
            outs = []
            for f in sorted((d / "output").glob("*.mp4")) if (d / "output").exists() else []:
                outs.append({"name": f.name, "short": f.stem.split("_")[-1], "size": f.stat().st_size,
                             "url": "/media/%s/output/%s?download=1" % (p["id"], f.name)})
            try:
                pj = json.loads((d / "project.json").read_text(encoding="utf-8"))
                kind, canvas = pj.get("kind"), (pj.get("settings") or {}).get("canvas") or "9:16"
            except Exception:
                kind, canvas = None, "9:16"
            tn = Path(p.get("thumb") or "thumb.jpg").name                    # 쇼핑 프로젝트는 source.jpg, 롱폼은 thumb.jpg
            thumb = "/media/%s/%s" % (p["id"], tn) if (d / tn).exists() else None
            out.append(dict(p, outputs=outs, kind=kind, canvas=canvas, thumb=thumb))
        return out

    # -- routes
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = unquote(u.path)
        if not self._gate(path):
            return
        try:
            if path == "/" or path == "/index.html":
                return self._file(WEB / "index.html")
            if path in ("/m", "/m/"):
                return self._file(WEB / "m.html")
            if path == "/favicon.ico":
                return self._file(WEB / "favicon.ico")
            if path == "/api/lan":
                return self._json(pl.lan_state(self.server.server_address[1]))
            if path == "/api/m/projects":
                return self._json(self.m_projects())
            if path.startswith("/static/"):
                return self._file(WEB / path[len("/static/"):])
            if path == "/api/layouts":
                return self._json(pl.all_layouts())
            if path == "/api/affiliate":
                return self._json(af.status())
            if path == "/api/product":
                pid = (q.get("id") or [""])[0].strip()
                if not pid:
                    return self._json({"items": [x.name for x in sorted(pr.PRODUCTS.glob("*"), reverse=True)
                                                 if (x / "meta.json").exists()][:20]})
                return self._json(product_result(pid))
            if path == "/api/projects":
                return self._json(self.list_projects())
            if path.startswith("/api/projects/"):
                pid = path.split("/")[3]
                if not (pl.pdir(pid) / "project.json").exists():
                    return self._err("no such project", 404)
                return self._json(self._project_view(pid))
            if path == "/api/probe":
                url = (q.get("url") or [""])[0].strip()
                if not url:
                    return self._err("url 이 비었습니다")
                return self._json(pl.probe_url(url))
            if path == "/api/probe_file":
                fp = Path((q.get("path") or [""])[0].strip().strip('"'))
                if not fp.exists():
                    return self._err("파일이 없습니다: %s" % fp)
                w, h, dur = pl.ffprobe_video(fp)
                return self._json({"title": fp.stem, "duration": dur, "width": w, "height": h,
                                   "path": str(fp)})
            if path == "/api/pick_file":
                kind = (q.get("kind") or ["image"])[0]
                return self._json({"path": pl.pick_file(kind)})
            if path == "/api/pick_folder":
                return self._json({"path": pl.pick_folder((q.get("initial") or [""])[0])})
            if path == "/api/caps":
                return self._json({"ocr": pl.ocr_available()})
            if path == "/api/tts/voices":
                # ElevenLabs 는 키가 있을 때만 목록에 붙는다(계정에서 받아 오며 10분 캐시)
                return self._json({"voices": pl.tts_voices(), "eleven_ready": bool(pl.eleven_key())})
            if path == "/api/tts/eleven":
                return self._json(pl.eleven_status())
            if path == "/api/tts/make":                  # 진행률 묻기
                j = dict(job_get("tts:" + (q.get("token", [""])[0] or "")) or {})
                j.pop("kind", None)
                return self._json({"job": j})
            if path == "/api/grok/videos":                # 그록 영상 작업 진행률(token)
                j = dict(job_get("grok:" + (q.get("token", [""])[0] or "")) or {})
                j.pop("kind", None)
                return self._json({"job": j})
            if path == "/api/flow/images":                # Flow 이미지 작업 진행률(token)
                j = dict(job_get("flow:" + (q.get("token", [""])[0] or "")) or {})
                j.pop("kind", None)
                return self._json({"job": j})
            if path == "/api/transitions":
                return self._json({"transitions": pl.TRANSITIONS})
            if path == "/api/music":
                return self._json({"items": pl.music_presets()})
            if path == "/api/fonts":
                return self._json({"fonts": pl.text_fonts()})
            if path == "/api/sfx":
                return self._json({"items": pl.sfx_list()})
            if path.startswith("/sfx/"):
                name = unquote(path[len("/sfx/"):])
                if "/" in name or "\\" in name or ".." in name:
                    return self._err("bad path")
                return self._file(pl.SFX_DIR / name)
            if path.startswith("/tts/"):
                name = unquote(path[len("/tts/"):])
                if "/" in name or "\\" in name or ".." in name:
                    return self._err("bad path")
                return self._file(pl.TTS_CACHE / name)
            if path.startswith("/fonts/"):
                name = unquote(path[len("/fonts/"):])
                if "/" in name or "\\" in name or ".." in name:
                    return self._err("bad path")
                return self._file(pl.FONTS / name)
            if path.startswith("/music/"):
                target = (pl.MUSIC_DIR / unquote(path[len("/music/"):])).resolve()
                if pl.MUSIC_DIR.resolve() not in target.parents:
                    return self._err("forbidden", 403)
                return self._file(target)
            if path == "/api/stock/search":
                d = pl.stock_search((q.get("q") or [""])[0], (q.get("kind") or ["video"])[0], (q.get("src") or ["pexels"])[0], (q.get("page") or ["1"])[0])
                if d.get("error"):
                    return self._err(d["error"], 400)
                return self._json(d)
            if path == "/api/license":
                return self._json(lic.status(pl.load_config()))
            if path == "/api/config":
                cfg = pl.load_config()
                masked = {k: (("•••" + v[-4:]) if isinstance(v, str) and v and k.endswith("_key") else v)
                          for k, v in cfg.items()}
                cli = bool(pl.which("claude"))
                return self._json({"config": masked, "providers": pl.PROVIDERS, "claude_cli": cli,
                                   "default_provider": cfg.get("default_provider") or ("claude" if cli else "anthropic"),
                                   "ffmpeg": pl.ffmpeg_status()})
            if path == "/api/ffmpeg":
                return self._json(pl.ffmpeg_status())
            if path == "/api/version":
                return self._json({"version": pl.VERSION, "update": pl.update_state(), "update_url": bool(pl.update_url())})
            if path == "/api/script/write":                # 대본 작업 진행률(token)
                j = dict(job_get("script:" + (q.get("token", [""])[0] or "")) or {})
                j.pop("kind", None)
                return self._json({"job": j})
            if path == "/api/cleanup/scan":
                return self._json(pl.cleanup_scan(q.get("days", [None])[0]))
            if path == "/api/doctor":
                return self._json(pl.doctor())
            if path == "/api/update/check":
                try:
                    return self._json(pl.update_check())
                except Exception as e:
                    return self._err("업데이트 확인 실패: %s" % e, 502)
            if path == "/api/thumb":
                # 업로드 목록 썸네일: ?path=<로컬 영상·이미지>. /api/logo 와 같은 규칙(있는 파일만, 미디어 확장자만)
                fp = Path((q.get("path") or [""])[0].strip().strip('"'))
                if not fp.exists() or fp.suffix.lower() not in pl.IMAGE_EXT | {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}:
                    return self._err("영상·이미지 파일이 아닙니다", 404)
                th = pl.path_thumb(fp)
                if not th:
                    return self._err("썸네일을 만들지 못했습니다", 500)
                return self._file(th)
            if path == "/api/logo":
                fp = Path((q.get("path") or [""])[0].strip().strip('"'))
                if not fp.exists() or fp.suffix.lower() not in pl.IMAGE_EXTS:
                    return self._err("이미지 파일이 아닙니다", 404)
                return self._file(fp)
            if path.startswith("/media/"):
                parts = path.split("/", 3)
                if len(parts) < 4:
                    return self._err("bad media path", 404)
                pid, rest = parts[2], parts[3]
                target = (pl.pdir(pid) / rest).resolve()
                if pl.PROJECTS.resolve() not in target.parents:
                    return self._err("forbidden", 403)
                if not target.exists() and "/" not in rest:
                    pl.restore_media(pid, rest)          # 옮기다 빠진 소재는 원본 경로에서 되살린다(2026-09-14)
                return self._file(target, download="download" in q)
            return self._err("not found", 404)
        except Exception as e:
            traceback.print_exc()
            return self._err(str(e), 500)

    def do_POST(self):
        u = urlparse(self.path)
        path = unquote(u.path)
        if not self._gate(path):
            return
        try:
            if path == "/api/m/upload":
                return self.m_upload(u)
            body = self._body()
            if path == "/api/m/login":
                return self.m_login(body)
            if path == "/api/m/create":
                paths = [str(x) for x in (body.get("paths") or [])]
                cfg = pl.load_config()
                return self.create_shop({"videos": paths, "tts": "", "script": "",
                                         "settings": {"ratio": "9:16", "canvas": body.get("canvas") or "9:16", "src_volume": 1,
                                                      "channel_name": cfg.get("last_channel") or "",
                                                      "provider": cfg.get("default_provider") or "claude", "effort": "low"}})
            if path == "/api/lan":
                if not self._is_local():
                    return self._err("이 설정은 PC 에서만 바꿀 수 있습니다", 403)
                cfg = pl.load_config()
                if "enabled" in body:
                    cfg["lan_enabled"] = bool(body.get("enabled"))
                if body.get("new_pin") or (cfg.get("lan_enabled") and not cfg.get("lan_pin")):
                    cfg["lan_pin"] = pl.gen_pin()
                pl.save_config(cfg)
                st = pl.lan_state(self.server.server_address[1])
                restart = bool(body.get("restart", "enabled" in body))
                self._json(dict(st, restart=restart))
                if restart:
                    threading.Timer(0.3, pl.restart_server).start()   # 바인드 주소가 바뀌므로 다시 뜬다
                return
            if path == "/api/script/write":
                b = body or {}
                if not (b.get("topic") or "").strip():
                    return self._err("무엇에 대한 영상인지 적어 주세요", 400)
                token = uuid.uuid4().hex[:12]
                key = "script:" + token
                job_set(key, kind="script", running=True, pct=0,
                        message="시작하는 중…", errors=[], started=time.time(), result=None)
                threading.Thread(target=run_script_job, args=(key, b), daemon=True).start()
                return self._json({"token": token})
            if path == "/api/cleanup/apply":
                return self._json(pl.cleanup_apply((body or {}).get("ids")))
            if path == "/api/license":
                # 키 등록(검증 뒤 config.json 에 저장) / 해제. 검증 실패면 저장하지 않고 이유를 돌려준다.
                cfg = pl.load_config()
                if body.get("clear"):
                    cfg.pop("license_key", None); pl.save_config(cfg)
                    return self._json(lic.status(cfg))
                key = (body.get("key") or "").strip()
                try:
                    lic.parse_key(key)
                except ValueError as e:
                    return self._err(str(e), 400)
                cfg["license_key"] = key.replace("\n", "").replace(" ", ""); pl.save_config(cfg)
                return self._json(lic.status(cfg))
            if path == "/api/projects":
                return self.create_project(body)
            if path == "/api/shop":
                return self.create_shop(body)
            if path == "/api/product":
                return self.create_product_job(body)
            if path == "/api/tts/eleven":
                # 키·모델 저장. 가려진 값(•••)이 되돌아와 덮어쓰는 것을 막는다.
                cfg = pl.load_config()
                v = (body.get("elevenlabs_key") or "").strip()
                if v and not v.startswith("\u2022"):
                    cfg["elevenlabs_key"] = v
                elif body.get("clear"):
                    cfg.pop("elevenlabs_key", None)
                m = (body.get("elevenlabs_model") or "").strip()
                if m in [x["id"] for x in pl.ELEVEN_MODELS]:
                    cfg["elevenlabs_model"] = m
                pl.save_config(cfg)
                pl.eleven_voices(force=True)                 # 캐시를 새 키로 다시 채운다
                return self._json(pl.eleven_status())
            if path == "/api/affiliate/keys":
                # 키 저장. 빈 값은 저장하지 않는다(마스킹된 값이 되돌아와 덮어쓰는 것을 막는다).
                cfg = pl.load_config()
                for k in ("coupang_access_key", "coupang_secret_key",
                          "toss_access_key", "toss_secret_key", "toss_publisher_id"):
                    v = (body.get(k) or "").strip()
                    if v and not v.startswith("•"):
                        cfg[k] = v
                pl.save_config(cfg)
                return self._json(af.status())
            if path == "/api/affiliate/link":
                try:
                    return self._json(af.make_link(body.get("provider") or "", body.get("target") or ""))
                except Exception as e:
                    return self._err(str(e))
            if path == "/api/grok/videos":
                return self.create_grok_job(body)
            if path == "/api/product/grok":
                return self.create_product_grok_job(body)
            if path == "/api/flow/images":
                return self.create_flow_job(body)
            if path == "/api/flow/login":
                try:
                    pl.flow_login()
                except Exception as e:
                    return self._err(str(e))
                return self._json({"ok": True})
            if path == "/api/product/flow":
                return self.create_product_flow_job(body)
            if path == "/api/product/voice":
                return self.create_product_voice_job(body)
            if path == "/api/tts/make":
                return self.create_tts_job(body)
            if path == "/api/tts/preview":
                # 프로젝트 없이(홈 화면에서) 목소리를 들어 본다. 결과는 cache/tts 에 남아 두 번째부터는 즉시.
                out, dur = pl.tts_preview(body.get("text") or "", body.get("voice") or "ko-KR-InJoonNeural",
                                          body.get("rate") or 0)
                return self._json({"url": "/tts/%s" % out.name, "duration": round(dur, 2)})
            if path == "/api/product/split":
                pid = (body.get("id") or "").strip()
                try:
                    pr.split_sheets(pid, int(body.get("per") or 3), body.get("axis") or "h")
                except SystemExit as e:
                    return self._err(str(e))
                return self._json(product_result(pid))
            if path == "/api/product/stills":
                pid = (body.get("id") or "").strip()
                try:
                    made = pr.stills_to_clips(pid)
                except SystemExit as e:
                    return self._err(str(e))
                r = product_result(pid)
                r["made"] = len(made)
                return self._json(r)
            if path == "/api/product/open":
                pid = (body.get("id") or "").strip()
                d = pr.pdir(pid)
                what = body.get("what") or "dir"
                target = {"dir": d, "prompts": d / "prompts.md", "sheets": d / "sheets",
                          "scenes": d / "scenes", "clips": d / "clips"}.get(what, d)
                if not target.exists():
                    return self._err("아직 없습니다: %s" % target)
                os.startfile(str(target))
                return self._json({"ok": True, "path": str(target)})
            if path == "/api/sfx":
                # 효과음 등록(여러 파일) / 제거(remove=id, 사용자 등록만)
                if body.get("remove"):
                    pl.sfx_remove(body["remove"])
                    return self._json({"ok": True, "items": pl.sfx_list()})
                fps = body.get("paths") or pl.pick_files("audio")
                if not fps:
                    return self._json({"cancelled": True})
                added = pl.sfx_add(fps)
                return self._json({"ok": True, "added": added, "items": pl.sfx_list()})
            if path == "/api/fonts":
                # 글꼴 등록(ttf/otf 여러 개) / 제거(remove=id, 사용자 등록만)
                if body.get("remove"):
                    pl.font_remove(body["remove"])
                    return self._json({"ok": True, "fonts": pl.text_fonts()})
                fps = body.get("paths") or pl.pick_files("font")
                if not fps:
                    return self._json({"cancelled": True})
                added = pl.font_add(fps)
                return self._json({"ok": True, "added": added, "fonts": pl.text_fonts()})
            if path == "/api/pick_files":
                return self._json({"paths": pl.pick_files(body.get("kind") or "video")})
            if path == "/api/update/apply":
                busy = [pid for pid, j in list(_jobs.items()) if j.get("running")]
                if busy and not body.get("force"):
                    return self._err("작업이 돌고 있습니다(%s). 끝난 뒤 업데이트하세요." % ", ".join(busy), 409)
                started = pl.update_apply(body.get("url") or None)
                return self._json({"ok": True, "started": started, "update": pl.update_state()})
            if path == "/api/report":
                out = pl.report_zip()
                if body.get("open", True):
                    try:
                        subprocess.run(["explorer", "/select,", str(out)], check=False)
                    except Exception:
                        pass
                return self._json({"ok": True, "path": str(out), "size": out.stat().st_size})
            if path == "/api/ffmpeg/install":
                started = pl.ffmpeg_install()
                return self._json({"ok": True, "started": started, **pl.ffmpeg_status()})
            if path == "/api/config":
                cfg = pl.load_config()
                for k in ("openai_key", "gemini_key", "anthropic_key", "ollama_url", "default_provider", "default_model", "default_effort",
                          "model_claude", "model_anthropic", "model_openai", "model_gemini", "model_ollama",
                          "xai_key", "model_xai", "script_root", "update_url", "last_channel",
                          "elevenlabs_key", "elevenlabs_model", "pexels_key", "pixabay_key"):
                    if k in body:
                        v = (body.get(k) or "").strip()
                        if k.endswith("_key") and v.startswith("•••"):
                            continue                      # 가려진 값이 그대로 돌아온 것 — 바꾸지 않는다
                        if v:
                            cfg[k] = v
                        else:
                            cfg.pop(k, None)
                pl.save_config(cfg)
                return self._json({"ok": True})
            if path == "/api/open_path":
                target = Path((body.get("path") or "").strip().strip('"'))
                if not target.exists():
                    return self._err("폴더가 아직 없습니다: %s" % target, 404)
                os.startfile(str(target))
                return self._json({"ok": True})
            if path == "/api/quit":
                busy = [pid for pid, j in list(_jobs.items()) if j.get("running")]
                if busy and not body.get("force"):
                    return self._err("작업이 돌고 있습니다(%s). 끝난 뒤 종료하거나 강제 종료를 고르세요." % ", ".join(busy), 409)
                self._json({"ok": True})
                print("%s 사용자가 서버를 종료했습니다" % time.strftime("%H:%M:%S"))
                threading.Timer(0.4, lambda: os._exit(0)).start()
                return
            if path.startswith("/api/projects/"):
                parts = path.split("/")
                pid = parts[3]
                action = parts[4] if len(parts) > 4 else ""
                if not (pl.pdir(pid) / "project.json").exists():
                    return self._err("no such project", 404)
                if action == "render":
                    p = pl.load(pid)
                    ids = body.get("ids") or [s["id"] for s in p["shorts"]]
                    if not start_job(pid, "render", lambda: run_render(pid, ids)):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "shop_copy":
                    # 쇼핑 쇼츠: 대본(또는 자막 전체)으로 제목·문안을 AI 가 다시 쓴다
                    with plock(pid):
                        p = pl.load(pid)
                    script = (body.get("script") or (p.get("shop") or {}).get("script") or
                              " ".join(c["text"] for c in p.get("cues") or []))
                    if len(script.strip()) < 10:
                        return self._err("대본이나 자막이 없어 문안을 만들 수 없습니다")
                    c = pl.shop_copy(script, provider=p["settings"].get("provider") or "claude", model=p["settings"].get("model") or None)
                    with plock(pid):
                        cur = pl.load(pid)
                        s = cur["shorts"][0]
                        for k in ("line1", "line2", "yt_title", "description", "tags"):
                            if c.get(k):
                                s[k] = c[k]
                        pl.save(cur)
                    return self._json({"ok": True, "short": s})
                if action == "narration":
                    # 편집기에서 낭독 파일을 나중에 넣는다(또는 바꾼다): 복사 → 받아쓰기 → 조각 길이 재배분
                    fp = (body.get("path") or "").strip().strip('"')
                    if not fp:
                        fp = pl.pick_file("audio")
                        if not fp:
                            return self._json({"cancelled": True})
                    if not Path(fp).exists():
                        return self._err("파일이 없습니다: %s" % fp)

                    def run_nar():
                        with plock(pid):
                            p = pl.load(pid)
                        job_set(pid, message="낭독을 담고 받아쓰는 중", pct=None)
                        script = (body.get("script") or (p.get("shop") or {}).get("script") or "").strip()
                        nar_dur = attach_narration(p, fp, script)
                        with plock(pid):
                            cur = pl.load(pid)
                            cur["narration"], cur["cues"], cur["cues_auto"], cur["cues_source"], cur["asr_model"] = \
                                p["narration"], p["cues"], p["cues_auto"], p["cues_source"], p.get("asr_model")
                            if script:
                                cur.setdefault("shop", {})["script"] = script
                            # 원본 소리는 그대로 둔다(모든 영상 트랙에서 소리가 나게). 줄이려면 편집기의 원본 소리 값을 낮춘다
                            # 조각 길이를 낭독에 맞춘다
                            for s in cur["shorts"]:
                                cs = s.get("clips") or []
                                lens = [pl.source_by_id(cur, c.get("src"))["duration"] - c["s"] for c in cs]
                                shares = pl.split_even(nar_dur, lens)
                                for c, L, shv in zip(cs, lens, shares):
                                    c["e"] = round(min(c["s"] + L, c["s"] + max(0.5, shv)), 3)
                                s["cue_edits"] = {}
                                s["end"] = nar_dur
                            pl.save(cur)
                        job_set(pid, message="낭독 %.1f초 · 자막 %d줄" % (nar_dur, len(p["cues"])))
                    if not start_job(pid, "ocr", run_nar):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "stock_get":
                    with plock(pid):
                        p = pl.load(pid)
                    src = pl.stock_get(p, body.get("item") or {})
                    with plock(pid):
                        cur = pl.load(pid)
                        cur["extra_sources"] = p["extra_sources"]
                        pl.save(cur)
                    return self._json({"ok": True, "source": src, "sources": p["extra_sources"]})
                if action == "audio_lib":
                    with plock(pid):
                        p = pl.load(pid)
                        if body.get("remove"):
                            gone = [a for a in p.get("audio_lib") or [] if a.get("id") == body["remove"]]
                            p["audio_lib"] = [a for a in p.get("audio_lib") or [] if a.get("id") != body["remove"]]
                            for g in gone:
                                try:
                                    Path(g["path"]).unlink()
                                except OSError:
                                    pass
                            pl.save(p)
                            return self._json({"ok": True, "audio_lib": p["audio_lib"]})
                    fps = body.get("paths") or pl.pick_files("audio")
                    if not fps:
                        return self._json({"cancelled": True})
                    with plock(pid):
                        p = pl.load(pid)
                        added = pl.audio_lib_add(p, fps)
                        pl.save(p)
                    return self._json({"ok": True, "added": added, "audio_lib": p.get("audio_lib") or []})
                if action == "audios":
                    # 추가 오디오 트랙: 파일을 프로젝트에 복사해 쇼츠의 audios[] 에 넣는다 / remove=id 로 뺀다
                    # (uuid 는 모듈 최상단에서 import 한다. 여기서 다시 import 하면 do_POST 전체에서
                    #  uuid 가 지역 변수가 되어, 이 줄보다 앞에서 쓰는 곳이 UnboundLocalError 로 죽는다)
                    with plock(pid):
                        p = pl.load(pid)
                        s = next((x for x in p["shorts"] if x["id"] == (body.get("sid") or p["shorts"][0]["id"])), p["shorts"][0])
                        if body.get("remove"):
                            keep = [a for a in s.get("audios") or [] if a.get("id") != body["remove"]]
                            gone = [a for a in s.get("audios") or [] if a.get("id") == body["remove"]]
                            s["audios"] = keep
                            still = any(a.get("path") == g.get("path") for g in gone for x in p["shorts"] for a in x.get("audios") or [])
                            for g in gone:
                                if not still and g.get("path"):
                                    try:
                                        Path(g["path"]).unlink()
                                    except OSError:
                                        pass
                            pl.save(p)
                            return self._json({"ok": True, "short": s})
                    fps = body.get("paths") or pl.pick_files("audio")
                    if not fps:
                        return self._json({"cancelled": True})
                    at = max(0.0, float(body.get("at") or 0))
                    try:
                        vol0 = min(2.0, max(0.0, float(body.get("volume")))) if body.get("volume") is not None else 1.0   # 효과음 기본 음량(프로젝트 설정)이 넘어온다
                    except Exception:
                        vol0 = 1.0
                    added = []
                    d = pl.pdir(pid)
                    for fp in fps:
                        src = Path(fp)
                        if not src.exists():
                            continue
                        aid = "a" + uuid.uuid4().hex[:6]
                        dst = d / ("aud_%s%s" % (aid, src.suffix.lower()))
                        shutil.copy2(src, dst)
                        dur = pl.audio_duration(dst)
                        item = {"id": aid, "path": str(dst), "file": dst.name, "url": "/media/%s/%s" % (pid, dst.name), "title": src.stem,
                                "duration": dur, "at": round(at, 3), "in": 0.0, "out": None, "volume": vol0,
                                "lane": max(1, int(body.get("lane") or 1))}
                        added.append(item)
                        at += dur
                    with plock(pid):
                        p = pl.load(pid)
                        s = next((x for x in p["shorts"] if x["id"] == (body.get("sid") or p["shorts"][0]["id"])), p["shorts"][0])
                        s.setdefault("audios", []).extend(added)
                        pl.save(p)
                    return self._json({"ok": True, "added": added, "short": s})
                if action == "transcribe_video":
                    # 낭독·대본이 없는 쇼핑 프로젝트: 본편(첫 영상)의 소리를 받아써 자막(원본 시간 기준)을 만들고, 원하면 제목·문안까지 쓴다
                    want_copy = bool(body.get("copy"))

                    def run_tv():
                        with plock(pid):
                            p = pl.load(pid)
                        job_set(pid, message="영상 소리를 받아쓰는 중… (긴 영상은 1~2분)", pct=None)
                        cues, desc = pl.transcribe_audio(p["source"]["path"], max_chars=pl.sub_max_chars(p.get("settings")))
                        with plock(pid):
                            cur = pl.load(pid)
                            cur["cues_auto"] = cues
                            cur["cues"] = cues
                            cur["cues_source"] = "video"
                            cur["asr_model"] = desc
                            for s in cur["shorts"]:
                                s["cue_edits"] = {}
                            pl.save(cur)
                        msg = "받아쓰기 완료: %d줄 (%s)" % (len(cues), desc)
                        if want_copy:
                            job_set(pid, message="AI 가 제목·문안을 쓰는 중…", pct=None)
                            # 지금 트랙에 남은 조각 구간의 말만 모아 준다(잘라낸 부분은 빼고)
                            with plock(pid):
                                cur = pl.load(pid)
                            short = cur["shorts"][0]
                            parts = []
                            for c in pl.clips_of(short):
                                if c.get("src", "main") != "main":
                                    continue
                                parts += [q["text"] for q in cues if q["e"] > c["s"] and q["s"] < c["e"]]
                            script = " ".join(parts) or " ".join(q["text"] for q in cues)
                            copy = pl.shop_copy(script, provider=cur["settings"].get("provider") or "claude", model=cur["settings"].get("model") or None)
                            with plock(pid):
                                cur = pl.load(pid)
                                s = cur["shorts"][0]
                                for k in ("line1", "line2", "yt_title", "description", "tags"):
                                    if copy.get(k):
                                        s[k] = copy[k]
                                pl.save(cur)
                            msg += " · 제목·문안 작성됨"
                        job_set(pid, message=msg)
                    if not start_job(pid, "ocr", run_tv):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "retranscribe":
                    def run_asr():
                        with plock(pid):
                            p = pl.load(pid)
                        job_set(pid, message="낭독을 다시 받아쓰는 중", pct=None)
                        cues, desc = pl.transcribe_audio(p["narration"]["path"], max_chars=pl.sub_max_chars(p.get("settings")))
                        with plock(pid):
                            cur = pl.load(pid)
                            cur["cues_auto"] = cues
                            cur["cues"] = cues
                            cur["cues_source"] = "whisper"
                            for s in cur["shorts"]:
                                s["cue_edits"] = {}
                            pl.save(cur)
                        job_set(pid, message="받아쓰기 완료: %d줄 (%s)" % (len(cues), desc))
                    if not start_job(pid, "ocr", run_asr):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "analyze":
                    with plock(pid):
                        p = pl.load(pid)
                        st = body.get("settings") or {}
                        p["settings"].update({k: st[k] for k in ("range", "count", "model", "effort", "provider") if k in st})
                        pl.save(p)
                    if not start_job(pid, "analyze", lambda: run_reanalyze(pid)):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "retry":
                    p = pl.load(pid)
                    if p.get("kind") == "shop":
                        return self._json({"ok": start_job(pid, "create", lambda: run_create_shop(pid))})
                    if p["source"].get("path") and Path(p["source"]["path"]).exists() and p.get("filmstrip"):
                        ok = start_job(pid, "analyze", lambda: run_reanalyze(pid))
                    else:
                        ok = start_job(pid, "create", lambda: run_create(pid))
                    return self._json({"ok": ok})
                if action == "open":
                    d = pl.pdir(pid) / "output"
                    d.mkdir(exist_ok=True)
                    os.startfile(str(d))
                    return self._json({"ok": True, "path": str(d)})
                if action == "export_capcut":
                    # 컷표·자막·텍스트·낭독을 CapCut 드래프트로 쓴다. 렌더는 CapCut 에서 한다.
                    import capcut_export as ce
                    if not ce.CAPCUT_ROOT.exists():
                        return self._err("이 PC 에 CapCut 프로젝트 폴더가 없습니다: %s" % ce.CAPCUT_ROOT, 404)
                    with plock(pid):
                        p = pl.load(pid)
                    sid = body.get("id") or (p["shorts"][0]["id"] if p.get("shorts") else None)
                    short = next((s for s in p["shorts"] if s["id"] == sid), None)
                    if not short:
                        return self._err("쇼츠가 없습니다")
                    try:
                        path = ce.export_capcut(p, short, name=body.get("name"), register=body.get("register", True))
                    except Exception as e:
                        traceback.print_exc()
                        return self._err("CapCut 내보내기 실패: %s" % e)
                    if body.get("open", True):
                        try:
                            os.startfile(path)
                        except Exception:
                            pass
                    return self._json({"ok": True, "path": path})
                if action == "export":
                    # 렌더 안 된(또는 다시 렌더할) 쇼츠를 먼저 만들고, mp4 + shorts-upload.json 을 폴더로 복사한 뒤 연다
                    dest = (body.get("dest") or "").strip().strip('"')
                    if not dest:
                        return self._err("내보낼 폴더를 골라 주세요")
                    rerender = bool(body.get("rerender"))
                    open_after = body.get("open", True)
                    only = body.get("ids")            # 없으면 전체

                    def run_export():
                        with plock(pid):
                            p = pl.load(pid)
                        targets = [s for s in p["shorts"] if not only or s["id"] in only]
                        ids = [s["id"] for s in targets if rerender or not s.get("output")
                               or not (pl.pdir(pid) / "output" / s["output"]).exists()]
                        if ids:
                            run_render(pid, ids)
                        with plock(pid):
                            p = pl.load(pid)
                        job_set(pid, message="파일 복사 중", pct=None, current=None)
                        copied = pl.export(p, dest, ids=[s["id"] for s in targets] if only else None)
                        with plock(pid):
                            cur = pl.load(pid)
                            cur["export_dest"] = dest
                            pl.save(cur)
                        job_set(pid, message="내보내기 완료: %d개 → %s" % (len(copied), dest), copied=copied, dest=dest)
                        if open_after:
                            try:
                                os.startfile(dest)
                            except Exception:
                                pass
                    if not start_job(pid, "export", run_export):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "export_default":
                    p = pl.load(pid)
                    return self._json({"dest": p.get("export_dest") or pl.default_export_dir(p)})
                if action == "script_cues":
                    # 낭독·자막이 없을 때 대본 문장을 이 쇼츠의 조각 시간에 고르게 나눠 자막으로 만든다(편집기 「대본 넣기」의 세 번째 방법)
                    text = (body.get("text") or "").strip()
                    if len(text) < 10:
                        return self._err("대본이 너무 짧습니다")
                    p = pl.load(pid)
                    sid = body.get("sid") or (p["shorts"][0]["id"] if p["shorts"] else None)
                    short = next((s for s in p["shorts"] if s["id"] == sid), None)
                    if not short:
                        return self._err("쇼츠를 찾지 못했습니다")
                    try:
                        new_cues = pl.script_even_cues(p, short, text)
                    except RuntimeError as e:
                        return self._err(str(e))
                    with plock(pid):
                        cur = pl.load(pid)
                        if cur.get("cues") and not cur.get("cues_auto"):
                            cur["cues_auto"] = cur["cues"]
                        cur["cues"] = new_cues
                        cur["cues_source"] = "script_even"
                        cur.setdefault("shop", {})["script"] = text
                        for s in cur["shorts"]:
                            s["cue_edits"] = {}
                        pl.save(cur)
                    return self._json({"ok": True, "cues": len(new_cues)})
                if action == "align":
                    # 대본 텍스트를 자동 자막 시간축에 붙인다. text / path / auto 중 하나
                    text = body.get("text") or ""
                    path = (body.get("path") or "").strip().strip('"')
                    p = pl.load(pid)
                    if not text and not path and body.get("auto"):
                        path = pl.find_script(p) or ""
                        if not path:
                            return self._err("저장소에서 이 영상의 대본을 찾지 못했습니다. 파일을 직접 골라 주세요.", 404)
                    if not text and path:
                        if not Path(path).exists():
                            return self._err("파일이 없습니다: %s" % path)
                        text = Path(path).read_text(encoding="utf-8", errors="replace")
                    if len(text.strip()) < 50:
                        return self._err("대본 내용이 너무 짧습니다")
                    base = p.get("cues_auto") or p["cues"]
                    if not base or sum(len(c.get("text") or "") for c in base) < 20:
                        return self._err("맞춰 넣을 자막이 아직 없습니다. 「대본 넣기」에서 '낭독 파일과 함께' 또는 '시간에 고르게 나누기'를 고르세요.")
                    new_cues, stats = pl.align_script(base, text, max_chars=pl.sub_max_chars(p.get("settings")))
                    with plock(pid):
                        cur = pl.load(pid)
                        cur.setdefault("cues_auto", base)
                        cur["cues"] = new_cues
                        cur["cues_source"] = "script"
                        for s in cur["shorts"]:
                            s["cue_edits"] = {}
                        pl.save(cur)
                    stats["path"] = path
                    return self._json(stats)
                if action == "ocr":
                    ocr_ok, ocr_why = pl.ocr_status()
                    if not ocr_ok:
                        return self._err("영상 속 자막 읽기를 할 수 없습니다 — " + ocr_why)

                    def run_ocr():
                        with plock(pid):
                            p = pl.load(pid)
                        job_set(pid, message="영상 아래쪽 자막을 읽는 중", pct=0)
                        cues = pl.ocr_burned_subs(p, on_progress=lambda pct: job_set(pid, pct=pct),
                                                  t0=body.get("start"), t1=body.get("end"))
                        with plock(pid):
                            cur = pl.load(pid)
                            cur.setdefault("cues_auto", cur["cues"])
                            cur["cues"] = cues
                            cur["cues_source"] = "ocr"
                            for s in cur["shorts"]:
                                s["cue_edits"] = {}
                            pl.save(cur)
                        job_set(pid, pct=100, message="OCR 완료: %d줄" % len(cues))
                    if not start_job(pid, "ocr", run_ocr):
                        return self._err("이미 작업이 돌고 있습니다", 409)
                    return self._json({"ok": True})
                if action == "snap":
                    with plock(pid):
                        p = pl.load(pid)
                        a, b = pl.snap_bounds(p, float(body.get("start", 0)), float(body.get("end", 0)))
                    return self._json({"start": a, "end": b})
                if action == "cues_restore":
                    with plock(pid):
                        cur = pl.load(pid)
                        if not cur.get("cues_auto"):
                            return self._err("되돌릴 자동 자막이 없습니다")
                        cur["cues"] = cur["cues_auto"]
                        cur["cues_source"] = "auto"
                        for s in cur["shorts"]:
                            s["cue_edits"] = {}
                        pl.save(cur)
                    return self._json({"ok": True, "cues": len(cur["cues"])})
                if action == "bgm":
                    fp = (body.get("path") or "").strip().strip('"')
                    if body.get("clear"):
                        with plock(pid):
                            p = pl.load(pid)
                            p["settings"]["bgm"] = {"enabled": False, "path": "", "file": "", "title": "",
                                                    "volume": (p["settings"].get("bgm") or {}).get("volume", 0.15)}
                            pl.save(p)
                            for old in pl.pdir(pid).glob("bgm.*"):      # 복사해 둔 음악 파일도 같이 지운다
                                try:
                                    old.unlink()
                                except Exception:
                                    pass
                        return self._json({"ok": True, "bgm": p["settings"]["bgm"]})
                    if body.get("preset"):
                        with plock(pid):
                            p = pl.load(pid)
                            bgm = pl.set_bgm(p, preset=body["preset"])
                        return self._json({"ok": True, "bgm": bgm})
                    if not fp:
                        fp = pl.pick_file("audio")
                        if not fp:
                            return self._json({"cancelled": True})
                    with plock(pid):
                        p = pl.load(pid)
                        bgm = pl.set_bgm(p, path=fp)
                    return self._json({"ok": True, "bgm": bgm})
                if action == "sources":
                    # 삽입 영상 등록(path) 또는 제거(remove=id)
                    if body.get("remove"):
                        with plock(pid):
                            p = pl.load(pid)
                            pl.remove_source(p, body["remove"])
                        return self._json({"ok": True, "sources": p.get("extra_sources", [])})
                    if body.get("black"):
                        # 주 트랙 바탕용 검정 화면 소스(프로젝트마다 한 번)
                        with plock(pid):
                            p = pl.load(pid)
                            src = pl.black_source(p)
                        return self._json({"ok": True, "source": src, "sources": p["extra_sources"]})
                    if body.get("multi"):
                        # 트랙 「＋ 영상」: 여러 파일을 한 번에 등록한다
                        fps = body.get("paths") or pl.pick_files(body.get("kind") or "video")
                        if not fps:
                            return self._json({"cancelled": True})
                        with plock(pid):
                            p = pl.load(pid)
                        added = [pl.add_source(p, fp) for fp in fps]
                        with plock(pid):
                            cur = pl.load(pid)
                            cur["extra_sources"] = p["extra_sources"]
                            pl.save(cur)
                        return self._json({"ok": True, "added": added, "sources": p["extra_sources"]})
                    fp = (body.get("path") or "").strip().strip('"')
                    if not fp:
                        fp = pl.pick_file("video")
                        if not fp:
                            return self._json({"cancelled": True})
                    with plock(pid):
                        p = pl.load(pid)
                    src = pl.add_source(p, fp)
                    with plock(pid):
                        cur = pl.load(pid)
                        cur["extra_sources"] = p["extra_sources"]
                        pl.save(cur)
                    return self._json({"ok": True, "source": src, "sources": p["extra_sources"]})
                if action == "tts_preview":
                    import hashlib
                    text = (body.get("text") or "").strip()
                    voice = body.get("voice") or "ko-KR-InJoonNeural"
                    rate = int(body.get("rate") or 0)
                    if not text:
                        return self._err("낭독할 문구가 비어 있습니다")
                    key = hashlib.md5(("%s|%s|%d" % (text, voice, rate)).encode("utf-8")).hexdigest()[:12]
                    work = pl.pdir(pid) / "work"
                    work.mkdir(exist_ok=True)
                    existing = [x for x in work.glob("tts_%s.*" % key)]
                    if existing:
                        out, dur = existing[0], pl.audio_duration(existing[0])
                    else:
                        out, dur = pl.tts_synth(text, voice, rate, work / ("tts_%s.mp3" % key))
                    return self._json({"url": "/media/%s/work/%s" % (pid, out.name), "duration": dur})
                if action == "poster":
                    p = pl.load(pid)
                    sid = body.get("id")
                    s = next((x for x in p["shorts"] if x["id"] == sid), None)
                    if not s:
                        return self._err("no such short", 404)
                    name = pl.preview_frame(p, s, at=body.get("at"))
                    return self._json({"poster": name})
            return self._err("not found", 404)
        except Exception as e:
            traceback.print_exc()
            return self._err(str(e), 500)

    def do_PUT(self):
        u = urlparse(self.path)
        path = unquote(u.path)
        if not self._gate(path):
            return
        try:
            body = self._body()
            if path.startswith("/api/projects/"):
                pid = path.split("/")[3]
                with plock(pid):
                    p = pl.load(pid)
                    # 낙관적 잠금: 화면이 알고 있던 updated(_base)보다 서버가 새로우면(다른 창·오래된 사본) 덮어쓰지 않고 409
                    base = body.get("_base")
                    if base is not None and float(p.get("updated") or 0) > float(base) + 0.0005:
                        return self._json({"stale": True, "updated": p.get("updated")}, 409)
                    if "settings" in body:
                        keep = {k: p["settings"].get(k) for k in ("range", "count", "model", "provider", "effort")}
                        p["settings"].update(body["settings"])
                        p["settings"].update({k: v for k, v in keep.items() if v is not None})
                    if isinstance(body.get("cues"), list) and len(body["cues"]) >= 1:   # 빈 목록만 거부(옛 화면이 자막을 지우는 사고 방지)
                        p["cues"] = body["cues"]        # 편집기에서 줄을 나누거나 합친 결과
                    if "narration" in body and body["narration"] is None and p.get("narration"):
                        # 트랙에서 낭독을 뺐다: 파일과 낭독으로 만든 자막도 같이 지운다
                        for old in pl.pdir(pid).glob("narration.*"):
                            try:
                                old.unlink()
                            except OSError:
                                pass
                        p["narration"] = None
                        p["cues"], p["cues_auto"], p["cues_source"] = [], [], "none"
                        if not p["settings"].get("src_volume"):
                            p["settings"]["src_volume"] = 1.0
                    if "shorts" in body:
                        try:
                            b0 = body["shorts"][0] if body["shorts"] else {}
                            print("PUT shorts", pid, "via=%s" % body.get("_via"), "clips=%d texts=%d tr=%s" % (len(b0.get("clips") or []), len(b0.get("texts") or []), [c.get("tr_in") for c in (b0.get("clips") or [])]), flush=True)
                        except Exception:
                            pass
                        disk = {s["id"]: s for s in p.get("shorts", [])}
                        new = []
                        for s in body["shorts"]:
                            old = disk.get(s["id"], {})
                            s["output"] = old.get("output")
                            s["render"] = old.get("render")
                            s.setdefault("poster", old.get("poster"))
                            if old.get("orig_clips") and not s.get("orig_clips"):
                                s["orig_clips"] = old["orig_clips"]
                            for k in ("orig_start", "orig_end"):    # 옛 화면이 보낸 사본에 없어도 처음 값은 지킨다
                                if s.get(k) is None and old.get(k) is not None:
                                    s[k] = old[k]
                            new.append(s)
                        p["shorts"] = new
                    p["updated"] = time.time()
                    pl.save(p)
                return self._json({"ok": True, "updated": p["updated"]})
            return self._err("not found", 404)
        except Exception as e:
            traceback.print_exc()
            return self._err(str(e), 500)

    def do_DELETE(self):
        path = unquote(urlparse(self.path).path)
        if not self._gate(path):
            return
        try:
            if path.startswith("/api/projects/"):
                pid = path.split("/")[3]
                j = job_get(pid)
                if j and j.get("running"):
                    return self._err("작업 중인 프로젝트는 지울 수 없습니다", 409)
                d = pl.pdir(pid)
                if d.exists():
                    shutil.rmtree(d, ignore_errors=True)
                return self._json({"ok": True})
            return self._err("not found", 404)
        except Exception as e:
            return self._err(str(e), 500)

    # -- actions
    def list_projects(self):
        out = []
        for d in sorted(pl.PROJECTS.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            f = d / "project.json"
            if not f.exists():
                continue
            try:
                p = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            j = job_get(p["id"])
            out.append({
                "id": p["id"], "created": p.get("created"), "status": p.get("status"), "kind": p.get("kind") or "long",
                # 가로 롱폼 편집도 kind 는 "shop" 이다(같은 자유 편집 폼). 화면에서 둘을
                # 가르려면 캔버스가 필요하다 — 목록 필터가 이 값을 쓴다(2026-09-14).
                "canvas": (p.get("settings") or {}).get("canvas") or "9:16",
                "title": p["source"].get("title") or p["source"].get("url") or p["source"].get("path"),
                "channel": p["source"].get("channel"), "duration": p["source"].get("duration"),
                "thumb": p["source"].get("thumb"), "n_shorts": len(p.get("shorts") or []),
                "n_rendered": sum(1 for s in p.get("shorts") or [] if s.get("output")),
                "progress": p.get("progress"), "error": p.get("error"),
                "running": bool(j and j.get("running")),
                "job": {"kind": j.get("kind"), "pct": j.get("pct"), "current": j.get("current"),
                        "message": j.get("message")} if j and j.get("running") else None,
            })
        return out

    def create_tts_job(self, body):
        """대본 한 편 → 낭독 파일 하나. 「쇼핑 쇼츠」의 낭독 칸을 채운다.
        1만 자짜리 가로 롱폼이면 1~3분 걸리므로 작업으로 돌리고 화면이 진행률을 묻는다."""
        text = (body.get("text") or "").strip()
        if not text:
            return self._err("먼저 아래 「대본」 칸에 읽을 글을 넣어 주세요")
        voice = (body.get("voice") or "ko-KR-InJoonNeural").strip()
        rate = int(body.get("rate") or 0)
        token = uuid.uuid4().hex[:12]
        key = "tts:" + token
        job_set(key, kind="tts", running=True, pct=0, message="낭독을 만드는 중…",
                errors=[], started=time.time(), result=None)
        threading.Thread(target=run_tts_make, args=(key, text, voice, rate), daemon=True).start()
        return self._json({"token": token})

    def create_flow_job(self, body):
        """홈 「Flow로 이미지 뽑기」: 프롬프트 여러 줄(한 줄 = 한 장) + 참조 이미지(선택) → 이미지 파일들. 진행은 token 으로 묻는다."""
        items = body.get("prompts")
        if not items:
            lines = [ln.strip() for ln in (body.get("text") or "").splitlines() if ln.strip()]
            items = [{"name": "img%02d" % (i + 1), "prompt": ln} for i, ln in enumerate(lines)]
        if not items:
            return self._err("프롬프트를 한 줄 이상 넣어 주세요 (한 줄이 한 장입니다)")
        if len(items) > 20:
            return self._err("한 번에 20장까지입니다")
        refs = [r for r in (body.get("refs") or []) if r and Path(str(r)).exists()]
        ratio = body.get("ratio") if body.get("ratio") in ("9:16", "16:9", "1:1") else "9:16"
        ok, why = pl.flow_available()
        if not ok:
            return self._err("Flow " + why)
        token = uuid.uuid4().hex[:12]
        key = "flow:" + token
        job_set(key, kind="flow", running=True, pct=0, message="시작하는 중…", errors=[], started=time.time(), result=None)
        threading.Thread(target=run_flow_job, args=(key, items, refs, ratio, None), daemon=True).start()
        return self._json({"token": token, "n": len(items)})

    def create_product_voice_job(self, body):
        """대본은 그대로 두고 낭독만 다른 목소리·배속으로 다시 만든다(신 시작 시각도 다시 계산). 끝나면 「쇼핑 쇼츠 만들기」를 다시 눌러야 새 낭독이 들어간다."""
        pid = (body.get("id") or "").strip()
        d = pr.pdir(pid)
        if not (d / "script.json").exists():
            return self._err("먼저 「대본·낭독 만들기」를 끝내 주세요")
        voice = (body.get("voice") or "ko-KR-InJoonNeural").strip()
        speed = body.get("speed")
        key = prod_key(pid)
        if (job_get(key) or {}).get("running"):
            return self._err("이 상품 작업이 아직 돌고 있습니다", 409)
        job_set(key, kind="product", running=True, pct=10, message="낭독을 다시 만드는 중… (%s)" % voice, errors=[], started=time.time())

        def run():
            try:
                pr.make_voice(pid, voice, speed)
                job_set(key, pct=100, message="낭독을 다시 만들었습니다 — 「쇼핑 쇼츠 만들기」를 다시 누르면 새 낭독이 들어갑니다")
            except Exception as e:
                traceback.print_exc()
                job_set(key, errors=[str(e)], message="실패: %s" % e)
            finally:
                job_set(key, running=False, finished=time.time())
        threading.Thread(target=run, daemon=True).start()
        return self._json(product_result(pid))

    def create_product_flow_job(self, body):
        """상품 쇼츠 ①단계 자동화: 시트 프롬프트(신 per 개씩) → Flow → sheets/sheetN.png. 참조는 등록한 제품 사진."""
        pid = (body.get("id") or "").strip()
        d = pr.pdir(pid)
        if not (d / "script.json").exists():
            return self._err("먼저 「대본·낭독 만들기」를 끝내 주세요")
        try:
            meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        except Exception:
            meta = {}
        refs = [x for x in (meta.get("images") or []) if Path(x).exists()][:3]
        # 신마다 9:16 한 장(2026-09-12). 없는 신만 만들고 → AI 검수 → 불합격만 고친 프롬프트로 다시(최대 2회). check_only 면 검수부터
        ok, why = pl.flow_available()
        if not ok:
            return self._err("Flow " + why)
        if body.get("force"):
            for p_ in (d / "scenes").glob("*.png"):
                if p_.stem.isdigit():
                    p_.unlink()
        n_todo = len([it for it in pr.scene_prompts(pid, with_ref=bool(refs)) if not (d / "scenes" / ("%s.png" % it["name"])).exists()])
        token = uuid.uuid4().hex[:12]
        key = "flow:" + token
        job_set(key, kind="flow", running=True, pct=0, message="시작하는 중…", errors=[], started=time.time(), result=None)
        threading.Thread(target=run_product_flow_job, args=(key, pid, refs, not body.get("check_only"), 2), daemon=True).start()
        return self._json({"token": token, "n": n_todo, "refs": len(refs)})

    def create_grok_job(self, body):
        """홈 「그록으로 영상 만들기」: 업로드 목록의 이미지들 + 프롬프트(전체 하나 또는 줄마다) → mp4 들."""
        images = [str(x) for x in (body.get("images") or []) if x and Path(str(x)).exists() and Path(str(x)).suffix.lower() in pl.IMAGE_EXT]
        if not images:
            return self._err("목록에 이미지 파일이 없습니다. 먼저 이미지를 올리거나 Flow 로 뽑아 주세요")
        if len(images) > 12:
            return self._err("한 번에 12장까지입니다(클립당 1~3분)")
        lines = [ln.strip() for ln in (body.get("text") or "").splitlines() if ln.strip()]
        default = "slow cinematic camera move, subtle natural motion, keep the product exactly as in the image"
        items = []
        for i, im in enumerate(images):
            pr_ = lines[i] if len(lines) == len(images) else (lines[0] if lines else default)
            items.append({"name": "clip%02d" % (i + 1), "image": im, "prompt": pr_})
        res = body.get("res") if body.get("res") in ("480p", "720p", "1080p") else "480p"
        length = int(body.get("len") or 6)
        length = length if length in (6, 10, 15) else 6
        ratio = body.get("ratio") if body.get("ratio") in ("9:16", "16:9", "1:1", "2:3", "3:2") else "9:16"
        ok, why = pl.grok_available()
        if not ok:
            return self._err("그록 " + why)
        token = uuid.uuid4().hex[:12]
        key = "grok:" + token
        job_set(key, kind="grok", running=True, pct=0, message="시작하는 중…", errors=[], started=time.time(), result=None)
        threading.Thread(target=run_grok_job, args=(key, items, res, length, ratio, None), daemon=True).start()
        return self._json({"token": token, "n": len(items)})

    def create_product_grok_job(self, body):
        """상품 쇼츠 ②단계 자동화: scenes/N.png + 신별 영상 프롬프트 → 그록 → clips/N.mp4."""
        pid = (body.get("id") or "").strip()
        d = pr.pdir(pid)
        if not (d / "script.json").exists():
            return self._err("먼저 「대본·낭독 만들기」를 끝내 주세요")
        data = json.loads((d / "script.json").read_text(encoding="utf-8"))
        style = (data.get("style") or "cinematic product photography, soft studio light").strip()
        items, missing = [], []
        for s in data.get("scenes") or []:
            n = s["n"]
            img = next((d / "scenes" / ("%d%s" % (n, ext)) for ext in (".png", ".jpg", ".jpeg", ".webp") if (d / "scenes" / ("%d%s" % (n, ext))).exists()), None)
            if not img:
                missing.append(n)
                continue
            if (d / "clips" / ("%d.mp4" % n)).exists() and not body.get("force"):
                continue                                   # 이미 있는 클립은 건너뛴다 — 실패한 신만 다시 만들 수 있게
            dur = float(s.get("dur") or 4)
            items.append({"name": str(n), "image": str(img), "prompt": "%s. %s. Keep the product exactly as in the image, no text." % ((s.get("video") or "slow cinematic camera move").rstrip("."), style), "dur": dur})
        if not items:
            if missing:
                return self._err("신 이미지가 없습니다. 먼저 「Flow로 시트 만들기」나 「시트 나누기」로 scenes 폴더를 채워 주세요")
            return self._err("모든 신의 클립이 이미 clips 폴더에 있습니다. 다시 만들려면 clips 폴더에서 지우고 누르세요")
        res = body.get("res") if body.get("res") in ("480p", "720p", "1080p") else "720p"    # 480p 는 400x736 이라 1080x1920 캔버스에서 무르다(2026-09-12 실측)
        maxdur = max(it["dur"] for it in items)
        length = 6 if maxdur <= 6 else (10 if maxdur <= 10 else 15)
        engine = body.get("engine") if body.get("engine") in ("grok", "flow", "auto") else "auto"
        if engine == "grok":
            ok, why = pl.grok_available()
            if not ok:
                return self._err("그록 " + why)
        token = uuid.uuid4().hex[:12]
        key = "grok:" + token
        job_set(key, kind="grok", running=True, pct=0, message="시작하는 중…", errors=[], started=time.time(), result=None)
        threading.Thread(target=run_grok_job, args=(key, items, res, length, "9:16", d / "clips", engine), daemon=True).start()
        return self._json({"token": token, "n": len(items), "missing": missing, "len": length})

    def create_product_job(self, body):
        """상품 정보 → 대본·낭독·프롬프트. 결과는 이 화면의 「쇼핑 쇼츠」 칸을 채운다."""
        deny = lic.require(pl.load_config(), "shop")
        if deny:
            return self._err(deny, 402)
        text = (body.get("text") or "").strip()
        url = (body.get("url") or "").strip()
        if not text and not url:
            return self._err("상품 정보를 붙여 넣거나 상품 URL 을 넣어 주세요")
        lane = body.get("lane") if body.get("lane") in pr.LANES else "product"
        cfg = pl.load_config()
        m = pr.new_project(lane, url, "")
        pid = m["id"]
        opts = {"text": text, "images": body.get("images") or [],
                "provider": body.get("provider") or cfg.get("default_provider") or "claude",
                "model": body.get("model") or None,
                "voice": body.get("voice") or "ko-KR-InJoonNeural",
                "speed": body.get("speed"), "per": body.get("per") or 3}
        job_set(prod_key(pid), kind="product", running=True, pct=0, message="시작하는 중…",
                errors=[], started=time.time())
        threading.Thread(target=run_product, args=(pid, opts), daemon=True).start()
        return self._json(product_result(pid))

    def create_shop(self, body):
        canvas = ((body.get("settings") or {}).get("canvas") or body.get("canvas") or "9:16")
        deny = lic.require(pl.load_config(), "wide" if canvas == "16:9" else "shop")
        if deny:
            return self._err(deny, 402)
        videos = [str(v).strip().strip('"') for v in (body.get("videos") or []) if str(v).strip()]
        tts = (body.get("tts") or "").strip().strip('"')
        empty = bool(body.get("empty")) and not videos
        if not videos and not empty:
            return self._err("영상 파일을 하나 이상 넣어 주세요")
        missing = [v for v in videos if not Path(v).exists()]
        if missing:
            return self._err("파일이 없습니다: %s" % missing[0])
        if tts and not Path(tts).exists():
            return self._err("낭독 파일이 없습니다: %s" % tts)
        st = _default_settings(body.get("settings") or {})
        _sv = (body.get("settings") or {}).get("src_volume")
        st.update(ratio=(body.get("settings") or {}).get("ratio") or "9:16", show_subs=True, src_volume=float(_sv) if _sv not in (None, "") else 1.0,
                  canvas=pl.canvas_of(body.get("settings") or {}))
        if st["canvas"] == "16:9":
            st.update(show_title=False, show_chan=False, show_logo=False)      # 가로 롱폼: 훅 제목·채널명·로고 없이 시작(2026-09-12). 편집기도 그 절을 감춘다
        else:
            st.setdefault("title_secs", 5)                                     # 세로 쇼핑: 훅 제목은 앞 5초만(2026-09-12 사용자). 0 이면 끝까지
            st.setdefault("aff_secs", 5)                                       # 광고 안내 문구도 앞 5초만(2026-09-12 사용자). 0 이면 끝까지
            st.setdefault("auto_sfx", True)                                    # 효과음 자동 배치(2026-09-12 사용자). 편집기에서 지울 수 있다
            if (body.get("settings") or {}).get("sfx_reveal"):
                st["sfx_reveal"] = (body.get("settings") or {}).get("sfx_reveal")
            st.update(sub_scale=1.5, sub_one_line=True, sub_max_chars=14)      # 세로 쇼핑 자막: 1.5배 · 한 줄 · 12자(2026-09-12 사용자: 작고 두 줄로 갈린다)
        pid = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
        title = (body.get("title") or "").strip() or ("새 프로젝트 " + time.strftime("%m/%d %H:%M") if empty else Path(videos[0]).stem)
        p = {"id": pid, "kind": "shop", "created": time.time(), "status": "created", "error": None,
             "source": {"type": "file", "url": None, "path": videos[0] if videos else "", "title": title, "channel": st["channel_name"], "video_id": None},
             "affiliate": body.get("affiliate") or None,
             "shop": {"videos": videos, "tts": tts, "script": body.get("script") or "", "empty": empty, "popup_text": (body.get("popup_text") or "").strip(),
                      "line1": (body.get("line1") or "").strip(), "line2": (body.get("line2") or "").strip(), "title": (body.get("yt_title") or "").strip()},
             "settings": st, "cues": [], "shorts": [], "progress": None}
        if body.get("bgm_preset"):
            try:
                pl.set_bgm(p, preset=body["bgm_preset"])
            except Exception as e:
                print("bgm preset 실패:", e)
        pl.save(p)
        start_job(pid, "create", lambda: run_create_shop(pid))
        return self._json(self._project_view(pid))

    def create_project(self, body):
        deny = lic.require(pl.load_config(), "long")
        if deny:
            return self._err(deny, 402)
        src = body.get("source") or {}
        st = body.get("settings") or {}
        if src.get("type") == "youtube":
            if not src.get("url"):
                return self._err("유튜브 링크가 비었습니다")
        elif src.get("type") == "file":
            if not src.get("path") or not Path(src["path"]).exists():
                return self._err("파일 경로가 없거나 파일이 없습니다")
        else:
            return self._err("source.type 은 youtube 또는 file")
        pid = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
        settings = {
            "range": [float(st.get("range", [0, 0])[0] or 0), float(st.get("range", [0, 0])[1] or 0)],
            "template": st.get("template") if st.get("template") in ("dark", "pop") else "dark",
            "ratio": st.get("ratio") if st.get("ratio") in pl.RATIOS else "16:9",
            "accent": st.get("accent") or "#FF3B3B",
            "channel_name": st.get("channel_name") or "",
            "channel_logo": st.get("channel_logo") or "",
            "count": max(1, min(10, int(st.get("count") or 4))),
            "min_len": 30, "max_len": 58,
            "provider": st.get("provider") if st.get("provider") in pl.PROVIDERS else "claude",
            "model": st.get("model") or "",
            "effort": st.get("effort") if st.get("effort") in ("low", "medium", "high") else "medium",
            "show_subs": bool(st.get("show_subs", True)),
            "show_logo": bool(st.get("show_logo", True)),
            "zoom": 1.0, "pan_x": 0, "pan_y": 0, "sub_dx": 0, "sub_dy": 0, "sub_scale": 1.0,
            "sub_fill": "#FFFFFF", "sub_stroke": "", "title_font": "noto", "sub_font": "noto",
            "bg_color": "#000000", "title_color": "#FFFFFF",
            "hook_tts": {"enabled": False, "voice": "ko-KR-InJoonNeural", "rate": 0, "duck": 0.25},
            "bgm": {"enabled": False, "path": "", "file": "", "title": "", "volume": 0.15},
            "transition": {"type": "none", "dur": 0.5, "edges": False},
            "mask": {"enabled": False, "type": "mosaic", "block": 16, "x": 0.0, "y": 0.8, "w": 1.0, "h": 0.17},
        }
        p = {"id": pid, "created": time.time(), "status": "created", "error": None,
             "source": {"type": src["type"], "url": src.get("url"), "path": src.get("path"),
                        "title": src.get("title"), "channel": src.get("channel"),
                        "video_id": src.get("video_id"), "subs": src.get("subs")},
             "settings": settings, "cues": [], "shorts": [], "progress": None}
        pl.save(p)
        start_job(pid, "create", lambda: run_create(pid))
        return self._json(self._project_view(pid))


def _default_settings(st):
    return {
        "range": [float(st.get("range", [0, 0])[0] or 0), float(st.get("range", [0, 0])[1] or 0)],
        "template": st.get("template") if st.get("template") in ("dark", "pop") else "dark",
        "ratio": st.get("ratio") if st.get("ratio") in pl.RATIOS else "16:9",
        "accent": st.get("accent") or "#FF3B3B",
        "channel_name": st.get("channel_name") or "",
        "channel_logo": st.get("channel_logo") or "",
        "count": max(1, min(10, int(st.get("count") or 4))),
        "min_len": 30, "max_len": 58,
        "provider": st.get("provider") if st.get("provider") in pl.PROVIDERS else "claude",
        "model": st.get("model") or "",
        "effort": st.get("effort") if st.get("effort") in ("low", "medium", "high") else "medium",
        "show_subs": bool(st.get("show_subs", True)),
        "show_logo": bool(st.get("show_logo", True)),
        "zoom": 1.0, "pan_x": 0, "pan_y": 0, "sub_dx": 0, "sub_dy": 0, "sub_scale": 1.0,
        "sub_fill": "#FFFFFF", "sub_stroke": "", "title_font": "noto", "sub_font": "noto",
        "bg_color": "#000000", "title_color": "#FFFFFF",
        "hook_tts": {"enabled": False, "voice": "ko-KR-InJoonNeural", "rate": 0, "duck": 0.25},
        "bgm": {"enabled": False, "path": "", "file": "", "title": "", "volume": 0.15},
        "transition": {"type": "none", "dur": 0.5, "edges": False},
        "mask": {"enabled": False, "type": "mosaic", "block": 16, "x": 0.0, "y": 0.8, "w": 1.0, "h": 0.17},
        "src_volume": 1.0,
    }


def _reexec_into_venv():
    """개발 폴더에서 시스템 파이썬으로 잘못 뜨면(.venv 밖) winsdk·edge-tts 가 없어 OCR·무료 낭독이 조용히 꺼진다
    (2026-09-12 서버 로그 35회 기동 중 4회가 그랬다). 배포판(python\\)이 아니고 .venv 가 있는데 그 안의 파이썬이 아니면
    같은 인자로 .venv 파이썬을 다시 띄우고 이 프로세스는 끝낸다. 포트를 잡기 전에 하므로 안전하다."""
    base = pl.BASE
    if (base / "python" / "python.exe").exists():
        return
    venv = base / ".venv" / "Scripts"
    if not venv.exists():
        return
    try:
        cur = Path(sys.executable).resolve()
        if venv.resolve() in cur.parents:
            return
    except Exception:
        return
    windowed = cur.name.lower().startswith("pythonw")
    exe = venv / ("pythonw.exe" if windowed else "python.exe")
    if not exe.exists():
        exe = venv / "python.exe"
    if not exe.exists():
        return
    print("%s 시스템 파이썬으로 떴습니다(%s) → .venv 파이썬으로 다시 띄웁니다: %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), cur, exe), flush=True)
    subprocess.Popen([str(exe), str(Path(__file__).resolve())] + sys.argv[1:], cwd=str(base),
                     creationflags=(0x08000000 if windowed else 0), close_fds=True)
    try:
        sys.stdout.flush()
    except Exception:
        pass
    os._exit(0)          # sys.exit 는 pythonw 에서 프로세스가 남는 일이 있었다(2026-09-12 실측). /api/quit 와 같은 방식으로 즉시 끝낸다.


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8796)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    _reexec_into_venv()
    pl.ensure_fonts()

    class Server(ThreadingHTTPServer):
        # 윈도는 SO_REUSEADDR 이 켜져 있으면 이미 쓰는 포트에도 조용히 두 번 바인드된다.
        # 그러면 요청은 먼저 뜬(옛 코드) 서버로 가고 새 서버는 아무것도 못 받는다. 끈다.
        allow_reuse_address = False

        def server_bind(self):
            # HTTPServer.server_bind 는 socket.getfqdn(host) 로 역방향 DNS 를 묻는다. 0.0.0.0 이면 이게 수십 초 멈춰
            # 서버가 '바인드만 된 채' 뜨지 않는 것처럼 보인다(2026-09-06 실측). 이름은 필요 없으니 건너뛴다.
            import socketserver
            socketserver.TCPServer.server_bind(self)
            host, port = self.server_address[:2]
            self.server_name, self.server_port = host, port

        def handle_error(self, request, client_address):
            # 브라우저가 미디어 스트림을 중간에 끊으면(탭 이동·시킹·창 닫기) 윈도는 10053/10054 를 던진다.
            # 고장이 아니므로 스택을 로그에 남기지 않는다(2026-09-12: server.log 의 Traceback 이 전부 이것이었다).
            ev = sys.exc_info()[1]
            if isinstance(ev, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
                return
            super().handle_error(request, client_address)

    url = "http://127.0.0.1:%d" % a.port
    lan = bool(pl.load_config().get("lan_enabled"))
    def another_alive():
        try:
            import urllib.request
            with urllib.request.urlopen(url + "/api/version", timeout=1.5) as r:
                return r.status == 200
        except Exception:
            return False

    # 0.0.0.0 하나로 열지 않고 주소마다 따로 연다(127.0.0.1 + 폰에서 쓰기를 켰을 때 각 LAN IP).
    # 이유: 윈도에서 0.0.0.0 바인드가 유령 소켓·예약 포트 범위에 막히는 일이 있었고(2026-09-06), 주소별 바인드는 그 영향을 받지 않는다.
    hosts = ["127.0.0.1"] + ([ip for ip in pl.lan_ips() if ip != "127.0.0.1"] if lan else [])
    servers = []
    for host in hosts:
        got = None
        for i in range(40):                               # 재시작 직후엔 옛 연결(TIME_WAIT)이 포트를 잠깐 잡고 있을 수 있다 → 최대 20초 재시도
            try:
                got = Server((host, a.port), Handler)
                break
            except OSError as e:
                if host == "127.0.0.1" and another_alive():
                    # 진짜로 이미 떠 있으면 새로 띄우지 않고 그 화면만 연다(바로가기를 두 번 눌러도 안전).
                    print("포트 %d 를 이미 쓰고 있습니다. 떠 있는 쇼츠컷을 브라우저로 엽니다." % a.port)
                    if not a.no_browser:
                        webbrowser.open(url)
                    sys.exit(0)
                if host != "127.0.0.1" and i >= 3:
                    print("LAN 주소 %s:%d 를 열지 못했습니다: %s" % (host, a.port, e))
                    break
                time.sleep(0.5)
        if got is None and host == "127.0.0.1":
            print("포트 %d 를 열지 못했습니다(20초 재시도). 다른 프로그램이 쓰고 있는지 확인하세요." % a.port)
            sys.exit(1)
        if got is not None:
            servers.append(got)
    srv = servers[0]
    for extra in servers[1:]:
        extra.daemon_threads = True
        threading.Thread(target=extra.serve_forever, daemon=True).start()
    srv.daemon_threads = True
    print("%s 쇼츠컷 v%s 시작  %s   (화면 왼쪽 아래 '서버 종료' 또는 Ctrl+C)  python=%s  LAN=%s" % (time.strftime("%Y-%m-%d %H:%M:%S"), pl.VERSION, url, sys.executable, ("on " + ",".join(sv.server_address[0] for sv in servers[1:])) if lan else "off"))
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
