' ShortsCut launcher without a console window.
' Prefers the bundled python\pythonw.exe (release build), then .venv\Scripts\pythonw.exe (dev), then pythonw on PATH.
' Log: logs\server.log. If the server is already running, it just opens the browser.
Dim fso, sh, here, py
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
py = here & "\python\pythonw.exe"
If Not fso.FileExists(py) Then py = here & "\.venv\Scripts\pythonw.exe"
If Not fso.FileExists(py) Then py = "pythonw.exe"
sh.CurrentDirectory = here
sh.Run """" & py & """ """ & here & "\server.py""", 0, False
