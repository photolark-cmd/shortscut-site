/* 쇼츠컷 프런트 — 서버 API 만 쓰고 레이아웃 좌표는 /api/layouts 에서 받는다. */
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const S = {
  layouts: {}, projects: [], probe: null, srcType: "yt",
  setup: { template: "dark", ratio: "16:9", accent: "#FF3B3B" },
  p: null, sid: null, poll: null, saveTimer: null, dirty: false,
  tlWin: [0, 60], drag: null,
};

async function api(path, opts = {}) {
  const r = await fetch(path, {
    method: opts.method || "GET",
    headers: opts.body ? { "Content-Type": "application/json" } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const err = new Error(j.error || r.statusText); if (r.status === 409 && j.stale) err.stale = true; throw err; }
  return j;
}
function toast(msg, err = false) {
  const t = $("#toast"); t.textContent = msg; t.classList.toggle("err", err); t.classList.remove("hidden");
  clearTimeout(t._t); t._t = setTimeout(() => t.classList.add("hidden"), err ? 6000 : 2600);
}
const fmt = (s, d = 0) => { s = Math.max(0, s || 0); const m = Math.floor(s / 60), r = s - m * 60; return m + ":" + (d ? r.toFixed(d).padStart(3 + d, "0") : String(Math.floor(r)).padStart(2, "0")); };
const parseTc = v => { v = String(v).trim(); if (!v.includes(":")) return parseFloat(v); return v.split(":").reduce((a, b) => a * 60 + parseFloat(b), 0); };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ───────── ? 도움말: .q[data-tip] 에 마우스를 대면 #tip 을 옆에 띄운다. 클릭은 절 접기로 번지지 않게 막는다 ───────── */
(() => {
  const tip = document.getElementById("tip"); if (!tip) return;
  const show = (el) => { tip.textContent = el.dataset.tip || ""; tip.classList.remove("hidden");
    const r = el.getBoundingClientRect(); const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = r.right + 8, y = r.top - 6; if (x + w > innerWidth - 8) x = Math.max(8, r.left - w - 8); if (y + h > innerHeight - 8) y = Math.max(8, innerHeight - h - 8);
    tip.style.left = x + "px"; tip.style.top = y + "px"; };
  document.addEventListener("mouseover", e => { const q = e.target.closest(".q[data-tip]"); if (q) show(q); });
  document.addEventListener("mouseout", e => { if (e.target.closest(".q[data-tip]")) tip.classList.add("hidden"); });
  document.addEventListener("click", e => { const q = e.target.closest(".q[data-tip]"); if (q) { e.preventDefault(); e.stopPropagation(); show(q); setTimeout(() => tip.classList.add("hidden"), 2500); } }, true);
})();
/* ───────── 화면 전환 ───────── */
function show(v) {
  $$(".view").forEach(x => x.classList.add("hidden"));
  $("#view-" + v).classList.remove("hidden");
  if (v !== "editor") stopAllMedia();                   // 편집기를 떠나면 영상뿐 아니라 음악·낭독·훅·효과음·오디오 트랙도 같이 멈춘다(2026-09-08: 홈으로 나가도 음악이 계속 나던 문제)
  if (v !== "results") $$("#rsList video").forEach(x => { x.pause(); });
  if (v === "home") { stopPoll(); loadProjects(); loadLicense(); }
}
function stopAllMedia() {
  ["#vid", "#ovVid", "#bgmAudio", "#narAudio", "#hookAudio"].forEach(id => { const el = $(id); if (el && !el.paused) el.pause(); });
  if (S.sfxAudio) { try { S.sfxAudio.pause(); } catch (_) {} }
  Object.values(S.audEls || {}).forEach(el => { try { el.pause(); } catch (_) {} });
  if (typeof stopTailTimer === "function") stopTailTimer();
  const bp = $("#btnBgmPlay"); if (bp) bp.textContent = "▶";
}
document.addEventListener("click", e => {
  const go = e.target.closest("[data-go]"); if (go) { e.preventDefault(); if (go.dataset.go === "home") { try { localStorage.removeItem("lastProject"); } catch (_) {} } show(go.dataset.go); }   // 홈으로 나가면 다음 실행은 홈에서 시작
});

/* ───────── 홈: 입력 ───────── */
$$(".tab").forEach(t => t.onclick = () => {
  $$(".tab").forEach(x => x.classList.toggle("on", x === t));
  S.srcType = t.dataset.tab;
  $("#in-yt").classList.toggle("hidden", S.srcType !== "yt");
  $("#in-file").classList.toggle("hidden", S.srcType !== "file");
});
$("#btnProbe").onclick = async () => {
  const url = $("#url").value.trim(); if (!url) return;
  $("#btnProbe").disabled = true; $("#probeHint").textContent = "영상 정보를 읽는 중…";
  try {
    const info = await api("/api/probe?url=" + encodeURIComponent(url));
    info.type = "youtube"; setProbe(info);
  } catch (e) { toast("불러오기 실패: " + e.message, true); $("#probeHint").textContent = "링크를 확인하세요."; }
  $("#btnProbe").disabled = false;
};
$("#url").addEventListener("keydown", e => { if (e.key === "Enter") $("#btnProbe").click(); });
$("#btnProbeFile").onclick = async () => {
  const path = $("#filepath").value.trim().replace(/^"|"$/g, ""); if (!path) return toast("영상 파일 경로를 넣거나 「찾아보기…」로 고르세요", true);
  $("#btnProbeFile").disabled = true; $("#probeHint").textContent = "영상 정보를 읽는 중…";
  try {
    const info = await api("/api/probe_file?path=" + encodeURIComponent(path));
    info.type = "file"; info.channel = ""; setProbe(info);
  } catch (e) { toast("불러오기 실패: " + e.message, true); $("#probeHint").textContent = "경로를 확인하세요. 파일이 있는 폴더에서 Shift+우클릭 → 「경로로 복사」가 편합니다."; }
  $("#btnProbeFile").disabled = false;
};
$("#filepath").addEventListener("keydown", e => { if (e.key === "Enter") $("#btnProbeFile").click(); });
$("#btnPickVideo").onclick = async () => {           // 파일 선택 창(여러 개 가능) → 하나면 바로 읽고, 여러 개면 자유 편집(쇼핑 쇼츠) 모드로
  toast("파일 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  let paths = [];
  try { const r = await api("/api/pick_files", { method: "POST", body: { kind: "video" } }); paths = r.paths || []; }
  catch (e) { return toast("파일 선택 실패: " + e.message, true); }
  if (!paths.length) return toast("선택된 파일이 없습니다. 창이 다른 창 뒤에 있었다면 작업 표시줄에서 찾아보세요.", true);
  if (paths.length === 1) { $("#filepath").value = paths[0]; $("#btnProbeFile").click(); return; }
  const modeBtn = $('.mode[data-mode="shop"]'); if (modeBtn) modeBtn.click();
  paths.forEach(p => { if (!S.shop.videos.includes(p)) S.shop.videos.push(p); }); renderShopVideos(); checkShopCreate();
  toast(`영상 ${paths.length}개는 쇼핑 쇼츠(자유 편집) 모드로 엽니다. 낭독·대본은 선택입니다.`);
  const ms = $("#mode-shop"); if (ms) ms.scrollIntoView({ behavior: "smooth", block: "start" });
};
function setProbe(info) {
  S.probe = info;
  $("#setup").classList.remove("hidden");
  $("#probeHint").textContent = "";
  $("#vThumb").src = info.thumbnail || "";
  $("#vTitle").textContent = info.title || "";
  $("#vChannel").textContent = info.channel || "로컬 파일";
  const av = $("#vAvatar"); av.classList.toggle("hidden", !info.channel_logo); if (info.channel_logo) av.src = logoUrl(info.channel_logo);
  if (info.type === "youtube") {
    $("#chanName").value = info.channel || "";          // 채널명·로고를 영상에서 그대로 가져온다
    setSetupLogo(info.channel_logo || "");
    $("#rights").checked = true;                        // 링크로 불러온 영상은 권리 확인을 켜 둔다(풀 수 있음)
  }
  $("#vDur").textContent = fmt(info.duration);
  $("#vSubs").textContent = info.type === "youtube"
    ? (info.has_ko_subs ? "한국어 자막 있음" : info.has_ko_auto ? "자동 자막 사용" : "⚠ 한국어 자막 없음")
    : "옆에 있는 자막 파일 사용";
  const d = Math.floor(info.duration || 0);
  $("#rangeA").max = d; $("#rangeB").max = d; $("#rangeA").value = 0; $("#rangeB").value = d;
  $("#rangeMax").textContent = fmt(d);
  updateDual();
  $("#setup").scrollIntoView({ behavior: "smooth", block: "start" });
  checkCreate();
  renderTplPreviews();
}
function updateDual() {
  const a = $("#rangeA"), b = $("#rangeB"); const max = +a.max || 1;
  let av = +a.value, bv = +b.value;
  if (bv - av < 240) { if (document.activeElement === a) av = Math.max(0, bv - 240); else bv = Math.min(max, av + 240); a.value = av; b.value = bv; }
  $("#dualFill").style.left = (av / max * 100) + "%"; $("#dualFill").style.width = ((bv - av) / max * 100) + "%";
  $("#rangeLabel").textContent = "(" + Math.round((bv - av) / 60) + "분)";
  const ta = $("#rangeAT"), tb = $("#rangeBT");                                   // 시각 칸은 타자 중이 아닐 때만 덮어쓴다
  if (document.activeElement !== ta) ta.value = fmt(av); if (document.activeElement !== tb) tb.value = fmt(bv);
}
$("#rangeA").oninput = updateDual; $("#rangeB").oninput = updateDual;
function rangeFromText(which) {                          // "12:34" / "754" 를 초로 → 슬라이더에 반영(4분 최소 간격은 updateDual 이 지킨다)
  const a = $("#rangeA"), b = $("#rangeB"); const max = +a.max || 0; const inp = $(which === "a" ? "#rangeAT" : "#rangeBT");
  let v = parseTc(inp.value); if (!isFinite(v)) { inp.value = fmt(+(which === "a" ? a : b).value); return; }
  v = Math.max(0, Math.min(max, Math.round(v)));
  if (which === "a") { a.value = Math.min(v, Math.max(0, +b.value - 240)); } else { b.value = Math.max(v, Math.min(max, +a.value + 240)); }
  inp.blur(); updateDual();
}
["#rangeAT", "#rangeBT"].forEach((id, i) => { const el = $(id); el.onchange = () => rangeFromText(i ? "b" : "a"); el.onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); rangeFromText(i ? "b" : "a"); } }; });
/* 템플릿 카드 = 라이브 미리보기. 편집기 스테이지와 같은 1080×1920 좌표(/api/layouts)를 축소해 그리므로 비율·강조색·채널명·로고·자막 설정이 그대로 보인다 */
function renderTplPreviews() {
  const ratio = S.setup.ratio || "16:9", acc = S.setup.accent || "#FF3B3B";
  const name = ($("#chanName").value || "").trim() || "채널명";
  const showSubs = $("#showSubs").checked; const logo = S.setup.logo || ""; const thumb = (S.probe && S.probe.thumbnail) || "";
  $$(".tpl").forEach(card => {
    const tpl = card.dataset.tpl; const l = S.layouts[ratio + "|" + tpl + "|9:16"] || S.layouts[ratio + "|" + tpl]; if (!l) return;
    const prev = $(".tpl-prev", card); let v = $(".tpv", prev); if (!v) { v = document.createElement("div"); v.className = "tpv"; prev.appendChild(v); }
    const full = l.mode === "full"; const subW = Math.min(l.sub_maxw || 960, 1040);
    const t1 = tpl === "pop" ? "AI 가 고른" : "놓치기 쉬운", t2 = tpl === "pop" ? "핵심 장면" : "결정적 순간";
    v.innerHTML = `<div class="band" style="left:${l.band_left || 0}px;top:${l.band_top}px;width:${l.band_w}px;height:${l.band_h}px">${thumb ? `<img src="${esc(thumb)}" alt="">` : `<span class="ph">영상 ${esc(ratio)}</span>`}</div>` +
      (full ? `<div class="g top"></div><div class="g bot"></div>` : "") +
      `<div class="t${full ? " stroke" : ""}" style="top:${l.title1_y}px;font-size:${l.title_size}px">${t1}</div>` +
      `<div class="t${full ? " stroke" : ""}" style="top:${l.title2_y}px;font-size:${l.title_size}px;color:${esc(acc)}">${t2}</div>` +
      (showSubs ? `<div class="sub" style="top:${l.sub_y}px;left:${(1080 - subW) / 2}px;width:${subW}px;font-size:${l.sub_size}px;-webkit-text-stroke:${tpl === "pop" ? 10 : 8}px #000">자막이 여기에 나옵니다</div>` : "") +
      `<div class="ch" style="top:${l.chan_y}px"><span class="av" style="background:${logo ? `url(${esc(logoUrl(logo))}) center/cover` : esc(acc)}">${logo ? "" : esc(name.slice(0, 1))}</span><span>${esc(name)}</span></div>`;
    v.style.transform = `scale(${(prev.clientHeight || 230) / 1920})`;
  });
}
$$(".tpl").forEach(t => t.onclick = () => { $$(".tpl").forEach(x => x.classList.toggle("on", x === t)); S.setup.template = t.dataset.tpl; renderTplPreviews(); });
$("#ratioSeg").onclick = e => { const b = e.target.closest("button"); if (!b) return; $$("button", $("#ratioSeg")).forEach(x => x.classList.toggle("on", x === b)); S.setup.ratio = b.dataset.r; renderTplPreviews(); };
$("#swatches").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; $$(".sw", $("#swatches")).forEach(x => x.classList.toggle("on", x === b)); S.setup.accent = b.dataset.c; $("#accentPick").value = b.dataset.c; renderTplPreviews(); };
$("#accentPick").oninput = e => { $$(".sw", $("#swatches")).forEach(x => x.classList.remove("on")); S.setup.accent = e.target.value; renderTplPreviews(); };
$("#chanName").addEventListener("input", renderTplPreviews);
$("#showSubs").addEventListener("change", renderTplPreviews);
window.addEventListener("resize", () => { clearTimeout(S.tplT); S.tplT = setTimeout(renderTplPreviews, 120); });
$("#rights").onchange = checkCreate;
/* AI 설정 카드(홈): 공급자 타일 + 그 공급자의 키·모델. 저장하면 config.json 에 남고 새 프로젝트의 기본이 된다 */
const PROVIDER_DEFAULT_MODEL = { anthropic: "claude-sonnet-5", openai: "gpt-4.1-mini", gemini: "gemini-2.5-flash", ollama: "qwen2.5:14b" };
const PROVIDER_LABEL = { anthropic: "Claude API", claude: "Claude Code", openai: "OpenAI", gemini: "Gemini", xai: "xAI Grok", ollama: "Ollama" };
S.ai = { provider: "claude" };
function aiModelFor(pv) {
  if (pv === "claude") return $("#model").value;
  return ($("#model_" + pv).value.trim()) || PROVIDER_DEFAULT_MODEL[pv] || "";
}
function applyProviderUI() {
  const pv = S.ai.provider;
  $$(".ai-tile").forEach(t => t.classList.toggle("on", t.dataset.p === pv));
  ["anthropic", "claude", "openai", "gemini", "xai", "ollama"].forEach(k => $$(".ai-" + k).forEach(el => el.classList.toggle("hidden", k !== pv)));
  const c = S.cfg?.config || {};
  const st = { claude: S.cfg?.claude_cli ? ["ok", "준비됨"] : ["no", "CLI 없음"],
    anthropic: c.anthropic_key ? ["ok", "키 " + c.anthropic_key] : ["no", "키 없음"], openai: c.openai_key ? ["ok", "키 " + c.openai_key] : ["no", "키 없음"],
    gemini: c.gemini_key ? ["ok", "키 " + c.gemini_key] : ["no", "키 없음"],
    xai: c.xai_key ? ["ok", "키 " + c.xai_key] : ["no", "키 없음"], ollama: ["", c.ollama_url || "127.0.0.1:11434"] };
  for (const k in st) { const el = $("#st-" + k); el.textContent = st[k][1]; el.className = st[k][0]; }
  const hints = { anthropic: "console.anthropic.com 에서 발급한 API 키. 사용한 만큼 내 계정에 과금되고, 키는 이 PC 의 config.json 에만 저장됩니다.",
    claude: S.cfg?.claude_cli ? "키 없이 Claude Code 구독으로 돕니다. 40KB 자막 기준 1~3분." : "이 PC 에 Claude Code CLI 가 없습니다. 「Claude API」 키를 넣으면 그쪽으로 자동 전환됩니다.",
    openai: "platform.openai.com 에서 발급한 키. 키는 이 PC 의 config.json 에만 저장됩니다.",
    gemini: "aistudio.google.com 에서 발급한 키. 무료 한도 안에서는 비용이 없습니다.",
    xai: "console.x.ai 에서 발급한 키. SuperGrok·X Premium+ 구독으로는 쓸 수 없고 API 는 따로 과금됩니다(데이터 공유 프로그램에 동의하면 월 무료 크레딧이 있습니다).",
    ollama: "Ollama 를 설치하고 `ollama pull 모델명` 을 먼저 하세요. 자막 40KB 를 넣으므로 32k 문맥 모델이 필요합니다." };
  $("#aiHint").textContent = hints[pv] || "";
  const m = aiModelFor(pv);
  $("#aiSummary").textContent = PROVIDER_LABEL[pv] + (m ? " · " + m : "") + (pv === "claude" ? " · 생각 깊이 " + $("#effort").value : "");
  const sum = $("#aiBoxSum"); if (sum) sum.textContent = "지금: " + PROVIDER_LABEL[pv] + (m ? " · " + m : "") + " — 제목·문안을 쓰는 AI 와 API 키";
}
$("#aiTiles").onclick = e => { const t = e.target.closest(".ai-tile"); if (!t) return; S.ai.provider = t.dataset.p; applyProviderUI(); };
["#model", "#effort", "#model_anthropic", "#model_openai", "#model_gemini", "#model_xai", "#model_ollama"].forEach(sel => $(sel).addEventListener("input", applyProviderUI));
async function loadAiConfig() {
  try {
    const r = await api("/api/config"); S.cfg = r; const c = r.config || {};
    S.ai.provider = r.default_provider || "claude";
    $("#cfgOpenai").value = c.openai_key || ""; $("#cfgGemini").value = c.gemini_key || ""; $("#cfgOllama").value = c.ollama_url || "";
    $("#cfgAnthropic").value = c.anthropic_key || ""; $("#cfgScriptRoot").value = c.script_root || "";
    $("#cfgXai").value = c.xai_key || "";
    ["anthropic", "openai", "gemini", "xai", "ollama"].forEach(k => { $("#model_" + k).value = c["model_" + k] || ""; });
    ffmpegBanner(r.ffmpeg); loadDoctor(); loadUsage(); checkUpdate(true);
    if (c.model_claude != null) $("#model").value = c.model_claude;
    if (c.default_effort) $("#effort").value = c.default_effort;
  } catch (e) { /* 설정 없음 */ }
  applyProviderUI();
}
$("#btnAiSave").onclick = async () => {
  try {
    await api("/api/config", { method: "POST", body: {
      default_provider: S.ai.provider, default_effort: $("#effort").value, model_claude: $("#model").value,
      openai_key: $("#cfgOpenai").value, gemini_key: $("#cfgGemini").value, ollama_url: $("#cfgOllama").value,
      anthropic_key: $("#cfgAnthropic").value, model_anthropic: $("#model_anthropic").value, script_root: $("#cfgScriptRoot").value,
      model_openai: $("#model_openai").value, model_gemini: $("#model_gemini").value, model_ollama: $("#model_ollama").value,
      xai_key: $("#cfgXai").value, model_xai: $("#model_xai").value } });
    toast("AI 설정을 저장했습니다: " + PROVIDER_LABEL[S.ai.provider]); loadAiConfig();
  } catch (e) { toast(e.message, true); }
};
$("#btnScriptRootPick").onclick = async () => {
  toast("폴더 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/pick_folder?initial=" + encodeURIComponent($("#cfgScriptRoot").value)); if (r.path) { $("#cfgScriptRoot").value = r.path; await saveScriptRoot(); } } catch (e) { toast(e.message, true); }
};
/* 대본 폴더는 AI 설정의 「저장」과 떨어져 낭독 음성 아래에 있으므로(2026-09-12) 바꾸는 즉시 저장한다 */
async function saveScriptRoot() {
  try { await api("/api/config", { method: "POST", body: { script_root: $("#cfgScriptRoot").value } }); toast($("#cfgScriptRoot").value ? "대본 폴더를 저장했습니다" : "대본 폴더를 비웠습니다"); }
  catch (e) { toast(e.message, true); }
}
$("#cfgScriptRoot").onchange = saveScriptRoot;
/* 첫 실행 점검 띠 · 버전 · 업데이트 · 문제 신고 */
async function loadDoctor() {
  try {
    const d = await api("/api/doctor"); S.doctor = d; $("#verTag").textContent = "v" + d.version + (d.embedded ? "" : " · dev");
    const bar = $("#doctorBar"); bar.classList.remove("hidden");
    bar.innerHTML = d.items.map(it => `<span class="chip${it.ok ? "" : " bad"}" data-id="${it.id}"${it.action ? ` data-action="${it.action}"` : ""} title="${esc(it.detail)}"><i>${it.ok ? "✓" : "!"}</i><b>${esc(it.label)}</b>${esc(it.detail)}</span>`).join("");
    if (d.items.some(it => it.id === "ai" && !it.ok) && typeof setAiBox === "function") setAiBox(true);
    /* 사이드바 요약 — 전부 정상이면 접힌 채로 두고, 하나라도 걸리면 펴서 보여 준다.
       평소에 볼 일 없는 아홉 줄이 첫 화면을 차지하던 것을 여기로 옮겼다(2026-09-14). */
    /* 그록·Flow 는 별도 도구가 있어야 돌아간다(전용 크롬 프로필 + 로그인). 없는 PC 에서
       단추를 눌러 봤자 「미연결」로 끝나고 남의 경로만 보이므로, 아예 그리지 않는다.
       없는 기능이 보이는 것보다 없는 편이 낫다(2026-09-14 사용자 결정). */
    const has = id => (d.items.find(it => it.id === id) || {}).ok;
    const hide = (sel, on) => $$(sel).forEach(el => el && el.classList.toggle("hidden", !on));
    hide("#btnQuickFlow, #btnProdFlow, #btnProdCheck", has("flow"));
    hide("#btnQuickGrok, #btnProdGrok", has("grok"));
    $$("#prodStep1, #prodStep2").forEach(el => {
      /* 단계 안내에 남은 단추가 하나도 없으면 그 줄도 감춘다 */
      const live = [...el.querySelectorAll(".btn")].some(b => !b.classList.contains("hidden"));
      el.classList.toggle("hidden", !live);
    });

    /* 그록·Flow 가 없는 것은 「정상」이다(별도 도구라 대부분의 PC 에 없다). 경고 수에 넣으면
       설치가 잘못된 줄 알게 되므로 세지 않고, 칩도 그리지 않는다. */
    const OPTIONAL = ["flow", "grok"];
    OPTIONAL.forEach(id => {
      if (!has(id)) { const c = bar.querySelector(`.chip[data-id="${id}"]`); if (c) c.remove(); }
    });
    const bad = d.items.filter(it => !it.ok && !OPTIONAL.includes(it.id)), box = $("#envBox"), sum = $("#envSum");
    const shown = bar.querySelectorAll(".chip").length;
    if (sum) sum.textContent = bad.length ? `⚠ 확인 필요 ${bad.length}개` : `환경 정상 · ${shown}개`;
    if (box) { box.classList.toggle("has-bad", !!bad.length); if (bad.length) setEnvBox(true); }
    bar.querySelectorAll(".chip[data-action]").forEach(el => el.onclick = () => {
      if (el.dataset.action === "ffmpeg") { $("#ffBanner").classList.remove("hidden"); $("#ffBanner").scrollIntoView({ block: "center" }); }
      if (el.dataset.action === "ai") { setAiBox(true); $("#aibox").scrollIntoView({ block: "start", behavior: "smooth" }); }
    });
  } catch (e) { /* 서버 옛 판 */ }
}
function setEnvBox(open) {
  const box = $("#envBox"); if (!box) return;
  box.classList.toggle("collapsed", !open);
  const t = $("#envToggle"); if (t) t.setAttribute("aria-expanded", open ? "true" : "false");
}
if ($("#envToggle")) $("#envToggle").onclick = () => setEnvBox($("#envBox").classList.contains("collapsed"));

/* ── 원본 영상 정리(2026-09-14) ─────────────────────────────────────────
   실측에서 프로젝트 188개 26.5GB 중 98.4% 가 mp4 였고 그 대부분이 「이미 완성본을
   뽑았는데 계속 들고 있는 원본」이었다. 목록을 줄이는 것으로는 디스크가 안 준다.
   지우는 기능이라 **스캔 → 목록을 눈으로 확인 → 지우기** 순서를 강제한다. */
function mb(n) { return n >= (1 << 30) ? (n / (1 << 30)).toFixed(1) + " GB" : Math.round(n / (1 << 20)) + " MB"; }
let cleanFound = [];

async function cleanScan() {
  const days = $("#cleanDays").value;
  $("#cleanSum").textContent = "훑는 중…";
  $("#btnCleanGo").disabled = true;
  try {
    const r = await api("/api/cleanup/scan?days=" + days);
    cleanFound = r.items || [];
    $("#cleanSum").textContent = cleanFound.length
      ? `${cleanFound.length}개 · ${mb(r.total)} 회수`
      : "지울 것이 없습니다";
    $("#cleanList").innerHTML = cleanFound.length
      ? cleanFound.map(it => `<div class="shop-item"><b>${mb(it.size)}</b>
          <span class="dim small" style="margin-left:8px">${esc(it.title)}</span></div>`).join("")
      : `<div class="dim small" style="padding:10px">그 기간을 넘긴 프로젝트 중 정리할 원본이 없습니다.
         기준을 짧게 잡아 보세요.</div>`;
    $("#btnCleanGo").disabled = !cleanFound.length;
    $("#btnCleanGo").textContent = cleanFound.length ? `${mb(r.total)} 지우기` : "지우기";
  } catch (e) { $("#cleanSum").textContent = e.message; }
}

async function loadUsage() {
  try {
    const r = await api("/api/cleanup/scan?days=99999");   // 지울 것은 안 세고 사용량만
    const el = $("#projUsage"); if (el) el.textContent = `· ${mb(r.used)} 사용`;
  } catch (e) { }
}

if ($("#btnClean")) $("#btnClean").onclick = () => { $("#cleanModal").classList.remove("hidden"); cleanScan(); };
if ($("#btnCleanScan")) $("#btnCleanScan").onclick = cleanScan;
if ($("#cleanDays")) $("#cleanDays").onchange = cleanScan;
if ($("#btnCleanCancel")) $("#btnCleanCancel").onclick = () => $("#cleanModal").classList.add("hidden");
if ($("#btnCleanGo")) $("#btnCleanGo").onclick = async () => {
  if (!cleanFound.length) return;
  const tot = cleanFound.reduce((a, b) => a + b.size, 0);
  if (!confirm(`프로젝트 ${cleanFound.length}개의 원본 영상을 지웁니다 (${mb(tot)}).\n\n완성본과 자막·설정은 남지만, 그 프로젝트를 다시 편집할 수는 없습니다.\n계속할까요?`)) return;
  const b = $("#btnCleanGo"); b.disabled = true; b.textContent = "지우는 중…";
  try {
    const r = await api("/api/cleanup/apply", { method: "POST", body: { ids: cleanFound.map(x => x.id) } });
    toast(`${mb(r.freed)} 를 비웠습니다 (프로젝트 ${r.projects}개)`);
    $("#cleanModal").classList.add("hidden");
    loadUsage(); loadProjects();
  } catch (e) { toast(e.message, true); }
  finally { b.disabled = false; b.textContent = "지우기"; }
};

/* ── AI 로 대본 쓰기(2026-09-14) ────────────────────────────────────────
   구매자는 대본을 갖고 있지 않다. 이미 자기 AI 를 연결해 놓고도 챗GPT 로 나갔다
   오게 할 이유가 없어서 여기서 바로 쓴다. 가로 롱폼에는 대본을 만드는 수단이
   아예 없었다(상품 대본은 9:16 전용이라 감춰져 있다). */
if ($("#btnScriptAi")) $("#btnScriptAi").onclick = () => {
  $("#scriptModal").classList.remove("hidden");
  $("#sgInfo").textContent = "";
  if (!$("#sgTopic").value.trim()) $("#sgTopic").focus();
};
/* 길이가 길수록 목표 자수에 못 미친다 — 실측 5분 105% / 12분 82%(2026-09-14).
   미리 알려 주지 않으면 「왜 짧게 나오냐」가 된다. */
function sgLenHint() {
  const m = parseInt($("#sgMin").value, 10) || 3;
  const el = $("#sgLenHint"); if (!el) return;
  el.textContent = m >= 20 ? "토막을 나눠 씁니다 · 5분쯤 걸립니다"
    : m >= 8 ? "토막을 나눠 씁니다 · 2~3분쯤 걸립니다" : "";
}
if ($("#sgMin")) { $("#sgMin").onchange = sgLenHint; sgLenHint(); }
if ($("#btnSgCancel")) $("#btnSgCancel").onclick = () => $("#scriptModal").classList.add("hidden");
if ($("#btnSgGo")) $("#btnSgGo").onclick = async () => {
  const topic = $("#sgTopic").value.trim();
  if (!topic) { $("#sgInfo").textContent = "무엇에 대한 영상인지 적어 주세요."; $("#sgTopic").focus(); return; }
  const cur = $("#shopScript").value.trim();
  if (cur && !confirm("대본 칸에 이미 글이 있습니다. 새로 쓴 대본으로 바꿀까요?")) return;
  const b = $("#btnSgGo"); b.disabled = true; b.textContent = "쓰는 중…";
  $("#sgInfo").textContent = "시작하는 중…";
  try {
    /* 긴 대본은 토막마다 AI 를 부르므로 몇 분 걸린다. 작업으로 돌리고 진행률을 묻는다. */
    const { token } = await api("/api/script/write", { method: "POST", body: {
      topic, kind: $("#sgKind").value, minutes: $("#sgMin").value,
      keywords: $("#sgKeys").value, audience: $("#sgWho").value } });
    const r = await new Promise((res, rej) => {
      const t = setInterval(async () => {
        let j;
        try { j = (await api("/api/script/write?token=" + token)).job; }
        catch (e) { clearInterval(t); return rej(e); }
        if (!j) return;
        if (j.running) { $("#sgInfo").textContent = (j.message || "쓰는 중…") + (j.pct != null ? ` (${j.pct}%)` : ""); return; }
        clearInterval(t);
        if (j.errors && j.errors.length) return rej(new Error(j.errors[0]));
        res(j.result);
      }, 1500);
    });
    $("#shopScript").value = r.script;
    $("#shopScript").dispatchEvent(new Event("change"));
    $("#scriptAiInfo").textContent = `${r.chars}자 · 낭독 약 ${r.minutes}분`
      + (r.sections > 1 ? ` · ${r.sections}토막` : "");
    $("#scriptModal").classList.add("hidden");
    toast("대본을 넣었습니다. 읽어 보고 고친 뒤 「🎙 대본으로 만들기」를 누르세요");
  } catch (e) { $("#sgInfo").textContent = e.message; }
  finally { b.disabled = false; b.textContent = "대본 쓰기"; }
};

function updBanner(u) {
  const b = $("#updBanner"); if (!b) return;
  if (u && u.available) {
    b.classList.remove("hidden"); $("#updTitle").textContent = `새 판 v${u.latest} 이 있습니다 (지금 v${u.current}).`;
    $("#updNotes").textContent = (u.date ? u.date + " · " : "") + (u.notes || "");
  } else b.classList.add("hidden");
}
async function checkUpdate(silent) {
  try {
    const u = await api("/api/update/check"); updBanner(u);
    if (!silent) toast(!u.configured ? "업데이트 주소가 설정되지 않았습니다(개발판)" : u.available ? `새 판 v${u.latest} 이 있습니다` : `최신 판입니다 (v${u.current})`);
    return u;
  } catch (e) { if (!silent) toast(e.message, true); }
}
$("#btnUpdate").onclick = () => checkUpdate(false);
$("#btnUpdApply").onclick = async () => {
  if (!confirm("프로그램 파일을 새 판으로 바꾸고 다시 시작합니다. 편집 중인 내용은 자동 저장돼 있습니다. 진행할까요?")) return;
  const btn = $("#btnUpdApply"); btn.disabled = true;
  try {
    let r = await api("/api/update/apply", { method: "POST", body: {} });
    const cur = (S.doctor || {}).version;
    const t = setInterval(async () => {
      try {
        const v = await api("/api/version"); const j = v.update || {};
        $("#updMsg").textContent = `${j.message || ""} ${j.pct != null ? j.pct + "%" : ""}`;
        if (j.error) { clearInterval(t); btn.disabled = false; toast("업데이트 실패: " + j.error, true); return; }
        if (v.version && cur && v.version !== cur) { clearInterval(t); toast("v" + v.version + " 으로 바뀌었습니다. 새로 고칩니다"); setTimeout(() => location.reload(), 800); }
      } catch (e) { $("#updMsg").textContent = "다시 시작하는 중…"; }   // 서버가 내려간 사이: 계속 기다린다
    }, 1000);
  } catch (e) { btn.disabled = false; toast(e.message, true); }
};
$("#btnReport").onclick = async () => {
  try { const r = await api("/api/report", { method: "POST", body: { open: true } }); toast("문제 신고 파일을 만들었습니다: " + r.path.split(/[\\/]/).pop() + " (탐색기에서 선택됨)"); }
  catch (e) { toast(e.message, true); }
};
/* ffmpeg 가 없으면 홈 위쪽에 안내 띠. 「자동으로 받기」는 공식 빌드를 bin\ 에 내려받고, 진행률을 1초마다 묻는다 */
function ffmpegBanner(st) {
  const b = $("#ffBanner"); if (!b || !st) return;
  b.classList.toggle("hidden", !!st.found && !st.job?.running);
  const j = st.job || {};
  if (j.running) { $("#ffMsg").textContent = `${j.message} ${j.pct != null ? j.pct + "%" : ""}`; $("#btnFfInstall").disabled = true; }
  else if (j.error) { $("#ffMsg").textContent = "실패: " + j.error + " — 다시 누르거나 ffmpeg.org 에서 직접 설치하세요."; $("#btnFfInstall").disabled = false; }
  else if (j.done && st.found) { toast("ffmpeg 를 받았습니다: " + st.version); $("#btnFfInstall").disabled = false; }
}
$("#btnFfInstall").onclick = async () => {
  try {
    ffmpegBanner(await api("/api/ffmpeg/install", { method: "POST", body: {} }));
    const t = setInterval(async () => {
      try { const st = await api("/api/ffmpeg"); ffmpegBanner(st); if (!st.job?.running) clearInterval(t); } catch (e) { clearInterval(t); }
    }, 1000);
  } catch (e) { toast(e.message, true); }
};
/* 로고: 서버가 윈도 파일 선택 창을 띄우고 경로를 돌려준다. 미리보기는 /api/logo 로 그 파일을 읽는다 */
const logoUrl = p => p ? "/api/logo?path=" + encodeURIComponent(p) + "&v=" + Date.now() : "";
async function pickFile(kind) {
  toast("파일 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/pick_file?kind=" + kind); return r.path || ""; } catch (e) { toast(e.message, true); return ""; }
}
function setSetupLogo(p) { S.setup.logo = p; $("#logoPath").value = p; const im = $("#logoPrev"); im.classList.toggle("hidden", !p); if (p) im.src = logoUrl(p); renderTplPreviews(); }
$("#btnLogoPick").onclick = async () => { const p = await pickFile("image"); if (p) setSetupLogo(p); };
$("#btnLogoClear").onclick = () => setSetupLogo("");
function checkCreate() { $("#btnCreate").disabled = !(S.probe && $("#rights").checked); }
$("#btnCreate").onclick = async () => {
  const info = S.probe; if (!info) return;
  const body = {
    source: info.type === "youtube" ? { type: "youtube", url: info.url, video_id: info.video_id, title: info.title, channel: info.channel, channel_id: info.channel_id }
      : { type: "file", path: info.path, title: info.title },
    settings: { range: [+$("#rangeA").value, +$("#rangeB").value], template: S.setup.template, ratio: S.setup.ratio,
      accent: S.setup.accent, channel_name: $("#chanName").value.trim(), count: +$("#count").value,
      provider: S.ai.provider, model: aiModelFor(S.ai.provider),
      effort: $("#effort").value, show_subs: $("#showSubs").checked,
      channel_logo: S.setup.logo || "", show_logo: true },
  };
  $("#btnCreate").disabled = true;
  try { const p = await api("/api/projects", { method: "POST", body }); openProgress(p.id); }
  catch (e) { toast(e.message, true); $("#btnCreate").disabled = false; }
};

/* ───────── 홈: 쇼핑 쇼츠 모드 ───────── */
S.shop = { videos: [], tts: "" };
/* ───────── 라이선스(모드 잠금): /api/license 로 상태를 읽어 잠긴 모드에 자물쇠, 생성 요청은 서버가 402 로 막는다 ───────── */
async function loadLicense() {
  try { S.lic = await api("/api/license"); } catch (_) { S.lic = null; return; }
  applyLicense();
}
function applyLicense() {
  const l = S.lic; if (!l) return;
  const has = m => l.dev || (l.modes || []).includes(m);
  $$(".mode").forEach(b => { const ok = has(b.dataset.mode); b.classList.toggle("locked", !ok); $(".lock", b).classList.toggle("hidden", ok); });
  $("#licMachine").textContent = l.machine || "—";
  const modesKo = (l.modes || []).map(m => ({ shop: "쇼핑 쇼츠", long: "롱폼→쇼츠", wide: "가로 편집" }[m] || m)).join(" · ");
  let sum, state;
  if (l.dev) { sum = "개발자 PC — 전체 열림"; state = sum; }
  else if (l.ok) {
    // 1년 이용권(2026-09-13 판매 조건): 만료 30일 전부터 남은 날을 보여 주고 하루 한 번 알린다
    const left = l.exp ? Math.ceil((new Date(l.exp + "T23:59:59") - Date.now()) / 86400000) : null;
    const trial = (l.plan || "").startsWith("체험");
    const leftTxt = left == null ? "" : ((trial || left <= 30) ? ` · ${left}일 남음` : "");
    sum = (l.plan || modesKo) + (l.exp ? " · " + l.exp + "까지" + leftTxt : " · 평생");
    state = `등록됨 — ${l.plan || ""} (${modesKo})` + (l.exp ? ` · 만료 ${l.exp}${leftTxt}` : " · 평생") + (l.to ? ` · ${l.to}` : "") + (l.pc ? " · 이 PC 전용" : "");
    if (trial) {
      // 체험판(2026-09-14): 남은 날을 항상 보이고, 오류·불편을 보내 달라는 안내를 라이선스 칸에 둔다
      sum = `체험판 · ${left}일 남음 (${l.exp}까지)`;
      state = `체험판 — 모든 기능 열림 · ${l.exp}까지 · ${left}일 남음. 쓰다가 오류나 불편한 점은 위쪽 「문제 신고」 파일과 함께 shortscut.kr 신청 폼으로 보내 주세요. 반영해서 업데이트합니다. 계속 쓰시려면 shortscut.kr 에서 구매하시면 됩니다.`;
      try { const k = "licTrial:" + l.exp, today = new Date().toISOString().slice(0, 10); if (localStorage.getItem(k) !== today && left <= 2) { localStorage.setItem(k, today); toast(`체험 기간이 ${left}일 남았습니다(${l.exp}까지). 계속 쓰시려면 shortscut.kr 에서 구매해 주세요.`, true); } } catch (_) {}
    }
    else if (left != null && left <= 30) { try { const k = "licWarn:" + l.exp, today = new Date().toISOString().slice(0, 10); if (localStorage.getItem(k) !== today) { localStorage.setItem(k, today); toast(`라이선스가 ${left}일 뒤(${l.exp}) 만료됩니다. 연장은 shortscut.kr 에서 1년 단위로 할 수 있습니다.`, true); } } catch (_) {} }
  }
  else if (l.error) { sum = "키 문제 — 펼쳐서 확인"; state = "⚠ " + l.error; }
  else { sum = "미등록 — 구매한 키를 넣으세요"; state = "미등록. 쇼핑 쇼츠·롱폼→쇼츠·가로 편집은 키를 넣어야 열립니다."; }
  $("#licSum").textContent = sum; $("#licState").textContent = state;
  $("#btnLicClear").classList.toggle("hidden", !(l.ok && !l.dev));
  const foot = $("#verTag"); if (foot && !foot.dataset.lic) { foot.dataset.lic = "1"; }
}
function setLicBox(open) { $("#licbox").classList.toggle("collapsed", !open); $("#licToggle").textContent = open ? "접기 ▴" : "펼치기 ▾"; }
$("#licToggle").onclick = () => setLicBox($("#licbox").classList.contains("collapsed"));
$("#btnLicCopyPc").onclick = async () => { const t = $("#licMachine").textContent; try { await navigator.clipboard.writeText(t); toast("PC 코드를 복사했습니다: " + t); } catch (_) { toast("PC 코드: " + t); } };
$("#btnLicSave").onclick = async () => {
  const key = $("#licKey").value.trim(); if (!key) return toast("키를 붙여 넣어 주세요", true);
  try { S.lic = await api("/api/license", { method: "POST", body: { key } }); applyLicense(); $("#licKey").value = ""; toast("라이선스를 등록했습니다: " + (S.lic.plan || "")); }
  catch (e) { toast(e.message, true); }
};
$("#btnLicClear").onclick = async () => { if (!confirm("라이선스 키를 이 PC 에서 지울까요? 다시 넣으면 복구됩니다.")) return; try { S.lic = await api("/api/license", { method: "POST", body: { clear: true } }); applyLicense(); } catch (e) { toast(e.message, true); } };
$$(".mode").forEach(b => b.onclick = () => {
  if (b.classList.contains("locked")) { setLicBox(true); $("#licbox").scrollIntoView({ behavior: "smooth", block: "center" }); toast(b.dataset.mode === "wide" ? "가로 롱폼 편집은 일괄 구매 라이선스에서 열립니다" : "이 모드는 라이선스 키를 넣어야 열립니다", true); }
  $$(".mode").forEach(x => x.classList.toggle("on", x === b));
  S.homeMode = b.dataset.mode; try { localStorage.setItem("homeMode", b.dataset.mode); } catch (e) { }
  const qb = $("#btnQuickShop"); if (qb) qb.textContent = "📁 영상·이미지 업로드";
  /* 쇼핑 쇼츠·가로 롱폼 공통(2026-09-12 사용자): 위 단추는 파일을 올리기만 하고 편집기를 열지 않는다. 위 권리 확인·빈 프로젝트는 없애고
     아래(자세히 절)의 권리 확인 + 올린 파일이 있어야 시작 단추가 켜진다. 그래서 자세히 절을 펼쳐 둔다 */
  const upl = b.dataset.mode === "wide" || b.dataset.mode === "shop";
  $(".quick-rights").classList.toggle("hidden", upl);
  $("#btnQuickEmpty").classList.toggle("hidden", upl);
  $("#quickList").classList.toggle("hidden", !upl);
  if (upl) $("#shopAdv").open = true;
  const wide = b.dataset.mode === "wide"; const shop = b.dataset.mode === "shop" || wide;   // 가로 롱폼 = 같은 자유 편집 폼, 출력 형식만 가로
  $("#mode-long").classList.toggle("hidden", shop); $("#mode-shop").classList.toggle("hidden", !shop);
  $("#wideNote").classList.toggle("hidden", !wide);
  $("#shopTitleBox").classList.toggle("hidden", wide);                                              // 가로 롱폼엔 훅 제목·채널명이 없다
  $("#shopOutBox").classList.toggle("hidden", wide); $("#affBox").classList.toggle("hidden", wide);   // 출력(16:9 고정, 음악·소리는 편집기에서)·제휴 링크(쇼핑 전용)도 뺀다
  $("#shopVideoBox").classList.toggle("hidden", shop); renderShopVideos();                            // 영상 파일 절은 위 「업로드」와 겹친다(두 모드 모두 위가 목록을 채운다)
  /* 「상품 정보로 대본·낭독 만들기」는 세로 쇼츠 전용이다 — 신 구성(6신·8신)도, 이미지
     프롬프트도 1080×1920 9:16 로 고정돼 있다(product.py). 가로 롱폼에서는 통째로 감춘다.
     남겨 두면 가로 프로젝트에 세로 소재를 만들어 주는 단추가 된다. */
  $("#prodBox").classList.toggle("hidden", wide);
  /* 세로 쇼츠 기준으로 쓴 안내 문구를 가로 롱폼용으로 바꾼다. HTML 의 data-wide 에 대체
     문구를 적어 두고, 원래 문구는 처음 바꿀 때 data-narrow 에 넣어 둔다(문구가 늘어나도
     여기는 안 고친다 — 문구는 문구가 있는 곳에서 관리한다). */
  $$("[data-wide]").forEach(el => {
    if (!el.dataset.narrow) el.dataset.narrow = el.textContent;
    el.textContent = wide ? el.dataset.wide : el.dataset.narrow;
  });
  /* 비율은 세로 화면 안에서 영상이 차지하는 크기다. 가로 롱폼에서는 캔버스가 곧 16:9 라
     뜻이 없고, 목록에 16:9 항목이 없어 값을 넣어도 빈 선택이 된다 — 그래서 감춘다. */
  $("#shopRatioFld").classList.toggle("hidden", wide);
  if (shop) { $("#shopCanvas").value = wide ? "16:9" : "9:16"; $("#btnShopCreate").textContent = wide ? "가로 롱폼 편집 시작" : "쇼핑 쇼츠 만들기"; }
  if (shop && !S.music) loadMusic().then(fillShopBgm); else if (shop) fillShopBgm();
  /* 홈은 허브다 — 프로그램을 고르면 작업 화면으로 들어간다. 첫 로드의 모드 복원
     (아래 localStorage 복원)은 화면을 옮기면 안 되므로 S.navOnMode 로 막는다. */
  const mt = $("#makeTitle");
  if (mt) mt.textContent = (b.childNodes[0] && b.childNodes[0].textContent || "").trim();
  if (S.navOnMode) {
    /* 눌린 카드를 잠깐 빛낸 뒤 넘어간다. 바로 바꾸면 무엇을 눌렀는지 안 보인다.
       170ms 는 느리다고 느끼기 전, 번쩍임은 보이는 구간이다. */
    $$(".mode").forEach(x => x.classList.remove("picked"));
    b.classList.add("picked");
    S.mkShown = PROJ_PAGE; S.mkQuery = ""; { const q = $("#mkProjSearch"); if (q) q.value = ""; }
    setTimeout(() => { show("make"); renderMakeProjects(); b.classList.remove("picked"); }, 170);
  }
});
$("#btnMakeBack").onclick = () => show("home");
/* 동봉 음악 드롭다운: 분위기별 묶음(optgroup). 42곡이라 평면 목록으로는 못 고른다(2026-09-08 32곡 추가) */
function musicOptions(withDur) {
  const groups = new Map();
  (S.music || []).forEach(m => { const k = m.mood || "기타"; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(m); });
  const ORDER = ["쇼핑·밝음", "경쾌·리듬", "잔잔·설명", "어둡고 잔잔", "긴장·미스터리", "웅장·드라마", "코믹"];
  const keys = [...groups.keys()].sort((x, y) => (ORDER.indexOf(x) + 1 || 99) - (ORDER.indexOf(y) + 1 || 99));
  return keys.map(mood => [mood, groups.get(mood)]).map(([mood, arr]) => `<optgroup label="${esc(mood)}">` + arr.map(m => `<option value="${m.id}">${esc(m.title)}${withDur ? " · " + fmt(m.duration) : ""}</option>`).join("") + `</optgroup>`).join("");
}
function fillShopBgm() { const sel = $("#shopBgm"); if (sel.options.length > 1) return; sel.innerHTML = `<option value="">없음 (편집기에서 고를 수 있음)</option>` + musicOptions(false); }
function renderShopVideos() {
  const boxes = [$("#shopVideos"), $("#quickList")].filter(Boolean); boxes.forEach(b => b.innerHTML = "");
  for (const box of boxes) S.shop.videos.forEach((v, i) => {
    const d = document.createElement("div"); d.className = "shop-item";
    d.innerHTML = `<span class="n">${i + 1}</span><img class="th" src="/api/thumb?path=${encodeURIComponent(v)}" loading="lazy" alt="" onerror="this.style.visibility='hidden'"><span class="nm" title="${esc(v)}">${esc(v.split(/[\\/]/).pop())}</span>
      <button class="btn sm" data-a="up" ${i === 0 ? "disabled" : ""}>▲</button><button class="btn sm" data-a="down" ${i === S.shop.videos.length - 1 ? "disabled" : ""}>▼</button><button class="btn sm" data-a="del">✕</button>`;
    d.onclick = e => { const a = e.target.dataset.a; if (!a) return; const arr = S.shop.videos;
      if (a === "del") arr.splice(i, 1); else if (a === "up" && i > 0) [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; else if (a === "down" && i < arr.length - 1) [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]];
      renderShopVideos(); };
    box.appendChild(d);
  });
  $("#shopVidInfo").textContent = S.shop.videos.length ? `${S.shop.videos.length}개` : "아직 없음";
  checkShopCreate();
}
function checkShopCreate() { $("#btnShopCreate").disabled = !(S.shop.videos.length && $("#shopRights").checked); }   // 올린 영상·이미지 + 권리 확인. 가로는 위 「업로드」가 목록을 채운다
$("#btnShopTtsClear").onclick = () => { S.shop.tts = ""; $("#shopTts").value = ""; $("#shopTtsInfo").textContent = ""; checkShopCreate(); };
$("#btnShopAddVideos").onclick = async () => {
  toast("영상 파일 선택 창이 열렸습니다(여러 개 선택 가능). 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/pick_files", { method: "POST", body: { kind: "video" } }); (r.paths || []).forEach(p => { if (!S.shop.videos.includes(p)) S.shop.videos.push(p); }); renderShopVideos(); }
  catch (e) { toast(e.message, true); }
};
$("#btnShopTts").onclick = async () => {
  toast("낭독 파일 선택 창이 열렸습니다.");
  try { const p = await pickFile("audio"); if (!p) return; S.shop.tts = p; $("#shopTts").value = p; $("#shopTtsInfo").textContent = ""; checkShopCreate(); }
  catch (e) { toast(e.message, true); }
};
$("#shopRights").onchange = checkShopCreate;
$("#btnShopCreate").onclick = async () => {
  const body = { videos: S.shop.videos, tts: S.shop.tts, script: $("#shopScript").value, line1: $("#shopL1").value, line2: $("#shopL2").value,
    yt_title: S.prod?.yt_title || "", affiliate: S.aff ? { ...S.aff, onscreen: ($("#affOnscreen").value.trim() || S.aff.onscreen) } : null,
    bgm_preset: $("#shopBgm").value || null,
    /* 가로 롱폼은 영상이 캔버스를 꽉 채운다 — 비율 칸을 감췄으므로 값도 여기서 정한다.
       예전에는 감춘 select 에 "16:9" 를 넣으려다 그런 항목이 없어 빈 값이 넘어갔다. */
    settings: { ratio: (S.homeMode === "wide" ? "16:9" : $("#shopRatio").value), canvas: $("#shopCanvas").value, channel_name: $("#shopChan").value.trim(), src_volume: +$("#shopSrcVol").value, provider: S.ai?.provider || "claude", model: aiModelFor(S.ai?.provider || "claude"), effort: "low" } };
  $("#btnShopCreate").disabled = true;
  try { const p = await api("/api/shop", { method: "POST", body }); openProgress(p.id); }
  catch (e) { toast(e.message, true); checkShopCreate(); }
};
renderShopVideos();
/* 바로 시작: 영상만 고르면 기본값으로 프로젝트를 만들고 편집기로 간다(나머지는 편집기 안에서). 권리 확인은 한 번 체크하면 기억 */
try { $("#quickRights").checked = localStorage.getItem("shopRightsOk") === "1"; } catch (e) { }
$("#quickRights").onchange = e => { try { localStorage.setItem("shopRightsOk", e.target.checked ? "1" : "0"); } catch (x) { } $("#shopRights").checked = e.target.checked; checkShopCreate(); };
$("#btnQuickShop").onclick = async () => {
  // 업로드만: 목록에 더하고 편집기는 열지 않는다(쇼핑·가로 공통, 2026-09-12). 시작은 아래 권리 확인 뒤 단추로
  toast("영상·이미지 파일 선택 창이 열렸습니다(여러 개 선택 가능). 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/pick_files", { method: "POST", body: { kind: "media" } }); (r.paths || []).forEach(p => { if (!S.shop.videos.includes(p)) S.shop.videos.push(p); }); renderShopVideos(); }
  catch (e) { toast(e.message, true); }
  if (S.shop.videos.length && !$("#shopRights").checked) toast(`아래 「영상 사용 권리 확인」에 체크하면 「${$("#btnShopCreate").textContent}」이 켜집니다`);
};
$("#btnQuickEmpty").onclick = async () => {
  const wide = S.homeMode === "wide";
  const chan = (() => { try { return localStorage.getItem("chanName") || ""; } catch (e) { return ""; } })();
  const body = { videos: [], empty: true, tts: "", script: "", settings: { ratio: wide ? "16:9" : "9:16", canvas: wide ? "16:9" : "9:16", channel_name: chan, src_volume: 1,   // 가로는 비율도 16:9(띠 없이 꽉 채움)
    provider: S.ai?.provider || "claude", model: aiModelFor(S.ai?.provider || "claude"), effort: "low" } };
  $("#btnQuickEmpty").disabled = true;
  try { const p = await api("/api/shop", { method: "POST", body }); openProgress(p.id); }
  catch (e) { toast(e.message, true); }
  finally { $("#btnQuickEmpty").disabled = false; }
};
$("#shopChan").addEventListener("input", e => { try { localStorage.setItem("chanName", e.target.value.trim()); } catch (x) { } });
$("#shopChan").addEventListener("change", e => { api("/api/config", { method: "POST", body: { last_channel: e.target.value.trim() } }).catch(() => { }); });
try { const c0 = localStorage.getItem("chanName"); if (c0 && !$("#shopChan").value) $("#shopChan").value = c0; } catch (e) { }
try { $("#shopAdv").open = localStorage.getItem("shopAdvOpen") === "1"; } catch (e) { }
$("#shopAdv").addEventListener("toggle", () => { try { localStorage.setItem("shopAdvOpen", $("#shopAdv").open ? "1" : "0"); } catch (e) { } });
/* AI 설정 접기: 기본은 접힘. 점검 띠에서 AI 가 빨간색이면 펼친다 */
function setAiBox(open) { $("#aibox").classList.toggle("collapsed", !open); $("#aiToggle").textContent = open ? "접기 ▴" : "펼치기 ▾"; try { localStorage.setItem("aiBoxOpen", open ? "1" : "0"); } catch (e) { } }
$("#aiToggle").onclick = () => setAiBox($("#aibox").classList.contains("collapsed"));
try { setAiBox(localStorage.getItem("aiBoxOpen") === "1"); } catch (e) { setAiBox(false); }
/* 폰에서 쓰기: 켜기/끄기(서버 재시작) · 주소 · PIN · QR */
function setLanBox(open) { $("#lanbox").classList.toggle("collapsed", !open); $("#lanToggle").textContent = open ? "접기 ▴" : "펼치기 ▾"; try { localStorage.setItem("lanBoxOpen", open ? "1" : "0"); } catch (e) { } }
$("#lanToggle").onclick = () => setLanBox($("#lanbox").classList.contains("collapsed"));
try { setLanBox(localStorage.getItem("lanBoxOpen") === "1"); } catch (e) { }
function drawLan(st) {
  S.lan = st;
  $("#lanSum").textContent = st.enabled ? `켜짐 — 폰에서 ${st.urls[0] || "(주소 없음)"} 을 열고 PIN ${st.pin} 을 넣으세요.` : "꺼짐 — 같은 와이파이의 폰에서 영상을 올리고 완성본을 내려받습니다.";
  $("#btnLanOn").classList.toggle("hidden", st.enabled); $("#btnLanOff").classList.toggle("hidden", !st.enabled);
  $("#lanUrls").innerHTML = st.enabled && st.urls.length ? st.urls.map(u => `<code>${esc(u)}</code>`).join("") : (st.enabled ? "네트워크 주소를 찾지 못했습니다" : "켜면 여기에 주소가 보입니다");
  $("#lanPin").textContent = st.enabled && st.pin ? st.pin : "—";
  const qr = $("#lanQr"); qr.innerHTML = "";
  if (st.enabled && st.urls[0] && window.QRCode) { try { new QRCode(qr, { text: st.urls[0], width: 134, height: 134, correctLevel: QRCode.CorrectLevel.M }); } catch (e) { } }
}
async function loadLan() { try { drawLan(await api("/api/lan")); } catch (e) { } }
async function setLan(body, msg) {
  $("#lanMsg").textContent = msg;
  try {
    const st = await api("/api/lan", { method: "POST", body });
    if (st.restart) {
      let n = 0; const t = setInterval(async () => {
        n++; try { await api("/api/version"); if (n > 2) { clearInterval(t); $("#lanMsg").textContent = ""; loadLan(); loadDoctor(); } } catch (e) { $("#lanMsg").textContent = "다시 시작하는 중…"; }
        if (n > 40) { clearInterval(t); $("#lanMsg").textContent = "서버가 돌아오지 않습니다. 바탕 화면의 쇼츠컷을 다시 누르세요."; }
      }, 1000);
    } else { drawLan(st); $("#lanMsg").textContent = ""; }
  } catch (e) { $("#lanMsg").textContent = e.message; }
}
$("#btnLanOn").onclick = () => { if (confirm("같은 와이파이의 폰에서 접속할 수 있게 엽니다. 서버가 잠깐 다시 뜨고, 윈도 방화벽 창이 나오면 「액세스 허용」을 누르세요.")) setLan({ enabled: true }, "켜는 중…"); };
$("#btnLanOff").onclick = () => setLan({ enabled: false }, "끄는 중…");
$("#btnLanPin").onclick = () => setLan({ new_pin: true, restart: false }, "");
loadLan();
/* 마지막에 쓴 모드로 연다(처음엔 쇼핑 쇼츠) */
(() => { let m = "shop"; try { m = localStorage.getItem("homeMode") || "shop"; } catch (e) { } const b = $(`.mode[data-mode="${m}"]`) || $(`.mode[data-mode="shop"]`); if (b) b.click(); S.navOnMode = true; })();

/* ───────── 홈: 상품 정보 → 대본·낭독 (쇼핑 쇼츠 앞단) ─────────
   product.py 가 대본·낭독·이미지 프롬프트까지 만들고, 여기서 그 결과로 위 칸을 채운다.
   화면(이미지·영상)은 구글 플로우에서 사람이 받아 오고, 자막·편집·렌더는 쇼핑 쇼츠가 맡는다. */
S.prod = null;
let prodTimer = null;

/* 목소리 목록: 「한국어 / 다국어 / 기타」로 묶어 그린다. group 이 없으면 묶지 않는다. */
function voiceOptions(voices) {
  const groups = [];
  (voices || []).forEach(v => {
    const g = v.group || "";
    let e = groups.find(x => x.g === g);
    if (!e) groups.push(e = { g, items: [] });
    e.items.push(v);
  });
  return groups.map(e => {
    const opts = e.items.map(v => `<option value="${v.id}">${esc(v.label)}</option>`).join("");
    return e.g ? `<optgroup label="${esc(e.g)}">${opts}</optgroup>` : opts;
  }).join("");
}

const PROD_SAMPLE = "이 상품, 왜 이렇게 싸게 파는지 아세요? 오늘 하루만 이 가격입니다.";
const prodAudio = new Audio();

/* 목소리 목록은 세 곳이 같이 쓴다 — 상품 대본(prodVoice) · 쇼핑 쇼츠 낭독(shopVoice) ·
   훅 낭독(hkVoice). 키를 넣거나 빼면 세 곳을 한꺼번에 다시 채운다. */
const VOICE_SELECTS = ["#prodVoice", "#shopVoice", "#hkVoice", "#ttsVoice"];
async function loadVoices() {
  let r;
  try { r = await api("/api/tts/voices"); } catch (e) { return; }
  VOICE_SELECTS.forEach(sel => {
    const el = $(sel); if (!el) return;
    const keep = el.value;
    el.innerHTML = voiceOptions(r.voices);
    if (keep && [...el.options].some(o => o.value === keep)) el.value = keep;
  });
}
loadVoices();

/* ElevenLabs — 본인 키를 넣을 때만 목소리 목록에 붙는다. 키가 없으면 무료 음성만 보인다.
   같은 칸이 화면 세 곳(상품 대본·쇼핑 쇼츠·훅 낭독)에 있으므로 접미 번호로 한 번에 묶는다. */
function elevenShow(st, n) {
  const box = $("#elevenInfo" + n), sel = $("#elevenModel" + n);
  if (sel) sel.innerHTML = (st.models || []).map(m =>
    `<option value="${m.id}"${m.id === st.model ? " selected" : ""}>${esc(m.label)}</option>`).join("");
  if (!box) return;
  if (!st.ready) { box.textContent = "키가 없습니다. 본인 ElevenLabs 구독의 키를 넣으면 목소리 목록에 「ElevenLabs」 묶음이 생깁니다."; return; }
  if (st.error) { box.textContent = "키를 확인하지 못했습니다: " + st.error; return; }
  const left = st.left == null ? "" : `남은 크레딧 ${st.left.toLocaleString()}자 / ${(st.limit || 0).toLocaleString()}자`;
  /* 편수 환산 — 쇼핑 쇼츠 낭독을 160자로 잡고, 자당 크레딧은 2026-09-09 실측값을 쓴다
     (v2·v3 0.55, flash 0.27). 정가 1.0/0.5 로 잡으면 남은 편수를 실제의 절반으로 알린다. */
  const perChar = st.model === "eleven_flash_v2_5" ? 0.27 : 0.55;
  const shorts = st.left == null ? "" : ` · 쇼핑쇼츠 약 ${Math.floor(st.left / (160 * perChar))}편분`;
  box.textContent = `${st.tier ? st.tier + " 플랜 · " : ""}${left}${shorts}`;
}
["", "2", "3"].forEach(n => {
  const btn = $("#btnElevenKeys" + n), box = $("#elevenBox" + n), save = $("#btnElevenSave" + n);
  if (!btn || !box || !save) return;
  btn.onclick = async () => {
    box.classList.toggle("hidden");
    if (box.classList.contains("hidden")) return;
    try { elevenShow(await api("/api/tts/eleven"), n); } catch (e) { toast(e.message, true); }
  };
  save.onclick = async () => {
    save.disabled = true;
    try {
      const st = await api("/api/tts/eleven", { method: "POST", body: {
        elevenlabs_key: $("#elevenKey" + n).value.trim(), elevenlabs_model: $("#elevenModel" + n).value } });
      $("#elevenKey" + n).value = "";
      elevenShow(st, n);
      await loadVoices();
      toast(st.ready ? "ElevenLabs 를 연결했습니다" : "키를 넣어 주세요");
    } catch (e) { toast(e.message, true); }
    finally { save.disabled = false; }
  };
  $("#elevenModel" + n).onchange = () => save.click();
});

/* 쇼핑 쇼츠(가로 롱폼 포함) — 아래 「대본」 칸의 글을 통째로 읽어 낭독 파일을 만든다.
   결과는 파일을 직접 고른 것과 똑같이 취급되므로 받아쓰기·자막·조각 배분은 그대로 이어진다.
   1만 자짜리 가로 롱폼이면 1~3분 걸려 작업으로 돌리고 진행률을 묻는다. */
function pollTts(token, onMsg) {
  return new Promise((resolve, reject) => {
    const t = setInterval(async () => {
      let job;
      try { job = (await api("/api/tts/make?token=" + token)).job; }
      catch (e) { clearInterval(t); return reject(e); }
      if (!job) return;
      if (job.running) { onMsg((job.message || "만드는 중…") + (job.pct != null ? ` (${job.pct}%)` : "")); return; }
      clearInterval(t);
      if (job.errors && job.errors.length) return reject(new Error(job.errors[0]));
      if (!job.result) return reject(new Error("낭독을 만들지 못했습니다"));
      resolve(job.result);
    }, 900);
  });
}
/* ───── Flow 이미지 생성(2026-09-12): 홈 「Flow로 이미지 뽑기」 모달 + 상품 시트 자동 생성. 진행은 /api/flow/images?token= 으로 묻는다 ───── */
function pollFlow(token, onMsg) {
  return new Promise((resolve, reject) => {
    const t = setInterval(async () => {
      let job;
      try { job = (await api("/api/flow/images?token=" + token)).job; }
      catch (e) { clearInterval(t); return reject(e); }
      if (!job) return;
      if (job.running) { onMsg((job.message || "만드는 중…") + (job.pct != null ? ` (${job.pct}%)` : "")); return; }
      clearInterval(t);
      if (job.errors && job.errors.length) return reject(new Error(job.errors[0]));
      if (!job.result) return reject(new Error("이미지를 만들지 못했습니다"));
      resolve(job.result);
    }, 1500);
  });
}
function pollGrok(token, onMsg) {
  return new Promise((resolve, reject) => {
    const t = setInterval(async () => {
      let job;
      try { job = (await api("/api/grok/videos?token=" + token)).job; }
      catch (e) { clearInterval(t); return reject(e); }
      if (!job) return;
      if (job.running) { onMsg((job.message || "만드는 중…") + (job.pct != null ? ` (${job.pct}%)` : "")); return; }
      clearInterval(t);
      if (job.errors && job.errors.length) return reject(new Error(job.errors[0]));
      if (!job.result) return reject(new Error("영상을 만들지 못했습니다"));
      resolve(job.result);
    }, 2000);
  });
}
const isImgPath = p => /\.(png|jpe?g|webp|bmp|gif)$/i.test(p || "");
$("#btnQuickGrok").onclick = () => {
  const imgs = S.shop.videos.filter(isImgPath);
  if (!imgs.length) return toast("목록에 이미지가 없습니다. 먼저 이미지를 올리거나 「Flow로 이미지 뽑기」로 만드세요", true);
  $("#grokTargets").textContent = `대상: 이미지 ${imgs.length}장 — ` + imgs.map(p => p.split(/[\\/]/).pop()).join(", ");
  $("#grokRatio").value = S.homeMode === "wide" ? "16:9" : "9:16"; $("#grokInfo").textContent = "";
  $("#grokModal").classList.remove("hidden"); $("#grokPrompt").focus();
};
$("#btnGrokCancel").onclick = () => { if (S.grokBusy) return toast("만드는 중입니다. 끝나면 닫힙니다."); $("#grokModal").classList.add("hidden"); };
$("#btnGrokMake").onclick = async () => {
  const imgs = S.shop.videos.filter(isImgPath);
  if (!imgs.length) return;
  const b = $("#btnGrokMake"); b.disabled = true; S.grokBusy = true;
  try {
    const r = await api("/api/grok/videos", { method: "POST", body: { images: imgs, text: $("#grokPrompt").value, res: $("#grokRes").value, len: +$("#grokLen").value, ratio: $("#grokRatio").value } });
    $("#grokInfo").textContent = `${r.n}개 만드는 중…`;
    const res = await pollGrok(r.token, m => { $("#grokInfo").textContent = m; });
    // 목록의 이미지 자리를 mp4 로 바꿔 넣는다(순서 유지). 실패한 건 이미지 그대로 둔다
    const made = new Map((res.videos || []).map(v => [v.image, v.file]));
    S.shop.videos = S.shop.videos.map(p => made.get(p) || p);
    renderShopVideos();
    $("#grokModal").classList.add("hidden");
    toast(`영상 ${made.size}개를 목록에 넣었습니다` + (res.failed && res.failed.length ? ` (${res.failed.length}개 실패: ${res.failed[0].error || ""})` : ""));
  } catch (e) { $("#grokInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; S.grokBusy = false; }
};
S.flowRef = "";
$("#btnQuickFlow").onclick = () => {
  $("#flowRatio").value = S.homeMode === "wide" ? "16:9" : "9:16";
  $("#flowRef").value = S.flowRef || ""; $("#flowInfo").textContent = "";
  $("#flowModal").classList.remove("hidden"); $("#flowPrompts").focus();
};
$("#btnFlowCancel").onclick = () => { if (S.flowBusy) return toast("만드는 중입니다. 끝나면 닫힙니다."); $("#flowModal").classList.add("hidden"); };
$("#btnFlowRefPick").onclick = async () => {
  try { const r = await api("/api/pick_files", { method: "POST", body: { kind: "image" } }); if ((r.paths || []).length) { S.flowRef = r.paths[0]; $("#flowRef").value = S.flowRef; } }
  catch (e) { toast(e.message, true); }
};
$("#btnFlowRefClear").onclick = () => { S.flowRef = ""; $("#flowRef").value = ""; };
$("#btnFlowLogin").onclick = async () => {
  try { await api("/api/flow/login", { method: "POST", body: {} }); toast("Flow 크롬 창을 열었습니다. 그 창에서 구글 로그인을 한 번 하면 됩니다."); }
  catch (e) { toast(e.message, true); }
};
$("#btnFlowMake").onclick = async () => {
  const text = $("#flowPrompts").value.trim();
  if (!text) return toast("프롬프트를 한 줄 이상 넣어 주세요", true);
  const b = $("#btnFlowMake"); b.disabled = true; S.flowBusy = true;
  try {
    const r = await api("/api/flow/images", { method: "POST", body: { text, refs: S.flowRef ? [S.flowRef] : [], ratio: $("#flowRatio").value } });
    $("#flowInfo").textContent = `${r.n}장 만드는 중…`;
    const res = await pollFlow(r.token, m => { $("#flowInfo").textContent = m; });
    (res.images || []).forEach(im => { if (!S.shop.videos.includes(im.file)) S.shop.videos.push(im.file); });
    renderShopVideos();
    $("#flowModal").classList.add("hidden");
    toast(`이미지 ${(res.images || []).length}장을 목록에 넣었습니다` + (res.missing && res.missing.length ? ` (${res.missing.length}장은 Flow 가 버려 다시 시도)` : ""));
  } catch (e) { $("#flowInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; S.flowBusy = false; }
};
$("#btnShopVoiceTest").onclick = async () => {
  const b = $("#btnShopVoiceTest"); b.disabled = true;
  const text = ($("#shopScript").value.trim().split(/(?<=[.!?])\s+/)[0] || PROD_SAMPLE).slice(0, 120);
  $("#shopMakeInfo").textContent = "음성 만드는 중…";
  try {
    const r = await api("/api/tts/preview", { method: "POST", body: { text, voice: $("#shopVoice").value, rate: +$("#shopRate").value } });
    prodAudio.src = r.url; prodAudio.currentTime = 0; await prodAudio.play();
    $("#shopMakeInfo").textContent = `${r.duration}초`;
  } catch (e) { $("#shopMakeInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnShopMakeTts").onclick = async () => {
  const text = $("#shopScript").value.trim();
  if (!text) return toast("아래 「대본」 칸에 읽을 글을 먼저 넣어 주세요", true);
  const b = $("#btnShopMakeTts"), info = $("#shopMakeInfo");
  b.disabled = true; info.textContent = "낭독을 만드는 중…";
  try {
    const r = await api("/api/tts/make", { method: "POST", body: {
      text, voice: $("#shopVoice").value, rate: +$("#shopRate").value } });
    const res = await pollTts(r.token, m => info.textContent = m);
    S.shop.tts = res.path;
    $("#shopTts").value = res.path;
    $("#shopTtsInfo").textContent = `${res.duration}초`;
    info.textContent = `${res.chars.toLocaleString()}자 → ${res.duration}초 낭독을 만들었습니다`;
    checkShopCreate();
  } catch (e) { info.textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};

$("#btnProdVoiceTest").onclick = async () => {
  // 이미 대본이 있으면 그 첫 문장으로, 없으면 견본 문장으로 들려 준다
  const text = (S.prod && S.prod.script ? S.prod.script.split(/(?<=[.!?])\s+/)[0] : "") || PROD_SAMPLE;
  const rate = $("#prodSpeed").value ? Math.round((+$("#prodSpeed").value - 1) * 100) : 0;
  const b = $("#btnProdVoiceTest");
  b.disabled = true; $("#prodVoiceInfo").textContent = "음성 만드는 중…";
  try {
    const r = await api("/api/tts/preview", { method: "POST", body: { text, voice: $("#prodVoice").value, rate } });
    prodAudio.src = r.url; prodAudio.currentTime = 0; await prodAudio.play();
    $("#prodVoiceInfo").textContent = `${r.duration}초`;
  } catch (e) { $("#prodVoiceInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#prodVoice").onchange = () => { prodAudio.pause(); $("#prodVoiceInfo").textContent = ""; };

function prodApply(r) {
  S.prod = r;
  const ready = !!(r.tts && r.prompts);
  $("#prodDone").classList.toggle("hidden", !ready);
  if (!ready) return;
  S.shop.tts = r.tts; $("#shopTts").value = r.tts;
  $("#btnProdSplit").classList.toggle("hidden", !r.sheet_files);          // 시트(가로 묶음)가 있을 때만 나누기 단추. Flow 자동 생성은 신마다 9:16 한 장이라 나눌 게 없다
  $("#shopTtsInfo").textContent = `${r.duration}초 · 신 ${r.scenes || 0}개`;
  if (r.script) $("#shopScript").value = r.script;
  const s1 = $("#prodStep1").parentElement, s2 = $("#prodStep2").parentElement;
  if (r.panels) $("#prodStep1").textContent = `신 이미지 ${r.panels}장 준비됨`;
  else if (r.sheet_files) $("#prodStep1").textContent = `시트 ${r.sheet_files}장 있음 — 「시트 나누기」를 누르세요`;
  else $("#prodStep1").textContent = "「Flow로 신 이미지 만들기」를 누르거나, 이미지를 scenes 폴더에 1.png 2.png… 로 넣으세요";
  s1.classList.toggle("ok", !!r.panels);
  if (r.clips && r.clips.length) $("#prodStep2").textContent = `영상 ${r.clips.length}개 준비됨 — 「clips 영상 불러오기」`;
  else $("#prodStep2").textContent = "플로우에서 영상을 만들어 clips 폴더에 1.mp4 … 로 넣으세요";
  s2.classList.toggle("ok", !!(r.clips && r.clips.length));
  checkShopCreate();
}

function prodPoll(id) {
  clearInterval(prodTimer);
  prodTimer = setInterval(async () => {
    let r; try { r = await api(`/api/product?id=${encodeURIComponent(id)}`); } catch (e) { return; }
    const j = r.job || {};
    $("#prodInfo").textContent = (j.pct != null ? `${j.pct}% · ` : "") + (j.message || "");
    if (j.running) return;
    clearInterval(prodTimer);
    $("#btnProdRun").disabled = false;
    if (j.errors && j.errors.length) { toast(j.errors[0], true); return; }
    prodApply(r);
    toast("대본·낭독이 준비됐습니다. 아래 칸이 채워졌습니다.");
  }, 1500);
}

$("#btnProdRun").onclick = async () => {
  const text = $("#prodText").value.trim(), url = $("#prodUrl").value.trim();
  if (!text && !url) return toast("상품 정보를 붙여 넣거나 상품 URL 을 넣어 주세요", true);
  const body = {
    text, url, lane: $("#prodLane").value, voice: $("#prodVoice").value,
    speed: $("#prodSpeed").value ? +$("#prodSpeed").value : null, per: +$("#prodPer").value, images: S.prodImages || [],
    provider: S.ai?.provider || "claude", model: aiModelFor(S.ai?.provider || "claude")
  };
  $("#btnProdRun").disabled = true; $("#prodInfo").textContent = "시작하는 중…";
  try { const r = await api("/api/product", { method: "POST", body }); S.prod = r; prodPoll(r.id); }
  catch (e) { toast(e.message, true); $("#btnProdRun").disabled = false; $("#prodInfo").textContent = ""; }
};

$$("[data-prod-open]").forEach(b => b.onclick = async () => {
  if (!S.prod) return;
  try { await api("/api/product/open", { method: "POST", body: { id: S.prod.id, what: b.dataset.prodOpen } }); }
  catch (e) { toast(e.message, true); }
});

$("#btnProdSplit").onclick = async () => {
  if (!S.prod) return;
  try {
    prodApply(await api("/api/product/split", { method: "POST", body: { id: S.prod.id, per: +$("#prodPer").value } }));
    toast("시트를 나눴습니다. scenes 폴더를 보세요.");
  } catch (e) { toast(e.message, true); }
};

/* 제품 사진(최대 3장) → /api/product 의 images → scenes/refNN 으로 복사돼 Flow 참조로 쓰인다 */
S.prodImages = [];
$("#btnProdImgPick").onclick = async () => {
  try { const r = await api("/api/pick_files", { method: "POST", body: { kind: "image" } }); const ps = (r.paths || []).slice(0, 3); if (ps.length) { S.prodImages = ps; $("#prodImages").value = ps.map(p => p.split(/[\\/]/).pop()).join(", "); } }
  catch (e) { toast(e.message, true); }
};
$("#btnProdImgClear").onclick = () => { S.prodImages = []; $("#prodImages").value = ""; };
$("#btnProdRevoice").onclick = async () => {
  if (!S.prod) return toast("먼저 「대본·낭독 만들기」를 끝내 주세요", true);
  const b = $("#btnProdRevoice"); b.disabled = true; $("#prodInfo").textContent = "낭독을 다시 만드는 중…";
  try {
    const r = await api("/api/product/voice", { method: "POST", body: { id: S.prod.id, voice: $("#prodVoice").value, speed: $("#prodSpeed").value ? +$("#prodSpeed").value : null } });
    S.prod = r; prodPoll(r.id);
  } catch (e) { $("#prodInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnProdFlow").onclick = async () => {
  if (!S.prod) return;
  const b = $("#btnProdFlow"); b.disabled = true; $("#prodInfo").textContent = "Flow 로 시트를 만드는 중…";
  try {
    const r = await api("/api/product/flow", { method: "POST", body: { id: S.prod.id, per: +$("#prodPer").value } });
    $("#prodInfo").textContent = r.n ? `신 이미지 ${r.n}장 만드는 중…` + (r.refs ? ` (제품 사진 ${r.refs}장 참조)` : "") : "검수 중…";
    const res = await pollFlow(r.token, m => { $("#prodInfo").textContent = m; });
    const made = (res.images || []).length;
    if (!made) throw new Error("Flow 가 이미지를 한 장도 돌려주지 않았습니다");
    prodApply(await api(`/api/product?id=${encodeURIComponent(S.prod.id)}`));
    const bad = (res.still_bad || []); const re = (res.regenerated || []);
    $("#prodInfo").textContent = bad.length ? `검수 불합격 남음: ${bad.map(c => `${c.n}신(${c.reason})`).join(" · ")}` : "";
    toast(`신 이미지 ${made}장 준비. 검수 ${(res.check || []).length ? "완료" : "생략"}` + (re.length ? ` · 다시 그림: ${re.join(",")}신` : "") + (bad.length ? ` · 아직 불합격 ${bad.length}장(위 안내 참고)` : "") + ` — 「그록으로 영상 만들기」를 누르세요`);
  } catch (e) { $("#prodInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnProdCheck").onclick = async () => {
  if (!S.prod) return;
  const b = $("#btnProdCheck"); b.disabled = true; $("#prodInfo").textContent = "AI 가 그림을 대본과 대조하는 중…";
  try {
    const r = await api("/api/product/flow", { method: "POST", body: { id: S.prod.id, check_only: true } });
    const res = await pollFlow(r.token, m => { $("#prodInfo").textContent = m; });
    prodApply(await api(`/api/product?id=${encodeURIComponent(S.prod.id)}`));
    const bad = (res.still_bad || []); const re = (res.regenerated || []); const ck = res.check || [];
    $("#prodInfo").textContent = bad.length ? `검수 불합격 남음: ${bad.map(c => `${c.n}신(${c.reason})`).join(" · ")}` : "";
    toast(`검수 ${ck.length}장: 합격 ${ck.filter(c => c.ok).length}` + (re.length ? ` · 다시 그림 ${re.join(",")}신` : "") + (bad.length ? ` · 아직 불합격 ${bad.length}장` : ""));
  } catch (e) { $("#prodInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnProdGrok").onclick = async () => {
  if (!S.prod) return;
  const b = $("#btnProdGrok"); b.disabled = true; $("#prodInfo").textContent = "그록으로 영상을 만드는 중…";
  try {
    const r = await api("/api/product/grok", { method: "POST", body: { id: S.prod.id, res: "720p" } });
    $("#prodInfo").textContent = `클립 ${r.n}개 만드는 중 (${r.len}초)…` + (r.missing && r.missing.length ? ` · 이미지 없는 신: ${r.missing.join(",")}` : "");
    const res = await pollGrok(r.token, m => { $("#prodInfo").textContent = m; });
    const made = (res.videos || []).length;
    $("#prodInfo").textContent = "";
    if (!made) throw new Error("그록이 클립을 하나도 돌려주지 않았습니다" + (res.failed && res.failed[0] ? ": " + (res.failed[0].error || "") : ""));
    toast(`클립 ${made}개를 clips 폴더에 넣었습니다` + (res.failed && res.failed.length ? ` (${res.failed.length}개 실패 — 다시 누르면 그 신만)` : ""));
    $("#btnProdClips").click();
  } catch (e) { $("#prodInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnProdStills").onclick = async () => {
  if (!S.prod) return;
  $("#btnProdStills").disabled = true; $("#prodInfo").textContent = "이미지로 영상을 만드는 중…";
  try {
    const r = await api("/api/product/stills", { method: "POST", body: { id: S.prod.id } });
    prodApply(r); $("#prodInfo").textContent = ""; toast(`이미지 ${r.made}개를 영상으로 만들었습니다.`);
  } catch (e) { toast(e.message, true); $("#prodInfo").textContent = ""; }
  finally { $("#btnProdStills").disabled = false; }
};


/* ───────── 홈: 제휴 링크 (쿠팡 파트너스 · 토스 쉐어링크) ─────────
   링크를 만들면 공정위 고지 문구가 두 곳에 들어간다 — 설명 첫 줄, 그리고 영상 내내 뜨는 자막.
   설명란에만 적으면 심사지침의 '반복 표시' 요건을 못 채운다(affiliate.py 주석 참고). */
S.aff = null;          // 만들어진 링크 {provider, name, link, disclosure, onscreen}
S.affMeta = null;      // 제휴사 목록·준비 여부

async function loadAffiliate() {
  try {
    const r = await api("/api/affiliate"); S.affMeta = r;
    $("#affProvider").innerHTML = `<option value="">쓰지 않음</option>` + r.providers.map(p =>
      `<option value="${p.id}">${esc(p.name)}${p.ready ? "" : " (키 없음)"}</option>`).join("");
    affSync();
  } catch (e) {}
}
loadAffiliate();

function affProv() { return (S.affMeta?.providers || []).find(p => p.id === $("#affProvider").value) || null; }

function affSync() {
  const p = affProv();
  $("#affTarget").disabled = !p;
  $("#affTarget").placeholder = p ? p.target_hint : "먼저 제휴사를 고르세요";
  $("#btnAffLink").disabled = !p || !p.ready;
  if (!p) { $("#affInfo").textContent = ""; return; }
  if (!p.ready) { $("#affInfo").textContent = `${p.name} API 키가 없습니다. 「🔑 제휴 설정」에서 넣어 주세요.`; return; }
  const has = S.aff && S.aff.provider === p.id;
  $("#affInfo").innerHTML = has
    ? `✅ 링크: <span class="mono">${esc(S.aff.link)}</span><br><span class="dim">고지 문구가 설명 첫 줄과 영상 자막에 들어갑니다. 화면 문구는 아래 칸에서 바꿀 수 있습니다.</span>`
    : `${esc(p.target_label)} 을 넣고 「링크 만들기」를 누르세요.`;
  $("#affTextRow").classList.toggle("hidden", !has);
  if (has && !$("#affOnscreen").value) $("#affOnscreen").value = affTextDefault(S.aff.onscreen);
}
/* 광고 안내 문구: 이 PC 기본값(localStorage) → 없으면 서버가 준 기본 문구 */
const AFF_TEXT_KEY = "affOnscreen";
function affTextDefault(fallback) { try { return localStorage.getItem(AFF_TEXT_KEY) || fallback || "유료 광고 포함 · 수수료를 받습니다"; } catch (_) { return fallback || "유료 광고 포함 · 수수료를 받습니다"; } }
function affTextRemember(v) { try { if (v) localStorage.setItem(AFF_TEXT_KEY, v); else localStorage.removeItem(AFF_TEXT_KEY); } catch (_) {} }
$("#affOnscreen").onchange = e => { affTextRemember(e.target.value.trim()); };

$("#affProvider").onchange = () => { S.aff = null; affSync(); };

$("#btnAffLink").onclick = async () => {
  const p = affProv(); if (!p) return;
  const target = $("#affTarget").value.trim();
  if (!target) return toast(`${p.target_label} 을 넣어 주세요`, true);
  $("#btnAffLink").disabled = true; $("#affInfo").textContent = "링크를 만드는 중…";
  try { S.aff = await api("/api/affiliate/link", { method: "POST", body: { provider: p.id, target } }); affSync(); toast("제휴 링크를 만들었습니다."); }
  catch (e) { S.aff = null; affSync(); toast(e.message, true); }
  finally { $("#btnAffLink").disabled = false; }
};

$("#btnAffKeys").onclick = () => $("#affKeyBox").classList.toggle("hidden");

$("#btnAffKeySave").onclick = async () => {
  const body = { coupang_access_key: $("#affCpAccess").value, coupang_secret_key: $("#affCpSecret").value,
    toss_access_key: $("#affTsAccess").value, toss_secret_key: $("#affTsSecret").value,
    toss_publisher_id: $("#affTsPub").value };
  try {
    S.affMeta = await api("/api/affiliate/keys", { method: "POST", body });
    ["#affCpAccess", "#affCpSecret", "#affTsAccess", "#affTsSecret", "#affTsPub"].forEach(k => $(k).value = "");
    await loadAffiliate(); $("#affKeyBox").classList.add("hidden"); toast("제휴 키를 저장했습니다.");
  } catch (e) { toast(e.message, true); }
};

$("#btnProdClips").onclick = async () => {
  if (!S.prod) return;
  let r; try { r = await api(`/api/product?id=${encodeURIComponent(S.prod.id)}`); } catch (e) { return toast(e.message, true); }
  prodApply(r);
  if (!r.clips.length) return toast("clips 폴더에 영상이 없습니다. 플로우에서 받은 mp4 를 1.mp4 … 로 넣어 주세요.", true);
  S.shop.videos = r.clips.slice();
  renderShopVideos();
  toast(`영상 ${r.clips.length}개를 순서대로 넣었습니다.`);
};

/* ───────── 홈: 프로젝트 목록 ───────── */
const PROJ_PAGE = 25;                                                   // 홈에 한 번에 그리는 카드 수(더 보기 = 25개씩). 227편을 다 그리면 썸네일 231장을 매번 받았다(2026-09-12, 2026-09-13 25로)
async function loadProjects(keep) {
  try { S.projects = await api("/api/projects"); } catch (e) { return; }
  if (!keep) S.projShown = PROJ_PAGE;
  renderProjects();
  clearTimeout(S.homeT);
  const watching = !$("#view-home").classList.contains("hidden") || !$("#view-make").classList.contains("hidden");
  if (S.projects.some(p => p.running || (p.status !== "ready" && p.status !== "error")) && watching)
    S.homeT = setTimeout(() => loadProjects(true), 1500);
}
/* 카드 한 장씩 그린다 — 홈의 「내 프로젝트」와 작업 화면의 목록이 같은 카드를 쓴다(2026-09-14) */
function drawCards(g, shown) {
  g.innerHTML = "";
  for (const p of shown) {
    const c = document.createElement("div"); c.className = "card";
    const st = p.status === "ready" ? ["ready", "완료"] : p.status === "error" ? ["error", "오류"] : ["busy", p.progress?.message || "작업 중"];
    // 진행 중이면 썸네일 위에 % 링과 단계 문구를 덮는다(다운로드·분석·렌더 모두)
    let ov = "";
    const busy = (p.status !== "ready" && p.status !== "error") || p.running;
    if (busy) {
      let pct = null, msg = p.progress?.message || "작업 중";
      if (p.running && p.job?.kind === "render") { pct = p.job.pct; msg = "렌더 중 " + (p.job.current || ""); }
      else if (p.running && p.job?.kind === "ocr") { pct = p.job.pct; msg = "영상 속 자막 읽는 중"; }
      else if (p.progress?.pct != null) pct = p.progress.pct;
      else if (p.progress?.step === "analyze") msg = "AI 구간 선정 중";
      const ring = pct == null ? `<div class="ring spin"></div>` : `<div class="ring" style="--p:${pct}"><span>${pct}%</span></div>`;
      ov = `<div class="ov">${ring}<div class="ov-msg">${esc(msg)}</div></div>`;
    }
    c.innerHTML = `<img src="${p.thumb ? "/media/" + p.id + "/" + p.thumb : ""}" alt="" loading="lazy" decoding="async">${ov}
      <span class="badge">${fmt(p.duration)}</span><button class="del" title="삭제">✕</button>
      <div class="cbody"><div class="ctitle">${esc(p.title)}</div>
      <div class="cmeta"><span class="st ${st[0]}">● ${esc(st[1])}</span><span>쇼츠 ${p.n_shorts}개${p.n_rendered ? " · 렌더 " + p.n_rendered : ""}</span><span>${new Date((p.created || 0) * 1000).toLocaleDateString("ko-KR")}</span></div></div>`;
    c.onclick = e => { if (e.target.closest(".del")) return; if (p.status === "ready" || p.status === "rendering") { if (p.kind === "shop") openEditor(p.id); else openResults(p.id); } else openProgress(p.id); };
    $(".del", c).onclick = async e => { e.stopPropagation(); if (!confirm("이 프로젝트를 지울까요?\n" + p.title)) return; try { await api("/api/projects/" + p.id, { method: "DELETE" }); loadProjects(true); } catch (err) { toast(err.message, true); } };
    g.appendChild(c);
  }
}
/* 프로젝트가 어느 프로그램 것인지. 가로 롱폼 편집도 kind 는 "shop" 이다(같은 자유 편집
   폼을 쓴다) — 그래서 캔버스로 갈라야 한다. 9:16 이면 쇼핑 쇼츠, 16:9 면 가로 롱폼. */
const progOf = p => (p.kind !== "shop") ? "long" : (p.canvas === "16:9" ? "wide" : "shop");
const PROG_NAME = { long: "롱폼 → 쇼츠", shop: "쇼핑 쇼츠", wide: "가로 롱폼 편집" };
function renderProjects() {
  const q = (S.projQuery || "").trim().toLowerCase();
  const all = S.projects || [];
  const list = q ? all.filter(p => (p.title || "").toLowerCase().includes(q) || (p.id || "").includes(q)) : all;
  $("#projCount").textContent = "(" + (q ? list.length + " / " + all.length : all.length) + ")";
  const shown = list.slice(0, S.projShown || PROJ_PAGE);
  drawCards($("#grid"), shown);
  const more = $("#projMore"); const rest = list.length - shown.length;
  more.classList.toggle("hidden", rest <= 0);
  if (rest > 0) more.textContent = `더 보기 (${rest}개 남음)`;
  renderMakeProjects();
}
/* 작업 화면의 목록 — 지금 고른 프로그램으로 만든 것만 보여 준다 */
function renderMakeProjects() {
  const g = $("#mkGrid"); if (!g) return;
  const mode = S.homeMode || "shop";
  const q = (S.mkQuery || "").trim().toLowerCase();
  const mine = (S.projects || []).filter(p => progOf(p) === mode);
  const list = q ? mine.filter(p => (p.title || "").toLowerCase().includes(q) || (p.id || "").includes(q)) : mine;
  const t = $("#mkProjTitle"); if (t && t.firstChild) t.firstChild.nodeValue = (PROG_NAME[mode] || "이 작업") + " 프로젝트 ";
  $("#mkProjCount").textContent = "(" + (q ? list.length + " / " + mine.length : mine.length) + ")";
  const shown = list.slice(0, S.mkShown || PROJ_PAGE);
  drawCards(g, shown);
  $("#mkProjEmpty").classList.toggle("hidden", list.length > 0);
  const more = $("#mkProjMore"); const rest = list.length - shown.length;
  more.classList.toggle("hidden", rest <= 0);
  if (rest > 0) more.textContent = `더 보기 (${rest}개 남음)`;
}
$("#projMore").onclick = () => { S.projShown = (S.projShown || PROJ_PAGE) + PROJ_PAGE; renderProjects(); };
$("#projSearch").oninput = e => { S.projQuery = e.target.value; S.projShown = PROJ_PAGE; renderProjects(); };
$("#mkProjMore").onclick = () => { S.mkShown = (S.mkShown || PROJ_PAGE) + PROJ_PAGE; renderMakeProjects(); };
$("#mkProjSearch").oninput = e => { S.mkQuery = e.target.value; S.mkShown = PROJ_PAGE; renderMakeProjects(); };

/* ───────── 진행 화면 ───────── */
function stopPoll() { clearInterval(S.poll); S.poll = null; }
function openProgress(pid) {
  show("progress"); stopPoll();
  const tick = async () => {
    let p; try { p = await api("/api/projects/" + pid); } catch (e) { return; }
    S.p = p;
    $("#pgTitle").textContent = p.source.title || p.source.url || "";
    $("#pgTitle2").textContent = p.source.title || "";
    if (p.source.thumb) $("#pgThumb").src = "/media/" + pid + "/" + p.source.thumb;
    const step = p.status === "ready" ? "done" : (p.progress?.step || "fetch");
    const order = ["fetch", "analyze", "poster", "done"]; const idx = order.indexOf(step);
    const lis = $$(".steps li"); const shop = p.kind === "shop"; const sh = p.shop || {};
    const hasNar = shop && !!((sh.tts || "").trim() || (sh.script || "").trim());     // 쇼핑 쇼츠: AI 구간 고르기 없음. 낭독·대본이 있을 때만 받아쓰기 단계
    lis[0].innerHTML = shop ? "<b>1</b> 영상 담기" : "<b>1</b> 영상·자막 내려받기";
    lis[1].classList.toggle("hidden", shop && !hasNar);
    lis[1].innerHTML = shop ? "<b>2</b> 낭독 받아쓰기·문안" : "<b>2</b> AI 가 쇼츠 구간 고르기";
    lis[2].innerHTML = `<b>${shop && !hasNar ? 2 : 3}</b> 미리보기 만들기`;
    lis.forEach((li, i) => { li.classList.toggle("done", i < idx || step === "done"); li.classList.toggle("on", i === idx && step !== "done"); });
    const bar = $("#pgBar"); const pct = p.progress?.pct;
    if (step === "done") { bar.className = ""; bar.style.width = "100%"; }
    else if (pct == null) { bar.className = "indet"; bar.style.width = ""; }
    else { bar.className = ""; bar.style.width = pct + "%"; }
    $("#pgMsg").textContent = p.progress?.message || "";
    const err = $("#pgErr"); err.classList.toggle("hidden", p.status !== "error"); err.textContent = p.error || "";
    $("#btnRetry").classList.toggle("hidden", p.status !== "error");
    $("#btnOpenEditor").classList.toggle("hidden", p.status !== "ready");
    $("#btnOpenEditor").textContent = shop ? "편집기 열기 →" : "쇼츠 목록 보기 →";
    if (p.status === "ready") { stopPoll(); setTimeout(() => { if (!$("#view-progress").classList.contains("hidden")) { if (shop) openEditor(pid); else openResults(pid, { reveal: true }); } }, 900); }
    if (p.status === "error") stopPoll();
  };
  tick(); S.poll = setInterval(tick, 1500);
  $("#btnRetry").onclick = async () => { await api("/api/projects/" + pid + "/retry", { method: "POST", body: {} }); openProgress(pid); };
  $("#btnOpenEditor").onclick = () => { if (S.p && S.p.kind !== "shop") openResults(pid, { reveal: true }); else openEditor(pid); };
}

/* ───────── 편집기 ───────── */
const vid = $("#vid");
let vidReady = false;
async function openEditor(pid, sid) {
  const token = (S.openToken = (S.openToken || 0) + 1);
  clearTimeout(S.rsT);                        // 열기가 겹치면(시작 시 자동 열기 + 사용자 클릭) 마지막 것만 살린다.
  S.tkSpan = 0; S.tkZoom = 1; const zi = $("#tkZoom"); if (zi) zi.value = 1;   // 다른 프로젝트를 열면 트랙 눈금을 새로 맞춘다
  try { localStorage.setItem("lastProject", pid); } catch (_) {}
  S.viewRestored = false; S.viewToRestore = null;                                 // 열자마자 저장된 화면 상태를 먼저 읽어 둔다(초기 seek 가 덮어쓰기 전에)
  try { S.viewToRestore = JSON.parse(localStorage.getItem("view:" + pid) || "null"); } catch (_) {}
  stopPoll(); show("editor");
  const loaded = await api("/api/projects/" + pid);
  if (token !== S.openToken) return;                                            // 그 사이 다른 열기가 시작됨 → 이 사본은 버린다(오래된 사본이 S.p 를 덮어써 편집이 되돌아가던 원인)
  S.p = loaded;
  S.sid = (sid && S.p.shorts.some(s => s.id === sid)) ? sid : (S.p.shorts[0]?.id || null);
  $("#edBackList").classList.toggle("hidden", S.p.kind === "shop");
  $("#edTitle").textContent = S.p.source.title || "";
  vidReady = false; S.curSrc = "main"; S.switching = false;
  const src = "/media/" + pid + "/source.mp4";
  if (!vid.src.endsWith(src)) { vid.src = src; vid.load(); }
  vid.onloadedmetadata = () => { vidReady = true; layoutStage(); seekTo(cur()?.start || 0); };
  if (vid.readyState >= 1) { vidReady = true; }
  fitStage();
  if (!$("#hkVoice").options.length) await loadVoices();
  if (!$("#trType").options.length) await loadTransitions();
  if (!S.music) await loadMusic();
  if (token !== S.openToken) return;
  applyShopMode();
  renderList(); fillDesign(); cueSourceLabel(); selectShort(S.sid, true); fillHook(); fillBgm(); fillMask(); fillSfxVol();
  histReset();                                                                  // 여기서부터가 실행 취소의 출발점
  startEditorPoll();
  if (S.p.job && S.p.job.running && S.p.job.kind === "ocr") watchJob("ocr");
}
const cur = () => S.p?.shorts.find(s => s.id === S.sid);
const CANVAS = { "9:16": [1080, 1920], "16:9": [1920, 1080], "1:1": [1080, 1080] };
// 가로 롱폼(16:9)에서는 「쇼츠」 대신 「영상」이라고 부른다(2026-09-14 사용자 요청). 문구는 두 벌 두지 않고 여기서 갈아 끼운다
const isWide = () => !!(S.p && S.p.settings && S.p.settings.canvas === "16:9");
const TERM = () => isWide() ? "이 영상" : "이 쇼츠", TERMn = () => isWide() ? "이 영상은" : "이 쇼츠는", TERMo = () => isWide() ? "이 영상을" : "이 쇼츠를";
const canvasOf = () => (S.p && S.p.settings && CANVAS[S.p.settings.canvas]) ? S.p.settings.canvas : "9:16";
const CW = () => CANVAS[canvasOf()][0], CH = () => CANVAS[canvasOf()][1];
const L = () => { const k = (S.p.settings.ratio || "16:9") + "|" + (S.p.settings.template || "dark"); return S.layouts[k + "|" + canvasOf()] || S.layouts[k]; };

/* ── 조각(clip) 모델: 쇼츠 하나 = 조각 목록. 옛 데이터(start/end)는 조각 하나로 옮긴다 ── */
function clipsOf(s) {
  if (!s.clips || !s.clips.length) s.clips = [{ s: +s.start, e: +s.end }];
  return s.clips;
}
/* ── 출처 영상: 'main'(본편) 또는 삽입 영상 id. 미리보기는 <video> 하나를 갈아 끼운다 ── */
function srcInfo(id) { if (!id || id === "main") return Object.assign({ id: "main" }, S.p.source); return (S.p.extra_sources || []).find(x => x.id === id) || Object.assign({ id: "main" }, S.p.source); }
function srcMediaUrl(id) { if (!id || id === "main") return `/media/${S.p.id}/source.mp4`; const x = srcInfo(id); return `/media/${S.p.id}/${(x.path || "").split(/[\\/]/).pop()}`; }
function srcLetter(id) { if (!id || id === "main") return ""; const i = (S.p.extra_sources || []).findIndex(x => x.id === id); return "[" + ("BCDEFGHIJ"[i] || (i + 2)) + "] "; }
function durFor(id) { return +(srcInfo(id).duration || S.p.source.duration); }
function stripFor(id) { return srcInfo(id).filmstrip || S.p.filmstrip; }
function switchSource(id) {
  id = id || "main";
  if ((S.curSrc || "main") === id && vidReady) return Promise.resolve();
  if ((S.curSrc || "main") === id && S.switching && S.switchPromise) return S.switchPromise;   // 같은 영상으로 전환 중이면 그 약속을 같이 기다린다
  S.curSrc = id; vidReady = false; S.switching = true;
  S.switchPromise = new Promise(res => {
    vid.pause(); vid.src = srcMediaUrl(id);
    vid.onloadedmetadata = () => { vidReady = true; S.switching = false; layoutStage(); res(); };
    vid.load();
  });
  return S.switchPromise;
}
function syncBounds(s) { const c = clipsOf(s); s.start = c[0].s; s.end = c[c.length - 1].e; }
function ac() { const s = cur(); if (!s) return null; const c = clipsOf(s); S.ci = Math.min(Math.max(0, S.ci || 0), c.length - 1); return c[S.ci]; }
function trAt(s, i) {   // 조각 i 앞의 전환 {type, dur}: 조각의 tr_in 이 있으면 그것, 없으면 프로젝트 전체 설정(pipeline.transition_at 과 같은 계산)
  const cs = clipsOf(s); if (i <= 0 || i >= cs.length) return { type: "none", dur: 0 };
  if (isGapClip(cs[i]) || isGapClip(cs[i - 1])) return { type: "none", dur: 0 };   // 빈 구간 앞뒤엔 전환 없음
  const tr = (cs[i].tr_in && typeof cs[i].tr_in === "object") ? cs[i].tr_in : (S.p.settings.transition || {});
  const type = tr.type || "none"; if (type === "none") return { type: "none", dur: 0 };
  const a = clipOut(cs[i - 1]), b = clipOut(cs[i]);
  return { type, dur: Math.max(0, Math.min(+tr.dur || 0.5, a / 2 - 0.05, b / 2 - 0.05)) };
}
function xfadesOf(s) { const cs = clipsOf(s); const out = []; for (let i = 1; i < cs.length; i++) out.push(trAt(s, i).dur); return out; }
function xfadeOf(s) { const x = xfadesOf(s); return x.length ? Math.max(...x) : 0; }   // 옛 호출 호환(가장 긴 전환)
const isGapClip = c => !!c && (srcInfo(c.src) || {}).kind === "black";   // 영상 1 의 빈 구간(검정 소스) — 화면엔 점선으로만
/* 조각 속도·멈춤: 결과 길이 = (e-s)/speed + hold. speed 1 = 그대로, 0.5 = 두 배 느리게. hold = 마지막 장면을 멈춰 두는 초 */
const spdOf = c => { const v = +(c && c.speed); return (v >= 0.1 && v <= 8) ? v : 1; };
const holdOf = c => Math.max(0, +(c && c.hold) || 0);
const clipOut = c => (c.e - c.s) / spdOf(c) + holdOf(c);                 // 결과 영상에서 차지하는 길이
const playOut = c => (c.e - c.s) / spdOf(c);                             // 그중 실제로 움직이는 길이(멈춤 제외)
const clipBadge = c => (spdOf(c) !== 1 ? ` ×${spdOf(c) % 1 ? spdOf(c).toFixed(2).replace(/0+$/, "") : spdOf(c)}` : "") + (holdOf(c) > 0 ? ` ⏸${holdOf(c).toFixed(1)}s` : "");
function applyRate() { const s = cur(); if (!s) return; const c = clipsOf(s)[S.playIdx || 0]; const r = c ? spdOf(c) : 1; if (vid.playbackRate !== r) vid.playbackRate = r; }
function clipOffsets(s) { const xf = xfadesOf(s); const offs = []; let t = 0; clipsOf(s).forEach((c, i) => { if (i > 0) t -= xf[i - 1]; offs.push(t); t += clipOut(c); }); return { offs, total: t }; }
function totalLen(s) { return clipOffsets(s).total; }
function clipIndexAt(s, t, prefer) {   // 지금 보이는 출처 영상(S.curSrc)의 조각 중에서 t 를 품은 것. prefer 가 맞으면 그대로
  const cs = clipsOf(s); const src = S.curSrc || "main";
  const ok = c => (c.src || "main") === src && t >= c.s - 0.05 && t <= c.e + 0.05;
  if (prefer != null && cs[prefer] && ok(cs[prefer])) return prefer;
  return cs.findIndex(ok);
}
function outTime(s, t) {     // 원본 시각 → 결과 영상 시각(조각 순서 반영). 본편 뒤 꼬리(검정 구간)에선 가상 시계를 쓴다
  if (S.tailT != null) return S.tailT;
  const { offs } = clipOffsets(s); const cs = clipsOf(s);
  // 파일 교체 중엔 vid.currentTime 이 옛 파일 시각(또는 0)이라 조각 대응이 엉킨다 → 새 조각의 시작 시각으로 본다(2026-09-13: 낭독이 엉뚱한 시각으로 맞춰져 5초 침묵)
  if (S.switching && S.playIdx != null && cs.length) return offs[Math.min(S.playIdx, cs.length - 1)];
  const i = clipIndexAt(s, t, S.playIdx);   // 선택(S.ci)이 아니라 빨간 선이 든 조각(S.playIdx) 기준
  if (i < 0) return 0; const c = cs[i]; return offs[i] + Math.min(Math.max(0, (t - c.s) / spdOf(c)), clipOut(c));
}
const clipLabel = (c, i) => `${"①②③④⑤⑥⑦⑧⑨"[i] || (i + 1)} ${srcLetter(c.src)}${fmt(c.s)}–${fmt(c.e)} · ${clipOut(c).toFixed(0)}s${clipBadge(c)}`;

function renderList() {
  const box = $("#shortList"); box.innerHTML = "";
  const job = S.p.job;
  S.p.shorts.forEach((s, i) => {
    const d = document.createElement("div"); d.className = "sh" + (s.id === S.sid ? " on" : "");
    const busy = job && job.running && (job.kind === "render" || job.kind === "export") && job.current === s.id;
    const st = busy ? `<span class="busy">렌더 ${job.pct || 0}%</span>` : s.output ? `<span class="ok">렌더됨</span>` : "미렌더";
    const cs = clipsOf(s);
    d.innerHTML = `<img src="${s.poster ? "/media/" + S.p.id + "/work/" + s.poster + "?v=" + (s.render?.at || 0) : ""}" alt="">
      <div><div class="sh-t">${esc(s.line1 || s.yt_title || s.id)}</div>
      <div class="sh-m">${fmt(cs[0].s)}부터 · ${totalLen(s).toFixed(0)}s${cs.length > 1 ? " · " + cs.length + "조각" : ""} · ${st}</div>
      ${s.output ? `<a class="sh-dl" href="/media/${S.p.id}/output/${encodeURIComponent(s.output)}?download=1">⬇ mp4</a> <a class="sh-dl" href="/media/${S.p.id}/output/${encodeURIComponent(s.output)}" target="_blank">▶ 결과 보기</a>` : ""}</div>`;
    d.onclick = e => { if (e.target.closest("a")) return; selectShort(s.id); };
    box.appendChild(d);
  });
}
function refreshListMeta() {
  const s = cur(); const i = S.p.shorts.findIndex(x => x.id === S.sid); const m = $$(".sh .sh-m")[i]; if (!m) return;
  const cs = clipsOf(s); m.firstChild.textContent = `${fmt(cs[0].s)}부터 · ${totalLen(s).toFixed(0)}s${cs.length > 1 ? " · " + cs.length + "조각" : ""} · `;
}

function selectShort(id, first = false) {
  S.sid = id; const s = cur(); if (!s) return;
  S.ci = 0; S.playIdx = 0;
  $$(".sh").forEach((el, i) => el.classList.toggle("on", S.p.shorts[i].id === id));
  $("#fL1").value = s.line1 || ""; $("#fL2").value = s.line2 || "";
  $("#fReason").textContent = s.reason ? "선정 이유: " + s.reason : "";
  if ($("#hkVoice").options.length) fillHook();
  if ($("#trType").options.length) fillBgm();
  $("#fYt").value = s.yt_title || ""; $("#fDesc").value = s.description || ""; $("#fTags").value = (s.tags || []).join(", ");
  renderClipBar(); fillTrimFields(); renderCues(); layoutStage(); updateLen();
  focusClipWindow(); drawTimeline();
  vid.pause(); const c0 = clipsOf(s)[0]; seekTo(c0.s, c0.src);
  renderInsertSources();
}

/* 조각 막대(구간 절): 조각 선택·추가·나누기·순서·삭제 */
function renderClipBar() {
  const s = cur(); if (!s) return; const cs = clipsOf(s); const bar = $("#clipBar"); bar.innerHTML = "";
  cs.forEach((c, i) => {
    const b = document.createElement("button"); b.className = "chip" + (i === S.ci ? " on" : ""); b.textContent = clipLabel(c, i);
    b.title = "이 조각을 편집합니다"; b.className += (c.src && c.src !== "main") ? " ext" : ""; b.onclick = () => { S.ci = i; S.playIdx = i; renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline(); vid.pause(); seekTo(c.s, c.src); };
    bar.appendChild(b);
  });
  $("#btnClipDel").disabled = cs.length <= 1; $("#btnClipUp").disabled = S.ci === 0; $("#btnClipDown").disabled = S.ci >= cs.length - 1;
  $("#fLenClips").textContent = cs.length > 1 ? `${cs.length}조각` : "";
  drawTrack();
}
function fillTrimFields() { const c = ac(); if (!c) return; $("#fStart").value = fmt(c.s, 1); $("#fEnd").value = fmt(c.e, 1); }
function focusClipWindow() { const c = ac(); if (!c) return; S.tlWin = [Math.max(0, c.s - 30), Math.min(durFor(c.src), c.e + 30)]; }
function afterClipsChange(seekT) {
  const s = cur(); syncBounds(s); renderClipBar(); fillTrimFields(); updateLen(); renderCues(); refreshListMeta(); focusClipWindow(); drawTimeline(); markDirty();
  if (typeof updateNarInfo === "function") updateNarInfo();
  if (seekT != null) { vid.pause(); seekTo(seekT, ac().src); }
}
$("#btnClipAdd").onclick = () => {          // 재생 위치에서 5초짜리 조각을 지금 조각 뒤에
  const s = cur(); if (!s) return; const cs = clipsOf(s); const t = vid.currentTime; const dur = durFor(S.curSrc);
  const a = Math.min(Math.max(0, t), dur - 1), b = Math.min(dur, a + 5);
  cs.splice(S.ci + 1, 0, { s: +a.toFixed(2), e: +b.toFixed(2), src: S.curSrc || "main" }); S.ci += 1; S.playIdx = S.ci;
  afterClipsChange(a); toast("조각을 추가했습니다. 손잡이로 길이를 맞추세요");
};
$("#btnClipHook").onclick = () => {         // 재생 위치의 4초를 훅으로 맨 앞에
  const s = cur(); if (!s) return; const cs = clipsOf(s); const t = vid.currentTime; const dur = durFor(S.curSrc);
  const a = Math.min(Math.max(0, t), dur - 1), b = Math.min(dur, a + 4);
  cs.unshift({ s: +a.toFixed(2), e: +b.toFixed(2), src: S.curSrc || "main" }); S.ci = 0; S.playIdx = 0;
  afterClipsChange(a); toast("훅 조각을 맨 앞에 넣었습니다. 본문에서 같은 부분을 빼려면 그 조각을 나눈 뒤 삭제하세요");
};
$("#btnClipSplit").onclick = () => {        // 지금 조각을 재생 위치에서 둘로
  const s = cur(); if (!s) return; const cs = clipsOf(s); const c = cs[S.ci]; const t = vid.currentTime;
  if (t <= c.s + 0.5 || t >= c.e - 0.5) return toast("조각 안쪽(양끝에서 0.5초 이상)으로 재생 위치를 옮긴 뒤 나누세요", true);
  cs.splice(S.ci, 1, { s: c.s, e: +t.toFixed(2), src: c.src, mute: c.mute, speed: c.speed }, { s: +t.toFixed(2), e: c.e, src: c.src, mute: c.mute, speed: c.speed, hold: c.hold }); S.ci += 1; S.playIdx = S.ci;
  afterClipsChange(t); toast("둘로 나눴습니다. 필요 없는 쪽을 골라 삭제하세요");
};
/* 미디어 목록(왼쪽 위): 본편 + 담아 둔 영상·이미지. 각 항목을 영상 1 끝에 붙이거나 빨간 선에 위층으로 얹는다 */
function mediaItems() { return [Object.assign({ id: "main", kind: "video" }, S.p.source), ...(S.p.extra_sources || [])]; }
async function ensureBlackSource() {                 // 빈 화면(검정) 소스: 프로젝트에 없으면 서버가 만들어 등록
  const have = (S.p.extra_sources || []).find(x => x.kind === "black"); if (have) return have.id;
  try { const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { black: true } }); S.p.extra_sources = r.sources; renderInsertSources(); renderMedia(); return r.source.id; }
  catch (e) { toast(e.message, true); return null; }
}
function renderMedia() {
  const box = $("#mediaList"); if (!box || !S.p) return; box.innerHTML = "";
  mediaItems().forEach(x => {
    if (x.kind === "black") return;
    const d = document.createElement("div"); d.className = "md";
    const thumb = x.thumb ? `/media/${S.p.id}/${x.thumb}` : "";
    d.innerHTML = `<img src="${thumb}" alt="" loading="lazy"><div class="md-b"><div class="md-t" title="${esc(x.original_path || x.path || "")}">${esc(srcLetter(x.id))}${esc(x.title || x.id)}</div>
      <div class="md-m">${x.kind === "image" ? "이미지" : "영상"} · ${fmt(x.duration)}${x.has_audio === false && x.kind !== "image" ? " · 무음" : ""}</div>
      <div class="md-a"><button data-act="main" title="영상 1 트랙 끝에 전체 길이로 붙입니다">영상 1 끝에</button><button data-act="ov" title="빨간 선 위치에 위층(영상 2)으로 얹습니다">위층에 얹기</button>${x.id !== "main" ? `<button data-act="rm" title="프로젝트에서 뺍니다(트랙에서 쓰고 있으면 못 뺌)">✕</button>` : ""}</div></div>`;
    d.querySelectorAll("button").forEach(b => b.onclick = () => mediaAct(b.dataset.act, x));
    box.appendChild(d);
  });
}
async function mediaAct(act, x) {
  const s = cur(); if (!s) return;
  if (act === "main") { const cs = clipsOf(s); cs.push({ s: 0, e: r2(x.duration), src: x.id }); S.ci = cs.length - 1; S.selKind = "clip"; keepPlayhead(() => afterClipsChange(null)); return toast(`${x.title || x.id} 를 영상 1 끝에 붙였습니다`); }
  if (act === "ov") { const ovs = ovsOf(s); const T = Math.max(0, outTime(s, vid.currentTime)); ovs.push({ id: newId(), src: x.id, s: 0, e: r2(x.duration), at: r2(T), layer: 1 }); S.selKind = "ov"; S.oi = ovs.length - 1; markDirty(); updateLen(); ovSync(); return toast(`${x.title || x.id} 를 빨간 선 위치에 위층으로 얹었습니다`); }
  if (act === "rm") {
    const used = clipsOf(s).some(c => c.src === x.id) || ovsOf(s).some(o => o.src === x.id);
    if (used) return toast("트랙에서 쓰고 있는 파일입니다. 먼저 트랙에서 지우세요", true);
    try { const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { remove: x.id } }); S.p.extra_sources = r.sources; renderMedia(); renderInsertSources(); toast("뺐습니다"); }
    catch (e) { toast(e.message, true); }
  }
}
$("#btnMediaAdd").onclick = async () => {
  toast("파일 선택 창이 열렸습니다(영상·이미지, 여러 개 가능). 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { multi: true, kind: "media" } }); if (r.cancelled) return; S.p.extra_sources = r.sources; renderMedia(); renderInsertSources(); toast(`${r.added.length}개를 담았습니다. 항목의 단추로 트랙에 넣으세요`); }
  catch (e) { toast(e.message, true); }
};
/* 효과음 라이브러리(왼쪽): 내장 + 내 등록. ▶ 미리듣기, ＋ 빨간 선 위치의 오디오 트랙에 넣기 */
S.sfx = null;
async function loadSfx() { try { const r = await api("/api/sfx"); S.sfx = r.items || []; } catch (_) { S.sfx = []; } renderSfx(); }
const SFX_CAT_ORDER = ["기본", "클릭·UI", "알림·확인", "전환·효과", "충격·타격", "발소리", "디지털·게임", "내 효과음"];
function renderSfx() {
  const box = $("#sfxList"); if (!box) return; box.innerHTML = ""; const all = S.sfx || []; $("#sfxCount").textContent = all.length ? `${all.length}개` : "";
  const catSel = $("#sfxCat"); const cats = [...new Set(all.map(it => it.kind === "user" ? "내 효과음" : (it.cat || "기본")))].sort((x, y) => (SFX_CAT_ORDER.indexOf(x) + 1 || 99) - (SFX_CAT_ORDER.indexOf(y) + 1 || 99));
  if (catSel && catSel.options.length !== cats.length + 1) { const keep = catSel.value; catSel.innerHTML = `<option value="">전체 (${all.length})</option>` + cats.map(c => `<option value="${esc(c)}">${esc(c)} (${all.filter(it => (it.kind === "user" ? "내 효과음" : (it.cat || "기본")) === c).length})</option>`).join(""); catSel.value = keep; }
  const q = ($("#sfxFind")?.value || "").trim().toLowerCase(); const wantCat = catSel ? catSel.value : "";
  const items = all.filter(it => { const c = it.kind === "user" ? "내 효과음" : (it.cat || "기본"); return (!wantCat || c === wantCat) && (!q || (it.title || "").toLowerCase().includes(q) || c.includes(q)); });
  let lastCat = null;
  items.forEach(it => {
    const c = it.kind === "user" ? "내 효과음" : (it.cat || "기본");
    if (!wantCat && c !== lastCat) { lastCat = c; const hdr = document.createElement("div"); hdr.className = "sfx-cat"; hdr.textContent = c; box.appendChild(hdr); }
    const d = document.createElement("div"); d.className = "sfx" + (it.kind === "user" ? " user" : "");
    d.innerHTML = `<button data-act="play" title="들어 보기">▶</button><span class="t" title="${esc(it.license || "")}">${esc(it.title)}</span><span class="d">${(+it.duration || 0).toFixed(1)}s</span><button data-act="ins" title="빨간 선 위치에 오디오 트랙으로 넣기">＋</button>${it.kind === "user" ? `<button data-act="rm" title="라이브러리에서 뺍니다">✕</button>` : ""}`;
    d.querySelector('[data-act="play"]').onclick = () => { if (S.sfxAudio) S.sfxAudio.pause(); S.sfxAudio = new Audio(it.url); S.sfxAudio.volume = Math.min(1, sfxVol() * mVol() * pVol()); S.sfxAudio.play().catch(() => {}); };
    d.querySelector('[data-act="ins"]').onclick = () => insertSfx(it);
    const rm = d.querySelector('[data-act="rm"]'); if (rm) rm.onclick = async () => { if (!confirm(`「${it.title}」을 라이브러리에서 뺄까요? (이미 넣은 트랙은 그대로)`)) return; try { const r = await api("/api/sfx", { method: "POST", body: { remove: it.id } }); S.sfx = r.items; renderSfx(); } catch (e) { toast(e.message, true); } };
    box.appendChild(d);
  });
}
/* 효과음 기본 음량(프로젝트 설정 sfx_volume, 기본 0.6): 새로 넣는 효과음의 시작 음량. 넣은 항목은 a.sfx 로 표시해 「전체에 적용」이 찾는다 */
function sfxVol() { const v = S.p && S.p.settings ? +S.p.settings.sfx_volume : NaN; return isFinite(v) && v > 0 ? v : 0.6; }
function fillSfxVol() { const v = sfxVol(); const el = $("#sfxVol"); if (el) { el.value = v; $("#sfxVolV").textContent = Math.round(v * 100) + "%"; } }
$("#sfxVol").oninput = e => { if (!S.p) return; S.p.settings.sfx_volume = +e.target.value; $("#sfxVolV").textContent = Math.round(+e.target.value * 100) + "%"; markDirty(); };
$("#btnSfxApplyAll").onclick = () => {
  const s = cur(); if (!s) return; const v = sfxVol(); let n = 0;
  (s.audios || []).forEach(a => { if (a.sfx) { a.volume = v; n++; } });
  if (!n) return toast(TERM() + " 트랙에 넣은 효과음이 없습니다");
  markDirty(); if (typeof audSync === "function") audSync(isPlaying()); if (typeof fillAudPanel === "function") fillAudPanel();
  toast(`효과음 ${n}개를 ${Math.round(v * 100)}% 로 맞췄습니다`);
};
async function insertSfx(it) {
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, vid.currentTime));
  try {
    const r = await api("/api/projects/" + S.p.id + "/audios", { method: "POST", body: { sid: s.id, paths: [it.path], at: T, lane: laneForNew(s), volume: sfxVol() } });
    s.audios = r.short.audios || []; const last = s.audios[s.audios.length - 1]; if (last) { last.sfx = it.id; last.volume = sfxVol(); last.title = it.title; }   // 트랙 라벨은 한글 이름으로
    S.selKind = "aud"; S.ai = s.audios.length - 1; markDirty(); updateLen(); fitStage(); audSync(isPlaying());
    toast(`효과음 「${it.title}」을 ${fmt(T, 1)} 에 ${Math.round(sfxVol() * 100)}% 로 넣었습니다`);
  } catch (e) { toast(e.message, true); }
}
$("#sfxFind").addEventListener("input", renderSfx); $("#sfxCat").addEventListener("change", renderSfx);
$("#btnSfxAdd").onclick = async () => {
  toast("효과음 파일 선택 창이 열렸습니다(여러 개 가능). 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/sfx", { method: "POST", body: { multi: true } }); if (r.cancelled) return; S.sfx = r.items; renderSfx(); toast(`효과음 ${r.added.length}개를 등록했습니다`); }
  catch (e) { toast(e.message, true); }
};
/* 글꼴 등록·제거(텍스트 절) */
$("#txFontAdd").onclick = async () => {
  toast("글꼴 파일(ttf/otf) 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  try {
    const r = await api("/api/fonts", { method: "POST", body: { multi: true } }); if (r.cancelled) return;
    await loadTextFonts(); const t = curText(); if (t && r.added.length) { t.font = r.added[0].id; txtChanged(false); fillTxtPanel(); }
    toast(`글꼴 ${r.added.length}개를 등록했습니다`);
  } catch (e) { toast(e.message, true); }
};
$("#txFontDel").onclick = async () => {
  const t = curText(); const f = S.fonts.find(x => x.id === (t && t.font)); if (!t || !f || f.kind !== "user") return;
  if (!confirm(`「${f.name}」 글꼴을 뺄까요? 이 글꼴을 쓰던 텍스트는 기본 글꼴로 나옵니다.`)) return;
  try { await api("/api/fonts", { method: "POST", body: { remove: f.id } }); await loadTextFonts(); t.font = "noto"; txtChanged(false); fillTxtPanel(); } catch (e) { toast(e.message, true); }
};
/* 삽입 영상: 프로젝트에 등록된 다른 영상 목록. 「삽입」은 그 영상의 앞 5초를 조각으로 넣는다 */
function renderInsertSources() {
  const sel = $("#insSrc"); const keep = sel.value;
  sel.innerHTML = (S.p.extra_sources || []).map(x => `<option value="${x.id}">${esc(srcLetter(x.id) + x.title)} · ${fmt(x.duration)}</option>`).join("") + `<option value="__new">＋ 다른 영상 파일…</option>`;
  if ([...sel.options].some(o => o.value === keep)) sel.value = keep;
  $("#btnSrcRemove").classList.toggle("hidden", sel.value === "__new");
}
$("#insSrc").onchange = () => $("#btnSrcRemove").classList.toggle("hidden", $("#insSrc").value === "__new");
$("#btnClipInsert").onclick = async () => {
  const s = cur(); if (!s) return; let id = $("#insSrc").value;
  if (id === "__new") {
    toast("영상 파일 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
    try { const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: {} }); if (r.cancelled) return; S.p.extra_sources = r.sources; id = r.source.id; renderInsertSources(); $("#insSrc").value = id; $("#btnSrcRemove").classList.remove("hidden"); }
    catch (e) { return toast(e.message, true); }
  }
  const x = srcInfo(id); const cs = clipsOf(s);
  cs.splice(S.ci + 1, 0, { s: 0, e: +Math.min(5, x.duration).toFixed(2), src: id }); S.ci += 1; S.playIdx = S.ci;
  afterClipsChange(0); toast(srcLetter(id) + x.title + " 의 앞 5초를 조각으로 넣었습니다. 손잡이로 구간을 맞추세요");
};
$("#btnSrcRemove").onclick = async () => {
  const id = $("#insSrc").value; if (id === "__new") return;
  if (!confirm("이 삽입 영상을 프로젝트에서 뺄까요? (쓰는 조각이 있으면 뺄 수 없습니다)")) return;
  try { const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { remove: id } }); S.p.extra_sources = r.sources; renderInsertSources(); toast("뺐습니다"); }
  catch (e) { toast(e.message, true); }
};
$("#btnClipUp").onclick = () => { const cs = clipsOf(cur()); if (S.ci <= 0) return; [cs[S.ci - 1], cs[S.ci]] = [cs[S.ci], cs[S.ci - 1]]; S.ci -= 1; S.playIdx = S.ci; afterClipsChange(null); };
$("#btnClipDown").onclick = () => { const cs = clipsOf(cur()); if (S.ci >= cs.length - 1) return; [cs[S.ci + 1], cs[S.ci]] = [cs[S.ci], cs[S.ci + 1]]; S.ci += 1; S.playIdx = S.ci; afterClipsChange(null); };
$("#btnClipDel").onclick = () => { const cs = clipsOf(cur()); if (cs.length <= 1) return; cs.splice(S.ci, 1); S.ci = Math.min(S.ci, cs.length - 1); S.playIdx = S.ci; afterClipsChange(ac().s); toast("조각을 지웠습니다"); };

/* 디자인(프로젝트 단위) */
$("#fShowTitle").onchange = e => { S.p.settings.show_title = e.target.checked; layoutStage(); markDirty(); };
$("#fTitleSecs").onchange = e => { S.p.settings.title_secs = Math.max(0, +e.target.value || 0); layoutStage(); markDirty(); };
/* 광고 안내 문구(aff_notice 텍스트)의 길이: 앞 n 초만, 0 이면 결과 끝까지. 타임라인의 그 텍스트 dur 를 직접 고친다 */
function applyAffSecs(v) {
  (S.p.shorts || []).forEach(s => (s.texts || []).forEach(t => {
    if (t.id !== "aff_notice") return;
    t.at = 0; t.dur = v > 0 ? v : +(outLen(s, { noBgm: true }) + 0.5).toFixed(2);
  }));
}
/* 광고 안내 문구 켜기/끄기: 끄면 aff_notice 텍스트를 빼고 settings.aff_backup 에 보관, 켜면 보관본(없으면 기본 모양)으로 다시 넣는다 */
$("#fAffOn").onchange = e => {
  const st = S.p.settings;
  if (!e.target.checked) {
    const t0 = (S.p.shorts || []).flatMap(x => x.texts || []).find(t => t.id === "aff_notice");
    if (t0) st.aff_backup = JSON.parse(JSON.stringify(t0));
    (S.p.shorts || []).forEach(x => { x.texts = (x.texts || []).filter(t => t.id !== "aff_notice"); });
    toast("화면의 광고 안내 문구를 뺐습니다. 설명 첫 줄의 고지문은 그대로입니다");
  } else {
    const full = Math.round((outLen(cur()) + 0.5) * 100) / 100; const secs = +st.aff_secs || 0;
    const base = st.aff_backup || { id: "aff_notice", text: (S.p.affiliate && S.p.affiliate.onscreen) || affTextDefault(""), at: 0, x: CW() / 2, y: Math.round(CH() * 0.055), size: Math.max(28, Math.round(CW() * 0.032)),
      color: "#FFFFFF", stroke: "#000000", bold: true, bg: true, align: "center", font: "noto", shadow: "none", w: 0, lane: 9, anim_in: "none", anim_out: "none" };
    const item = { ...base, dur: secs > 0 ? Math.min(full, secs) : full };
    (S.p.shorts || []).forEach(x => { x.texts = (x.texts || []).filter(t => t.id !== "aff_notice"); x.texts.push({ ...item }); });
    toast("광고 안내 문구를 다시 넣었습니다");
  }
  if (typeof renderTexts === "function") renderTexts(); if (typeof drawTrack === "function") drawTrack(); fillDesign(); layoutStage(); markDirty();
};
$("#fAffText").onchange = e => {
  const v = e.target.value.trim() || (S.p.affiliate && S.p.affiliate.onscreen) || "유료 광고 포함 · 수수료를 받습니다";
  (S.p.shorts || []).forEach(x => (x.texts || []).forEach(t => { if (t.id === "aff_notice") t.text = v; }));
  if (S.p.affiliate) S.p.affiliate.onscreen = v;
  affTextRemember(e.target.value.trim()); e.target.value = v;
  if (typeof renderTexts === "function") renderTexts(); if (typeof drawTrack === "function") drawTrack(); layoutStage(); markDirty(); toast("광고 안내 문구를 바꿨습니다");
};
$("#fAffSecs").onchange = e => { const v = Math.max(0, +e.target.value || 0); S.p.settings.aff_secs = v; applyAffSecs(v); layoutStage(); if (typeof drawTimeline === "function") drawTimeline(); markDirty(); };
$("#fShowChan").onchange = e => { S.p.settings.show_chan = e.target.checked; layoutStage(); markDirty(); };
$("#btnChanReset").onclick = () => { S.p.settings.chan_dx = 0; S.p.settings.chan_dy = 0; layoutStage(); markDirty(); };
(() => {                                             // 채널명·로고를 미리보기에서 끌어 옮기기(스테이지 px 오프셋으로 저장 → 렌더도 같은 자리)
  const chan = $("#stChan");
  chan.addEventListener("pointerdown", ev => {
    if (!ev.target.closest(".av, .nm")) return; ev.stopPropagation(); ev.preventDefault();
    const st = S.p.settings; const k = CW() / $(".stage-wrap").clientWidth; const x0 = ev.clientX, y0 = ev.clientY, dx0 = +st.chan_dx || 0, dy0 = +st.chan_dy || 0; chan.classList.add("dragging");
    const l = L(); const lim = () => ({ x: CW() / 2 - 60, yMin: -(l ? l.chan_y : 0) + 20, yMax: CH() - (l ? l.chan_y : 0) - 80 });
    const mv = e2 => {
      const m = lim(); let dx = clamp(dx0 + (e2.clientX - x0) * k, -m.x, m.x), dy = clamp(dy0 + (e2.clientY - y0) * k, m.yMin, m.yMax);
      const baseY = (l ? l.chan_y : 0) + chan.offsetHeight / 2;             // 블록 중심 세로 위치
      const sn = snapCenter(CW() / 2 + dx, baseY + dy); dx = sn.x - CW() / 2; dy = sn.y - baseY; showGuides(sn.sx, sn.sy, sn.yc);
      st.chan_dx = Math.round(dx); st.chan_dy = Math.round(dy); chan.style.transform = `translate(${st.chan_dx}px, ${st.chan_dy}px)`;
    };
    const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); chan.classList.remove("dragging"); hideGuides(); markDirty(); };
    window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
  });
})();
$("#fCanvas").onchange = e => {                   // 출력 형식 바꾸기: 캔버스 밖으로 나간 텍스트는 안으로 당긴다
  const s = cur(); if (!s) return; S.p.settings.canvas = e.target.value;
  S.p.shorts.forEach(sh => (sh.texts || []).forEach(t => { t.x = clamp(+t.x || CW() / 2, 40, CW() - 40); t.y = clamp(+t.y || CH() / 2, 40, CH() - 40); }));
  fitStage(); layoutStage(); renderTexts(); drawTrack(); markDirty(); toast("출력 형식: " + e.target.options[e.target.selectedIndex].text);
};
function fillDesign() {
  if ($("#fCanvas")) $("#fCanvas").value = canvasOf();
  // 쇼핑 쇼츠·롱폼→쇼츠는 세로 1080×1920 고정 — 선택 줄을 숨긴다. 가로 롱폼(16:9)·정사각 프로젝트만 보인다(2026-09-13 사용자 요청)
  if ($("#canvasRow")) $("#canvasRow").classList.toggle("hidden", canvasOf() === "9:16");
  const st = S.p.settings;
  $$("button", $("#edTpl")).forEach(b => b.classList.toggle("on", b.dataset.t === st.template));
  if (!$$("button", $("#edRatio")).some(b => b.dataset.r === st.ratio)) { st.ratio = "4:5"; markDirty(); }  // 빠진 비율(5:6)은 가장 가까운 4:5 로
  $$("button", $("#edRatio")).forEach(b => b.classList.toggle("on", b.dataset.r === st.ratio));
  $$(".sw", $("#edSw")).forEach(b => b.classList.toggle("on", b.dataset.c.toLowerCase() === (st.accent || "").toLowerCase()));
  $("#edAccent").value = st.accent || "#FF3B3B";
  $("#fChan").value = st.channel_name || ""; $("#fLogo").value = st.channel_logo || "";
  $("#fShowSubs").checked = st.show_subs !== false;
  $("#fShowLogo").checked = st.show_logo !== false;
  $("#fZoom").value = st.zoom || 1; $("#fZoomV").textContent = (+st.zoom || 1).toFixed(2) + "×"; $("#zoomBtnV").textContent = (+st.zoom || 1).toFixed(2) + "×";
  $("#stZoomTag").textContent = (+st.zoom || 1).toFixed(2) + "×"; $("#stZoomTag").classList.toggle("hidden", (+st.zoom || 1) <= 1);
  const lp = $("#fLogoPrev"); lp.classList.toggle("hidden", !st.channel_logo); if (st.channel_logo) lp.src = logoUrl(st.channel_logo);
  if (st.template === "comment") { st.template = "dark"; markDirty(); }   // 댓글 템플릿은 뺐다 — 옛 프로젝트는 제목 템플릿으로
  $$(".sw", $("#bgSw")).forEach(b => b.classList.toggle("on", b.dataset.c.toLowerCase() === (st.bg_color || "#000000").toLowerCase()));
  $("#bgPick").value = st.bg_color || "#000000";
  if ($("#bgImgName")) { const bi = st.bg_image || ""; $("#bgImgName").textContent = bi ? bi.split(/[\\/]/).pop() : "없음"; $("#bgImgName").title = bi; }
  $$(".sw", $("#titleSw")).forEach(b => b.classList.toggle("on", b.dataset.c.toLowerCase() === (st.title_color || "#FFFFFF").toLowerCase()));
  $("#titlePick").value = st.title_color || "#FFFFFF";
  $("#reCount").value = String(st.count || 4);
}
$("#edTpl").onclick = e => { const b = e.target.closest("button"); if (!b) return; S.p.settings.template = b.dataset.t; fillDesign(); layoutStage(); markDirty(); };
$("#edRatio").onclick = e => { const b = e.target.closest("button"); if (!b) return; S.p.settings.ratio = b.dataset.r; fillDesign(); layoutStage(); markDirty(); };
$("#bgSw").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; S.p.settings.bg_color = b.dataset.c; fillDesign(); layoutStage(); markDirty(); };
$("#bgPick").oninput = e => { S.p.settings.bg_color = e.target.value; fillDesign(); layoutStage(); markDirty(); };
/* 배경 이미지(settings.bg_image): 영상 띠 뒤 캔버스 전체에 cover. 9:16 꽉 찬 화면에서는 보이지 않는다(렌더도 같음) */
$("#btnBgPick").onclick = async () => { const p = await pickFile("image"); if (!p) return; S.p.settings.bg_image = p; fillDesign(); layoutStage(); markDirty(); toast("배경 이미지를 넣었습니다. 영상이 화면을 꽉 채우는 비율(9:16)에서는 보이지 않습니다"); };
$("#btnBgClear").onclick = () => { S.p.settings.bg_image = ""; fillDesign(); layoutStage(); markDirty(); };
$("#titleSw").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; S.p.settings.title_color = b.dataset.c; fillDesign(); layoutStage(); markDirty(); };
$("#titlePick").oninput = e => { S.p.settings.title_color = e.target.value; fillDesign(); layoutStage(); markDirty(); };
$("#edSw").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; S.p.settings.accent = b.dataset.c; fillDesign(); layoutStage(); markDirty(); };
$("#edAccent").oninput = e => { S.p.settings.accent = e.target.value; fillDesign(); layoutStage(); markDirty(); };
$("#fChan").oninput = e => { S.p.settings.channel_name = e.target.value; layoutStage(); markDirty(); };
$("#fShowSubs").onchange = e => { S.p.settings.show_subs = e.target.checked; layoutStage(); markDirty(); };
$("#fLogo").onchange = e => { S.p.settings.channel_logo = e.target.value.trim(); fillDesign(); layoutStage(); markDirty(); };
$("#fShowLogo").onchange = e => { S.p.settings.show_logo = e.target.checked; layoutStage(); markDirty(); };
$("#btnFLogoPick").onclick = async () => { const p = await pickFile("image"); if (!p) return; S.p.settings.channel_logo = p; fillDesign(); layoutStage(); markDirty(); };
$("#btnFLogoClear").onclick = () => { S.p.settings.channel_logo = ""; fillDesign(); layoutStage(); markDirty(); };

/* 필드 → 상태 */
function bind(id, fn) { $(id).oninput = e => { const s = cur(); if (!s) return; fn(s, e.target.value); layoutStage(); markDirty(); }; }
bind("#fL1", (s, v) => { s.line1 = v; renderListTitle(); });
bind("#fL2", (s, v) => s.line2 = v);
bind("#fYt", (s, v) => s.yt_title = v);
bind("#fDesc", (s, v) => s.description = v);
bind("#fTags", (s, v) => s.tags = v.split(",").map(x => x.trim()).filter(Boolean));
function renderListTitle() { const i = S.p.shorts.findIndex(s => s.id === S.sid); const el = $$(".sh .sh-t")[i]; if (el) el.textContent = cur().line1 || cur().yt_title || S.sid; }

$("#fStart").onchange = e => setTrim(parseTc(e.target.value), null);
$("#fEnd").onchange = e => setTrim(null, parseTc(e.target.value));
$$(".nudge button").forEach(b => b.onclick = () => { const [k, d] = b.dataset.n.split(":"); const c = ac(); if (!c) return; if (k === "s") setTrim(c.s + +d, null); else setTrim(null, c.e + +d); });
$$("[data-set]").forEach(b => b.onclick = () => { if (b.dataset.set === "s") setTrim(vid.currentTime, null); else setTrim(null, vid.currentTime); });
/* 시작·끝 조정은 '지금 조각'에만 적용된다 */
function setTrim(a, b) {
  const c = ac(); if (!c) return; const dur = durFor(c.src);
  if (a != null && !isNaN(a)) c.s = Math.min(Math.max(0, a), c.e - 1);
  if (b != null && !isNaN(b)) c.e = Math.max(Math.min(dur, b), c.s + 1);
  afterTrim(a != null ? c.s : Math.max(c.s, c.e - 0.05));
}
/* 조각 통째로 옮기기: 길이를 유지한 채 시작·끝을 같이 민다 */
function moveSeg(newStart) {
  const c = ac(); if (!c) return; const dur = durFor(c.src); const len = c.e - c.s;
  const st = Math.min(Math.max(0, newStart), dur - len);
  c.s = st; c.e = st + len;
  afterTrim(c.s);
}
function afterTrim(seekT) {
  const s = cur(); const c = ac();
  c.s = +c.s.toFixed(2); c.e = +c.e.toFixed(2); syncBounds(s);
  fillTrimFields(); renderClipBar(); updateLen(); renderCues(); drawTimeline(); markDirty(); refreshListMeta();
  seekTo(seekT, c.src);
}
$("#btnSnap").onclick = async () => {
  const c = ac(); if (!c) return;
  try {
    const r = await api("/api/projects/" + S.p.id + "/snap", { method: "POST", body: { start: c.s, end: c.e } });
    const da = (r.start - c.s).toFixed(2), db = (r.end - c.e).toFixed(2);
    c.s = r.start; c.e = r.end; afterTrim(c.s);
    toast(`문장 경계로 맞췄습니다. 시작 ${da >= 0 ? "+" : ""}${da}s · 끝 ${db >= 0 ? "+" : ""}${db}s`);
  } catch (e) { toast(e.message, true); }
};

/* ───────── 가리기(모자이크): 원본 영상 좌표(0~1 비율)로 저장, 미리보기는 흐림으로 표시 ───────── */
function maskSettings() {
  S.p.settings.mask = S.p.settings.mask || { enabled: false, type: "mosaic", block: 16, rects: [] };
  const m = S.p.settings.mask;
  if (!Array.isArray(m.rects)) m.rects = (m.w > 0 && m.h > 0) ? [{ x: +m.x || 0, y: +m.y || 0, w: +m.w, h: +m.h }] : [];   // 옛 한 칸짜리 → 첫 영역
  return m;
}
const maskRects = m => (m.rects || []).filter(r => r && r.w > 0 && r.h > 0);
const rectKind = (m, r) => r.type || m.type || "mosaic";
const rectBlock = (m, r) => +(r.block || m.block || 16);
const KIND_KO = { mosaic: "모자이크", blur: "흐림", black: "검정" };
function fillMask() {
  const m = maskSettings(); const rs = maskRects(m);
  $("#mkOn").checked = !!m.enabled; $("#mkType").value = m.type || "mosaic"; $("#mkBlock").value = String(m.block || 16);
  $("#mkInfo").textContent = rs.length ? `영역 ${rs.length}개` + (m.enabled ? "" : " (꺼짐)") : "";
  // 영역 목록: 줄마다 종류·세기·삭제 (영역별로 따로 준다 — 2026-09-13)
  const list = $("#mkList");
  if (list) {
    list.innerHTML = rs.map((r, i) => `<div class="mk-row" data-i="${i}"><span class="mono dim">영역 ${i + 1}</span>
      <select data-k="type"><option value="mosaic">모자이크</option><option value="blur">흐림</option><option value="black">검정</option></select>
      <select data-k="block"><option value="8">약하게 · 잘게</option><option value="16">보통</option><option value="32">강하게 · 굵게</option></select>
      <span class="dim">${Math.round(r.x * 100)}%,${Math.round(r.y * 100)}% · ${Math.round(r.w * 100)}×${Math.round(r.h * 100)}%</span>
      <span class="mk-range" data-k="range"></span>
      <button class="btn sm" data-k="del" title="이 영역만 지웁니다">✕</button></div>`).join("");
    $$(".mk-row", list).forEach(row => {
      const r = rs[+row.dataset.i];
      const ts = row.querySelector('[data-k="type"]'), bs = row.querySelector('[data-k="block"]');
      ts.value = rectKind(m, r); bs.value = String(rectBlock(m, r)); if (bs.value !== String(rectBlock(m, r))) bs.value = "16";
      bs.disabled = rectKind(m, r) === "black";
      ts.onchange = e => { r.type = e.target.value; fillMask(); markDirty(); };
      bs.onchange = e => { r.block = +e.target.value; fillMask(); markDirty(); };
      row.querySelector('[data-k="del"]').onclick = () => { m.rects.splice(m.rects.indexOf(r), 1); if (!m.rects.length) m.enabled = false; fillMask(); markDirty(); if (tkVisible()) { drawTrack(); fitStage(); } };
      // 구간(2026-09-14): 전체 ↔ 시작·끝 초. 트랙 「가리기」 줄 막대와 같은 값
      const rg = row.querySelector('[data-k="range"]'); const ranged = r.at != null || r.until != null; const s0 = cur();
      if (!ranged) { rg.innerHTML = `<span class="dim">전체</span><button class="btn sm" data-k="mkrange" title="빨간 선부터 3초 구간에만 걸리게 바꿉니다">⏱ 구간</button>`;
        rg.querySelector('[data-k="mkrange"]').onclick = () => { const T = Math.max(0, outTime(s0, vid.currentTime)); const len = outLen(s0); r.at = r2(Math.min(T, Math.max(0, len - 0.5))); r.until = r2(Math.min(len, r.at + 3)); fillMask(); markDirty(); if (tkVisible()) { drawTrack(); fitStage(); } }; }
      else { rg.innerHTML = `<input type="number" step="0.1" min="0" data-k="at" title="시작(초)"> ~ <input type="number" step="0.1" min="0" data-k="until" title="끝(초)"><button class="btn sm" data-k="mkall" title="구간을 풀고 전체에 걸리게 합니다">전체로</button>`;
        const ia = rg.querySelector('[data-k="at"]'), ib = rg.querySelector('[data-k="until"]'); ia.value = (+r.at || 0).toFixed(1); ib.value = (r.until != null ? +r.until : outLen(s0)).toFixed(1);
        const upd = () => { const len = outLen(s0); let a = clamp(+ia.value || 0, 0, len), b = clamp(+ib.value || 0, 0, len); if (b < a + 0.2) b = Math.min(len, a + 0.2); r.at = r2(a); r.until = r2(b); ia.value = a.toFixed(1); ib.value = b.toFixed(1); markDirty(); maskTick(); if (tkVisible()) drawTrack(); };
        ia.onchange = upd; ib.onchange = upd;
        rg.querySelector('[data-k="mkall"]').onclick = () => { delete r.at; delete r.until; fillMask(); markDirty(); if (tkVisible()) { drawTrack(); fitStage(); } }; }
    });
  }
  layoutMask();
}
/* 원본 비율 사각형들 → 지금 크롭·확대 기준의 스테이지 좌표(영상 띠 안). 영역마다 .st-mask 하나 */
function layoutMask() {
  const band = $("#stBand"); const m = maskSettings(); const st = S.p.settings; const rs = maskRects(m);
  const isMain = !S.curSrc || S.curSrc === "main";
  let els = $$(".st-mask", band);
  const show = m.enabled && (isMain || isShop()) && rs.length > 0;    // 쇼핑 쇼츠는 렌더가 모든 조각에 걸므로 미리보기도 모든 출처에서 그린다
  while (els.length < rs.length) { const e = document.createElement("div"); e.className = "st-mask hidden"; band.appendChild(e); els = $$(".st-mask", band); }
  els.forEach((el, i) => {
    if (!show || i >= rs.length) { el.classList.add("hidden"); return; }
    const r = rs[i]; const l = L(); const [sw, sh] = srcSize();
    const { cw, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, st.pan_x, st.pan_y);
    const k = l.band_w / cw;
    el.style.left = ((r.x * sw - cx) * k) + "px"; el.style.top = ((r.y * sh - cy) * k) + "px";
    el.style.width = (r.w * sw * k) + "px"; el.style.height = (r.h * sh * k) + "px";
    const kind = rectKind(m, r); const block = rectBlock(m, r);          // 영역별 종류·세기(없으면 전체 기본값)
    el.classList.toggle("black", kind === "black"); el.classList.toggle("mosaic", kind === "mosaic"); el.classList.remove("hidden");
    el.dataset.i = i; if (!el.querySelector(".mk-handle")) { const hd = document.createElement("div"); hd.className = "mk-handle"; hd.title = "끌어서 크기 조절"; el.appendChild(hd); }
    if (!el._bound) { el._bound = true; bindMaskDrag(el); }
    const blurPx = kind === "blur" ? Math.max(2, block) : 0;             // 흐림 세기 = 같은 선택(8/16/32)을 흐림 반경으로
    el.style.backdropFilter = el.style.webkitBackdropFilter = blurPx ? `blur(${blurPx}px)` : "";
    if (kind === "mosaic") {                              // 진짜 모자이크 미리보기: 원본 영역을 블록 수만큼의 작은 캔버스에 그려 pixelated 로 키운다
      let cv = el.querySelector("canvas"); if (!cv) { cv = document.createElement("canvas"); el.appendChild(cv); }
      const px = Math.max(2, block);                     // 결과 화면 px 기준 블록 크기(렌더와 같은 기준)
      const bw = Math.max(1, Math.round(r.w * sw * k / px)), bh = Math.max(1, Math.round(r.h * sh * k / px));
      if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
      cv.dataset.src = [r.x * sw, r.y * sh, r.w * sw, r.h * sh].map(v => Math.round(v)).join(",");
    } else { const cv = el.querySelector("canvas"); if (cv) cv.remove(); }
  });
  maskTick();
}
/* 앱 화면 겹쳐 보기(미리보기 전용): 유튜브 쇼츠·인스타 릴스·틱톡의 실제 글자·단추 자리를 1080×1920 위에 근사로 그린다.
   가려지는 경계선(빨간 점선)은 편집규칙 §82 실측(유튜브 약 65%↓, 틱톡 약 76%↓, 인스타는 하단 탭바 포함). 결과물에는 안 들어간다. */
const SAFE_KEY = "safeZone";
function safeZoneKind() { try { return localStorage.getItem(SAFE_KEY) || ""; } catch (_) { return ""; } }
function renderSafeZone() {
  const box = $("#stSafe"); if (!box) return;
  const kind = safeZoneKind(); if ($("#safeZone")) $("#safeZone").value = kind;
  if (!kind || !S.p || canvasOf() !== "9:16") { box.classList.add("hidden"); box.innerHTML = ""; return; }
  const s = cur() || {}; const st = S.p.settings || {};
  const name = (st.channel_name || "채널이름").replace(/^@/, ""); const title = (s.yt_title || s.line1 || "제목이 여기에 표시됩니다").slice(0, 40);
  const e = t => String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const rail = (x, items) => items.map(([ic, lb, y]) => `<div class="el ic" style="left:${x}px;top:${y}px">${ic}<small>${e(lb)}</small></div>`).join("");
  let h = "";
  // 좌우 잘림 띠: 세 앱 모두 세로를 꽉 채우느라 양옆이 잘린다(사용자 폰 실측 2026-09-13)
  const crop = pct => `<div class="el side" style="left:0;width:${Math.round(1080 * pct)}px"></div><div class="el side" style="right:0;width:${Math.round(1080 * pct)}px"><i>잘림</i></div>`;
  const railIc = (x, items) => items.map(([ic, lb, y]) => `<div class="el ic" style="left:${x - 65}px;top:${y - 40}px">${ic}${lb ? `<small>${e(lb)}</small>` : ""}</div>`).join("");
  if (kind === "yt") {
    h += crop(0.04) + `<div class="zone top" style="top:0;height:200px"></div><div class="el" style="left:60px;top:40px;font-size:56px">←</div><div class="el" style="left:820px;top:40px;font-size:56px">🔍&nbsp;&nbsp;&nbsp;⋮</div>`;
    h += `<div class="edge" style="top:1400px"><i>여기부터 유튜브 글자가 덮음(≈73%) · 오른쪽 열은 52%부터</i></div>`;
    h += `<div class="zone" style="top:1400px;height:520px"></div>`;
    h += railIc(957, [["♡", "좋아요", 1025], ["💬", "0", 1182], ["🔖", "저장", 1339], ["↪", "공유", 1491], ["⟳", "리믹스", 1654]]) + `<div class="el" style="left:915px;top:1785px"><span class="av">${e(name[0] || "채")}</span></div>`;
    h += `<div class="el" style="left:85px;top:1412px;font-size:36px"><span class="av">${e(name[0] || "채")}</span>&nbsp; @${e(name)}<span class="pill">구독</span></div>`;
    h += `<div class="el txt" style="left:85px;top:1515px;max-width:760px">${e(title)}</div>`;
    h += `<div class="el" style="left:85px;top:1605px;font-size:28px"><span class="tag">ⓘ AI</span> <span class="tag">유료 프로모션</span></div>`;
    h += `<div class="el" style="left:85px;top:1690px;font-size:30px;font-weight:500">♪&nbsp; ${e(name)} · 오리지널 사운드</div>`;
  } else if (kind === "ig") {
    h += crop(0.035) + `<div class="zone top" style="top:0;height:200px"></div><div class="el" style="left:60px;top:44px;font-size:56px">←</div><div class="el" style="left:170px;top:52px;font-size:46px;font-weight:800">릴스</div><div class="el" style="left:960px;top:40px;font-size:60px">+</div>`;
    h += `<div class="edge" style="top:1690px"><i>여기부터 인스타 글자가 덮음(≈88%) · 오른쪽 열은 50%부터</i></div>`;
    h += `<div class="zone" style="top:1650px;height:270px"></div>`;
    h += railIc(967, [["♡", "", 1007], ["💬", "", 1149], ["⟲", "", 1286], ["✈", "", 1428], ["🔖", "", 1559], ["≡", "", 1690]]) + `<div class="el" style="left:930px;top:1780px;width:76px;height:76px;border:3px solid #fff;border-radius:14px;background:#333"></div>`;
    h += `<div class="el" style="left:45px;top:1690px;font-size:38px;font-weight:800"><span class="av">${e(name[0] || "채")}</span>&nbsp; ${e(name)}<span class="pill line">팔로우</span></div>`;
    h += `<div class="el txt" style="left:45px;top:1790px;max-width:800px">${e(title)}<span style="opacity:.7"> … 더 보기</span></div>`;
  } else if (kind === "tt") {
    h += crop(0.06) + `<div class="zone top" style="top:0;height:200px"></div><div class="el" style="left:0;width:1080px;text-align:center;top:52px;font-size:40px"><span style="opacity:.7">팔로잉</span>&nbsp;&nbsp;&nbsp;&nbsp;<b>추천</b></div><div class="el" style="left:960px;top:44px;font-size:56px">🔍</div>`;
    h += `<div class="edge" style="top:1520px"><i>여기부터 틱톡 글자가 덮음(≈79%) · 오른쪽 열은 48%부터</i></div>`;
    h += `<div class="zone" style="top:1520px;height:400px"></div>`;
    h += `<div class="el" style="left:938px;top:920px"><span class="av">${e(name[0] || "채")}</span></div>` + railIc(980, [["♥", "0", 1126], ["💬", "0", 1295], ["🔖", "0", 1458], ["•••", "", 1627]]) + `<div class="el" style="left:938px;top:1755px;width:84px;height:84px;border-radius:50%;border:12px solid #222;background:#444"></div>`;
    h += `<div class="el" style="left:56px;top:1612px;font-size:38px;font-weight:800">${e(name)} <span style="opacity:.6;font-weight:500">· 3시간 전</span></div>`;
    h += `<div class="el txt" style="left:56px;top:1685px;max-width:780px;font-size:34px">${e(title)}<span style="opacity:.7"> … 자세히</span></div>`;
    h += `<div class="el" style="left:56px;top:1808px;font-size:26px"><span class="tag">AI 생성 미디어 포함</span></div>`;
  }
  box.innerHTML = h; box.classList.remove("hidden");
}
$("#safeZone").onchange = e => { try { localStorage.setItem(SAFE_KEY, e.target.value); } catch (_) {} renderSafeZone(); if (e.target.value) toast("앱 화면 겹쳐 보기는 미리보기 전용입니다. 결과물에는 들어가지 않습니다"); };
/* 영역 옮기기·크기 바꾸기: 상자 안을 끌면 이동, 오른쪽 아래 ● 를 끌면 크기. 좌표는 영역 그리기와 같은 변환(스테이지 px → 원본 비율) */
function bindMaskDrag(el) {
  let d0 = null;
  const geo = () => { const st = S.p.settings; const l = L(); const [sw, sh] = srcSize(); const { cw, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, st.pan_x, st.pan_y); return { sw, sh, k: l.band_w / cw, kk: CW() / $(".stage-wrap").clientWidth }; };
  el.addEventListener("pointerdown", e => {
    if (!S.p || S.drawMask || e.button !== 0) return; e.preventDefault(); e.stopPropagation();
    const m = maskSettings(); const r = maskRects(m)[+el.dataset.i]; if (!r) return;
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    d0 = { x: e.clientX, y: e.clientY, r, r0: { x: r.x, y: r.y, w: r.w, h: r.h }, resize: e.target.classList.contains("mk-handle"), g: geo() };
    el.classList.add("dragging");
  });
  el.addEventListener("pointermove", e => {
    if (!d0) return; e.stopPropagation();
    const { sw, sh, k, kk } = d0.g; const dx = (e.clientX - d0.x) * kk / k / sw, dy = (e.clientY - d0.y) * kk / k / sh;   // 화면 px → 원본 비율
    const r = d0.r, r0 = d0.r0;
    if (d0.resize) { r.w = +clamp(r0.w + dx, 0.02, 1 - r0.x).toFixed(4); r.h = +clamp(r0.h + dy, 0.02, 1 - r0.y).toFixed(4); }
    else { r.x = +clamp(r0.x + dx, 0, 1 - r0.w).toFixed(4); r.y = +clamp(r0.y + dy, 0, 1 - r0.h).toFixed(4); }
    layoutMask();
  });
  const end = e => { if (!d0) return; e.stopPropagation(); d0 = null; el.classList.remove("dragging"); fillMask(); markDirty(); };
  el.addEventListener("pointerup", end); el.addEventListener("pointercancel", end);
}
/* 모자이크 미리보기 갱신: 보이는 mosaic 상자마다 지금 영상 프레임의 그 영역을 캔버스에 그린다(재생 중 매 프레임, 멈추면 seek 때) */
function maskRangedRects() { const m = S.p && S.p.settings && S.p.settings.mask; return (m && Array.isArray(m.rects) ? m.rects : []).filter(r => r && r.w > 0 && r.h > 0 && (r.at != null || r.until != null)); }
function maskTick() {
  if (!S.p) return;
  { const s0 = cur(); if (s0) { const T = Math.max(0, outTime(s0, vid.currentTime)); const rs = maskRects(maskSettings());   // 구간 지정 영역은 그 구간에서만 보인다(2026-09-14)
      $$("#stBand .st-mask").forEach(el => { const r = rs[+el.dataset.i]; if (!r || (r.at == null && r.until == null)) { el.classList.remove("tm-off"); return; }
        const vis = T >= (+r.at || 0) - 0.02 && T < (r.until != null ? +r.until : 1e9); el.classList.toggle("tm-off", !vis); }); } }
  $$("#stBand .st-mask.mosaic:not(.hidden) canvas").forEach(cv => {
    const [sx, sy, sw, sh] = (cv.dataset.src || "").split(",").map(Number); if (!(sw > 0 && sh > 0) || vid.readyState < 2) return;
    try { cv.getContext("2d").drawImage(vid, sx, sy, sw, sh, 0, 0, cv.width, cv.height); } catch (_) {}
  });
}
vid.addEventListener("seeked", maskTick); vid.addEventListener("loadeddata", maskTick);
$("#mkOn").onchange = e => { maskSettings().enabled = e.target.checked; fillMask(); markDirty(); };
$("#mkType").onchange = e => { maskSettings().type = e.target.value; fillMask(); markDirty(); };
$("#mkBlock").onchange = e => { maskSettings().block = +e.target.value; layoutMask(); markDirty(); };
$("#btnMkBottom").onclick = () => { const m = maskSettings(); m.enabled = true; m.rects.push({ x: 0, y: 0.80, w: 1, h: 0.17, type: m.type || "mosaic", block: +m.block || 16 }); fillMask(); markDirty(); toast(`원본 아래 17% 영역을 추가했습니다 (영역 ${maskRects(m).length}개)`); };
$("#btnMkPop").onclick = () => { const m = maskSettings(); if (!m.rects.length) return; m.rects.pop(); if (!m.rects.length) m.enabled = false; fillMask(); markDirty(); };
$("#btnMkClear").onclick = () => { const m = maskSettings(); m.rects = []; m.enabled = false; delete m.x; delete m.y; delete m.w; delete m.h; fillMask(); markDirty(); };
$("#btnMkDrawRange").onclick = () => {                 // 구간 지정(2026-09-14): 그린 영역이 빨간 선부터 3초에만 걸린다. 트랙 「가리기」 줄에서 구간을 끈다
  S.drawMask = !S.drawMask; S.drawMaskRange = S.drawMask; $("#btnMkDrawRange").classList.toggle("on", S.drawMask); $("#btnMkDraw").classList.remove("on"); $("#stBand").classList.toggle("drawing", S.drawMask);
  if (S.drawMask) toast("미리보기 영상 위에서 가릴 곳을 끌어 그리세요. 빨간 선 위치부터 3초 구간에만 걸리고, 트랙 「가리기」 줄에서 구간을 바꿉니다");
};
$("#btnMkDraw").onclick = () => { S.drawMask = !S.drawMask; S.drawMaskRange = false; $("#btnMkDrawRange").classList.remove("on"); $("#btnMkDraw").classList.toggle("on", S.drawMask); $("#stBand").classList.toggle("drawing", S.drawMask); if (S.drawMask) toast("미리보기 영상 위에서 가릴 곳을 끌어 사각형을 그리세요. 그릴 때마다 영역이 추가됩니다"); };
/* 그리기: 스테이지 좌표 → 원본 비율. 끝나면 그리기 모드는 자동으로 꺼진다 */
(() => {
  const band = $("#stBand"), box = $("#stDraw"); let d0 = null;
  const toStage = e => { const r = band.getBoundingClientRect(); const k = CW() / $(".stage-wrap").clientWidth; return [(e.clientX - r.left) * k, (e.clientY - r.top) * k]; };
  band.addEventListener("pointerdown", e => {
    if (!S.drawMask || !S.p) return; e.preventDefault(); e.stopPropagation();
    try { band.setPointerCapture(e.pointerId); } catch (_) {}
    d0 = toStage(e); box.style.left = d0[0] + "px"; box.style.top = d0[1] + "px"; box.style.width = "0px"; box.style.height = "0px"; box.classList.remove("hidden");
  }, true);
  band.addEventListener("pointermove", e => {
    if (!d0) return; e.stopPropagation(); const [x, y] = toStage(e);
    box.style.left = Math.min(x, d0[0]) + "px"; box.style.top = Math.min(y, d0[1]) + "px"; box.style.width = Math.abs(x - d0[0]) + "px"; box.style.height = Math.abs(y - d0[1]) + "px";
  }, true);
  const end = e => {
    if (!d0) return; e.stopPropagation(); const [x, y] = toStage(e); const st = S.p.settings; const l = L(); const [sw, sh] = srcSize();
    const { cw, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, st.pan_x, st.pan_y); const k = l.band_w / cw;
    const x0 = Math.min(x, d0[0]) / k + cx, y0 = Math.min(y, d0[1]) / k + cy, x1 = Math.max(x, d0[0]) / k + cx, y1 = Math.max(y, d0[1]) / k + cy;
    d0 = null; box.classList.add("hidden");
    const m = maskSettings(); const w = (x1 - x0) / sw, h = (y1 - y0) / sh;
    if (w < 0.02 || h < 0.02) { toast("너무 작습니다. 더 크게 끌어 주세요", true); return; }
    const nr = { x: +Math.max(0, x0 / sw).toFixed(4), y: +Math.max(0, y0 / sh).toFixed(4), w: +Math.min(1, w).toFixed(4), h: +Math.min(1, h).toFixed(4), type: m.type || "mosaic", block: +m.block || 16 };
    const ranged = !!S.drawMaskRange;
    if (ranged) { const s0 = cur(); const T = Math.max(0, outTime(s0, vid.currentTime)); const len = outLen(s0); nr.at = r2(Math.min(T, Math.max(0, len - 0.5))); nr.until = r2(Math.min(len, nr.at + 3)); }
    m.enabled = true; m.rects.push(nr); S.mkSel = maskRects(m).length - 1;
    S.drawMask = false; S.drawMaskRange = false; $("#btnMkDraw").classList.remove("on"); $("#btnMkDrawRange").classList.remove("on"); band.classList.remove("drawing");
    fillMask(); markDirty(); if (ranged && tkVisible()) { drawTrack(); fitStage(); }
    toast(ranged ? `구간 영역을 추가했습니다 (${fmt(nr.at, 1)}~${fmt(nr.until, 1)}). 트랙 「가리기」 줄의 막대를 끌어 구간을 바꾸세요` : `영역을 추가했습니다 (영역 ${maskRects(m).length}개). 더 가리려면 「영역 추가」를 다시 누르세요`);
  };
  band.addEventListener("pointerup", end, true); band.addEventListener("pointercancel", end, true);
})();

/* ───────── 배경음악 · 전환 ───────── */
const bgmAudio = $("#bgmAudio");
function bgmSettings() { S.p.settings.bgm = S.p.settings.bgm || { enabled: false, path: "", file: "", title: "", volume: 0.15 }; return S.p.settings.bgm; }
function trSettings() { S.p.settings.transition = S.p.settings.transition || { type: "none", dur: 0.5, edges: false }; return S.p.settings.transition; }
async function loadTransitions() {
  try { const r0 = await api("/api/transitions"); S.trNames = r0.transitions || S.trNames; } catch (_) {}
  try { const r = await api("/api/transitions"); $("#trType").innerHTML = Object.entries(r.transitions).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join(""); } catch (e) {}
}
const bgmOn = b => !!(b.enabled && (b.file || b.preset));
const bgmUrl = b => b.preset ? b.url : (b.file ? `/media/${S.p.id}/${b.file}` : "");
async function loadMusic() {
  try { const r = await api("/api/music"); S.music = r.items || []; } catch (e) { S.music = []; }
  $("#bgmPreset").innerHTML = `<option value="">없음</option>` + musicOptions(true) + `<option value="__file">내 파일 (파일… 버튼)</option>`;
}
function fillBgm() {
  const b = bgmSettings(), tr = trSettings(), s = cur();
  const on = bgmOn(b);
  $("#bgmName").textContent = on ? (b.title || b.file) + (b.artist ? " · " + b.artist : "") + (b.duration ? " · " + fmt(b.duration) : "") + (b.preset ? " · CC BY 4.0 (출처 자동 표기)" : " · 내 파일") : "없음";
  $("#btnBgmClear").classList.toggle("hidden", !on);
  $("#bgmPreset").value = b.preset ? b.preset : (b.file ? "__file" : "");
  $("#bgmVol").value = b.volume != null ? b.volume : 0.15; $("#bgmVolV").textContent = Math.round((b.volume != null ? b.volume : 0.15) * 100) + "%";
  if (s) $("#bgmOffShort").checked = !!s.bgm_off;
  if ($("#trType").options.length) $("#trType").value = tr.type || "none";
  $("#trDur").value = String(tr.dur || 0.5); $("#trEdges").checked = !!tr.edges;
  if (on) { const u = bgmUrl(b); if (u && !bgmAudio.src.endsWith(u)) bgmAudio.src = u; bgmAudio.volume = Math.min(1, (b.volume != null ? b.volume : 0.15) * mVol() * pVol()); }
  else { bgmAudio.pause(); }
  drawTrack();
}
$("#bgmPreset").onchange = async e => {
  const v = e.target.value;
  if (v === "__file") { $("#btnBgmPick").click(); return; }
  try {
    if (!v) { const r = await api("/api/projects/" + S.p.id + "/bgm", { method: "POST", body: { clear: true } }); S.p.settings.bgm = r.bgm; bgmAudio.pause(); bgmAudio.removeAttribute("src"); fillBgm(); return; }
    const r = await api("/api/projects/" + S.p.id + "/bgm", { method: "POST", body: { preset: v } }); S.p.settings.bgm = r.bgm; fillBgm(); toast("배경음악: " + r.bgm.title);
  } catch (err) { toast(err.message, true); }
};
$("#btnBgmPlay").onclick = () => { const b = bgmSettings(); if (!bgmOn(b)) return toast("먼저 음악을 고르세요"); if (bgmAudio.paused) { bgmAudio.currentTime = 0; bgmAudio.volume = Math.min(1, b.volume != null ? b.volume : 0.15); bgmAudio.play().catch(() => {}); $("#btnBgmPlay").textContent = "❚❚"; } else { bgmAudio.pause(); $("#btnBgmPlay").textContent = "▶"; } };
bgmAudio.addEventListener("pause", () => $("#btnBgmPlay").textContent = "▶");
$("#btnBgmPick").onclick = async () => {
  toast("음악 파일 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/projects/" + S.p.id + "/bgm", { method: "POST", body: {} }); if (r.cancelled) { fillBgm(); return; } S.p.settings.bgm = r.bgm; fillBgm(); toast("배경음악을 넣었습니다: " + (r.bgm.title || r.bgm.file)); }
  catch (e) { toast(e.message, true); }
};
$("#btnBgmClear").onclick = async () => {
  try { const r = await api("/api/projects/" + S.p.id + "/bgm", { method: "POST", body: { clear: true } }); S.p.settings.bgm = r.bgm; bgmAudio.pause(); bgmAudio.removeAttribute("src"); fillBgm(); }
  catch (e) { toast(e.message, true); }
};
$("#bgmVol").oninput = e => { bgmSettings().volume = +e.target.value; $("#bgmVolV").textContent = Math.round(+e.target.value * 100) + "%"; bgmAudio.volume = Math.min(1, +e.target.value); markDirty(); };
$("#bgmOffShort").onchange = e => { const s = cur(); if (s) { s.bgm_off = e.target.checked; markDirty(); if (e.target.checked) bgmAudio.pause(); } };
$("#trType").onchange = e => { trSettings().type = e.target.value; renderCues(); updateLen(); markDirty(); };
$("#trDur").onchange = e => { trSettings().dur = +e.target.value; renderCues(); updateLen(); markDirty(); };
$("#trEdges").onchange = e => { trSettings().edges = e.target.checked; markDirty(); };
/* 미리듣기: 재생하면 결과 시각에 맞춰 음악을 같이 튼다(렌더와 같은 음량, 끝 페이드는 렌더에서만) */
/* 보조 재생기(낭독·음악·효과음·덧영상)를 영상 시각 lt 에 맞춘다. 재생 중엔 절대 뒤로 되감지 않는다(되감으면 방금 나온 소리가 한 번 더 난다).
   앞서 있으면(el 이 lt 보다 tol 넘게) 멈추고 영상이 따라오면 다시 켠다. 뒤처지면 앞으로만 건너뛴다. 멈춘 상태면 그냥 맞춘다. 2026-09-13 */
function syncEl(el, lt, tol, playing) {
  const d = el.currentTime - lt;                       // + 면 소리가 앞섬
  if (!playing || vid.seeking) {                       // 멈춤·이동 중: 소리를 멈추고 자리는 바로 맞춘다(사용자가 뒤로 옮겨도 여기서 맞는다)
    if (!el.paused) el.pause();
    if (Math.abs(d) > tol) el.currentTime = lt;
    return;
  }
  if (el.paused) {
    if (el._pp || el.seeking) return;                  // play() 가 아직 시작 전이거나 seek 중이면 손대지 않는다(매 프레임 seek+play 를 반복하면 play 가 영영 안 붙는다 — 2026-09-13 5초 침묵의 원인)
    if (d < -0.08) el.currentTime = lt;               // 뒤처짐: 앞으로 건너뛰고 재생
    else if (d > 1.5) el.currentTime = lt;             // 크게 앞서 있으면 계산 오류로 보고 맞춘다
    else if (d > 0.08) return;                         // 앞섬(경계에서 잠깐 쉰 상태): 영상이 따라올 때까지 기다린다
    const pp = el.play(); if (pp && pp.finally) { el._pp = pp; pp.finally(() => { el._pp = null; }); }
    return;
  }
  if (d > 1.5) { el.currentTime = lt; return; }        // 1.5초 넘게 앞서면 드리프트가 아니라 시각 계산 오류 — 그냥 맞춘다
  if (d > tol) { el.pause(); return; }                 // 재생 중 앞섬: 되감지 말고 잠깐 쉰다
  if (d < -tol) el.currentTime = lt;                   // 재생 중 뒤처짐: 앞으로만
}
function bgmSync(playing) {
  const b = bgmSettings(), s = cur(); if (!s || !bgmOn(b) || s.bgm_off) { bgmAudio.pause(); return; }
  if (!playing) { bgmAudio.pause(); return; }
  const g = bgmPlace(s); const t = Math.max(0, outTime(s, vid.currentTime));
  if (t < g.at - 0.05 || t >= g.until) { if (!bgmAudio.paused) bgmAudio.pause(); return; }
  const D = bgmAudio.duration || g.D || 1e9; const loopLen = Math.max(0.5, D - g.in); const lt = g.in + ((t - g.at) % loopLen);
  syncEl(bgmAudio, lt, 0.4, true);
}
vid.addEventListener("seeking", () => { narSync(false); bgmSync(false); audSync(false); if (typeof ovSync === "function") ovSync(); });   // 이동 중엔 보조 소리 멈춤(어긋남 누적 방지)
vid.addEventListener("play", () => setTimeout(() => bgmSync(true), 50));
vid.addEventListener("pause", () => bgmSync(false));
vid.addEventListener("seeked", () => { if (!vid.paused) bgmSync(true); });

/* ───────── 훅 낭독 (TTS) ───────── */
const hookAudio = $("#hookAudio");
S.hookCache = {};
function hookText(s) { return (s.hook_text || "").trim() || [s.line1, s.line2].map(x => (x || "").trim()).filter(Boolean).join(" "); }
function fillHook() {
  const hk = S.p.settings.hook_tts || {}; const s = cur();
  $("#hkOn").checked = !!hk.enabled; $("#hkVoice").value = hk.voice || "ko-KR-InJoonNeural"; $("#hkRate").value = String(hk.rate || 0);
  if (s) { $("#hkText").value = s.hook_text || ""; $("#hkText").placeholder = hookText(s) || "읽을 문구"; }
}
/* 훅 목소리도 위의 공용 loadVoices 가 같이 채운다(VOICE_SELECTS). 여기 따로 두면
   같은 이름이 나중에 선언되어 공용 함수를 가린다 — 실제로 그렇게 가려져 있었다. */
function hookSettings() { S.p.settings.hook_tts = S.p.settings.hook_tts || { enabled: false, voice: "ko-KR-InJoonNeural", rate: 0, duck: 0.25 }; return S.p.settings.hook_tts; }
$("#hkOn").onchange = e => { hookSettings().enabled = e.target.checked; markDirty(); };
$("#hkVoice").onchange = e => { hookSettings().voice = e.target.value; markDirty(); };
$("#hkRate").onchange = e => { hookSettings().rate = +e.target.value; markDirty(); };
$("#hkText").oninput = e => { const s = cur(); if (s) { s.hook_text = e.target.value; markDirty(); } };
async function hookUrl(s) {
  const hk = hookSettings(); const text = hookText(s); if (!text) return null;
  const key = text + "|" + hk.voice + "|" + hk.rate;
  if (!S.hookCache[key]) {
    const r = await api("/api/projects/" + S.p.id + "/tts_preview", { method: "POST", body: { text, voice: hk.voice, rate: hk.rate } });
    S.hookCache[key] = r;
  }
  return S.hookCache[key];
}
$("#btnHkPlay").onclick = async () => {
  const s = cur(); if (!s) return; $("#hkInfo").textContent = "음성 만드는 중…";
  try { const r = await hookUrl(s); hookAudio.src = r.url; hookAudio.currentTime = 0; await hookAudio.play(); $("#hkInfo").textContent = `${r.duration.toFixed(1)}초`; }
  catch (e) { $("#hkInfo").textContent = ""; toast(e.message, true); }
};
/* 미리보기 재생을 구간 시작에서 누르면 훅 음성을 같이 틀고 그동안 영상 소리를 줄인다 */
async function playHookWithVideo(s) {
  const hk = hookSettings(); if (!hk.enabled) return;
  try {
    const r = await hookUrl(s); if (!r) return;
    hookAudio.src = r.url; hookAudio.currentTime = 0;
    const duck = hk.duck != null ? hk.duck : 0.25; vid.volume = duck;
    hookAudio.onended = () => { applyMaster(); };
    await hookAudio.play();
  } catch (e) { vid.volume = 1; }
}
vid.addEventListener("pause", () => { if (!hookAudio.paused) hookAudio.pause(); applyMaster(); });   // 훅 낭독 덕킹 해제: 원본 소리·전체 음량 설정대로 되돌린다(1 로 고정하면 설정이 풀린다)

$("#btnToStart").onclick = () => { const s = cur(); if (!s) return; vid.pause(); S.ci = 0; S.playIdx = 0; renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline(); const c0 = clipsOf(s)[0]; seekTo(c0.s, c0.src); };
$("#btnRevertSeg").onclick = () => {
  const s = cur(); if (!s) return;
  const orig = (s.orig_clips && s.orig_clips.length) ? s.orig_clips : (s.orig_start != null ? [{ s: s.orig_start, e: s.orig_end }] : null);
  if (!orig) return toast(TERMn() + " 처음 값이 저장돼 있지 않습니다", true);
  if (JSON.stringify(clipsOf(s)) === JSON.stringify(orig)) return toast("이미 처음 구간입니다");
  s.clips = orig.map(c => ({ s: +c.s, e: +c.e, src: c.src || "main" })); S.ci = 0; S.playIdx = 0;
  afterClipsChange(s.clips[0].s);
  toast(`처음 구간으로 되돌렸습니다 (${s.clips.length}조각, ${totalLen(s).toFixed(1)}초)`);
};
function updateLen() { const s = cur(); const len = outLen(s); const main = totalLen(s); $("#fLen").textContent = len.toFixed(1) + "초" + (len > main + 0.05 ? ` (본편 ${main.toFixed(1)})` : ""); $("#tlen").textContent = fmt(len, 1); $("#seekBar").max = Math.max(1, len); $("#lenWarn").classList.toggle("hidden", len <= SHORTS_LIMIT + 0.01); drawTrack(); }

/* 자막 목록: 조각 순서대로, 결과 영상 시각(out)으로 표시 */
function shortCues(s) {
  if (isShop() && S.p.narration && S.p.narration.url) {   // 낭독 기준 자막: 낭독 파일의 in~out 구간이 결과 at 부터 놓인다(pipeline.short_cues 와 같은 계산). 낭독이 없으면 아래 조각 기준
    const total = outLen(s); const n = narPlace(s); const sh = n.at - n.in;
    return (S.p.cues || []).filter(c => c.e > n.in && c.s < n.out && Math.max(c.s, n.in) + sh < total)
      .map(c => ({ ...c, ci: 0, out_s: Math.max(c.s, n.in) + sh, out_e: Math.min(Math.min(c.e, n.out) + sh, total), text: (s.cue_edits && s.cue_edits[c.id] != null) ? s.cue_edits[c.id] : c.text }));
  }
  const cs = clipsOf(s); const { offs } = clipOffsets(s); const out = [];
  cs.forEach((clip, ci) => {
    if (clip.src && clip.src !== "main") return;
    for (const c of (S.p.cues || [])) {
      if (c.e <= clip.s || c.s >= clip.e) continue;
      const cs0 = Math.max(c.s, clip.s), ce0 = Math.min(c.e, clip.e);
      out.push({ ...c, s: cs0, e: ce0, ci, out_s: offs[ci] + (cs0 - clip.s) / spdOf(clip), out_e: offs[ci] + (ce0 - clip.s) / spdOf(clip), text: (s.cue_edits && s.cue_edits[c.id] != null) ? s.cue_edits[c.id] : c.text });   // out_e 가 없으면 자막 트랙 폭·오른쪽 클릭 나누기가 NaN 이 된다
    }
  });
  return out;
}
function renderCues() {
  const s = cur(); const box = $("#cueList"); box.innerHTML = ""; const multi = clipsOf(s).length > 1; let lastCi = -1;
  for (const c of shortCues(s)) {
    if (multi && c.ci !== lastCi) { const h = document.createElement("div"); h.className = "cue-clip"; h.textContent = clipLabel(clipsOf(s)[c.ci], c.ci); box.appendChild(h); lastCi = c.ci; }
    const d = document.createElement("div"); d.className = "cue"; d.dataset.id = c.id; d.dataset.ci = c.ci;
    d.innerHTML = `<span class="ct">${fmt(c.out_s, 1)}</span><textarea class="${s.cue_edits && s.cue_edits[c.id] != null ? "edited" : ""}">${esc(c.text)}</textarea>`;
    const ta = $("textarea", d);
    ta.oninput = () => { s.cue_edits = s.cue_edits || {}; s.cue_edits[c.id] = ta.value; ta.classList.add("edited"); markDirty(); showSub(vid.currentTime); };
    ta.onfocus = () => {                              // 고치는 자막으로 미리보기 이동(재생 중이면 멈춤). 결과 시각 기준이라 쇼핑·롱폼 모두 같다
      if (!isShop() && S.ci !== c.ci) { S.ci = c.ci; S.playIdx = c.ci; renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline(); }
      seekOut(Math.min(c.out_s + 0.03, Math.max(c.out_s, c.out_e - 0.05))); tkScrollToT(c.out_s);
    };
    ta.onkeydown = e => {
      if (e.key === "Escape") { ta.blur(); return; }
      if (e.key === "Enter") { e.preventDefault(); splitCue(c.id, ta.value, ta.selectionStart); return; }
      if (e.key === "Backspace" && ta.selectionStart === 0 && ta.selectionEnd === 0) { e.preventDefault(); mergeCueWithPrev(c.id, ta.value); }
    };
    box.appendChild(d);
  }
}

/* 자막 줄 나누기·합치기 — 프로젝트 마스터 자막(S.p.cues)을 고친다. 밀려서 두 줄이 된 자막을
   커서 위치에서 엔터로 끊으면 각각 한 줄이 되고, 시간은 글자 수 비례로 나뉜다. */
function remapCueEdits(fromId, delta, dropId) {
  for (const sh of S.p.shorts) {
    const ed = sh.cue_edits || {}; const out = {};
    for (const k in ed) { const id = +k; if (id === dropId) continue; out[id >= fromId ? id + delta : id] = ed[k]; }
    sh.cue_edits = out;
  }
}
function afterCueStructureChange(focusId) {
  S.p.cues.forEach((c, i) => c.id = i);
  renderCues(); layoutStage(); showSub(vid.currentTime); markDirty();
  const el = $(`.cue[data-id="${focusId}"] textarea`); if (el) { el.focus(); el.setSelectionRange(0, 0); }
}
function splitCue(id, text, pos) {
  const i = S.p.cues.findIndex(c => c.id === id); if (i < 0) return;
  const left = text.slice(0, pos).trim(), right = text.slice(pos).trim();
  if (!left || !right) { toast("나눌 위치에 커서를 두고 엔터를 누르세요"); return; }
  const c = S.p.cues[i]; const dur = c.e - c.s; const share = left.length / (left.length + right.length);
  const mid = +(c.s + dur * share).toFixed(3);
  const a = { ...c, e: mid, text: left }, b = { ...c, s: mid, text: right };
  S.p.cues.splice(i, 1, a, b);
  remapCueEdits(i + 1, +1, id);          // 이 줄의 쇼츠별 수정은 마스터에 반영됐으니 지우고, 뒤 번호는 한 칸 민다
  afterCueStructureChange(i + 1);
  toast("자막을 두 줄로 나눴습니다");
}
/* 줄 다시 나누기: 자막 전체를 화면 폭 기준 한 줄(또는 두 줄)씩으로 다시 묶는다. 단어 시각이 없으므로 큐 안에서 글자 수 비례로 시간을 나눈다.
   끊는 자리: 폭 초과 · 문장 끝(. ? ! …) · 1초 넘는 쉼. 마지막 줄이 너무 짧으면 앞줄 단어를 끌어와 균형을 맞춘다. (2026-09-08 사용자 요청: 일일이 엔터로 나누기 귀찮다) */
function reflowCues(linesPer) {
  const l = L(); if (!l || !(S.p.cues || []).length) { toast("자막이 없습니다", true); return; }
  const st = S.p.settings; const sc = Math.min(Math.max(0.5, +st.sub_scale || 1), 2);
  const fs = Math.round(l.sub_size * sc); const maxw = Math.min(l.sub_maxw || 960, CW() - 40) * 0.94;
  const ctx = (reflowCues._c || (reflowCues._c = document.createElement("canvas").getContext("2d")));
  ctx.font = `700 ${fs}px ${getComputedStyle($("#stSub")).fontFamily}`;
  const wpx = t => ctx.measureText(t).width;
  const isEnd = w => /[.!?。？！…]["'”’)\]]?$/.test(w);
  const GAP = 1.0;
  const toks = [];
  S.p.cues.forEach(c => {
    const words = String(c.text || "").trim().split(/\s+/).filter(Boolean); if (!words.length) return;
    const total = words.reduce((a, w) => a + w.length, 0) || 1; const dur = Math.max(0, c.e - c.s); let t = c.s;
    words.forEach(w => { const d = dur * w.length / total; toks.push({ w, s: t, e: t + d }); t += d; });
  });
  if (!toks.length) { toast("자막이 비어 있습니다", true); return; }
  for (let i = 0; i < toks.length; i++) toks[i].gap = i ? toks[i].s - toks[i - 1].e : 0;
  const lineText = ln => ln.map(x => x.w).join(" ");
  const lines = []; let curL = [];
  const flush = why => { if (curL.length) { lines.push({ t: curL, why }); curL = []; } };
  toks.forEach(tk => {
    if (curL.length && tk.gap > GAP) flush("gap");
    else if (curL.length && wpx(lineText([...curL, tk])) > maxw) flush("width");
    curL.push(tk);
    if (isEnd(tk.w)) flush("end");
  });
  flush("end");
  for (let i = 1; i < lines.length; i++) {                       // 고아 줄 균형: 앞줄이 폭 때문에 끊긴 경우에만 단어를 끌어온다
    const prev = lines[i - 1], me = lines[i]; if (prev.why !== "width") continue;
    while (prev.t.length > 1 && wpx(lineText(me.t)) < maxw * 0.35) {
      const w = prev.t[prev.t.length - 1]; if (wpx(lineText([w, ...me.t])) > maxw) break;
      prev.t.pop(); me.t.unshift(w);
    }
  }
  const cues = []; let i = 0;
  while (i < lines.length) {
    const grp = [lines[i]]; i++;
    while (grp.length < linesPer && i < lines.length) { if (lines[i].t[0].gap > GAP) break; grp.push(lines[i]); i++; }
    const all = grp.flatMap(g => g.t);
    cues.push({ s: +all[0].s.toFixed(3), e: +all[all.length - 1].e.toFixed(3), text: lineText(all), id: cues.length, se: isEnd(all[all.length - 1].w), ss: false });
  }
  cues.forEach((c, k) => { c.ss = k === 0 || !!cues[k - 1].se; if (c.e - c.s < 0.3) c.e = +(c.s + 0.3).toFixed(3); });
  const before = S.p.cues.length; const edited = S.p.shorts.reduce((a, sh) => a + Object.keys(sh.cue_edits || {}).length, 0);
  S.p.shorts.forEach(sh => { sh.cue_edits = {}; });
  S.p.cues = cues; afterCueStructureChange(0);
  const cs = clipsOf(cur())[0]; const first = cues.findIndex(c => c.e > cs.s); if (first >= 0) { const el = $(`.cue[data-id="${first}"]`); if (el) el.scrollIntoView({ block: "start" }); }
  toast(`자막 ${before}줄 → ${cues.length}줄(${linesPer === 1 ? "한" : "두"} 줄씩)로 다시 나눴습니다` + (edited ? ` · 쇼츠별 손교정 ${edited}건은 초기화` : "") + ". 되돌리기는 Ctrl+Z");
}
$("#btnReflow1").onclick = () => reflowCues(1);
$("#btnReflow2").onclick = () => reflowCues(2);
function mergeCueWithPrev(id, text) {
  const i = S.p.cues.findIndex(c => c.id === id); if (i <= 0) return;
  const prev = S.p.cues[i - 1], c = S.p.cues[i];
  const s = cur(); const prevText = (s.cue_edits && s.cue_edits[prev.id] != null) ? s.cue_edits[prev.id] : prev.text;
  const merged = { ...prev, e: c.e, text: (prevText + " " + text).replace(/\s+/g, " ").trim() };
  S.p.cues.splice(i - 1, 2, merged);
  remapCueEdits(i, -1, id); remapCueEdits(i - 1, 0, i - 1);   // 두 줄의 쇼츠별 수정은 합친 마스터로 대체
  afterCueStructureChange(i - 1);
  toast("앞 줄과 합쳤습니다");
}

/* ───────── 쇼핑 쇼츠 모드: 조각 편집·삽입을 켜고, 문장 경계(본편 자막 기반)는 숨기고, 낭독을 미리보기에 얹는다 ───────── */
const narAudio = $("#narAudio");
const isShop = () => S.p && S.p.kind === "shop";
function applyShopMode() {
  const shop = isShop();
  $$('[data-off="clips"]').forEach(el => el.classList.add("hidden"));   // 조각 단추 묶음(훅으로 앞에·＋조각·나누기·◀▶·✕)은 트랙이 대신한다 — 2026-09-06 사용자 요청으로 숨김. 단축키·트랙 단추가 .click() 으로 계속 쓴다
  $("#btnSnap").classList.toggle("hidden", shop);
  $("#shopBar").classList.toggle("hidden", !shop);
  $$(".shop-only").forEach(el => el.classList.toggle("hidden", !shop));
  $("#btnReanalyze").closest(".pn-sec").classList.toggle("hidden", shop);
  // 가로 롱폼(16:9)은 훅 제목·채널을 쓰지 않는다 — 절을 감추고, 생성 때 show_title/show_chan 이 꺼져 있다(server.create_shop)
  const wideCanvas = !!(S.p && S.p.settings && S.p.settings.canvas === "16:9");
  // 가로 롱폼: 디자인 절(출력 형식·템플릿·비율·배경·제목 글꼴)은 세로 쇼츠 개념이라 통째로 숨기고 캔버스·비율을 16:9 로 못박는다(2026-09-14 사용자 결정)
  if ($("#designSec")) $("#designSec").classList.toggle("hidden", wideCanvas);
  if ($("#btnRenderOnly")) $("#btnRenderOnly").classList.add("hidden");   // 「렌더링」(복사 없는 렌더)은 「이 쇼츠 내보내기」와 사실상 같아 세 모드 모두 숨김(2026-09-14 사용자 결정). 코드는 유지
  if (wideCanvas && S.p.settings.ratio !== "16:9") { S.p.settings.ratio = "16:9"; markDirty(); }
  if ($("#bgmOffShortT")) $("#bgmOffShortT").textContent = wideCanvas ? "이 영상은 음악 끄기" : "이 쇼츠는 끄기";
  if ($("#btnSfxApplyAll")) $("#btnSfxApplyAll").title = TERM() + " 트랙에 이미 넣은 효과음 전부를 기본 음량으로 맞춥니다";
  if ($("#upTip")) $("#upTip").dataset.tip = wideCanvas ? "이 영상을 유튜브에 올릴 때 쓸 제목·설명·태그입니다. 대본이 있으면 「제목·문안 AI」로 채우고, 내보내기 때 shorts-upload.json 에 함께 저장됩니다."
                                                       : "유튜브에 올릴 때 쓸 제목·설명·태그입니다. 롱폼→쇼츠는 AI 가 채워 두고, 내보내기 때 shorts-upload.json 에 함께 저장됩니다.";
  if ($("#segTip")) $("#segTip").dataset.tip = TERM() + "이 원본 영상의 어디부터 어디까지인지입니다. 시작·끝 칸을 고치거나 타임라인 손잡이를 끌고, 「문장 경계에 맞추기」로 말이 잘리지 않게 맞춥니다.";
  $("#fShowTitle").closest(".pn-sec").classList.toggle("hidden", wideCanvas);
  $("#fShowChan").closest(".pn-sec").classList.toggle("hidden", wideCanvas);
  const s0 = cur(); const showTrack = shop || (s0 && clipsOf(s0).length > 1);
  $("#mediaSec").classList.toggle("hidden", !showTrack); if (showTrack) renderMedia();
  $("#sfxSec").classList.toggle("hidden", !showTrack); if (showTrack && S.sfx == null) loadSfx();
  if (shop && !(S.p.extra_sources || []).some(x => x.kind === "black") && !S.blackPrefetch) { S.blackPrefetch = S.p.id; ensureBlackSource().catch(() => {}); }   // 옮길 때 기다리지 않게 미리
  renderTexts(); fillTxtPanel();
  $("#btnRenderOne").classList.toggle("hidden", shop);                // 쇼핑 쇼츠는 하나뿐이라 「내보내기」만 둔다
  const trim = $(".trim"); if (trim) trim.classList.toggle("hidden", shop);   // 시작·끝 미세 조정 칸은 트랙이 대신한다
  const secH = $("#shopBar").closest(".pn-sec").querySelector(".pn-h"); if (secH && secH.firstChild) secH.firstChild.textContent = shop ? "낭독·소리 " : "구간 ";
  if (!S.viewRestored && !S.viewTimer) S.viewTimer = setTimeout(() => { S.viewTimer = null; restoreView(); }, 300);
  if ($("#trackWrap").classList.contains("hidden") === !!showTrack) {
    $("#trackWrap").classList.toggle("hidden", !showTrack);
    $("#tl").classList.toggle("hidden", !!showTrack); $(".tl-labels").classList.toggle("hidden", !!showTrack);
    const zh = $(".zb-hint"); if (zh) zh.classList.toggle("hidden", !!showTrack);   // 트랙 모드에선 안내 한 줄을 접어 미리보기 공간을 지킨다
    fitStage();
  }
  if (shop) {
    const nar = S.p.narration || {};
    if (nar.url && !narAudio.src.endsWith(nar.url)) narAudio.src = nar.url;
    const sv = S.p.settings.src_volume == null ? 1 : +S.p.settings.src_volume;
    vid.volume = Math.min(1, sv * mVol() * pVol()); $("#srcVol").value = sv; $("#srcVolV").textContent = Math.round(sv * 100) + "%";
    updateNarInfo();
  } else { vid.volume = Math.min(1, mVol() * pVol()); narAudio.pause(); }
  applyMaster();
}
function updateNarInfo() {
  if (!isShop()) return; const s = cur(); if (!s) return;
  const nd = +(S.p.narration || {}).duration || 0; const tot = totalLen(s); const diff = tot - nd;
  const has = !!(S.p.narration && S.p.narration.url);
  $("#btnFitNar").classList.toggle("hidden", !has); $("#btnAddNar").textContent = has ? "낭독 파일 바꾸기…" : "낭독 파일 넣기…"; $("#btnMakeNar").textContent = has ? "🎙 낭독 다시 만들기(TTS)…" : "🎙 낭독 만들기(TTS)…";
  $("#narInfo").textContent = has
    ? `낭독 ${fmt(nd, 1)} · 영상 ${fmt(tot, 1)}` + (Math.abs(diff) > 0.5 ? (diff > 0 ? ` · 영상이 ${diff.toFixed(1)}초 김` : ` · 영상이 ${(-diff).toFixed(1)}초 짧음`) : " · 맞음")
    : `낭독 없음 · 영상 ${fmt(tot, 1)} · 원본 소리 사용`;
}
$("#srcVol").oninput = e => { const v = +e.target.value; S.p.settings.src_volume = v; vid.volume = Math.min(1, v * mVol() * pVol()); $("#srcVolV").textContent = Math.round(v * 100) + "%"; markDirty(); };
$("#btnAddNar").onclick = async () => {
  if (!isShop()) return;
  // 낭독 파일 넣기: 파일 선택 창으로 바로. 저장된 대본이 있으면 그걸로 글자를 교정한다(2026-09-09: 대본 모달과 같아 보여 혼란 → 분리)
  const script = ((S.p.shop || {}).script || "").trim();
  toast("낭독 파일 선택 창이 열렸습니다. 고르면 받아쓰기가 시작됩니다" + (script ? " (저장된 대본으로 글자 교정)" : "") + ".");
  try { const r = await api("/api/projects/" + S.p.id + "/narration", { method: "POST", body: { script } }); if (r.cancelled) return; watchJob("ocr"); }
  catch (e) { toast(e.message, true); }
};
/* 편집기 안 TTS: 홈의 「대본으로 만들기」와 같은 /api/tts/make 작업을 돌린 뒤 결과 파일을 /narration 으로 넣는다 */
$("#btnMakeNar").onclick = async () => {
  if (!isShop()) return;
  $("#ttsText").value = ((S.p.shop || {}).script || "").trim(); $("#ttsInfo").textContent = "";
  if (!$("#ttsVoice").options.length) await loadVoices();
  $("#ttsModal").classList.remove("hidden"); $("#ttsText").focus();
};
$("#btnTtsCancel").onclick = () => { if (S.ttsBusy) return toast("만드는 중입니다. 끝나면 닫힙니다."); $("#ttsModal").classList.add("hidden"); };
$("#btnTtsTest").onclick = async () => {
  const b = $("#btnTtsTest"); b.disabled = true;
  const text = ($("#ttsText").value.trim().split(/(?<=[.!?])\s+/)[0] || PROD_SAMPLE).slice(0, 120);
  $("#ttsInfo").textContent = "음성 만드는 중…";
  try { const r = await api("/api/tts/preview", { method: "POST", body: { text, voice: $("#ttsVoice").value, rate: +$("#ttsRate").value } }); prodAudio.src = r.url; prodAudio.currentTime = 0; await prodAudio.play(); $("#ttsInfo").textContent = `${r.duration}초`; }
  catch (e) { $("#ttsInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; }
};
$("#btnTtsMake").onclick = async () => {
  const text = $("#ttsText").value.trim(); if (text.length < 5) return toast("읽을 대본을 넣어 주세요", true);
  const b = $("#btnTtsMake"); b.disabled = true; S.ttsBusy = true; $("#ttsInfo").textContent = "낭독을 만드는 중…";
  try {
    const r = await api("/api/tts/make", { method: "POST", body: { text, voice: $("#ttsVoice").value, rate: +$("#ttsRate").value } });
    const res = await pollTts(r.token, m => $("#ttsInfo").textContent = m);
    $("#ttsInfo").textContent = `${res.duration}초 낭독 완성 — 트랙에 넣는 중…`;
    await api("/api/projects/" + S.p.id + "/narration", { method: "POST", body: { path: res.path, script: text } });
    S.p.shop = Object.assign(S.p.shop || {}, { script: text });
    $("#ttsModal").classList.add("hidden"); toast(`${res.duration}초 낭독을 만들어 넣었습니다. 받아쓰기가 끝나면 자막이 붙습니다.`); watchJob("ocr");
  } catch (e) { $("#ttsInfo").textContent = ""; toast(e.message, true); }
  finally { b.disabled = false; S.ttsBusy = false; }
};
$("#btnFitNar").onclick = () => {
  const s = cur(); if (!s || !isShop()) return; const nd = +(S.p.narration || {}).duration || 0; if (!nd) return;
  const cs = clipsOf(s); const lens = cs.map(c => durFor(c.src) - c.s);   // 각 조각은 자기 시작점부터 영상 끝까지 늘어날 수 있다
  let remaining = nd; const order = [...cs.keys()].sort((a, b) => lens[a] - lens[b]); let left = order.length; const share = [];
  order.forEach(i => { const want = remaining / left; share[i] = Math.min(lens[i], want); remaining -= share[i]; left--; });
  cs.forEach((c, i) => { c.e = +Math.min(durFor(c.src), c.s + Math.max(0.5, share[i])).toFixed(2); });
  afterClipsChange(cs[0].s); updateNarInfo(); toast("조각 길이를 낭독에 맞췄습니다");
};
$("#btnShopCopy").onclick = async () => {
  if (!isShop()) return;
  const script = ((S.p.shop || {}).script || "").trim(); const hasCues = (S.p.cues || []).length >= 3;
  if (!script && !hasCues) {                          // 대본·낭독·자막이 없으면 영상의 소리를 받아써서 그걸로 쓴다
    if (!confirm("대본이나 낭독이 없습니다.\n영상의 소리를 받아써서 자막과 제목·문안을 만들까요? (긴 영상은 1~2분 걸립니다)")) return;
    try { await api("/api/projects/" + S.p.id + "/transcribe_video", { method: "POST", body: { copy: true } }); toast("영상 소리를 받아쓰는 중…"); watchJob("ocr"); }
    catch (e) { toast(e.message, true); }
    return;
  }
  toast("AI 가 제목·문안을 쓰는 중…");
  try { const r = await api("/api/projects/" + S.p.id + "/shop_copy", { method: "POST", body: { script } }); Object.assign(cur(), r.short); selectShort(S.sid); toast("제목·문안을 새로 썼습니다"); }
  catch (e) { toast(e.message, true); }
};
$("#btnTranscribeVideo").onclick = async () => {
  if (!isShop()) return;
  if (S.p.narration && S.p.narration.url) return toast("낭독이 있는 프로젝트는 낭독으로 자막을 만듭니다(「낭독 다시 받아쓰기」)", true);
  if ((S.p.cues || []).length && !confirm("영상 소리를 받아써 자막을 새로 만듭니다. 지금 자막은 바뀝니다.")) return;
  try { await api("/api/projects/" + S.p.id + "/transcribe_video", { method: "POST", body: { copy: false } }); toast("영상 소리를 받아쓰는 중…"); watchJob("ocr"); }
  catch (e) { toast(e.message, true); }
};
$("#btnRetranscribe").onclick = async () => {
  if (!isShop()) return; if (!confirm("낭독을 다시 받아씁니다. 고친 자막은 초기화됩니다.")) return;
  try { await api("/api/projects/" + S.p.id + "/retranscribe", { method: "POST", body: {} }); toast("받아쓰는 중…"); watchJob("ocr"); } catch (e) { toast(e.message, true); }
};
/* 낭독 미리듣기: 재생하면 결과 시각에 맞춰 같이 틀고, 멈추면 같이 멈춘다 */
function narSync(playing) {
  if (!isShop() || !narAudio.getAttribute("src")) { return; }
  const s = cur(); if (!s) return;
  if (!playing) { narAudio.pause(); return; }
  const n = narPlace(s); const t = Math.max(0, outTime(s, vid.currentTime)); const lt = t - n.at + n.in;
  if (t < n.at - 0.05 || lt >= n.out) { if (!narAudio.paused) narAudio.pause(); return; }
  syncEl(narAudio, lt, 0.3, true);
}
vid.addEventListener("play", () => setTimeout(() => narSync(true), 50));
vid.addEventListener("pause", () => narSync(false));
vid.addEventListener("seeked", () => { if (!vid.paused) narSync(true); });

/* ───────── 접이식 절: 제목을 누르면 접고 펼친다. 기본값은 data-collapsed, 사용자가 바꾼 상태는 기억 ───────── */
(() => {
  let saved = {}; try { saved = JSON.parse(localStorage.getItem("secState") || "{}"); } catch (_) {}
  $$(".pn-sec").forEach(sec => {
    const h = $(".pn-h", sec); if (!h) return;
    const key = h.firstChild.textContent.trim();
    const body = document.createElement("div"); body.className = "pn-body";
    while (h.nextSibling) body.appendChild(h.nextSibling);
    sec.appendChild(body);
    const chev = document.createElement("span"); chev.className = "chev"; h.appendChild(chev);
    const collapsed = key in saved ? saved[key] : sec.dataset.collapsed === "1";
    sec.classList.toggle("collapsed", collapsed);
    h.onclick = e => { if (e.target.closest("a,button,input,select")) return; sec.classList.toggle("collapsed"); saved[key] = sec.classList.contains("collapsed"); try { localStorage.setItem("secState", JSON.stringify(saved)); } catch (_) {} };
  });
})();
$("#designMore").onclick = () => { const b = $("#designMoreBody"); const open = b.classList.toggle("hidden"); $("#designMore").textContent = open ? "제목 글꼴·색 ▾" : "제목 글꼴·색 ▴"; };
$("#cueTool").onchange = e => { const id = e.target.value; e.target.value = ""; if (id) $("#" + id).click(); };

/* ───────── 자막 교정: 대본 정렬 · OCR · 복원 ───────── */
$("#cueHelpToggle").onclick = () => {
  const h = $("#cueHelp"); const open = h.classList.toggle("hidden");
  $("#cueHelpToggle").textContent = open ? "자세히 보기 ▾" : "접기 ▴";
  try { localStorage.setItem("cueHelpOpen", open ? "0" : "1"); } catch (_) {}
};
try { if (localStorage.getItem("cueHelpOpen") === "1") { $("#cueHelp").classList.remove("hidden"); $("#cueHelpToggle").textContent = "접기 ▴"; } } catch (_) {}
function cueSourceLabel() {
  const src = S.p.cues_source || "auto";
  $("#cueSrc").textContent = src === "script" ? "대본 기준(시간은 자동 자막)" : src === "ocr" ? "영상 속 자막(OCR)" : src === "video" ? "영상 소리 받아쓰기(조각 기준)" : src === "whisper" ? "낭독 받아쓰기" : src === "script_even" ? "대본(시간 고르게 나눔)" : src === "none" ? "자막 없음" : "자동 자막(음성 인식)";
  $("#btnCuesRestore").classList.toggle("hidden", !S.p.cues_auto || src === "auto");
}
async function applyAlign(body, label) {
  await saveNow();
  toast(label + " 중…");
  try {
    const r = await api("/api/projects/" + S.p.id + "/align", { method: "POST", body });
    toast(`대본 ${r.sentences}문장 중 ${r.matched}문장을 자막에 붙였습니다 (자막 ${r.cues}줄)` + (r.path ? "\n" + r.path : ""));
    openEditor(S.p.id);
  } catch (e) { toast(e.message, true); }
}
$("#btnAlignAuto").onclick = () => applyAlign({ auto: true }, "저장소에서 대본을 찾아 정렬");
$("#btnAlignFile").onclick = async () => { const p = await pickFile("text"); if (p) applyAlign({ path: p }, "대본 파일로 정렬"); };
/* 「대본 넣기」 모달: 상태에 따라 방법을 고른다 — 자막이 있으면 글자 교정(align), 쇼핑이면 낭독 파일과 함께(narration), 아니면 시간에 고르게(script_cues) */
function openPasteModal(preset) {
  const hasCues = (S.p.cues || []).some(c => (c.text || "").trim()); const shop = isShop();
  $("#pasteText").value = (S.p.shop || {}).script || "";
  const radios = $$('input[name="pasteMode"]');
  radios.forEach(r => { const lab = r.closest("label"); const ok = r.value === "align" ? hasCues : r.value === "nar" ? shop : true; r.disabled = !ok; lab.classList.toggle("off", !ok); lab.classList.toggle("hidden", r.value === "nar" && !shop); });
  const hasNar = !!(S.p.narration && S.p.narration.url);
  const want = preset || (hasCues ? "align" : "even");            // 낭독 파일이 없으면 「시간에 고르게」가 기본 — 파일 선택 창이 갑자기 열리지 않게(2026-09-09 사용자 보고)
  $("#pasteNarNote").textContent = hasNar ? "지금 낭독이 들어 있습니다. 자막이 있으면 1번으로 글자만 고치세요." : "";
  const pick = radios.find(r => r.value === want && !r.disabled) || radios.find(r => !r.disabled); if (pick) pick.checked = true;
  $("#pasteHint").textContent = hasCues ? "" : "지금 이 프로젝트에는 자막이 없습니다. 「자막에 적용」을 누르면 고른 방법대로 만듭니다.";
  $("#pasteModal").classList.remove("hidden"); $("#pasteText").focus();
}
$("#btnAlignPaste").onclick = () => openPasteModal("align");
$("#btnScriptIn").onclick = () => openPasteModal();
$("#btnPasteCancel").onclick = () => $("#pasteModal").classList.add("hidden");
$("#btnPasteApply").onclick = async () => {
  const t = $("#pasteText").value; const mode = ($$('input[name="pasteMode"]').find(r => r.checked) || {}).value || "align";
  if (mode !== "nar" && t.trim().length < (mode === "even" ? 10 : 50)) return toast("대본이 너무 짧습니다", true);   // 낭독 파일과 함께 넣기는 대본이 없어도 된다
  $("#pasteModal").classList.add("hidden");
  if (mode === "align") return applyAlign({ text: t }, "붙여 넣은 대본으로 정렬");
  if (mode === "nar") {
    toast("낭독 파일 선택 창이 열렸습니다. 고르면 받아쓰기가 시작되고 이 대본으로 교정합니다.");
    try { const r = await api("/api/projects/" + S.p.id + "/narration", { method: "POST", body: { script: t } }); if (r.cancelled) return; S.p.shop = Object.assign(S.p.shop || {}, { script: t }); watchJob("ocr"); }
    catch (e) { toast(e.message, true); }
    return;
  }
  await saveNow();
  try { const r = await api("/api/projects/" + S.p.id + "/script_cues", { method: "POST", body: { text: t, sid: S.sid } }); toast(`대본 ${r.cues}문장을 이 쇼츠 구간에 고르게 깔았습니다. 트랙의 자막 조각을 끌어 시간을 맞추세요.`); openEditor(S.p.id, S.sid); }
  catch (e) { toast(e.message, true); }
};
$("#btnOcr").onclick = async () => {
  if (!confirm("영상 아래쪽에 박힌 자막을 처음부터 끝까지 읽습니다. 27분 영상 기준 3~5분 걸리며, 그동안 편집은 계속할 수 있습니다. 시작할까요?")) return;
  await saveNow();
  try { await api("/api/projects/" + S.p.id + "/ocr", { method: "POST", body: {} }); toast("OCR 을 시작했습니다. 끝나면 자막 목록이 바뀝니다."); watchJob("ocr"); }
  catch (e) { toast(e.message, true); }
};
$("#btnCuesRestore").onclick = async () => {
  if (!confirm("자막을 원래 자동 자막으로 되돌립니다. " + TERM() + "에서 고친 문장도 지워집니다. 계속할까요?")) return;
  try { await api("/api/projects/" + S.p.id + "/cues_restore", { method: "POST", body: {} }); openEditor(S.p.id); } catch (e) { toast(e.message, true); }
};
function watchJob(kind) {
  clearInterval(S.jobPoll);
  S.jobPoll = setInterval(async () => {
    let p; try { p = await api("/api/projects/" + S.p.id); } catch (e) { return; }
    const j = p.job;
    if (j && j.running && j.kind === kind) { $("#cueSrc").textContent = `${j.message || kind} ${j.pct || 0}%`; return; }
    clearInterval(S.jobPoll);
    if (j && j.kind === kind) { if (j.errors?.length) toast(j.errors.join(" / "), true); else { toast(j.message || "완료"); openEditor(S.p.id); } }
  }, 1500);
}

/* ───────── 스테이지 크기: 창 높이에 맞춰 키운다 ───────── */
function fitStage() {
  const center = $(".ed-center"); if (!center || $("#view-editor").classList.contains("hidden")) return;
  if (!S.edColsApplied || S.edColsApplied !== edColsKey()) { S.edColsApplied = edColsKey(); applyEdCols(); }   // 편집기 종류가 바뀌면 그 종류의 저장된 칸 너비로
  // 미리보기 말고 나머지 요소(재생줄·확대줄·안내·타임라인 또는 트랙)의 실제 높이를 재서 남는 만큼 미리보기를 키운다
  const stageWrap = $(".stage-wrap");
  const used = [...center.children].filter(el => el !== stageWrap && !el.classList.contains("hidden"))
    .reduce((a, el) => { const cs = getComputedStyle(el); return a + el.offsetHeight + (parseFloat(cs.marginTop) || 0) + (parseFloat(cs.marginBottom) || 0); }, 0);
  const fixed = used + 40;                                              // + 위아래 패딩·여유
  const availH = center.clientHeight - fixed;
  const availW = center.clientWidth - 40;
  let h = Math.max(tkVisible() ? (S.trackAreaH ? 200 : 340) : 560, Math.min(availH, 1100));
  const cw = S.p ? CW() : 1080, ch = S.p ? CH() : 1920;
  let w = Math.round(h * cw / ch);
  if (w > availW) { w = Math.max(315, availW); h = Math.round(w * ch / cw); }
  const root = document.documentElement.style;
  root.setProperty("--cw", cw + "px"); root.setProperty("--ch", ch + "px");
  root.setProperty("--stage-w", w + "px"); root.setProperty("--stage-h", h + "px");
  root.setProperty("--stage-scale", (w / cw).toFixed(5));
  root.setProperty("--wide-w", Math.max(900, Math.min(availW, w * 2.4)) + "px");
  if (S.p) { drawTimeline(); drawTrack(); }
}
window.addEventListener("resize", fitStage);
/* 왼쪽·오른쪽 칸 너비 손잡이(2026-09-14 사용자 요청): 미리보기는 가운데 고정, 경계를 끌어 폭을 바꾼다. 편집기 종류(long·shop·wide)별로 기억, 두 번 누르면 기본값 */
const ED_COL = { L: [220, 600, 340], R: [260, 600, 360] };
function edColsKey() { return "edCols:" + (S.p ? progOf({ kind: S.p.kind, canvas: (S.p.settings || {}).canvas }) : "x"); }
function applyEdCols() {
  let v = null; try { v = JSON.parse(localStorage.getItem(edColsKey()) || "null"); } catch (_) {}
  const r = document.documentElement.style;
  if (v && v.l) r.setProperty("--ed-l", clamp(v.l, ED_COL.L[0], ED_COL.L[1]) + "px"); else r.removeProperty("--ed-l");
  if (v && v.r) r.setProperty("--ed-r", clamp(v.r, ED_COL.R[0], ED_COL.R[1]) + "px"); else r.removeProperty("--ed-r");
}
(() => {
  const bind = (id, side) => {
    const g = $(id); if (!g) return; let x0 = 0, w0 = 0, raf = 0;
    const el = () => side === "l" ? $(".ed-left") : $(".ed-panel");
    const lim = side === "l" ? ED_COL.L : ED_COL.R;
    g.addEventListener("pointerdown", e => { e.preventDefault(); x0 = e.clientX; w0 = el().offsetWidth; try { g.setPointerCapture(e.pointerId); } catch (_) {} g.classList.add("on"); document.body.classList.add("ed-resizing"); });
    g.addEventListener("pointermove", e => {
      if (!g.classList.contains("on")) return;
      const w = clamp(side === "l" ? w0 + (e.clientX - x0) : w0 - (e.clientX - x0), lim[0], lim[1]);
      document.documentElement.style.setProperty(side === "l" ? "--ed-l" : "--ed-r", w + "px");
      if (!raf) raf = requestAnimationFrame(() => { raf = 0; fitStage(); if (typeof drawTrack === "function" && tkVisible()) drawTrack(); });
    });
    const end = () => { if (!g.classList.contains("on")) return; g.classList.remove("on"); document.body.classList.remove("ed-resizing");
      let v = {}; try { v = JSON.parse(localStorage.getItem(edColsKey()) || "{}"); } catch (_) {}
      v[side] = el().offsetWidth; try { localStorage.setItem(edColsKey(), JSON.stringify(v)); } catch (_) {} fitStage(); };
    g.addEventListener("pointerup", end); g.addEventListener("pointercancel", end);
    g.addEventListener("dblclick", () => { let v = {}; try { v = JSON.parse(localStorage.getItem(edColsKey()) || "{}"); } catch (_) {} delete v[side]; try { localStorage.setItem(edColsKey(), JSON.stringify(v)); } catch (_) {} applyEdCols(); fitStage(); toast((side === "l" ? "왼쪽" : "오른쪽") + " 칸 너비를 기본값으로 되돌렸습니다"); });
  };
  bind("#gripL", "l"); bind("#gripR", "r");
})();

/* ───────── 스테이지(미리보기) ───────── */
/* pipeline.crop_rect 와 같은 계산. 여기를 바꾸면 거기도 바꾼다 */
function cropRect(sw, sh, ratio, zoom = 1, panX = 0, panY = 0) {
  const [a, b] = ratio.split(":").map(Number); const r = a / b;
  zoom = Math.min(Math.max(1, +zoom || 1), 3);
  let cw = Math.min(sw, Math.round(sh * r)), ch = Math.min(sh, Math.round(sw / r));
  cw = Math.trunc(cw / zoom); ch = Math.trunc(ch / zoom);
  cw -= cw % 2; ch -= ch % 2;
  let cx = Math.round((sw - cw) / 2 + (+panX || 0)), cy = Math.round((sh - ch) / 2 + (+panY || 0));
  cx = Math.min(Math.max(0, cx), sw - cw); cy = Math.min(Math.max(0, cy), sh - ch);
  cx -= cx % 2; cy -= cy % 2;
  return { cw, ch, cx, cy };
}
function srcSize() { const x = srcInfo(S.curSrc); return [vid.videoWidth || x.width || 1920, vid.videoHeight || x.height || 1080]; }
function setZoom(z) {
  S.p.settings.zoom = Math.round(Math.min(Math.max(1, +z || 1), 3) * 100) / 100;
  $("#fZoom").value = S.p.settings.zoom; $("#fZoomV").textContent = S.p.settings.zoom.toFixed(2) + "×"; $("#zoomBtnV").textContent = S.p.settings.zoom.toFixed(2) + "×";
  const tag = $("#stZoomTag"); tag.textContent = S.p.settings.zoom.toFixed(2) + "×"; tag.classList.toggle("hidden", S.p.settings.zoom <= 1);
  layoutStage(); markDirty();
}
$("#fZoom").oninput = e => setZoom(e.target.value);
$("#btnZoomIn").onclick = () => setZoom((+S.p.settings.zoom || 1) + 0.1);
$("#btnZoomOut").onclick = () => setZoom((+S.p.settings.zoom || 1) - 0.1);
$("#btnZoomReset").onclick = () => { S.p.settings.pan_x = 0; S.p.settings.pan_y = 0; setZoom(1); };
/* 확대·자르기는 자주 쓰지 않아 재생 줄 오른쪽 🔍 단추 뒤의 작은 팝업으로(2026-09-08 사용자 요청). 그 자리는 재생 위치 막대가 차지한다 */
$("#btnZoomPop").onclick = () => $("#zoomPop").classList.toggle("hidden");
$("#btnZoomClose").onclick = () => $("#zoomPop").classList.add("hidden");
/* 재생 위치 막대: 결과 영상 시각(0 ~ 결과 길이). 끌면 그 자리로 이동하고, 끌기 전에 재생 중이었으면 손을 뗀 뒤 이어 간다 */
(() => {
  const sb = $("#seekBar");
  sb.addEventListener("pointerdown", () => { S.seekDrag = true; S.seekWas = !vid.paused || !!S.tailPlaying; });
  sb.addEventListener("input", () => { if (!cur()) return; seekOut(+sb.value); });
  const done = () => { if (!S.seekDrag) return; S.seekDrag = false; if (S.seekWas && vid.paused && !S.tailPlaying) $("#btnPlay").click(); S.seekWas = false; };
  sb.addEventListener("pointerup", done); sb.addEventListener("pointercancel", done); sb.addEventListener("change", done);
})();
/* 아래 자막 잘라내기: 원본 아래 18% 가 화면 밖으로 나가도록 확대하고, 보이는 창을 맨 위로 붙인다 */
$("#btnCutBottom").onclick = () => {
  const st = S.p.settings; const [sw, sh] = srcSize();
  const { ch } = cropRect(sw, sh, st.ratio || "16:9", 1, 0, 0);
  const needed = sh * 0.82;                                   // 남길 높이
  const z = Math.max(+st.zoom || 1, ch / needed);              // 비율상 이미 그만큼 잘려 있으면 그대로
  st.pan_y = -sh; st.pan_x = +st.pan_x || 0;                   // 위로 끝까지(잘림 처리는 cropRect 가)
  setZoom(z);
  const c = cropRect(sw, sh, st.ratio || "16:9", st.zoom, st.pan_x, st.pan_y);
  st.pan_y = Math.round(c.cy - (sh - c.ch) / 2); markDirty();
};
/* 자막 위치: 미리보기 자막을 끌거나 ↑↓ 버튼. 값은 스테이지 px(1080×1920 기준) */
function setSubDy(v) { S.p.settings.sub_dy = Math.round(v); layoutStage(); markDirty(); }
$("#subFillSw").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; S.p.settings.sub_fill = b.dataset.c; layoutStage(); markDirty(); };
$("#subFillPick").oninput = e => { S.p.settings.sub_fill = e.target.value; layoutStage(); markDirty(); };
$("#subStrokeSw").onclick = e => { const b = e.target.closest(".sw"); if (!b) return; S.p.settings.sub_stroke = b.dataset.c; layoutStage(); markDirty(); };
$("#subStrokePick").oninput = e => { S.p.settings.sub_stroke = e.target.value; layoutStage(); markDirty(); };
function setSubScale(v) { S.p.settings.sub_scale = Math.round(Math.min(Math.max(0.5, +v || 1), 2) * 100) / 100; layoutStage(); markDirty(); }
$("#fSubScale").oninput = e => setSubScale(e.target.value);
$("#btnSubSmaller").onclick = () => setSubScale((+S.p.settings.sub_scale || 1) - 0.1);
$("#btnSubBigger").onclick = () => setSubScale((+S.p.settings.sub_scale || 1) + 0.1);
$("#btnSubUp").onclick = () => setSubDy((+S.p.settings.sub_dy || 0) - 20);
$("#btnSubDown").onclick = () => setSubDy((+S.p.settings.sub_dy || 0) + 20);
$("#btnSubReset").onclick = () => { S.p.settings.sub_dx = 0; S.p.settings.sub_scale = 1; setSubDy(0); };
/* 훅 제목 위치(title_dy)·영상 띠 위치(band_dy): 템플릿 기본 자리에서 위아래로. 렌더(pipeline.apply_offsets)와 같은 한계값 (2026-09-13 사용자 요청) */
function titleDy(l) { l = l || L(); if (!l) return 0; return Math.round(Math.min(Math.max(-l.title1_y + 10, +S.p.settings.title_dy || 0), CH() - l.title2_y - 120)); }
function bandDy(l) { l = l || L(); if (!l || l.mode === "full") return 0; return Math.round(Math.min(Math.max(-l.band_top, +S.p.settings.band_dy || 0), CH() - l.band_top - l.band_h)); }
function setTitleDy(v) { S.p.settings.title_dy = Math.round(v); layoutStage(); markDirty(); }
function setBandDy(v) { S.p.settings.band_dy = Math.round(v); layoutStage(); markDirty(); }
$("#btnTitleUp").onclick = () => setTitleDy((+S.p.settings.title_dy || 0) - 20);
$("#btnTitleDown").onclick = () => setTitleDy((+S.p.settings.title_dy || 0) + 20);
$("#btnTitleReset").onclick = () => setTitleDy(0);
$("#btnBandUp").onclick = () => setBandDy((+S.p.settings.band_dy || 0) - 20);
$("#btnBandDown").onclick = () => setBandDy((+S.p.settings.band_dy || 0) + 20);
$("#btnBandReset").onclick = () => setBandDy(0);
["#stT1", "#stT2"].forEach(sel => {                        // 제목 두 줄은 한 덩어리로 끌린다
  const el = $(sel); let d0 = null;
  el.addEventListener("pointerdown", e => {
    if (!S.p) return; e.preventDefault(); e.stopPropagation();
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    el.classList.add("dragging"); d0 = { y: e.clientY, dy: +S.p.settings.title_dy || 0 };
  });
  el.addEventListener("pointermove", e => {
    if (!d0) return; const k = CW() / $(".stage-wrap").clientWidth;
    S.p.settings.title_dy = Math.round(d0.dy + (e.clientY - d0.y) * k); layoutStage();
  });
  const end = () => { if (!d0) return; d0 = null; el.classList.remove("dragging"); S.p.settings.title_dy = titleDy(); layoutStage(); markDirty(); };
  el.addEventListener("pointerup", end); el.addEventListener("pointercancel", end);
});
$("#fSubOneLine").onchange = e => { S.p.settings.sub_one_line = e.target.checked; if (e.target.checked && !S.p.settings.sub_max_chars) S.p.settings.sub_max_chars = 14; layoutStage(); markDirty(); toast(e.target.checked ? "한 줄 자막: 이미 만든 자막은 「자막 교정 › 낭독 다시 받아쓰기」나 「대본으로 교정」을 다시 하면 14자로 잘립니다" : "두 줄 자막으로 돌아갑니다"); };
(() => {
  const el = $("#stSub"); let d0 = null;
  el.addEventListener("pointerdown", e => {
    if (!S.p) return; e.preventDefault(); e.stopPropagation();
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    el.classList.add("dragging"); d0 = { y: e.clientY, dy: +S.p.settings.sub_dy || 0 };
  });
  el.addEventListener("pointermove", e => {
    if (!d0) return; const k = CW() / $(".stage-wrap").clientWidth;
    let dy = d0.dy + (e.clientY - d0.y) * k; const l = L();
    if (l) { const baseY = l.sub_y + el.offsetHeight / 2; const sn = snapCenter(CW() / 2, baseY + dy, { noX: true }); dy = sn.y - baseY; showGuides(false, sn.sy, sn.yc); }   // 자막도 세로 가운데에 붙는다
    S.p.settings.sub_dy = Math.round(dy); layoutStage();
  });
  const end = () => { if (!d0) return; d0 = null; el.classList.remove("dragging"); hideGuides(); markDirty(); };
  el.addEventListener("pointerup", end); el.addEventListener("pointercancel", end);
})();
/* 영상 위에서 휠 = 확대·축소 */
$("#stBand").addEventListener("wheel", e => {
  if (!S.p) return; e.preventDefault();
  setZoom((+S.p.settings.zoom || 1) + (e.deltaY < 0 ? 0.05 : -0.05));
}, { passive: false });
/* 미리보기 영상을 끌어 보이는 위치를 옮긴다. 스테이지는 1/3 로 축소돼 있으므로 화면 px × 3 = 스테이지 px */
(() => {
  const band = $("#stBand"); let p0 = null;
  band.addEventListener("pointerdown", e => {
    const st = S.p?.settings; if (!st) return; e.preventDefault();
    try { band.setPointerCapture(e.pointerId); } catch (_) { /* 합성 이벤트는 캡처 불가 */ }
    band.classList.add("panning");
    // 가리기 상자·손잡이 위에서 시작한 건 그쪽 드래그라 클릭 재생에서 뺀다
    p0 = { x: e.clientX, y: e.clientY, px: +st.pan_x || 0, py: +st.pan_y || 0, t: Date.now(), noClick: !!(e.target.closest && e.target.closest(".st-mask, .mk-handle")) };
  });
  band.addEventListener("pointermove", e => {
    if (!p0) return; const st = S.p.settings; const [sw, sh] = srcSize();
    const k = CW() / $(".stage-wrap").clientWidth;                 // 화면 px → 스테이지 px
    const { cw } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, 0, 0);
    const scale = (L() ? L().band_w : CW()) / cw;                                        // 스테이지 px → 원본 px 의 역수
    st.pan_x = p0.px - (e.clientX - p0.x) * k / scale; st.pan_y = p0.py - (e.clientY - p0.y) * k / scale;
    layoutStage();
  });
  const end = e => { if (!p0) return; const q = p0; p0 = null; band.classList.remove("panning");
    // 움직임 없이 뗀 건 클릭 → 재생/정지 토글 + 가운데 ▶/❚❚ 표시(2026-09-14 사용자 요청). 끌었으면 위치 이동으로 처리
    if (!q.noClick && e && Math.hypot(e.clientX - q.x, e.clientY - q.y) < 5 && Date.now() - q.t < 800) {
      const wasPlaying = !vid.paused || S.tailPlaying;
      $("#btnPlay").click(); showPlayFx(wasPlaying ? "❚❚" : "▶"); return;
    }
    const st = S.p.settings; const [sw, sh] = srcSize();            // 잘린 값으로 되돌려 저장(밖으로 못 나감)
    const { cw, ch, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, st.pan_x, st.pan_y);
    st.pan_x = Math.round(cx - (sw - cw) / 2); st.pan_y = Math.round(cy - (sh - ch) / 2); markDirty(); };
  band.addEventListener("pointerup", end); band.addEventListener("pointercancel", () => { p0 = null; band.classList.remove("panning"); });
})();
function showPlayFx(sym) {
  const fx = $("#stPlayFx"); if (!fx) return; fx.textContent = sym; fx.classList.remove("show"); void fx.offsetWidth; fx.classList.add("show");
}
function fitTitle(el, text, size, maxw, min) {
  el.textContent = text; el.style.fontSize = size + "px";
  const c = fitTitle._c || (fitTitle._c = document.createElement("canvas").getContext("2d"));
  let fs = size;
  while (fs > min) { c.font = `700 ${fs}px ${getComputedStyle(el).fontFamily}`; if (c.measureText(text).width <= maxw) break; fs -= 2; }
  el.style.fontSize = fs + "px";
}
function layoutStage() {
  const s = cur(); if (!s || !S.p) return;
  const st = S.p.settings; const l = L(); if (!l) return;
  const acc = st.accent || "#FF3B3B";
  const bg = st.bg_color || "#000000", tcol = st.title_color || "#FFFFFF";
  $("#stage").style.background = st.bg_image ? `url(${JSON.stringify(logoUrl(st.bg_image))}) center/cover no-repeat, ${bg}` : bg;
  const bdy = bandDy(l); const band = $("#stBand"); band.style.top = (l.band_top + bdy) + "px"; band.style.height = l.band_h + "px"; band.style.left = (l.band_left || 0) + "px"; band.style.width = l.band_w + "px";
  if ($("#fBandPos")) { $("#fBandPos").textContent = (bdy > 0 ? "+" : "") + bdy; $("#bandPosRow").classList.toggle("hidden", l.mode === "full"); }
  if (getComputedStyle(document.documentElement).getPropertyValue("--cw").trim() !== CW() + "px") fitStage();
  const [sw, sh] = srcSize();
  const isMain = !S.curSrc || S.curSrc === "main";
  const { cw, ch, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, isMain ? st.pan_x : 0, isMain ? st.pan_y : 0);
  const scale = l.band_w / cw;
  vid.style.width = (sw * scale) + "px"; vid.style.height = (sh * scale) + "px";
  vid.style.left = (-cx * scale) + "px"; vid.style.top = (-cy * scale) + "px";
  const full = l.mode === "full";
  $("#stGradTop").classList.toggle("hidden", !full); $("#stGradBot").classList.toggle("hidden", !full);
  const t1 = $("#stT1"), t2 = $("#stT2");
  const tdy = titleDy(l); t1.style.top = (l.title1_y + tdy) + "px"; t2.style.top = (l.title2_y + tdy) + "px";
  if ($("#fTitlePos")) $("#fTitlePos").textContent = (tdy > 0 ? "+" : "") + tdy;
  t1.style.fontFamily = t2.style.fontFamily = fontFamilyOf(st.title_font || "noto");     // fitTitle 이 computed font 로 재니 먼저 넣는다
  if ($("#titleFont").value !== (st.title_font || "noto")) $("#titleFont").value = st.title_font || "noto";
  if ($("#subFont").value !== (st.sub_font || "noto")) $("#subFont").value = st.sub_font || "noto";
  fitTitle(t1, s.line1 || "", l.title_size, l.title_maxw, l.title_min);
  fitTitle(t2, s.line2 || "", l.title_size, l.title_maxw, l.title_min);
  t1.style.color = tcol; t2.style.color = acc; t1.classList.toggle("stroke", full); t2.classList.toggle("stroke", full);
  $("#chNm").style.color = tcol;
  const sub = $("#stSub");
  const dy = Math.min(Math.max(-l.sub_y + 20, +st.sub_dy || 0), CH() - l.sub_y - 120);
  const sc = Math.min(Math.max(0.5, +st.sub_scale || 1), 2);
  const subW = Math.min(l.sub_maxw || 960, CW() - 40);
  sub.style.top = (l.sub_y + dy) + "px"; sub.style.left = ((CW() - subW) / 2 + (+st.sub_dx || 0)) + "px"; sub.style.width = subW + "px"; sub.style.fontSize = Math.round(l.sub_size * sc) + "px";
  sub.style.fontFamily = fontFamilyOf(st.sub_font || "noto");
  $("#fSubScale").value = sc; $("#fSubScaleV").textContent = Math.round(sc * 100) + "%";
  if ($("#fSubOneLine")) $("#fSubOneLine").checked = !!st.sub_one_line;
  sub.classList.toggle("hidden", st.show_subs === false);
  $("#fSubPos").textContent = (dy > 0 ? "+" : "") + dy;
  // 자막 색·외곽선은 제목 강조색과 별개. ''=템플릿 기본, 'none'=외곽선 없음
  const fill = st.sub_fill || "#FFFFFF"; const sv = st.sub_stroke || "";
  const strokeC = sv === "none" ? "transparent" : sv === "accent" ? acc : (sv.startsWith("#") ? sv : "#000");
  const strokeW = sv === "none" ? "0px" : (st.template === "pop" ? "10px" : "8px");
  sub.style.color = fill; sub.style.webkitTextStroke = strokeW + " " + strokeC;
  $$(".sw", $("#subFillSw")).forEach(b => b.classList.toggle("on", b.dataset.c.toLowerCase() === fill.toLowerCase()));
  $("#subFillPick").value = fill;
  $$(".sw", $("#subStrokeSw")).forEach(b => b.classList.toggle("on", b.dataset.c.toLowerCase() === sv.toLowerCase()));
  if (sv.startsWith("#")) $("#subStrokePick").value = sv;
  const cm = $("#stComment"); const showCm = st.template === "comment" && l.comment_y != null;
  cm.classList.toggle("hidden", !showCm);
  if (showCm) { cm.style.top = l.comment_y + "px"; const c = s.comment || {}; $("#cmName").textContent = "@" + (c.name || "시청자"); $("#cmAv").textContent = (c.name || "시")[0]; $("#cmAv").style.background = acc; $("#cmText").textContent = c.text || ""; $("#cmLikes").textContent = c.likes || ""; }
  const chan = $("#stChan"); chan.style.top = l.chan_y + "px"; chan.style.transform = `translate(${+st.chan_dx || 0}px, ${+st.chan_dy || 0}px)`;
  const name = st.channel_name || ""; chan.classList.toggle("hidden", !name || st.show_chan === false);
  t1.classList.toggle("hidden", st.show_title === false); t2.classList.toggle("hidden", st.show_title === false);
  if ($("#fTitleSecs") && document.activeElement !== $("#fTitleSecs")) $("#fTitleSecs").value = +st.title_secs || 0;
  if ($("#fAffSecs") && document.activeElement !== $("#fAffSecs")) {
    const hasAff = (S.p.shorts || []).some(x => (x.texts || []).some(t => t.id === "aff_notice"));
    const canAff = hasAff || !!st.aff_backup || !!S.p.affiliate;                 // 껐다 켤 수 있도록 제휴 프로젝트면 줄을 유지한다
    $("#affSecsRow").classList.toggle("hidden", !canAff); if ($("#affSec")) $("#affSec").classList.toggle("hidden", !canAff); $("#fAffSecs").value = st.aff_secs != null ? +st.aff_secs : 0;
    if ($("#fAffOn")) { $("#fAffOn").checked = hasAff; $("#fAffSecs").disabled = !hasAff; }
    if ($("#affTextRow2")) { $("#affTextRow2").classList.toggle("hidden", !hasAff); if (hasAff && document.activeElement !== $("#fAffText")) { const t0 = (S.p.shorts || []).flatMap(x => x.texts || []).find(t => t.id === "aff_notice"); $("#fAffText").value = t0 ? (t0.text || "") : ""; } } }
  if ($("#fShowTitle")) $("#fShowTitle").checked = st.show_title !== false; if ($("#fShowChan")) $("#fShowChan").checked = st.show_chan !== false;
  $("#chNm").textContent = name; const av = $("#chAv");
  const showAv = st.show_logo !== false;                    // 로고 표시를 끄면 원도 없이 채널명만
  const useLogo = showAv && !!st.channel_logo;
  av.classList.toggle("hidden", !showAv);
  av.textContent = useLogo ? "" : (name[0] || "");
  av.style.background = useLogo ? ("#000 url(" + JSON.stringify(logoUrl(st.channel_logo)) + ") center/cover") : acc;
  showSub(vid.currentTime);
  if (typeof layoutMask === "function") layoutMask();
  if (typeof renderSafeZone === "function") renderSafeZone();
}
function showSub(t) {
  const s = cur(); if (!s) return;
  let c;
  if (isShop() && S.p.narration && S.p.narration.url) { const ot = outTime(s, t); c = shortCues(s).find(c => ot >= c.out_s && ot < c.out_e); }
  else { const ci = clipIndexAt(s, t, S.playIdx); c = shortCues(s).find(c => (ci < 0 || c.ci === ci) && t >= c.s && t < c.e); }
  const txt = (c && S.p.settings.show_subs !== false) ? c.text : "";
  const subEl = $("#stSub"); subEl.textContent = txt; subEl.classList.toggle("empty", !txt);
  // 한 줄 모드: 줄바꿈 없이 글자를 줄여 폭에 맞춘다(렌더 sub_pngs 와 같은 규칙, 최소 60%)
  if (S.p.settings.sub_one_line) {
    subEl.style.whiteSpace = "nowrap";
    const lay = L(); const base = Math.round((lay ? lay.sub_size : 54) * Math.min(Math.max(0.5, +S.p.settings.sub_scale || 1), 2));
    let fs = base; subEl.style.fontSize = fs + "px";
    while (txt && fs > base * 0.6 && subEl.scrollWidth > subEl.clientWidth + 1) { fs -= 2; subEl.style.fontSize = fs + "px"; }
  } else { subEl.style.whiteSpace = ""; }
  // 훅 제목 표시 시간(title_secs): 결과 시각이 넘어가면 미리보기에서도 숨긴다(렌더는 pipeline 이 같은 값으로 자른다)
  const ts = +S.p.settings.title_secs || 0;
  if (ts > 0 && S.p.settings.show_title !== false) { const rt = (isShop() && S.p.narration && S.p.narration.url) ? outTime(s, t) : t; const hide = rt > ts; $("#stT1").classList.toggle("hidden", hide); $("#stT2").classList.toggle("hidden", hide); }
  $$(".cue").forEach(el => el.classList.toggle("live", !!c && +el.dataset.id === c.id && +el.dataset.ci === c.ci));
  $$(".tk-cue").forEach(el => el.classList.toggle("live", !!c && +el.dataset.cue === c.id));
  if (typeof layoutTexts === "function") layoutTexts();
}
function updateTcur(t) {
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, t)); $("#tcur").textContent = fmt(T, 1);
  if (!S.seekDrag) $("#seekBar").value = T;
  const c = clipsOf(s)[clamp(S.playIdx || 0, 0, clipsOf(s).length - 1)];
  const sv = S.p.settings.src_volume == null ? 1 : +S.p.settings.src_volume; const m = typeof mVol === "function" ? mVol() * pVol() : 1;
  const want = c && c.mute ? 0 : Math.min(1, (isShop() ? sv : 1) * m);
  if (Math.abs(vid.volume - want) > 0.001) vid.volume = want;
}
function seekTo(t, srcId) {                          // 전환 중에 온 요청은 버리지 않고, 마지막 요청만 반영한다(순번 S.seekSeq)
  const want = srcId || S.curSrc || "main"; const my = (S.seekSeq = (S.seekSeq || 0) + 1);
  const apply = () => { if (my !== S.seekSeq) return; vid.currentTime = t; applyRate(); updateTcur(t); drawPlayhead(); showSub(t); if (typeof ovSync === "function") ovSync(); };
  if (want !== (S.curSrc || "main") || !vidReady) { switchSource(want).then(apply); return; }
  apply();
}
/* 순차 재생: 조각 끝에 닿으면 다음 조각 시작으로 건너뛰고, 마지막 조각 끝에서 멈춘다 */
function advanceClips() {
  const s = cur(); if (!s || vid.paused) return; const cs = clipsOf(s); const t = vid.currentTime;
  const i = Math.min(S.playIdx || 0, cs.length - 1);
  if (S.switching) return;
  if (t >= cs[i].e - 0.03) {
    if (holdOf(cs[i]) > 0 && S.holdI !== i) { const { offs } = clipOffsets(s); enterHoldAt(i, offs[i] + playOut(cs[i]), true); return; }
    if (i < cs.length - 1) {
      S.playIdx = i + 1; S.ci = S.playIdx; const nx = cs[S.playIdx];
      renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline();
      if ((nx.src || "main") !== (S.curSrc || "main")) { switchSource(nx.src).then(() => { vid.currentTime = nx.s; applyRate(); vid.play(); }); }
      else { vid.currentTime = nx.s; applyRate(); }
    } else if (outLen(s) > totalLen(s) + 0.05) { enterTailAt(totalLen(s), true); }
    else {
      // 마지막 조각 끝: 정리는 여기서 직접 한다. vid.pause() 뒤에 바로 src 를 바꾸면(첫 조각이 다른 파일일 때)
      // 브라우저의 load 알고리즘이 대기 중인 pause 이벤트를 버려서 단추 글자·음악 정지가 안 됐다(2026-09-13 실측: 단추 「❚❚ 정지」 고정, 음악 계속)
      vid.pause(); S.playIdx = 0; const c0 = cs[0];
      narSync(false); bgmSync(false); audSync(false); ovSync(); $("#btnPlay").textContent = "▶ 재생";
      if ((c0.src || "main") !== (S.curSrc || "main")) switchSource(c0.src).then(() => { vid.currentTime = c0.s; ovSync(); }); else vid.currentTime = c0.s;
    }
  }
}
vid.addEventListener("timeupdate", () => { advanceClips(); const t = vid.currentTime; updateTcur(t); drawPlayhead(); showSub(t); if (!vid.paused) { narSync(true); bgmSync(true); audSync(true); } });   // 탭이 가려져 rAF 가 멈춰도 보조 소리는 따라간다
vid.addEventListener("play", () => $("#btnPlay").textContent = "❚❚ 정지");
vid.addEventListener("error", () => { const c = vid.error && vid.error.code; if (!vid.currentSrc) return; toast(c === 4 ? "영상 파일을 열 수 없습니다: " + decodeURIComponent(vid.currentSrc.split("/").pop()) + " — 프로젝트 폴더에 파일이 없거나 형식이 안 맞습니다" : "영상 재생 오류 (" + c + ")", true); });   // 소재가 빠진 프로젝트를 열면 왜 검은지 알려 준다(2026-09-14)
vid.addEventListener("pause", () => $("#btnPlay").textContent = "▶ 재생");
$("#btnPlay").onclick = () => {
  const s = cur(); if (!s) return; const cs = clipsOf(s);
  if (S.tailPlaying) { stopTailTimer(); narSync(false); bgmSync(false); audSync(false); ovSync(); $("#btnPlay").textContent = "▶ 재생"; return; }
  if (S.tailT != null) { startTailTimer(); return; }
  if (vid.paused) {
    const i = clipIndexAt(s, vid.currentTime, S.playIdx);
    const sameSrc = i >= 0 && (cs[i].src || "main") === (S.curSrc || "main");
    const restart = !sameSrc || vid.currentTime >= cs[i].e - 0.05;     // 조각 밖이거나 끝에 닿아 있을 때만 처음부터
    S.playIdx = restart ? 0 : i;
    const target = cs[S.playIdx];
    const go = () => { if (restart) vid.currentTime = target.s; const fromStart = S.playIdx === 0 && Math.abs(vid.currentTime - cs[0].s) < 0.3; vid.play(); if (fromStart) playHookWithVideo(s); };
    if ((target.src || "main") !== (S.curSrc || "main")) switchSource(target.src).then(go); else go();
  } else vid.pause();
};
let raf; function loop() {
  if (!vid.paused) { const s = cur(); if (s) { advanceClips(); showSub(vid.currentTime); drawPlayhead(); updateTcur(vid.currentTime); narSync(true); bgmSync(true); audSync(true); ovSync(); maskTick(); } }
  raf = requestAnimationFrame(loop);
} loop();
vid.addEventListener("seeked", () => ovSync());
vid.addEventListener("pause", () => ovSync());

/* ───────── 타임라인 (지금 조각 ±30초, 다른 조각은 위쪽에 표시) ───────── */
const tl = $("#tl");
const tlX = t => (t - S.tlWin[0]) / (S.tlWin[1] - S.tlWin[0]) * tl.clientWidth;
const tlT = x => S.tlWin[0] + x / tl.clientWidth * (S.tlWin[1] - S.tlWin[0]);
function drawTimeline() {
  const s = cur(); if (!s || !S.p.filmstrip) return; const c = ac();
  if (tl.classList.contains("hidden")) return;       // 트랙 모드에서는 원본 타임라인을 접어 둔다
  const f = stripFor(c.src); const [ws, we] = S.tlWin; const W = tl.clientWidth || 800;
  const strip = $("#tlStrip"); strip.innerHTML = "";
  const fw = f.interval / (we - ws) * W; const fh = tl.clientHeight; const scaleW = fw / f.fw;
  const url = `/media/${S.p.id}/${f.file}`;
  for (let k = Math.floor(ws / f.interval); k <= Math.min(f.count - 1, Math.ceil(we / f.interval)); k++) {
    const d = document.createElement("div");
    d.style.left = ((k * f.interval - ws) / (we - ws) * W) + "px"; d.style.width = Math.ceil(fw) + "px";
    d.style.backgroundImage = `url(${url})`; d.style.backgroundSize = `${f.cols * f.fw * scaleW}px ${f.rows * f.fh * scaleW}px`;
    const col = k % f.cols, row = Math.floor(k / f.cols);
    d.style.backgroundPosition = `${-col * f.fw * scaleW}px ${-(row * f.fh * scaleW) + (fh - f.fh * scaleW) / 2}px`;
    strip.appendChild(d);
  }
  const marks = $("#tlMarks"); marks.innerHTML = "";
  clipsOf(s).forEach((o, i) => {         // 다른 조각의 위치를 위쪽 띠로
    if (i === S.ci || (o.src || "main") !== (c.src || "main") || o.e < ws || o.s > we) return;
    const m = document.createElement("div"); m.className = "tl-mark"; m.style.left = Math.max(0, tlX(o.s)) + "px"; m.style.width = Math.max(4, tlX(Math.min(o.e, we)) - Math.max(0, tlX(o.s))) + "px";
    m.title = clipLabel(o, i); m.onclick = ev => { ev.stopPropagation(); S.ci = i; S.playIdx = i; renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline(); seekTo(o.s, o.src); };
    marks.appendChild(m);
  });
  const xa = tlX(c.s), xb = tlX(c.e);
  $("#tlShadeL").style.width = Math.max(0, xa) + "px"; $("#tlShadeR").style.width = Math.max(0, W - xb) + "px";
  $("#tlHL").style.left = (xa - 12) + "px"; $("#tlHR").style.left = xb + "px";
  $("#tlRange").style.left = xa + "px"; $("#tlRange").style.width = Math.max(0, xb - xa) + "px";
  $("#tlA").textContent = fmt(ws); $("#tlB").textContent = fmt(we);
  drawPlayhead();
}
function drawPlayhead() { if (!cur()) return; $("#tlPh").style.left = tlX(vid.currentTime) + "px"; drawTrackPh(); }
// 좌표는 항상 타임라인 컨테이너 기준으로 읽는다. e.offsetX 는 클릭된 필름 조각 기준이라
// 어디를 눌러도 창 맨 앞으로 튀었다(2026-09-05 사용자 녹화로 확인).
const tlPos = e => { const r = tl.getBoundingClientRect(); return Math.min(Math.max(e.clientX - r.left, 0), r.width); };
const seekClamped = t => { vid.pause(); seekTo(Math.min(Math.max(t, 0), durFor(S.curSrc))); };
tl.addEventListener("pointerdown", e => {
  e.preventDefault();
  if (e.target.closest(".tl-mark")) return;
  const h = e.target.closest(".tl-h");
  try { tl.setPointerCapture(e.pointerId); } catch (_) {}
  if (h) { S.drag = h.classList.contains("left") ? "s" : "e"; return; }
  if (e.target.closest(".tl-ph")) {      // 빨간 선을 잡으면 재생 위치만 옮긴다(재생 중이면 놓을 때 이어서 재생)
    S.drag = "ph"; S.resumeAfter = !vid.paused; vid.pause(); return;
  }
  if (e.target.closest(".tl-range")) {   // 가운데 띠를 잡으면 조각을 통째로 옮긴다
    const c = ac(); S.drag = "mv"; S.dragT0 = tlT(tlPos(e)); S.dragS0 = c.s; tl.classList.add("moving"); vid.pause(); return;
  }
  S.drag = "ph"; S.resumeAfter = false;  // 빈 곳을 누르면 그 지점으로 가고, 누른 채 끌면 빨간 선이 따라온다
  seekClamped(tlT(tlPos(e)));
});
tl.addEventListener("pointermove", e => {
  if (!S.drag) return; const t = tlT(tlPos(e));
  if (S.drag === "s") setTrim(t, null);
  else if (S.drag === "e") setTrim(null, t);
  else if (S.drag === "mv") moveSeg(S.dragS0 + (t - S.dragT0));
  else seekClamped(t);
});
tl.addEventListener("pointerup", () => {
  if (!S.drag) return; const was = S.drag; S.drag = null; tl.classList.remove("moving");
  if (was === "ph") { if (S.resumeAfter) { S.resumeAfter = false; vid.play(); } return; }
  focusClipWindow(); drawTimeline();
});
window.addEventListener("resize", () => { if (S.p) drawTimeline(); });

/* ───────── 트랙(캡컷식): 영상 여러 층 + 낭독 + 음악을 결과 시간 축에 늘어놓는다 ─────────
   영상 1(주 트랙, 맨 아래 영상 줄)은 조각을 이어 붙인 본편 — 길이와 소리를 정한다. 영상 2·3…(위층)은 결과 시각 at 에 얹는 조각으로,
   그 구간엔 아래층 대신 보인다(소리 없음). 조각은 층 사이를 위아래로 끌어 옮길 수 있다(주 트랙 → 위층: 본편에서 빠짐, 위층 → 주 트랙: 그 자리에 끼움).
   낭독: 끌어 시작 시각, 양끝으로 파일 안 구간 — 자막이 같이 따라감.  음악: 끌어 시작, 오른쪽 끝으로 끝, Alt 로 곡 안 시작점. */
const tk = $("#track"), tkIn = $("#trackIn"), ovVid = $("#ovVid");
const TK_PAD = 12;                                  // .tk-row 의 좌우 여백과 같아야 한다
const MAX_LAYERS = 5, MAX_OUT = 10800, SHORTS_LIMIT = 180;   // 편집 길이 상한은 사실상 없음(3시간). 3분은 쇼츠 한계로 노란 선·경고만
S.tkZoom = 1; S.selKind = "clip"; S.oi = 0; S.tkRows = []; S.tkSpan = 30; S.tailT = null; S.tailPlaying = false;
const isPlaying = () => !vid.paused || !!S.tailPlaying;
function outLen(s, opt = {}) {                       // 결과 길이 = 본편·위층·낭독·음악 끝 중 가장 늦은 시각(pipeline.out_len 과 같은 계산)
  let end = totalLen(s);
  ovsOf(s).forEach(o => { end = Math.max(end, o.at + clipOut(o)); });
  if (isShop() && S.p.narration && S.p.narration.url) { const n = narPlace(s); end = Math.max(end, n.at + (n.out - n.in)); }
  if (!opt.noBgm) { const b = bgmSettings(); if (bgmOn(b) && !s.bgm_off && b.until != null) end = Math.max(end, +b.until); }
  audsOf(s).forEach(a => { const g = audPlace(a); end = Math.max(end, g.at + (g.out - g.in)); });
  txtsOf(s).forEach(t => { end = Math.max(end, (+t.at || 0) + (+t.dur || 0)); });
  return Math.min(MAX_OUT, +end.toFixed(3));
}
/* 꼬리: 본편이 끝난 뒤 남는 구간(검정 화면). 가상 시계 S.tailT 로 재생 위치를 잡는다 */
function tailShow(on) { vid.style.visibility = on ? "hidden" : ""; }
function tailTick() {                                // 꼬리·멈춤 재생 시계(setInterval: 탭이 뒤에 있어도 간다)
  const s = cur(); if (!s || !S.tailPlaying) return stopTailTimer();
  const T = S.tailBase + (performance.now() - S.tailT0) / 1000;
  if (S.holdI != null) {                             // 마지막 장면 멈춤 구간: 영상은 멈춘 채 시계만 간다
    const cs = clipsOf(s); const i = S.holdI; const { offs } = clipOffsets(s); const end = offs[i] + clipOut(cs[i]);
    if (T >= end - 0.01) {
      stopTailTimer(); S.holdI = null; S.tailT = null;
      if (i < cs.length - 1) {
        S.playIdx = i + 1; S.ci = S.playIdx; const nx = cs[S.playIdx]; renderClipBar(); fillTrimFields(); drawTimeline(); drawTrack();
        switchSource(nx.src).then(() => { vid.currentTime = nx.s; applyRate(); vid.play(); });
      } else if (outLen(s) > totalLen(s) + 0.05) { enterTailAt(totalLen(s), true); }
      else { narSync(false); bgmSync(false); audSync(false); ovSync(); S.playIdx = 0; seekOut(0); $("#btnPlay").textContent = "▶ 재생"; }
      return;
    }
    S.tailT = T; drawPlayhead(); updateTcur(vid.currentTime); showSub(vid.currentTime); narSync(true); bgmSync(true); audSync(true); ovSync(); return;
  }
  if (T >= outLen(s)) { stopTailTimer(); exitTail(); narSync(false); bgmSync(false); ovSync(); S.playIdx = 0; seekOut(0); $("#btnPlay").textContent = "▶ 재생"; return; }
  S.tailT = T; drawPlayhead(); updateTcur(vid.currentTime); showSub(vid.currentTime); narSync(true); bgmSync(true); audSync(true); ovSync();
}
function startTailTimer() { stopTailTimer(); S.tailPlaying = true; S.tailBase = S.tailT; S.tailT0 = performance.now(); S.tailTimer = setInterval(tailTick, 40); $("#btnPlay").textContent = "❚❚ 정지"; }
function stopTailTimer() { clearInterval(S.tailTimer); S.tailTimer = null; S.tailPlaying = false; }
function enterTailAt(T, playing) {
  vid.pause(); S.tailT = T; tailShow(true);
  updateTcur(vid.currentTime); drawPlayhead(); showSub(vid.currentTime); ovSync();
  if (playing) startTailTimer(); else { stopTailTimer(); narSync(false); bgmSync(false); audSync(false); $("#btnPlay").textContent = "▶ 재생"; }
}
function exitTail() { stopTailTimer(); S.holdI = null; if (S.tailT == null) return; S.tailT = null; tailShow(false); }
function enterHoldAt(i, T, playing) {                // 조각 i 의 마지막 장면 멈춤 구간에 빨간 선을 둔다(영상은 마지막 프레임에 멈춤)
  const s = cur(); const c = clipsOf(s)[i]; if (!c) return;
  stopTailTimer(); vid.pause(); S.holdI = i; S.playIdx = i; S.tailT = T; tailShow(false);
  const want = Math.max(c.s, c.e - 0.04);
  if ((c.src || "main") !== (S.curSrc || "main") || Math.abs(vid.currentTime - want) > 0.08) seekTo(want, c.src);
  updateTcur(vid.currentTime); drawPlayhead(); showSub(vid.currentTime); ovSync();
  if (playing) startTailTimer(); else { narSync(false); bgmSync(false); audSync(false); $("#btnPlay").textContent = "▶ 재생"; }
}
const r2 = v => +(+v).toFixed(2), clamp = (v, a, b) => Math.min(Math.max(v, a), b);
const newId = () => "o" + Math.random().toString(36).slice(2, 8);
function tkVisible() { const w = $("#trackWrap"); return !!w && !w.classList.contains("hidden"); }
function tkPps() { return Math.max(0.2, (tk.clientWidth - TK_PAD * 2) / S.tkSpan * S.tkZoom); }   // 하한을 낮게: 긴 영상도 확대 1 에서 한 화면에 들어온다   // 결과 1초당 px. 눈금 범위(tkSpan)는 drawTrack 이 정한다
const tkPos = e => e.clientX - tkIn.getBoundingClientRect().left - TK_PAD;
const srcTitle = id => { const x = srcInfo(id); return (x.title || "").slice(0, 14); };
const ovsOf = s => (s.overlays = s.overlays || []);
const ovLayer = o => Math.max(1, +o.layer || 1);
const ovAudioOn = o => o.audio !== false;             // 위층 소리는 기본 켬. 끈 조각만 audio:false
function layersOf(s) { const used = Math.max(1, ...ovsOf(s).map(ovLayer)); return clamp(Math.max(used, +s.video_layers || 1), 1, MAX_LAYERS); }
const audsOf = s => (s.audios = s.audios || []);
const txtsOf = s => (s.texts = s.texts || []);
const txtLane = t => Math.max(1, +t.lane || 1);
function txtLanesOf(s) { const used = Math.max(1, ...txtsOf(s).map(txtLane)); return clamp(Math.max(used, +s.text_lanes || 1), 1, 6); }
function txtLaneForNew(s) { if (S.selKind === "txt") { const t = txtsOf(s)[S.ti]; if (t) return txtLane(t); } return S.txtLane || 1; }
const TXT_PRESETS = { basic: { color: "#FFFFFF", stroke: "#000000", bold: true, bg: false }, yellow: { color: "#FFE14D", stroke: "#000000", bold: true, bg: false },
  box: { color: "#FFFFFF", stroke: "none", bold: true, bg: true }, red: { color: "#FF3B3B", stroke: "#FFFFFF", bold: true, bg: false }, plain: { color: "#FFFFFF", stroke: "none", bold: false, bg: false } };
const mVol = () => { const v = S.p && S.p.settings ? S.p.settings.master_volume : 1; return v == null ? 1 : Math.max(0, +v); };
/* 미리듣기 전용 음량(0~1): 브라우저에서만 곱한다. 프로젝트에 저장하지 않고 렌더와 무관(2026-09-13: 결과물 음량과 헷갈려 줄여 놓고 렌더하는 실수 방지) */
const pVol = () => { if (S.prevVol == null) { let v = 1; try { const s = localStorage.getItem("prevVol"); if (s != null && s !== "") v = Math.min(1, Math.max(0, +s)); } catch (_) {} S.prevVol = isNaN(v) ? 1 : v; } return S.prevVol; };   // 전체 음량(0~2). 미리보기 요소는 1 을 넘지 못한다
const audLane = a => Math.max(1, +a.lane || 1);
function audLanesOf(s) { const used = Math.max(1, ...audsOf(s).map(audLane)); return clamp(Math.max(used, +s.audio_lanes || 1), 1, 8); }
function laneForNew(s) { if (S.selKind === "aud") { const a = audsOf(s)[S.ai]; if (a) return audLane(a); } return S.audLane || 1; }
function audPlace(a) { const D = +a.duration || 0; const at = Math.max(0, +a.at || 0); const i = clamp(+a.in || 0, 0, D); const o = a.out == null ? D : clamp(+a.out, i, D); return { at, in: i, out: o, D, vol: a.volume == null ? 1 : +a.volume }; }
function audSet(a, v) { a.at = r2(v.at); a.in = r2(v.in); a.out = r2(v.out); }
function tkRows(s) {                                 // 줄 배치(위→아래, 캡컷 순서): 자막, 영상 N … 영상 2, 영상 1(주), 낭독, 오디오 1…N, 음악
  const rows = []; let top = 22; const n = layersOf(s);
  for (let l = txtLanesOf(s); l >= 1; l--) { rows.push({ kind: "txt", lane: l, key: "T" + l, top, h: 26 }); top += 30; }   // 위층이 위에(렌더도 위층이 위)
  rows.push({ kind: "subs", key: "subs", top, h: 24 }); top += 28;
  if (maskRangedRects().length) { rows.push({ kind: "mask", key: "mask", top, h: 24 }); top += 28; }   // 구간 지정 가리기(2026-09-14)
  for (let l = n; l >= 1; l--) { rows.push({ kind: "layer", layer: l, key: "L" + l, top, h: 40 }); top += 44; }
  rows.push({ kind: "main", key: "main", top, h: 56 }); top += 60;
  rows.push({ kind: "nar", key: "nar", top, h: 28 }); top += 32;
  for (let l = 1; l <= audLanesOf(s); l++) { rows.push({ kind: "aud", lane: l, key: "A" + l, top, h: 28 }); top += 32; }
  rows.push({ kind: "bgm", key: "bgm", top, h: 28 }); top += 32;
  return { rows, height: top };
}
function narPlace(s) {
  const D = +(S.p.narration || {}).duration || 0; const n = s.nar || {};
  const at = Math.max(0, +n.at || 0); const i = clamp(+n.in || 0, 0, D); const o = n.out == null ? D : clamp(+n.out, i, D);
  return { at, in: i, out: o, D };
}
function narSet(s, v) { s.nar = { at: r2(v.at), in: r2(v.in), out: r2(v.out) }; }
function bgmPlace(s) {
  const b = bgmSettings(); const total = outLen(s, { noBgm: true }); const D = +b.duration || 0;
  const at = clamp(+b.at || 0, 0, MAX_OUT - 0.5); const inn = Math.max(0, +b.in || 0);
  const until = b.until == null ? Math.max(total, at + 0.5) : clamp(+b.until, at + 0.5, MAX_OUT);
  return { at, in: inn, until, D, total };
}
function clampOverlays(s) { ovsOf(s).forEach(o => { o.at = r2(clamp(o.at, 0, Math.max(0, MAX_OUT - clipOut(o)))); }); }
function thumbsInto(el, srcId, s0, width, pps, H) {   // 필름스트립에서 구간의 프레임만 골라 채운다
  const f = stripFor(srcId); if (!f || !f.count) return;
  const tw = f.fw * H / f.fh, sc = H / f.fh, n = Math.ceil(width / tw);
  for (let k = 0; k < n; k++) {
    const t = s0 + (k * tw + tw / 2) / pps; const idx = clamp(Math.floor(t / f.interval), 0, f.count - 1);
    const d = document.createElement("div"); d.className = "th"; d.style.left = k * tw + "px"; d.style.width = Math.ceil(tw) + "px";
    d.style.backgroundImage = `url(/media/${S.p.id}/${f.file})`; d.style.backgroundSize = `${f.cols * f.fw * sc}px ${f.rows * f.fh * sc}px`;
    d.style.backgroundPosition = `${-(idx % f.cols) * f.fw * sc}px ${-Math.floor(idx / f.cols) * f.fh * sc}px`;
    el.appendChild(d);
  }
}
function handles(el) { const hl = document.createElement("div"); hl.className = "tk-h left"; const hr = document.createElement("div"); hr.className = "tk-h right"; el.appendChild(hl); el.appendChild(hr); }
function mkRow(r) { const d = document.createElement("div"); d.className = "tk-row k-" + r.kind; /* k- 접두: 홈 화면의 .main 등과 이름이 겹치지 않게 */ d.dataset.key = r.key; d.style.top = r.top + "px"; d.style.height = r.h + "px"; return d; }
function drawTrack() {
  const s = cur(); if (!s || !tkVisible()) return; const cs = clipsOf(s); const { offs } = clipOffsets(s); const mainEnd = totalLen(s); const end = outLen(s);
  if (!S.tkDrag) S.tkSpan = Math.max(S.tkSpan || 0, clamp(end * 1.15 + 2, 30, MAX_OUT + 5));   // 눈금 범위: 내용이 늘면 따라 커지고, 줄어도 그대로(축척·기준 위치 유지). 「맞춤」이 다시 맞춘다
  const total = S.tkSpan; const pps = tkPps(); $("#tkZoom").max = zoomMax();
  const { rows, height } = tkRows(s); S.tkRows = rows; const n = layersOf(s);
  S.tkContentH = height; applyTrackArea(); $("#tkLabels").style.minHeight = "0"; $("#tkLabelsIn").style.height = (height + 2) + "px";
  tkIn.style.width = Math.max(tk.clientWidth - 2, total * pps + TK_PAD * 2) + "px";
  const step = [0.5, 1, 2, 5, 10, 15, 30, 60].find(x => x * pps >= 70) || 60; const ruler = $("#tkRuler"); ruler.innerHTML = "";
  for (let t = 0; t <= total + 1e-6; t += step) { const sp = document.createElement("span"); sp.style.left = t * pps + "px"; sp.textContent = fmt(t, step < 1 ? 1 : 0); ruler.appendChild(sp); const i = document.createElement("i"); i.style.left = t * pps + "px"; ruler.appendChild(i); }
  // 왼쪽 라벨
  const lb = $("#tkLabelsIn"); lb.innerHTML = "";
  rows.forEach(r => {
    const d = document.createElement("div"); d.className = "tk-lb k-" + r.kind; d.style.top = r.top + "px"; d.style.height = r.h + "px";
    if (r.kind === "txt") { const lanes = txtLanesOf(s); const empty = !txtsOf(s).some(t => txtLane(t) === r.lane);
      d.innerHTML = `<span title="자유 위치 텍스트. 위 트랙이 화면에서도 위층입니다">텍스트 ${r.lane}</span><span class="btns">${(r.lane === lanes && lanes > 1 && empty) ? `<button data-act="txt-lane-rm" data-lane="${r.lane}" title="빈 텍스트 트랙을 없앱니다">−</button>` : ""}<button data-act="txt-lane-add" title="텍스트 트랙을 하나 더 만듭니다">＋</button></span>`; }
    else if (r.kind === "subs") d.innerHTML = `<span title="자막(읽기 전용 표시). 누르면 그 자막으로 이동합니다">자막 <small class="dim">${shortCues(s).length}</small></span>`;
    else if (r.kind === "aud") {
      const lanes = audLanesOf(s); const empty = !audsOf(s).some(a => audLane(a) === r.lane);
      d.innerHTML = `<span title="효과음·오디오 파일이 놓이는 줄. 항목을 위아래로 끌어 다른 오디오 트랙으로 옮길 수 있습니다">오디오 ${r.lane}</span><span class="btns">${(r.lane === lanes && lanes > 1 && empty) ? `<button data-act="aud-lane-rm" data-lane="${r.lane}" title="빈 오디오 트랙을 없앱니다">−</button>` : ""}<button data-act="aud-lane-new" title="오디오 트랙을 하나 더 만듭니다">＋</button></span>`;
    } else if (r.kind === "layer") {
      const empty = !ovsOf(s).some(o => ovLayer(o) === r.layer);
      d.innerHTML = `<span>영상 ${r.layer + 1}</span><span class="btns">${(r.layer === n && n > 1 && empty) ? `<button data-act="del-layer" data-layer="${r.layer}" title="빈 트랙을 없앱니다">−</button>` : ""}<button data-act="layer-new" title="영상 트랙을 하나 더 만듭니다">＋</button></span>`;
    } else if (r.kind === "main") d.innerHTML = `<span title="주 영상 트랙. 파일은 왼쪽 「미디어」에서 넣습니다">영상 1</span><button data-act="layer-new" title="영상 트랙을 하나 더 만듭니다">＋</button>`;
    else if (r.kind === "nar") d.innerHTML = `<span title="낭독은 오른쪽 「낭독·소리」의 「낭독 넣기」로 넣습니다">낭독</span>`;
    else if (r.kind === "mask") d.innerHTML = `<span title="구간 지정 가리기 영역. 막대를 끌어 위치를, 양끝으로 구간을 바꿉니다">가리기</span>`;
    else d.innerHTML = `<span title="배경음악은 왼쪽 「음악·전환」에서 고릅니다">음악</span>`;
    lb.appendChild(d);
  });
  // 줄
  const box = $("#tkRows"); box.innerHTML = "";
  rows.forEach(r => {
    const row = mkRow(r);
    if (r.kind === "layer") {
      let any = false;
      ovsOf(s).forEach((o, k) => {
        if (ovLayer(o) !== r.layer) return; any = true;
        const el = document.createElement("div"); el.className = "tk-item tk-ov" + (S.selKind === "ov" && k === S.oi ? " on" : ""); el.dataset.kind = "ov"; el.dataset.i = k;
        const width = Math.max(6, clipOut(o) * pps); el.style.left = o.at * pps + "px"; el.style.width = width + "px";
        thumbsInto(el, o.src, o.s, width, pps * (playOut(o) / Math.max(0.01, clipOut(o))) / spdOf(o), r.h);
        const lab = document.createElement("span"); lab.className = "tk-lab"; lab.textContent = `${srcLetter(o.src)}${srcTitle(o.src)} · ${clipOut(o).toFixed(1)}s${clipBadge(o)}`; el.appendChild(lab); handles(el);
        const hasA = srcInfo(o.src).has_audio !== false;   // 소리 켜기/끄기 단추(기본 끔). 원본에 소리가 없으면 비활성
        const aon = ovAudioOn(o) && hasA;
        const snd = document.createElement("button"); snd.className = "tk-snd" + (aon ? " on" : ""); snd.textContent = aon ? "🔊" : "🔇"; snd.disabled = !hasA;
        snd.title = hasA ? (aon ? "소리 켜짐 — 누르면 끕니다" : "소리 꺼짐 — 누르면 이 조각의 소리를 함께 넣습니다") : "이 영상엔 소리가 없습니다"; el.appendChild(snd);
        el.title = `영상 ${r.layer + 1} · ${fmt(o.at, 1)}부터 ${clipOut(o).toFixed(1)}초 (원본 ${fmt(o.s, 1)}–${fmt(o.e, 1)}${clipBadge(o)})\n끌어서 좌우 위치·위아래 트랙 이동 · 양끝: 길이 · Alt+끌기: 원본 구간 밀기`; row.appendChild(el);
      });
      if (!any) row.innerHTML = `<div class="tk-hint">${r.layer === 1 ? "아래 조각을 끌어 올리거나 ＋ 로 파일을 얹으세요 — 이 구간엔 아래층 대신 보입니다(소리 없음)" : "빈 트랙"}</div>`;
    } else if (r.kind === "main") {
      cs.forEach((c, i) => {
        if (isGapClip(c)) {                              // 빈 구간(검정): 선택·끌기 대상이 아닌 점선 자리. 오른쪽 클릭으로 지우기·길이
          const g = document.createElement("div"); g.className = "tk-gap"; g.dataset.gap = i; g.style.left = offs[i] * pps + "px"; g.style.width = Math.max(4, clipOut(c) * pps) + "px";
          g.textContent = clipOut(c) >= 1.2 ? `빈 구간 ${clipOut(c).toFixed(1)}s` : ""; g.title = `빈 구간 ${clipOut(c).toFixed(1)}초 (렌더에선 검정) — 오른쪽 클릭: 지우기·길이 바꾸기`;
          row.appendChild(g); return;
        }
        const el = document.createElement("div"); el.className = "tk-item tk-clip" + (S.selKind === "clip" && i === S.ci ? " on" : "") + ((c.src && c.src !== "main") ? " ext" : "");
        el.dataset.kind = "clip"; el.dataset.i = i; const width = Math.max(6, clipOut(c) * pps); el.style.left = offs[i] * pps + "px"; el.style.width = width + "px";
        thumbsInto(el, c.src, c.s, width, pps / spdOf(c), r.h);
        const hasA = srcInfo(c.src).has_audio !== false;   // 조각별 소리 켜기/끄기(원본에 소리가 없으면 비활성)
        const snd = document.createElement("button"); snd.className = "tk-snd" + (hasA && !c.mute ? " on" : ""); snd.textContent = hasA && !c.mute ? "🔊" : "🔇"; snd.disabled = !hasA;
        snd.title = hasA ? (c.mute ? "이 조각 무음 — 누르면 소리를 켭니다" : "소리 켜짐 — 누르면 이 조각만 무음으로") : "이 영상엔 소리가 없습니다"; el.appendChild(snd);
        const lab = document.createElement("span"); lab.className = "tk-lab"; lab.textContent = `${i + 1} ${srcLetter(c.src)}${srcTitle(c.src)} · ${clipOut(c).toFixed(1)}s${clipBadge(c)}`; el.appendChild(lab); handles(el);
        el.title = `${clipLabel(c, i)}\n영상 1 은 빈틈 없이 이어 붙는 기본 트랙입니다. 끌어서 순서 바꾸기 · 끝 너머로 끌면 그 사이가 빈 화면(검정)으로 채워짐 · 자유롭게 겹쳐 놓으려면 위 트랙(영상 2)으로 올리기 · 양끝: 길이 · Alt+끌기: 구간 밀기`; row.appendChild(el);
      });
      cs.forEach((c, i) => {                          // 조각 사이 전환 단추(경계 위)
        if (i === 0 || isGapClip(c) || isGapClip(cs[i - 1])) return; const tr = trAt(s, i); const b = document.createElement("div"); b.className = "tk-tr" + (tr.type !== "none" ? " on" : ""); b.dataset.j = i;
        b.style.left = (offs[i] + tr.dur / 2) * pps + "px"; b.textContent = tr.type !== "none" ? "⇆" : "|";
        b.title = tr.type !== "none" ? `전환: ${(S.trNames || {})[tr.type] || tr.type} ${tr.dur.toFixed(1)}초 — 누르면 바꾸기` : "전환 없음 — 누르면 고르기";
        b.addEventListener("pointerdown", ev => { ev.stopPropagation(); ev.preventDefault(); openTrMenu(i, ev.clientX, ev.clientY); });
        b.addEventListener("contextmenu", ev => { ev.preventDefault(); ev.stopPropagation(); openTrMenu(i, ev.clientX, ev.clientY); });
        row.appendChild(b);
      });
    } else if (r.kind === "txt") {
      const ts = txtsOf(s);
      if (S.tkDrag && S.tkDrag.kind === "txt" && S.tkDrag.op === "mv" && S.tkDrag.row && S.tkDrag.row.key === r.key && S.tkDrag.row0 && S.tkDrag.row0.key !== r.key) row.classList.add("drop");
      if (!ts.some(t => txtLane(t) === r.lane)) row.innerHTML = `<div class="tk-hint">${r.lane === 1 ? "＋ 또는 「Ｔ 텍스트」로 글자를 넣으면 여기 나타납니다 — 화면에서 끌어 옮기고 오른쪽 「텍스트」에서 고칩니다" : "빈 텍스트 트랙 — 항목을 끌어 올리거나 ＋ 로 넣으세요"}</div>`;
      ts.forEach((t, k) => {
        if (txtLane(t) !== r.lane) return;
        const el = document.createElement("div"); el.className = "tk-item tk-bar txt" + (S.selKind === "txt" && S.ti === k ? " on" : ""); el.dataset.kind = "txt"; el.dataset.i = k;
        el.style.left = (+t.at || 0) * pps + "px"; el.style.width = Math.max(6, (+t.dur || 0) * pps) + "px";
        el.innerHTML = `<span>Ｔ ${esc((t.text || "").split("\n")[0].slice(0, 30) || "(빈 텍스트)")} · ${(+t.dur || 0).toFixed(1)}s</span>`; handles(el);
        el.title = "끌어서 시작 시각 이동 · 양끝: 시작·끝 · Q/S/W 자르기·나누기 · Delete 삭제"; row.appendChild(el);
      });
    } else if (r.kind === "subs") {
      const cues = shortCues(s);
      if (!cues.length) row.innerHTML = `<div class="tk-hint">자막 없음 — 낭독을 넣거나 자막 도구에서 만들면 여기 나타납니다</div>`;
      cues.forEach(c => {
        const el = document.createElement("div"); el.className = "tk-cue"; el.dataset.cue = c.id; el.style.left = c.out_s * pps + "px"; el.style.width = Math.max(4, (c.out_e - c.out_s) * pps - 2) + "px";
        el.textContent = c.text; el.title = `${fmt(c.out_s, 1)}–${fmt(c.out_e, 1)} ${c.text}\n가운데를 끌면 시각 이동, 양끝을 끌면 시작·끝 조절 · 오른쪽 클릭: 글자 고치기`;
        el.onpointermove = ev => { const r = el.getBoundingClientRect(); el.style.cursor = (ev.clientX < r.left + 12 || ev.clientX > r.right - 12) ? "ew-resize" : "grab"; };
        el.onpointerdown = ev => {                     // 끌기: 가운데 = 시각 이동, 양끝 12px = 시작·끝 조절. 안 움직이면 클릭(이동+목록 표시)
          ev.stopPropagation(); ev.preventDefault();
          const master = S.p.cues.find(q => q.id === c.id); if (!master) return;
          const rect = el.getBoundingClientRect(); const zone = ev.clientX < rect.left + 12 ? "s" : ev.clientX > rect.right - 12 ? "e" : "mv";
          const spd = (!isShop() || !(S.p.narration && S.p.narration.url)) && clipsOf(s)[c.ci] ? spdOf(clipsOf(s)[c.ci]) : 1;   // 조각 기준 자막: 화면 1초 = 원본 spd초
          const x0 = ev.clientX, s0 = +master.s, e0 = +master.e, pps0 = tkPps(); let moved = false;
          const mv = e2 => {
            const dt = (e2.clientX - x0) / pps0 * spd; if (!moved && Math.abs(e2.clientX - x0) < 4) return; moved = true;
            if (zone === "mv") { const ns = Math.max(0, s0 + dt); master.s = r2(ns); master.e = r2(ns + (e0 - s0)); }
            else if (zone === "s") master.s = r2(clamp(s0 + dt, 0, e0 - 0.2));
            else master.e = r2(Math.max(s0 + 0.2, e0 + dt));
            drawTrack(); showSub(vid.currentTime);
          };
          const up = () => {
            window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up);
            if (!moved) { seekOut(c.out_s + 0.02); const li = $$(".cue").find(x => +x.dataset.id === c.id); if (li) li.scrollIntoView({ block: "center", behavior: "smooth" }); return; }
            renderCues(); markDirty(); toast(zone === "mv" ? "자막 시각을 옮겼습니다" : "자막 길이를 바꿨습니다");
          };
          window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
        };
        el.style.cursor = "grab";
        row.appendChild(el);
      });
    } else if (r.kind === "aud") {
      if (S.tkDrag && S.tkDrag.kind === "aud" && S.tkDrag.op === "mv" && S.tkDrag.row && S.tkDrag.row.key === r.key && S.tkDrag.row0 && S.tkDrag.row0.key !== r.key) row.classList.add("drop");
      let any = false;
      audsOf(s).forEach((a, i) => {
        if (audLane(a) !== r.lane) return; any = true; const g = audPlace(a);
        const el = document.createElement("div"); el.className = "tk-item tk-bar aud" + (S.selKind === "aud" && S.ai === i ? " on" : ""); el.dataset.kind = "aud"; el.dataset.i = i;
        el.style.left = g.at * pps + "px"; el.style.width = Math.max(6, (g.out - g.in) * pps) + "px";
        el.innerHTML = `<span>🔊 ${esc(a.title || "오디오")} ${(g.out - g.in).toFixed(1)}s${g.in > 0.05 ? ` (파일 ${fmt(g.in, 1)}부터)` : ""}${g.vol !== 1 ? ` · ${Math.round(g.vol * 100)}%` : ""}</span>`; handles(el);
        el.title = "끌어서 좌우 위치·위아래 트랙 이동 · 양끝: 파일 안의 구간 · Alt+끌기: 구간 밀기 · Q/S/W 로 자르기·나누기"; row.appendChild(el);
      });
      if (!any) row.innerHTML = `<div class="tk-hint">${r.lane === 1 ? "왼쪽 「효과음」의 ＋ 나 「＋ 오디오 파일」로 넣습니다" : "빈 오디오 트랙 — 항목을 끌어 올리거나 ＋ 로 파일을 넣으세요"}</div>`;
    } else if (r.kind === "nar") {
      if (isShop() && S.p.narration && S.p.narration.url) {
        const nn = narPlace(s); const el = document.createElement("div"); el.className = "tk-item tk-bar nar" + (S.selKind === "nar" ? " on" : ""); el.dataset.kind = "nar"; el.dataset.i = 0;
        el.style.left = nn.at * pps + "px"; el.style.width = Math.max(6, (nn.out - nn.in) * pps) + "px";
        el.innerHTML = `<span>🎙 낭독 ${(nn.out - nn.in).toFixed(1)}s${nn.in > 0.05 ? ` (파일 ${fmt(nn.in, 1)}부터)` : ""}${nn.at > 0.05 ? ` · ${fmt(nn.at, 1)}에 시작` : ""}</span>`; handles(el);
        el.title = "끌어서 시작 시각 이동 · 양끝: 낭독 파일 안의 구간 · Alt+끌기: 구간 밀기 (자막이 같이 따라갑니다)"; row.appendChild(el);
      } else row.innerHTML = `<div class="tk-hint">${isShop() ? "＋ 로 낭독(mp3·wav)을 넣으면 받아써서 자막을 만듭니다" : "낭독 트랙은 쇼핑 쇼츠에서 씁니다"}</div>`;
    } else if (r.kind === "mask") {
      /* 구간 지정 가리기 막대는 drawMaskBars() 가 그린다 — 여기 두지 않으면 마지막 else(음악)로 떨어져 음악 막대가 겹쳐 그려졌다(2026-09-14 사용자 제보) */
    } else {
      const b = bgmSettings();
      if (bgmOn(b) && !s.bgm_off) {
        const g = bgmPlace(s); const el = document.createElement("div"); el.className = "tk-item tk-bar bgm" + (S.selKind === "bgm" ? " on" : ""); el.dataset.kind = "bgm"; el.dataset.i = 0;
        el.style.left = g.at * pps + "px"; el.style.width = Math.max(6, (g.until - g.at) * pps) + "px";
        el.innerHTML = `<span>♪ ${esc(b.title || b.file || "음악")}${g.in > 0.05 ? ` (곡 ${fmt(g.in)}부터)` : ""} · ${Math.round((b.volume != null ? b.volume : 0.15) * 100)}%</span>`; handles(el);
        el.title = "끌어서 시작 시각 이동 · 왼쪽 끝: 시작 · 오른쪽 끝: 끝 · Alt+끌기: 곡 안에서 시작점 밀기"; row.appendChild(el);
      } else row.innerHTML = `<div class="tk-hint">${s.bgm_off ? TERMn() + " 음악을 끔(음악·전환 절에서 켤 수 있음)" : "＋ 로 배경음악을 고릅니다"}</div>`;
    }
    box.appendChild(row);
  });
  // 본편 끝(빗금 시작)과 결과 끝(주황 점선) 표시
  const vidRows = rows.filter(r => r.kind === "main" || r.kind === "layer"); const vt = vidRows[0].top, vb = vidRows[vidRows.length - 1].top + vidRows[vidRows.length - 1].h;
  if (end > mainEnd + 0.05) { const sh = document.createElement("div"); sh.className = "tk-mainend"; sh.style.left = (TK_PAD + mainEnd * pps) + "px"; sh.style.width = ((end - mainEnd) * pps) + "px"; sh.style.top = vt + "px"; sh.style.height = (vb - vt) + "px"; sh.title = "본편이 끝난 뒤 구간: 검정 화면에 위층·소리만 나갑니다"; box.appendChild(sh); }
  const em = document.createElement("div"); em.className = "tk-end"; em.style.left = (TK_PAD + end * pps) + "px"; em.innerHTML = `<span>끝 ${fmt(end, 1)}</span>`; box.appendChild(em);
  if (SHORTS_LIMIT <= S.tkSpan) {                    // 쇼츠 한계(3분) 노란 선: 넘어도 편집·렌더는 되지만 쇼츠로는 못 올린다
    const lm = document.createElement("div"); lm.className = "tk-limit"; lm.style.left = (TK_PAD + SHORTS_LIMIT * pps) + "px"; lm.innerHTML = `<span>쇼츠 한계 3:00</span>`; lm.title = "유튜브 쇼츠는 3분까지입니다. 이 선을 넘는 결과물은 일반 영상으로만 올릴 수 있습니다"; box.appendChild(lm);
  }
  $("#tkDel").disabled = S.selKind === "clip" && cs.length <= 1;
  $("#tkLayerAdd").disabled = n >= MAX_LAYERS;
  drawMaskBars();
  drawTrackPh();
}
/* 트랙 「가리기」 줄: 구간 지정 영역마다 막대 하나. 끌면 이동, 양끝은 구간(2026-09-14) */
function drawMaskBars() {
  const row = $('.tk-row[data-key="mask"]'); if (!row) return; const s = cur(); if (!s) return; const pps = tkPps(); const m = maskSettings(); const all = maskRects(m); const len = outLen(s);
  maskRangedRects().forEach(r => {
    const i = all.indexOf(r); if (i < 0) return; const at = +r.at || 0, un = r.until != null ? +r.until : len;
    const el = document.createElement("div"); el.className = "tk-mask" + (S.mkSel === i ? " on" : ""); el.style.left = (TK_PAD + at * pps) + "px"; el.style.width = Math.max(6, (un - at) * pps) + "px";
    el.innerHTML = `<span>${KIND_KO[rectKind(m, r)] || "가리기"} ${i + 1}</span><div class="h l"></div><div class="h r"></div>`; el.title = `${fmt(at, 1)} ~ ${fmt(un, 1)} · 끌어서 옮기기, 양끝으로 구간`;
    el.addEventListener("pointerdown", e => {
      e.stopPropagation(); e.preventDefault(); if (e.button !== 0) return; vid.pause();
      const op = e.target.classList.contains("h") ? (e.target.classList.contains("l") ? "s" : "e") : "mv"; const x0 = e.clientX, a0 = +r.at || 0, b0 = r.until != null ? +r.until : len;
      S.mkSel = i; $$(".tk-mask.on", row).forEach(x => x.classList.remove("on")); el.classList.add("on"); try { el.setPointerCapture(e.pointerId); } catch (_) {}
      const mv = e2 => { const dt = (e2.clientX - x0) / pps; let a = a0, b = b0;
        if (op === "mv") { a = clamp(a0 + dt, 0, Math.max(0, len - (b0 - a0))); b = a + (b0 - a0); } else if (op === "s") a = clamp(a0 + dt, 0, b0 - 0.2); else b = clamp(b0 + dt, a0 + 0.2, len);
        r.at = r2(a); r.until = r2(b); el.style.left = (TK_PAD + a * pps) + "px"; el.style.width = Math.max(6, (b - a) * pps) + "px"; el.title = `${fmt(a, 1)} ~ ${fmt(b, 1)}`; maskTick(); };
      const up = () => { el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); el.removeEventListener("pointercancel", up); markDirty(); fillMask(); };
      el.addEventListener("pointermove", mv); el.addEventListener("pointerup", up); el.addEventListener("pointercancel", up);
    });
    el.addEventListener("dblclick", e => { e.stopPropagation(); seekOut(+r.at || 0); });
    row.appendChild(el);
  });
}
function drawTrackPh() {
  const s = cur(); if (!s || !tkVisible()) return; const x = Math.max(0, outTime(s, vid.currentTime)) * tkPps(); $("#tkPh").style.left = (x + TK_PAD) + "px";
  if (!vid.paused && (x < tk.scrollLeft || x > tk.scrollLeft + tk.clientWidth - 30)) tk.scrollLeft = Math.max(0, x - 60);   // 재생 중이면 빨간 선을 따라간다
}
function selectClip(i, seek) {
  const s = cur(); const cs = clipsOf(s); i = clamp(i, 0, cs.length - 1); S.ci = i; S.selKind = "clip";
  if (seek) S.playIdx = i;                          // 선택만 할 때는 빨간 선(playIdx)을 건드리지 않는다
  renderClipBar(); fillTrimFields(); focusClipWindow(); drawTimeline();
  if (seek) { exitTail(); vid.pause(); seekTo(cs[i].s, cs[i].src); }
}
function select(kind, i, seek) {
  const s = cur(); if (kind === "clip") return selectClip(i, seek);
  S.selKind = kind; if (kind === "ov") S.oi = clamp(i, 0, Math.max(0, ovsOf(s).length - 1)); if (kind === "aud") S.ai = clamp(i, 0, Math.max(0, audsOf(s).length - 1));
  if (kind === "txt") S.ti = clamp(i, 0, Math.max(0, txtsOf(s).length - 1));
  if (kind === "aud") { const a = audsOf(s)[S.ai]; if (a) S.audLane = audLane(a); }
  if (kind === "txt") { const t = txtsOf(s)[S.ti]; if (t) S.txtLane = txtLane(t); }
  drawTrack(); fillTxtPanel(); fillAudPanel();
  if (seek) seekOut(kind === "ov" ? (ovsOf(s)[S.oi] || {}).at || 0 : kind === "nar" ? narPlace(s).at : kind === "aud" ? audPlace(audsOf(s)[S.ai]).at : kind === "txt" ? (+(txtsOf(s)[S.ti] || {}).at || 0) : bgmPlace(s).at);
}
function seekOut(T) {                                // 결과 영상 시각 → 해당 조각의 원본 시각으로 이동(본편 뒤면 꼬리 시계)
  const s = cur(); const cs = clipsOf(s); const { offs, total } = clipOffsets(s); const end = outLen(s);
  if (T > total + 0.02 && end > total + 0.05) { enterTailAt(clamp(T, total, end - 0.02), false); return; }
  exitTail(); T = clamp(T, 0, Math.max(0, total - 0.05));
  let i = cs.length - 1; for (let k = 0; k < cs.length; k++) { if (T < offs[k] + clipOut(cs[k])) { i = k; break; } }
  S.playIdx = i;
  if (i !== S.ci) { const keep = S.selKind; selectClip(i, false); S.selKind = keep; if (keep !== "clip") drawTrack(); }
  vid.pause();
  const rel = T - offs[i];
  if (rel >= playOut(cs[i]) - 0.02 && holdOf(cs[i]) > 0) { enterHoldAt(i, T, false); return; }   // 멈춤 구간
  seekTo(Math.min(cs[i].e, cs[i].s + rel * spdOf(cs[i])), cs[i].src);
}
/* 위층 미리보기: 결과 시각에 걸린 위층 조각 중 가장 높은 층을 두 번째 <video> 로 본편 위에 보인다 */
function ovSync() {
  const s = cur(); const hide = () => { if (!ovVid.classList.contains("hidden")) { ovVid.classList.add("hidden"); ovVid.pause(); } };
  if (!s || !tkVisible()) return hide();
  const T = outTime(s, vid.currentTime); const hits = ovsOf(s).filter(o => T >= o.at - 0.02 && T < o.at + clipOut(o));
  if (!hits.length) return hide();
  const o = hits.sort((a, b) => ovLayer(b) - ovLayer(a))[0];
  if (ovVid.dataset.src !== o.src) { ovVid.dataset.src = o.src; ovVid.src = srcMediaUrl(o.src); ovVid.load(); }
  const x = srcInfo(o.src); const sw = x.width || 1920, sh = x.height || 1080; const l = L(); const st = S.p.settings; if (!l) return;
  const { cw, cx, cy } = cropRect(sw, sh, st.ratio || "16:9", st.zoom, 0, 0); const scale = l.band_w / cw;
  ovVid.style.width = (sw * scale) + "px"; ovVid.style.height = (sh * scale) + "px"; ovVid.style.left = (-cx * scale) + "px"; ovVid.style.top = (-cy * scale) + "px";
  const rel = T - o.at; const inHold = rel >= playOut(o) - 0.02;
  const want = inHold ? Math.max(o.s, o.e - 0.04) : o.s + rel * spdOf(o);
  const ovPlaying = isPlaying() && !inHold && !vid.seeking;
  if (!ovPlaying || ovVid.paused) { if (Math.abs(ovVid.currentTime - want) > 0.08) ovVid.currentTime = want; }
  else { const d = ovVid.currentTime - want; if (d > 0.25) { ovVid.pause(); } else if (d < -0.25) ovVid.currentTime = want; }   // 재생 중엔 뒤로 안 감는다: 앞서면 잠깐 멈춰 기다림
  if (ovVid.playbackRate !== spdOf(o)) ovVid.playbackRate = spdOf(o);
  ovVid.muted = !ovAudioOn(o); ovVid.volume = Math.min(1, mVol() * pVol());
  ovVid.classList.remove("hidden");
  if (ovPlaying) { if (ovVid.paused && ovVid.currentTime - want <= 0.08) ovVid.play().catch(() => {}); } else if (!ovVid.paused) ovVid.pause();
}
const rowOfItem = (s, kind, i) => kind === "clip" ? S.tkRows.find(r => r.kind === "main")
  : kind === "ov" ? S.tkRows.find(r => r.kind === "layer" && r.layer === ovLayer(ovsOf(s)[i]))
  : null;   // 텍스트·낭독·오디오·음악은 줄 이동이 없다(예전엔 여기서 예외가 나 끌기가 시작되지 않았다)
tk.addEventListener("pointerdown", e => {
  if (e.button !== 0) return; const s = cur(); if (!s) return; e.preventDefault();
  try { tk.setPointerCapture(e.pointerId); } catch (_) {}
  const h = e.target.closest(".tk-h"); const item = e.target.closest(".tk-item");
  const snd = e.target.closest(".tk-snd");
  if (snd && item && item.dataset.kind === "clip") {  // 영상 1 조각 무음 켜고 끄기
    if (snd.disabled) return; const c = clipsOf(s)[+item.dataset.i]; c.mute = !c.mute; S.selKind = "clip"; S.ci = +item.dataset.i;
    markDirty(); drawTrack(); applyMaster(); toast(c.mute ? "이 조각을 무음으로 했습니다(렌더에도 적용)" : "이 조각의 소리를 켰습니다"); return;
  }
  if (snd && item && item.dataset.kind === "ov") {   // 위층 조각 소리 켜고 끄기
    if (snd.disabled) return; const o = ovsOf(s)[+item.dataset.i]; o.audio = !ovAudioOn(o); S.selKind = "ov"; S.oi = +item.dataset.i;
    markDirty(); drawTrack(); ovSync(); toast(ovAudioOn(o) ? "이 조각의 소리를 켰습니다(아래 소리와 함께 섞입니다)" : "이 조각의 소리를 껐습니다"); return;
  }
  if (item) {
    const kind = item.dataset.kind, i = +item.dataset.i, x0 = tkPos(e);
    const snap = () => kind === "clip" ? { ...clipsOf(s)[i] } : kind === "ov" ? { ...ovsOf(s)[i] } : kind === "nar" ? narPlace(s) : kind === "aud" ? audPlace(audsOf(s)[i]) : kind === "txt" ? { ...txtsOf(s)[i] } : bgmPlace(s);
    if (e.ctrlKey || e.metaKey || e.shiftKey) {          // Ctrl/Shift+클릭: 복수 선택에 넣고 빼기. 이미 고른 항목을 Ctrl 든 채 끌면 묶음 이동
      if (S.msel.length > 1 && mselHas(kind, i) && !h) {
        S.tkDrag = { kind, op: "mv", i, x0, y0: e.clientY, c0: snap(), moved: false, el: item, to: i, row0: rowOfItem(s, kind, i), row: rowOfItem(s, kind, i), group: mselGroupFor(kind, i), toggleOnClick: true }; return;
      }
      if (!S.msel.length) mselAddPrimary(); mselToggle(kind, i); paintMsel(); return;
    }
    const already = (kind === "clip" && S.selKind === "clip" && i === S.ci) || (kind === "ov" && S.selKind === "ov" && i === S.oi) || (kind === "aud" && S.selKind === "aud" && i === S.ai) || (kind === "txt" && S.selKind === "txt" && i === S.ti) || (!["clip", "ov", "aud", "txt"].includes(kind) && S.selKind === kind);
    if (h) { vid.pause(); if (!already) select(kind, i, false); S.tkDrag = { kind, op: h.classList.contains("left") ? "s" : "e", i, x0, c0: snap() }; return; }
    if (e.altKey) { vid.pause(); if (!already) select(kind, i, false); S.tkDrag = { kind, op: "slip", i, x0, c0: snap() }; return; }
    S.tkDrag = { kind, op: "mv", i, x0, y0: e.clientY, c0: snap(), moved: false, el: item, to: i, row0: rowOfItem(s, kind, i), row: rowOfItem(s, kind, i), group: mselGroupFor(kind, i) }; return;
  }
  const yIn = e.clientY - tkIn.getBoundingClientRect().top;
  if (e.target.closest(".tk-ph") || yIn < 22) {       // 빨간 막대를 잡거나 눈금 줄을 누르면 재생 위치 이동(끌기 가능)
    S.tkDrag = { kind: "ph", resume: !vid.paused }; try { tk.setPointerCapture(e.pointerId); } catch (_) {}   // 트랙 밖으로 나가도 끌기가 이어진다(가장자리 자동 스크롤용)
    seekOut(tkPos(e) / tkPps()); return;
  }
  // 빈 곳: 끌면 상자 선택(걸치는 항목을 모두 고름), 그냥 클릭이면 복수 선택 해제. 빨간 막대는 막대·눈금 줄 끌기나 ←/→ 키로만
  if (!e.target.closest(".tk-tr") && !e.target.closest(".tk-snd")) S.tkDrag = { kind: "box", cx0: e.clientX, cy0: e.clientY, moved: false, add: e.ctrlKey || e.shiftKey };
});
tk.addEventListener("pointermove", e => {
  const d = S.tkDrag; if (!d) return; const s = cur(); const x = tkPos(e); const pps = tkPps();
  const dtRaw = (x - d.x0) / pps; const total = totalLen(s);
  if (d.kind === "ph") {                                                                        // 빨간 막대: 항목 경계에 붙는다
    // 화면 가장자리로 끌고 가면 트랙이 그쪽으로 따라 흐른다(2026-09-14 사용자 요청). 가장자리 40px 안에서 시작, 끝으로 갈수록 빠르게
    const r = tk.getBoundingClientRect(); const edge = 40; let dx = 0;
    if (e.clientX > r.right - edge) dx = Math.min(40, (e.clientX - (r.right - edge)) * 1.2 + 4);
    else if (e.clientX < r.left + edge) dx = -Math.min(40, ((r.left + edge) - e.clientX) * 1.2 + 4);
    if (dx) tk.scrollLeft = Math.max(0, tk.scrollLeft + dx);
    return seekOut(snapOut(x / pps, new Set(["ph"]), e));
  }
  const dt = (d.kind === "box" || (d.op === "mv" && (d.kind === "clip" || d.kind === "ov") && !d.group)) ? dtRaw : snapDt(d, dtRaw, e);
  if (d.kind === "box") {
    if (!d.moved && Math.abs(e.clientX - d.cx0) < 4 && Math.abs(e.clientY - d.cy0) < 4) return;
    d.moved = true; const r = tkIn.getBoundingClientRect(); const b = tkBoxEl();
    const l = Math.min(e.clientX, d.cx0) - r.left, t = Math.min(e.clientY, d.cy0) - r.top;
    b.style.left = l + "px"; b.style.top = t + "px"; b.style.width = Math.abs(e.clientX - d.cx0) + "px"; b.style.height = Math.abs(e.clientY - d.cy0) + "px"; b.classList.remove("hidden");
    d.rect = { l: Math.min(e.clientX, d.cx0), t: Math.min(e.clientY, d.cy0), r: Math.max(e.clientX, d.cx0), b: Math.max(e.clientY, d.cy0) };
    return;
  }
  if (d.op === "mv" && d.group) {                       // 묶음 이동: 선택된 자유 항목(위층·텍스트·오디오·낭독·음악)을 같은 만큼 옮긴다
    if (!d.moved && Math.abs(x - d.x0) < 8) return; d.moved = true; vid.pause();
    const minAt = Math.min(...d.group.map(g => g.at0)); const dd = Math.max(dt, -minAt);
    d.group.forEach(g => itemMoveTo(g, g.at0 + dd)); drawTrack(); layoutTexts(); paintMsel(); return;
  }
  if (d.op === "mv" && !d.moved) {
    if (Math.abs(x - d.x0) < 8 && Math.abs(e.clientY - (d.y0 || 0)) < 8) return; d.moved = true;
    if (S.moveBusy && d.kind === "clip") { S.tkDrag = null; return; }   // 빈 화면 준비 중엔 조각 끌기를 잠깐 막는다(두 번 옮겨지는 사고 방지)
  if (d.kind === "clip") { S.ci = d.i; S.playIdx = d.i; S.selKind = "clip"; } else { S.selKind = d.kind; if (d.kind === "ov") S.oi = d.i; if (d.kind === "aud") S.ai = d.i; if (d.kind === "txt") S.ti = d.i; vid.pause(); }
    if (d.el) d.el.classList.add("dragging");
  }
  if (d.op === "mv" && (d.kind === "clip" || d.kind === "ov")) {
    // 영상 조각 끌기: 좌우는 위치·순서, 위아래는 트랙 이동. 놓을 때 반영한다
    const dx = x - d.x0, dy = e.clientY - d.y0; d.el.style.transform = `translate(${dx}px,${dy}px)`;
    if (S.msel.length > 1 && mselHas(d.kind, d.i)) $$("#tkRows .tk-item.msel").forEach(el => { if (el !== d.el) { el.style.transform = `translate(${dx}px,${dy}px)`; el.classList.add("dragging"); } });
    const yIn = e.clientY - tkIn.getBoundingClientRect().top;
    d.row = S.tkRows.find(r => (r.kind === "main" || r.kind === "layer") && yIn >= r.top - 2 && yIn < r.top + r.h + 2) || d.row0;
    $$(".tk-row").forEach(r => r.classList.toggle("drop", r.dataset.key === d.row.key && d.row.key !== d.row0.key));
    const ins = $("#tkIns");
    if (d.row.kind === "main") {                      // 주 트랙에 끼울 자리
      const cs = clipsOf(s); const { offs } = clipOffsets(s);
      const w = d.kind === "clip" ? clipOut(cs[d.i]) : clipOut(ovsOf(s)[d.i]);
      const left0 = d.kind === "clip" ? offs[d.i] : ovsOf(s)[d.i].at; const center = (left0 + w / 2) * pps + dx;
      const others = cs.map((c, j) => j).filter(j => !(d.kind === "clip" && j === d.i));
      let to = 0; others.forEach(j => { if ((offs[j] + clipOut(cs[j]) / 2) * pps < center) to++; });
      d.to = to; const insX = to === 0 ? 0 : (offs[others[to - 1]] + clipOut(cs[others[to - 1]])) * pps;
      ins.classList.remove("hidden"); ins.style.left = (insX + TK_PAD - 1) + "px"; ins.style.top = (d.row.top - 2) + "px"; ins.style.height = (d.row.h + 4) + "px";
    } else ins.classList.add("hidden");
    return;
  }
  if (d.kind === "clip") {
    const cs = clipsOf(s); const c = cs[d.i];
    if (d.op === "slip") { const len = d.c0.e - d.c0.s; const ns = clamp(d.c0.s + dt, 0, durFor(c.src) - len); c.s = r2(ns); c.e = r2(ns + len); fillTrimFields(); drawTrack(); seekTo(c.s, c.src); return; }
    const k = spdOf(c);
    if (d.op === "s") c.s = r2(clamp(d.c0.s + dt * k, 0, c.e - 0.5));
    else { const r = stretchEnd(d.c0, dt, durFor(c.src), k); c.e = r.e; if (r.hold > 0) c.hold = r.hold; else delete c.hold; if (r.speed !== 1) c.speed = r.speed; else delete c.speed; }
    syncBounds(s); fillTrimFields(); updateLen(); drawTimeline(); drawTrack(); seekTo(d.op === "s" ? c.s : Math.max(c.s, c.e - 0.05), c.src); return;
  }
  if (d.kind === "ov") {
    const o = ovsOf(s)[d.i]; if (!o) return; const D = durFor(o.src); const c0 = d.c0;
    const k = spdOf(o);
    if (d.op === "s") { let ns = clamp(c0.s + dt * k, 0, c0.e - 0.5); ns = Math.max(ns, c0.s - c0.at * k); o.s = r2(ns); o.at = r2(c0.at + (ns - c0.s) / k); }
    else if (d.op === "e") { const r = stretchEnd(c0, dt, Math.min(D, o.s + (MAX_OUT - o.at) * k), k); o.e = r.e; if (r.hold > 0) o.hold = r.hold; else delete o.hold; if (r.speed !== 1) o.speed = r.speed; else delete o.speed; }
    else { const len = c0.e - c0.s; const ns = clamp(c0.s + dt, 0, Math.max(0, D - len)); o.s = r2(ns); o.e = r2(ns + len); }
    drawTrack(); seekOut(d.op === "e" ? o.at + clipOut(o) - 0.05 : o.at); return;
  }
  if (d.kind === "nar") {
    const c0 = d.c0; const v = { at: c0.at, in: c0.in, out: c0.out }; const len = c0.out - c0.in;
    if (d.op === "mv") v.at = clamp(c0.at + dt, 0, Math.max(0, MAX_OUT - len));
    else if (d.op === "s") { let ni = clamp(c0.in + dt, 0, c0.out - 0.5); ni = Math.max(ni, c0.in - c0.at); v.in = ni; v.at = c0.at + (ni - c0.in); }
    else if (d.op === "e") v.out = clamp(c0.out + dt, c0.in + 0.5, c0.D);
    else { const ni = clamp(c0.in + dt, 0, Math.max(0, c0.D - len)); v.in = ni; v.out = ni + len; }
    narSet(s, v); drawTrack(); renderCues(); return;
  }
  if (d.kind === "txt") {
    const t = txtsOf(s)[d.i]; if (!t) return; const c0 = d.c0; const at0 = +c0.at || 0, du0 = +c0.dur || 3;
    if (d.op === "mv" || d.op === "slip") t.at = r2(clamp(at0 + dt, 0, MAX_OUT - du0));
    else if (d.op === "s") { const na = clamp(at0 + dt, 0, at0 + du0 - 0.3); t.at = r2(na); t.dur = r2(du0 - (na - at0)); }
    else t.dur = r2(clamp(du0 + dt, 0.3, MAX_OUT - at0));
    if (d.op === "mv") {                              // 위아래로 끌면 다른 텍스트 트랙으로
      const yIn = e.clientY - tkIn.getBoundingClientRect().top;
      d.row0 = d.row0 || S.tkRows.find(r => r.kind === "txt" && r.lane === txtLane(t));
      d.row = S.tkRows.find(r => r.kind === "txt" && yIn >= r.top - 2 && yIn < r.top + r.h + 2) || d.row0;
    }
    drawTrack(); layoutTexts(); return;
  }
  if (d.kind === "aud") {
    const a = audsOf(s)[d.i]; if (!a) return; const c0 = d.c0; const v = { at: c0.at, in: c0.in, out: c0.out }; const len = c0.out - c0.in;
    if (d.op === "mv") v.at = clamp(c0.at + dt, 0, Math.max(0, MAX_OUT - len));
    else if (d.op === "s") { let ni = clamp(c0.in + dt, 0, c0.out - 0.3); ni = Math.max(ni, c0.in - c0.at); v.in = ni; v.at = c0.at + (ni - c0.in); }
    else if (d.op === "e") v.out = clamp(c0.out + dt, c0.in + 0.3, c0.D);
    else { const ni = clamp(c0.in + dt, 0, Math.max(0, c0.D - len)); v.in = ni; v.out = ni + len; }
    if (d.op === "mv") {                              // 위아래로 끌면 다른 오디오 트랙으로
      const yIn = e.clientY - tkIn.getBoundingClientRect().top;
      d.row0 = d.row0 || S.tkRows.find(r => r.kind === "aud" && r.lane === audLane(a));
      d.row = S.tkRows.find(r => r.kind === "aud" && yIn >= r.top - 2 && yIn < r.top + r.h + 2) || d.row0;
    }
    audSet(a, v); drawTrack(); return;
  }
  const b = bgmSettings(); const c0 = d.c0; const span = c0.until - c0.at;
  if (d.op === "mv") { b.at = r2(clamp(c0.at + dt, 0, MAX_OUT - 0.5)); b.until = r2(Math.min(MAX_OUT, b.at + span)); }
  else if (d.op === "s") { let na = clamp(c0.at + dt, 0, c0.until - 0.5); na = Math.max(na, c0.at - c0.in); b.at = r2(na); b.in = r2(c0.in + (na - c0.at)); }
  else if (d.op === "e") b.until = r2(clamp(c0.until + dt, c0.at + 0.5, MAX_OUT));
  else b.in = r2(clamp(c0.in + dt, 0, Math.max(0, (c0.D || 1e9) - 0.5)));
  const base = outLen(s, { noBgm: true }); if (b.until != null && Math.abs(b.until - base) < 0.3) b.until = null;   // 다른 트랙 끝에 맞추면 '끝까지'로 저장(길어져도 따라감)
  drawTrack();
});
tk.addEventListener("pointerup", e => {
  const d = S.tkDrag; if (!d) return; S.tkDrag = null; $("#tkIns").classList.add("hidden"); $$(".tk-row.drop").forEach(r => r.classList.remove("drop"));
  if (d.kind === "ph") { showSnap(null); if (d.resume) vid.play(); return; }
  $$("#tkRows .tk-item").forEach(el => { el.style.transform = ""; el.classList.remove("dragging"); });
  if (d.toggleOnClick && !d.moved) { mselToggle(d.kind, d.i); paintMsel(); return; }
  if (d.kind === "box") {
    tkBoxEl().classList.add("hidden");
    if (!d.moved) { if (S.msel.length) { mselClear(); paintMsel(); } return; }
    const hit = []; $$("#tkRows .tk-item").forEach(el => { const r = el.getBoundingClientRect(); if (r.right >= d.rect.l && r.left <= d.rect.r && r.bottom >= d.rect.t && r.top <= d.rect.b) hit.push(el); });
    if (!d.add) mselClear();
    hit.forEach(el => { const k = mselKeyOf(el.dataset.kind, +el.dataset.i); if (k && !S.msel.includes(k)) S.msel.push(k); });
    if (hit.length && !d.add) { const el = hit[0]; const keep = S.msel.slice(); select(el.dataset.kind, +el.dataset.i, false); S.msel = keep; }
    paintMsel(); if (S.msel.length > 1) toast(`${S.msel.length}개 선택 — 끌어서 함께 옮기고, Delete·Ctrl+C·Ctrl+X·Ctrl+D 가 전부에 적용됩니다`); return;
  }
  if (d.op === "mv" && d.group) {
    if (!d.moved) { if (d.el) d.el.classList.remove("dragging"); return; }
    markDirty(); updateLen(); ovSync(); audSync(isPlaying()); narSync(isPlaying()); bgmSync(isPlaying()); renderCues(); layoutTexts(); drawTrack(); paintMsel(); return;
  }
  if (d.op === "mv" && d.el) { d.el.classList.remove("dragging"); d.el.style.transform = ""; if (!d.moved) { if (S.msel.length) mselClear(); return select(d.kind, d.i, false); } }   // 클릭은 선택만(빨간 선은 그대로)
  const s = cur(); const cs = clipsOf(s); const ovs = ovsOf(s); const x = tkPos(e); const dt = snapDt(d, (x - d.x0) / tkPps(), e); showSnap(null);
  if (d.kind === "clip") {
    if (d.op !== "mv") return afterClipsChange(null);
    // 옮길 조각: 복수 선택에 이 조각이 들어 있으면 선택된 주 트랙 조각 전부(블록), 아니면 이 조각 하나
    const selIdx = (S.msel.length > 1 && mselHas("clip", d.i)) ? mselResolve().filter(m => m.kind === "clip").map(m => m.i).sort((a, b) => a - b) : [d.i];
    const { offs } = clipOffsets(s); const T0 = Math.max(0, outTime(s, vid.currentTime));
    const block = selIdx.map(k => cs[k]); const rest = cs.filter((c, k) => !selIdx.includes(k));
    const restTotal = rest.reduce((a, c) => a + clipOut(c), 0);
    const targetStart = Math.max(0, offs[d.i] + dt - (offs[d.i] - offs[selIdx[0]]));   // 블록 첫 조각이 놓일 결과 시각
    if (d.row.kind === "main") {
      // 자유 배치: 놓은 시각(T)이 다른 조각 위면 그 앞/뒤에 끼우고, 검정(빈 화면) 위면 검정을 갈라 그 자리에, 끝 너머면 사이를 검정으로 채운다.
      // 이어진 검정끼리는 합치고 0.05초 미만은 버린다 → 영상 1 은 빈틈이 검정으로 채워지는 '자유 트랙'처럼 움직인다
      const T = Math.max(0, targetStart); const isBlk = c => (srcInfo(c.src) || {}).kind === "black";
      if (selIdx.length === 1 && Math.abs(T - offs[d.i]) < 0.25 / Math.max(0.2, tkPps()) * tkPps() && Math.abs(dt) < 0.15) { drawTrack(); return; }   // 제자리
      const place = (fid) => {
        const out = []; let acc = 0, placed = false;
        for (const c of rest) {
          const len = clipOut(c);
          if (!placed && T < acc + len - 0.02) {
            if (isBlk(c) && fid && !c.speed && !c.hold) {                    // 검정 위: 갈라서 그 자리에
              const a = T - acc, b = len - a;
              if (a > 0.05) out.push({ ...c, e: r2(c.s + a) });
              out.push(...block);
              if (b > 0.05) out.push({ ...c, s: 0, e: r2(b) });
            } else if (T < acc + len / 2) out.push(...block, c); else out.push(c, ...block);
            placed = true;
          } else out.push(c);
          acc += len;
        }
        if (!placed) { const gap = T - acc; if (gap > 0.05 && fid) out.push({ s: 0, e: r2(gap), src: fid }); out.push(...block); }
        const merged = [];
        out.forEach(c => { const last = merged[merged.length - 1]; if (last && isBlk(last) && isBlk(c) && !last.speed && !c.speed && !last.hold && !c.hold) last.e = r2(last.e + clipOut(c)); else merged.push(c); });
        const finalCs = merged.filter(c => !isBlk(c) || clipOut(c) > 0.05);
        if (finalCs.length === cs.length && finalCs.every((c, k) => c === cs[k])) { drawTrack(); return; }
        cs.length = 0; cs.push(...finalCs);
        const first = cs.indexOf(block[0]); S.ci = first >= 0 ? first : 0;
        if (selIdx.length > 1) S.msel = block.map(b => "clip:" + cs.indexOf(b)).filter(k => !k.endsWith("-1")); else mselClear();
        afterClipsChange(null); seekOut(Math.min(T0, Math.max(0, outLen(s) - 0.05)));
        toast(selIdx.length > 1 ? `${selIdx.length}개 조각을 ${fmt(T, 1)} 자리로 옮겼습니다` : `${fmt(T, 1)} 자리로 옮겼습니다` + (!placed && T - acc > 0.05 && fid ? ` (앞은 ${(T - acc).toFixed(1)}초 빈 화면)` : ""));
      };
      if (S.moveBusy) { drawTrack(); return; }
      S.moveBusy = true;
      ensureBlackSource().then(id => place(id || null)).catch(() => place(null)).finally(() => { S.moveBusy = false; });
      return;
    }
    // 위 트랙으로: 선택된 조각 전부를 원래 결과 시각(+끈 만큼)에 얹는다. 주 트랙이 비면 같은 길이의 빈 화면(검정)을 깐다
    const layer = d.row.layer;
    const doMove = (fillerId) => {
      const totalBlock = block.reduce((a, c) => a + clipOut(c), 0);
      cs.length = 0; cs.push(...rest); if (!rest.length && fillerId) cs.push({ s: 0, e: r2(totalBlock), src: fillerId });
      const newKeys = [];
      selIdx.forEach(k => { const c = block[selIdx.indexOf(k)]; const id = newId(); ovs.push({ id, src: c.src || "main", s: c.s, e: c.e, at: r2(Math.max(0, offs[k] + dt)), layer, mute: c.mute, speed: c.speed, hold: c.hold }); newKeys.push("ov:" + id); });
      S.ci = clamp(S.ci, 0, cs.length - 1); S.selKind = "ov"; S.oi = ovs.length - 1; S.msel = newKeys.length > 1 ? newKeys : [];
      afterClipsChange(null); clampOverlays(s); drawTrack(); seekOut(Math.min(T0, Math.max(0, outLen(s) - 0.05))); ovSync(); renderMedia();
      toast(`${block.length > 1 ? block.length + "개를 " : ""}영상 ${layer + 1} 트랙으로 올렸습니다.` + (fillerId ? " 영상 1 에는 같은 길이의 빈 화면(검정)을 깔았습니다" : " 그 구간엔 아래 영상 대신 보입니다"));
    };
    if (rest.length) { doMove(null); return; }
    if (S.moveBusy) { drawTrack(); return; }
    S.moveBusy = true; toast("빈 화면(검정) 바탕을 준비하는 중…");
    ensureBlackSource().then(id => { if (id) doMove(id); else drawTrack(); }).finally(() => { S.moveBusy = false; });
    return;
  }
  if (d.kind === "ov") {
    if (d.op !== "mv") { markDirty(); updateLen(); ovSync(); return; }
    const o = ovs[d.i];
    if (d.row.kind === "main") {                      // 위층 → 주 트랙에 끼우기
      keepPlayhead(() => { ovs.splice(d.i, 1); cs.splice(d.to, 0, { s: o.s, e: o.e, src: o.src, speed: o.speed, hold: o.hold }); S.ci = d.to; S.selKind = "clip"; S.oi = 0; afterClipsChange(null); clampOverlays(s); drawTrack(); });
      ovSync(); return toast("영상 1(주 트랙)에 끼워 넣었습니다");
    }
    o.layer = d.row.layer; o.at = r2(clamp(d.c0.at + dt, 0, Math.max(0, MAX_OUT - clipOut(o))));
    markDirty(); updateLen(); ovSync(); return;
  }
  markDirty(); updateLen();
  if (d.kind === "nar") { renderCues(); narSync(isPlaying()); }
  if (d.kind === "bgm") bgmSync(isPlaying());
  if (d.kind === "aud") {
    const a = audsOf(s)[d.i]; if (a && d.op === "mv" && d.row && d.row.kind === "aud" && d.row.lane !== audLane(a)) { a.lane = d.row.lane; drawTrack(); toast(`오디오 ${a.lane} 트랙으로 옮겼습니다`); }
    audSync(isPlaying()); fillAudPanel();
  }
  if (d.kind === "txt") {
    const t = txtsOf(s)[d.i]; if (t && d.op === "mv" && d.row && d.row.kind === "txt" && d.row.lane !== txtLane(t)) { t.lane = d.row.lane; drawTrack(); renderTexts(); toast(`텍스트 ${t.lane} 트랙으로 옮겼습니다`); }
    layoutTexts(); fillTxtPanel();
  }
});
tk.addEventListener("pointercancel", () => { const d = S.tkDrag; S.tkDrag = null; $("#tkIns").classList.add("hidden"); $$(".tk-row.drop").forEach(r => r.classList.remove("drop")); if (d && d.el) { d.el.classList.remove("dragging"); d.el.style.transform = ""; } });
tk.addEventListener("wheel", e => { if (e.ctrlKey) { e.preventDefault(); setZoomKeepPh(S.tkZoom * (e.deltaY < 0 ? 1.2 : 1 / 1.2)); } else if (e.deltaY && !e.shiftKey) { tk.scrollLeft += e.deltaY; } }, { passive: false });
/* 확대: 1 = 전체가 한 화면. 긴 영상일수록 더 크게 확대할 수 있게 상한은 눈금 범위에 따라(약 8초가 한 화면이 될 때까지) */
const zoomMax = () => Math.max(10, Math.ceil((S.tkSpan || 30) / 8));
function setZoomKeepPh(z) {
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, vid.currentTime)); const phX = T * tkPps() - tk.scrollLeft;   // 빨간 막대의 화면 위치를 지킨다
  S.tkZoom = clamp(z, 0.2, zoomMax()); $("#tkZoom").max = zoomMax(); $("#tkZoom").value = S.tkZoom; drawTrack();   // 0.2 = 맞춤보다 더 작게(여백을 두고 보기)
  tk.scrollLeft = Math.max(0, T * tkPps() - phX);
}
$("#tkZoom").oninput = e => setZoomKeepPh(+e.target.value);
$("#tkZoomIn").onclick = () => setZoomKeepPh(S.tkZoom * 1.4);
$("#tkZoomOut").onclick = () => setZoomKeepPh(S.tkZoom / 1.4);
$("#tkFit").onclick = () => { S.tkSpan = 0; S.tkZoom = 1; $("#tkZoom").value = 1; drawTrack(); tk.scrollLeft = 0; };
$("#tkFull").onclick = () => {                     // 선택한 조각을 원본 전체 길이로
  const s = cur(); if (!s) return;
  if (S.selKind === "ov") { const o = ovsOf(s)[S.oi]; if (!o) return; o.s = 0; o.e = r2(durFor(o.src)); markDirty(); updateLen(); ovSync(); return toast("위층 조각을 원본 전체 길이로 늘렸습니다"); }
  if (S.selKind !== "clip") return toast("영상 조각을 고른 뒤 누르세요", true);
  const c = clipsOf(s)[S.ci]; keepPlayhead(() => { c.s = 0; c.e = r2(durFor(c.src)); afterClipsChange(null); }); toast("조각을 원본 전체 길이로 늘렸습니다(처음부터 끝까지)");
};
/* 트랙 영역 높이: 위 경계(손잡이)를 끌어 올리면 트랙이 커지고 미리보기가 줄어든다. 값은 브라우저에 기억 */
try { S.trackAreaH = +localStorage.getItem("trackAreaH") || 0; } catch (_) { S.trackAreaH = 0; }
function applyTrackArea() {
  const w = $("#trackWrap"); const bodyH = S.trackAreaH ? Math.max(60, S.trackAreaH - 52) : 0;    // 52 = 손잡이+도구줄+여백
  w.style.height = S.trackAreaH ? S.trackAreaH + "px" : "";
  tk.style.height = bodyH ? bodyH + "px" : ((S.tkContentH || 0) + 2) + "px";
  tk.style.overflowY = bodyH && (S.tkContentH || 0) + 2 > bodyH ? "auto" : "hidden";
  const lb = $("#tkLabels"); lb.style.height = tk.style.height; lb.style.overflow = "hidden"; lb.scrollTop = tk.scrollTop;
}
tk.addEventListener("scroll", () => { $("#tkLabels").scrollTop = tk.scrollTop; });
(() => {
  const g = $("#tkGrip"); if (!g) return; let y0 = 0, h0 = 0;
  g.addEventListener("pointerdown", e => { e.preventDefault(); y0 = e.clientY; h0 = $("#trackWrap").offsetHeight; g.setPointerCapture(e.pointerId); g.classList.add("on"); });
  g.addEventListener("pointermove", e => { if (!g.classList.contains("on")) return; S.trackAreaH = clamp(h0 + (y0 - e.clientY), 110, window.innerHeight - 260); applyTrackArea(); fitStage(); });
  g.addEventListener("pointerup", () => { g.classList.remove("on"); try { localStorage.setItem("trackAreaH", String(S.trackAreaH)); } catch (_) {} });
  g.addEventListener("dblclick", () => { S.trackAreaH = 0; try { localStorage.removeItem("trackAreaH"); } catch (_) {} applyTrackArea(); fitStage(); toast("트랙 높이를 자동으로 되돌렸습니다"); });
})();
$("#tkLayerAdd").onclick = () => { const s = cur(); if (!s) return; s.video_layers = Math.min(MAX_LAYERS, layersOf(s) + 1); markDirty(); drawTrack(); fitStage(); toast(`영상 ${s.video_layers + 1} 트랙을 만들었습니다. 조각을 끌어 올리거나 ＋ 로 파일을 얹으세요`); };
/* 조각 사이 전환 고르기(경계 단추·오른쪽 클릭 「앞 전환」): 종류와 길이. 조각의 tr_in 에 저장, 없애면 프로젝트 전체 설정을 따른다 */
function openTrMenu(i, x, y) {
  const s = cur(); const cs = clipsOf(s); if (i <= 0 || i >= cs.length) return;
  const cur0 = trAt(s, i); const names = S.trNames || { none: "없음", fade: "디졸브" }; const own = cs[i].tr_in && typeof cs[i].tr_in === "object" ? cs[i].tr_in : null;
  const setTr = (type, dur) => { cs[i].tr_in = { type, dur: dur != null ? dur : (own && own.dur) || cur0.dur || 0.5 }; keepPlayhead(() => afterClipsChange(null)); renderCues(); toast(type === "none" ? "전환을 없앴습니다" : `전환: ${names[type] || type} ${(cs[i].tr_in.dur).toFixed(1)}초`); };
  const items = Object.keys(names).map(k => ({ k: "t:" + k, label: (k === cur0.type ? "✓ " : "") + names[k], run: () => setTr(k) }));
  items.push("-");
  [0.3, 0.5, 0.8, 1.2].forEach(d => items.push({ k: "d:" + d, label: (Math.abs((own ? +own.dur : +((S.p.settings.transition || {}).dur || 0.5)) - d) < 0.01 ? "✓ " : "") + `길이 ${d.toFixed(1)}초`, dis: cur0.type === "none", run: () => setTr(cur0.type, d) }));
  items.push("-", { k: "all", label: "이 전환을 모든 경계에", dis: cur0.type === "none", run: () => { cs.forEach((c, k) => { if (k > 0) c.tr_in = { type: cur0.type, dur: (own && own.dur) || 0.5 }; }); keepPlayhead(() => afterClipsChange(null)); renderCues(); toast("모든 경계에 같은 전환을 걸었습니다"); } },
    { k: "clear", label: "모든 경계 전환 없애기", run: () => { cs.forEach(c => { delete c.tr_in; }); S.p.settings.transition = { type: "none", dur: 0.5, edges: !!(S.p.settings.transition || {}).edges }; keepPlayhead(() => afterClipsChange(null)); renderCues(); toast("전환을 모두 없앴습니다"); } });
  ctxShow(x, y, `${i}번 ↔ ${i + 1}번 조각 사이 전환`, items);
}
/* 속도·멈춤 대화 상자(간단 prompt). 자막 끝까지 늘리기 = 이 조각이 시작된 뒤 끝나는 마지막 자막·텍스트의 끝을 기본값으로 */
function itemStart(item, kind) { const s = cur(); if (kind === "ov") return item.at; const cs = clipsOf(s); const i = cs.indexOf(item); return clipOffsets(s).offs[Math.max(0, i)]; }
function suggestEnd(item, kind) {
  const s = cur(); const st = itemStart(item, kind); const en = st + clipOut(item); let best = 0;
  shortCues(s).forEach(c => { if (c.out_s < en + 0.01 && c.out_e > st) best = Math.max(best, c.out_e); });
  txtsOf(s).forEach(t => { const a = +t.at || 0, b = a + (+t.dur || 0); if (a < en + 0.01 && b > st) best = Math.max(best, b); });
  if (isShop() && S.p.narration && S.p.narration.url) { const n = narPlace(s); const b = n.at + (n.out - n.in); if (n.at < en + 0.01 && b > st) best = Math.max(best, b); }
  return best > en + 0.05 ? best : 0;
}
function timeFitDialog(item, kind, after) {
  const st = itemStart(item, kind); const sug = suggestEnd(item, kind); const curLen = clipOut(item);
  const v = prompt(`이 조각을 몇 초 길이로 만들까요? (지금 ${curLen.toFixed(1)}초, 원본 ${(item.e - item.s).toFixed(1)}초)` + (sug ? `\n자막·낭독 끝에 맞추면 ${(sug - st).toFixed(1)}초` : "") +
    `\n\n숫자 뒤에 '멈춤'을 붙이면 느리게 대신 마지막 장면을 멈춰 채웁니다 (예: 12 멈춤)`, sug ? (sug - st).toFixed(1) : curLen.toFixed(1));
  if (v == null) return; const m = String(v).trim().match(/^([\d.]+)\s*(멈춤|hold|freeze)?/i); if (!m) return toast("숫자를 넣어 주세요", true);
  const target = +m[1]; if (!(target > 0.3)) return toast("0.3초보다 길어야 합니다", true);
  const src = item.e - item.s;
  if (m[2]) { delete item.speed; item.hold = r2(Math.max(0, target - src)); }
  else { const k = src / target; if (k < 0.1 || k > 8) return toast("속도는 0.1배~8배 사이만 됩니다. 멈춤을 써 보세요", true); item.speed = r2(k); if (holdOf(item) && Math.abs(k - 1) > 1e-6) delete item.hold; }
  after(); toast(m[2] ? `마지막 장면을 ${holdOf(item).toFixed(1)}초 멈춰 ${target}초로 맞췄습니다` : `×${spdOf(item)} 속도로 ${target}초에 맞췄습니다`);
}
function speedDialog(item, kind, after) {
  const v = prompt("재생 속도 배율 (0.1~8). 1보다 작으면 느리게·길어지고, 크면 빠르게·짧아집니다. 소리는 음높이를 유지합니다", String(spdOf(item)));
  if (v == null) return; const k = +String(v).replace(/[^\d.]/g, ""); if (!(k >= 0.1 && k <= 8)) return toast("0.1~8 사이 숫자만 됩니다", true);
  if (Math.abs(k - 1) < 1e-6) delete item.speed; else item.speed = r2(k); after(); toast(`속도 ×${spdOf(item)} · 결과 ${clipOut(item).toFixed(1)}초`);
}
function holdDialog(item, kind, after) {
  const v = prompt("마지막 장면을 몇 초 멈춰 둘까요? (0 = 없음). 영상은 원래 속도로 끝까지 가고 남는 시간은 마지막 프레임이 정지 화면으로 채워집니다", holdOf(item).toFixed(1));
  if (v == null) return; const h = +String(v).replace(/[^\d.]/g, ""); if (!(h >= 0 && h <= 600)) return toast("0~600초 사이만 됩니다", true);
  if (h < 0.05) delete item.hold; else item.hold = r2(h); after(); toast(h < 0.05 ? "멈춤을 없앴습니다" : `마지막 장면 ${holdOf(item).toFixed(1)}초 멈춤 · 결과 ${clipOut(item).toFixed(1)}초`);
}
/* 선택한 항목과 빨간 선의 관계: 결과 시각 T, 항목의 시작·끝(결과 시각), 항목 안 원본 시각 local */
function selAtPlayhead() {
  const s = cur(); if (!s) return null; const T = Math.max(0, outTime(s, vid.currentTime));
  if (S.selKind === "clip") { const cs = clipsOf(s); const i = clamp(S.ci, 0, cs.length - 1); const { offs } = clipOffsets(s); const c = cs[i]; return { kind: "clip", c, i, T, local: Math.min(c.e, c.s + (T - offs[i]) * spdOf(c)), start: offs[i], end: offs[i] + clipOut(c), inHold: T - offs[i] >= playOut(c) - 0.02 }; }
  if (S.selKind === "ov") { const o = ovsOf(s)[S.oi]; if (!o) return null; return { kind: "ov", o, T, local: Math.min(o.e, o.s + (T - o.at) * spdOf(o)), start: o.at, end: o.at + clipOut(o), inHold: T - o.at >= playOut(o) - 0.02 }; }
  if (S.selKind === "nar") { const n = narPlace(s); return { kind: "nar", n, T, local: n.in + (T - n.at), start: n.at, end: n.at + (n.out - n.in) }; }
  if (S.selKind === "aud") { const a = audsOf(s)[S.ai]; if (!a) return null; const g = audPlace(a); return { kind: "aud", a, g, T, local: g.in + (T - g.at), start: g.at, end: g.at + (g.out - g.in) }; }
  if (S.selKind === "txt") { const t = txtsOf(s)[S.ti]; if (!t) return null; const at = +t.at || 0, du = +t.dur || 3; return { kind: "txt", t, T, local: T - at, start: at, end: at + du }; }
  const g = bgmPlace(s); return { kind: "bgm", g, T, local: g.in + (T - g.at), start: g.at, end: g.until };
}
function keepPlayhead(fn) {                          // 편집 전후로 빨간 막대의 결과 시각을 지킨다(내용이 짧아지면 끝으로)
  const s = cur(); const T = Math.max(0, outTime(s, vid.currentTime)); fn(); seekOut(Math.min(T, Math.max(0, outLen(s) - 0.05)));
}
function trimAtPlayhead(side) {                      // side: "left" = 빨간 선 왼쪽을 버림, "right" = 오른쪽을 버림
  const s = cur(); const x = selAtPlayhead(); if (!x) return;
  if (x.T <= x.start + 0.1 || x.T >= x.end - 0.1) return toast("빨간 선을 선택한 조각 안쪽(양끝에서 0.1초 이상)에 두고 자르세요", true);
  const left = side === "left";
  if ((x.kind === "clip" || x.kind === "ov") && x.inHold) {   // 멈춤 구간 안: 오른쪽 자르기는 멈춤 길이를 줄이고, 왼쪽 자르기는 의미가 없다
    if (left) return toast("멈춤 구간에서는 왼쪽 자르기를 할 수 없습니다. 빨간 선을 움직이는 구간으로 옮기세요", true);
    const item = x.kind === "clip" ? x.c : x.o; item.hold = r2(Math.max(0, x.T - (x.start + playOut(item))));
    if (x.kind === "clip") keepPlayhead(() => afterClipsChange(null)); else { markDirty(); updateLen(); drawTrack(); ovSync(); }
    return toast(`멈춤을 ${holdOf(item).toFixed(1)}초로 줄였습니다`);
  }
  if (x.kind === "clip") {
    keepPlayhead(() => { if (left) x.c.s = r2(x.local); else x.c.e = r2(x.local); afterClipsChange(null); });
  } else if (x.kind === "ov") {
    if (left) { x.o.s = r2(x.local); x.o.at = r2(x.T); } else x.o.e = r2(x.local);
    markDirty(); updateLen(); ovSync();
  } else if (x.kind === "nar") {
    narSet(s, left ? { at: x.T, in: x.local, out: x.n.out } : { at: x.n.at, in: x.n.in, out: x.local });
    markDirty(); updateLen(); renderCues(); narSync(isPlaying());
  } else if (x.kind === "aud") {
    audSet(x.a, left ? { at: x.T, in: x.local, out: x.g.out } : { at: x.g.at, in: x.g.in, out: x.local });
    markDirty(); updateLen(); audSync(isPlaying());
  } else if (x.kind === "txt") {
    if (left) { x.t.dur = r2(x.end - x.T); x.t.at = r2(x.T); } else x.t.dur = r2(x.T - x.start);
    markDirty(); updateLen(); layoutTexts();
  } else {
    const b = bgmSettings(); if (left) { b.at = r2(x.T); b.in = r2(x.local); } else b.until = r2(x.T);
    markDirty(); updateLen(); bgmSync(isPlaying());
  }
  toast(left ? "빨간 선 왼쪽을 잘라냈습니다" : "빨간 선 오른쪽을 잘라냈습니다");
}
$("#tkTrimL").onclick = () => trimAtPlayhead("left");
$("#tkUndo").onclick = undo; $("#tkRedo").onclick = redo;
$("#tkTrimR").onclick = () => trimAtPlayhead("right");
$("#tkSplit").onclick = () => {
  const s = cur(); if (!s) return;
  if (S.selKind === "ov") {
    const ovs = ovsOf(s); const o = ovs[S.oi]; if (!o) return; const T = outTime(s, vid.currentTime); const local = o.s + (T - o.at);
    if (local <= o.s + 0.5 || local >= o.e - 0.5) return toast("조각 안쪽(양끝에서 0.5초 이상)으로 빨간 선을 옮긴 뒤 나누세요", true);
    ovs.splice(S.oi, 1, { ...o, e: r2(local), hold: 0 }, { ...o, id: newId(), s: r2(local), at: r2(T) }); S.oi += 1;
    markDirty(); drawTrack(); return toast("둘로 나눴습니다");
  }
  if (S.selKind === "txt") {                         // 텍스트: 같은 내용을 둘로
    const ts = txtsOf(s); const t = ts[S.ti]; if (!t) return; const T = outTime(s, vid.currentTime); const at = +t.at || 0, du = +t.dur || 3;
    if (T <= at + 0.3 || T >= at + du - 0.3) return toast("텍스트 안쪽(양끝에서 0.3초 이상)으로 빨간 선을 옮긴 뒤 나누세요", true);
    ts.splice(S.ti, 1, { ...t, dur: r2(T - at) }, { ...t, id: newId(), at: r2(T), dur: r2(at + du - T) }); S.ti += 1;
    markDirty(); drawTrack(); return toast("텍스트를 둘로 나눴습니다");
  }
  if (S.selKind === "aud") {                         // 오디오: 같은 파일을 둘로 나눠 두 트랙에
    const auds = audsOf(s); const a = auds[S.ai]; if (!a) return; const g = audPlace(a); const T = outTime(s, vid.currentTime); const local = g.in + (T - g.at);
    if (local <= g.in + 0.3 || local >= g.out - 0.3) return toast("오디오 안쪽(양끝에서 0.3초 이상)으로 빨간 선을 옮긴 뒤 나누세요", true);
    auds.splice(S.ai, 1, { ...a, out: r2(local) }, { ...a, id: "a" + Math.random().toString(36).slice(2, 8), in: r2(local), out: g.out === g.D ? null : r2(g.out), at: r2(T) }); S.ai += 1;
    markDirty(); updateLen(); fitStage(); return toast("오디오를 둘로 나눴습니다");
  }
  if (S.selKind === "nar" || S.selKind === "bgm") return toast("낭독·음악은 나누지 않습니다. 양끝을 끌어 구간을 정하세요", true);
  $("#btnClipSplit").click();
};
async function removeAudio(i) {
  const s = cur(); const a = audsOf(s)[i]; if (!a) return;
  try { const r = await api("/api/projects/" + S.p.id + "/audios", { method: "POST", body: { sid: s.id, remove: a.id } }); s.audios = r.short.audios || []; }
  catch (e) { return toast(e.message, true); }
  const el = S.audEls && S.audEls[a.id]; if (el) { el.pause(); delete S.audEls[a.id]; }
  S.selKind = "clip"; S.ai = 0; updateLen(); fitStage(); fillAudPanel(); toast("오디오를 뺐습니다");
}
async function addAudios() {                        // 오디오 파일(여러 개) → 빨간 선 위치부터 차례로 오디오 트랙에
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, vid.currentTime));
  toast("오디오 파일 선택 창이 열렸습니다(여러 개 가능). 다른 창 뒤에 있을 수 있습니다.");
  try {
    const r = await api("/api/projects/" + S.p.id + "/audios", { method: "POST", body: { sid: s.id, multi: true, at: T, lane: S.audLaneAddTo || laneForNew(s) } }); S.audLaneAddTo = 0; if (r.cancelled) return;
    s.audios = r.short.audios || []; S.selKind = "aud"; S.ai = s.audios.length - 1; updateLen(); fitStage(); audSync(isPlaying());
    toast(`오디오 ${r.added.length}개를 넣었습니다. 끌어서 위치를, 양끝으로 구간을 맞추세요`);
  } catch (e) { toast(e.message, true); }
}
$("#tkAudAdd").onclick = addAudios;
$("#tkAudLaneAdd").onclick = () => { const s = cur(); if (!s) return; s.audio_lanes = Math.min(8, audLanesOf(s) + 1); S.audLane = s.audio_lanes; markDirty(); drawTrack(); fitStage(); toast(`오디오 ${s.audio_lanes} 트랙을 만들었습니다. 효과음·파일은 선택한 트랙에 들어가고, 항목을 위아래로 끌어 옮길 수 있습니다`); };
/* 오른쪽 「오디오」 절: 선택한 항목의 음량·삭제 */
function fillAudPanel() {
  const sec = $("#audSec"); if (!sec) return; const s = cur(); const a = s && S.selKind === "aud" ? audsOf(s)[S.ai] : null; sec.classList.toggle("hidden", !a); if (!a) return;
  const g = audPlace(a); $("#audMeta").textContent = `${esc(a.title || "")} · 오디오 ${audLane(a)} · ${fmt(g.at, 1)}부터 ${(g.out - g.in).toFixed(1)}초`;
  $("#audVol").value = g.vol; $("#audVolV").textContent = Math.round(g.vol * 100) + "%";
}
$("#audVol").oninput = e => { const s = cur(); const a = s && audsOf(s)[S.ai]; if (!a || S.selKind !== "aud") return; a.volume = +e.target.value; $("#audVolV").textContent = Math.round(a.volume * 100) + "%"; markDirty(); drawTrack(); audSync(isPlaying()); };
$("#audDel").onclick = () => { if (S.selKind === "aud") removeAudio(S.ai); };
/* ───── 자유 위치 텍스트: 트랙(시간) + 스테이지(위치·끌기) + 오른쪽 패널(글자·크기·색·스타일) ───── */
/* 무료 글꼴 목록: 서버에서 받아 @font-face 로 등록하고 셀렉트를 채운다 */
S.fonts = [];
async function loadTextFonts() {
  try { const r = await api("/api/fonts"); S.fonts = r.fonts || []; } catch (_) { S.fonts = []; }
  const css = S.fonts.filter(f => f.url).map(f => `@font-face{font-family:"tf-${f.id}";src:url("${f.url}");font-display:swap}`).join("\n");
  let st = $("#tfStyles"); if (!st) { st = document.createElement("style"); st.id = "tfStyles"; document.head.appendChild(st); } st.textContent = css;
  // 묶음(optgroup)별로, 각 항목은 제 글꼴로 보여 준다(38종이라 이름만으로는 못 고른다. 2026-09-12)
  const groups = new Map();
  for (const f of S.fonts) { const g = f.group || "기타"; if (!groups.has(g)) groups.set(g, []); groups.get(g).push(f); }
  const opt = f => `<option value="${f.id}"${f.available ? "" : " disabled"} style="font-family:${f.url ? `'tf-${f.id}',` : ""}var(--kr);font-size:15px">${esc(f.name)}${f.available ? "" : " (파일 없음)"}</option>`;
  const html = [...groups].map(([g, arr]) => `<optgroup label="${esc(g)}">${arr.map(opt).join("")}</optgroup>`).join("");
  for (const id of ["txFont", "titleFont", "subFont"]) { const sel = $("#" + id); if (sel) sel.innerHTML = html; }
  // 제목·자막 글꼴은 프로젝트 설정(title_font · sub_font). 렌더는 pipeline.overlay_png / sub_pngs 가 같은 id 로 읽는다(2026-09-12)
  if (S.p && S.p.settings) { $("#titleFont").value = S.p.settings.title_font || "noto"; $("#subFont").value = S.p.settings.sub_font || "noto"; }
}
$("#titleFont").onchange = e => { if (!S.p) return; S.p.settings.title_font = e.target.value; layoutStage(); markDirty(); };
$("#subFont").onchange = e => { if (!S.p) return; S.p.settings.sub_font = e.target.value; layoutStage(); markDirty(); };
loadTextFonts();
const fontFamilyOf = fid => { const f = S.fonts.find(x => x.id === fid); return f && f.url ? `"tf-${f.id}", var(--kr)` : "var(--kr)"; };
const ANIM_D = 0.45;
/* 가운데 맞춤: 끌던 요소의 중심이 캔버스 가운데(가로·세로) 근처에 오면 붙이고 안내선을 보인다. 롱폼·쇼츠 공통 */
const SNAP = 26;
function snapCenter(cx, cy, opts = {}) {
  const out = { x: cx, y: cy, sx: false, sy: false };
  if (!opts.noX && Math.abs(cx - CW() / 2) <= SNAP) { out.x = CW() / 2; out.sx = true; }
  const l = L(); const ys = [CH() / 2]; if (l && l.mode !== "full") ys.push(l.band_top + l.band_h / 2);   // 세로 가운데는 캔버스 중앙, 띠 모드면 영상 띠 중앙도
  if (!opts.noY) for (const yc of ys) { if (Math.abs(cy - yc) <= SNAP) { out.y = yc; out.sy = true; out.yc = yc; break; } }
  return out;
}
function showGuides(sx, sy, yc) { $("#guideV").classList.toggle("hidden", !sx); const h = $("#guideH"); h.classList.toggle("hidden", !sy); if (sy) h.style.top = ((yc != null ? yc : CH() / 2) - 1) + "px"; }
function hideGuides() { showGuides(false, false); }
function addText() {
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, vid.currentTime)); const l = L();
  const y = l && l.mode !== "full" ? l.band_top + l.band_h / 2 : CH() / 2;
  const lane = S.txtLaneAddTo || txtLaneForNew(s); S.txtLaneAddTo = 0;
  txtsOf(s).push({ id: newId(), text: "텍스트", at: r2(T), dur: 3, x: CW() / 2, y: Math.round(y), size: 72, color: "#FFFFFF", stroke: "#000000", bold: true, bg: false, align: "center", font: "noto", anim_in: "fade", anim_out: "fade", lane });
  S.selKind = "txt"; S.ti = txtsOf(s).length - 1; markDirty(); updateLen(); fitStage(); renderTexts(); fillTxtPanel();
  const ta = $("#txText"); if (ta) { ta.focus(); ta.select(); }
  toast("텍스트를 넣었습니다. 화면에서 끌어 옮기고 오른쪽 「텍스트」에서 글자를 고치세요");
}
function removeText(i) {
  const s = cur(); const ts = txtsOf(s); if (!ts[i]) return; ts.splice(i, 1); S.ti = Math.max(0, i - 1); if (!ts.length) S.selKind = "clip";
  markDirty(); updateLen(); fitStage(); renderTexts(); fillTxtPanel(); toast("텍스트를 지웠습니다");
}
function curText() { const s = cur(); if (!s || S.selKind !== "txt") return null; return txtsOf(s)[S.ti] || null; }
function txtStyle(el, t) {                          // 미리보기 CSS = 렌더 PIL 규칙(가운데 기준 좌표, 외곽선 = 크기/12)
  const size = clamp(+t.size || 72, 16, 300); el.style.left = (+t.x || CW() / 2) + "px"; el.style.top = (+t.y || CH() / 2) + "px";
  el.style.fontSize = size + "px"; el.style.color = t.color || "#FFFFFF"; el.style.fontWeight = t.bold === false ? 500 : 700; el.style.textAlign = t.align || "center";
  el.style.fontFamily = fontFamilyOf(t.font || "noto");
  const sk = (t.stroke == null || t.stroke === "" || t.stroke === "none") ? null : t.stroke;
  el.style.webkitTextStroke = sk ? `${Math.max(1, Math.round(size / 12)) * 2}px ${sk}` : "0";   // CSS 외곽선은 절반이 글자 밖으로 나오므로 두 배
  el.style.textShadow = t.shadow === "soft" ? "0.05em 0.07em 0.12em rgba(0,0,0,.75)" : t.shadow === "hard" ? "0.06em 0.06em 0 rgba(0,0,0,.9)" : "none";
  const w = +t.w || 0; el.style.width = (w >= 120 && w <= CW() - 20) ? w + "px" : ""; el.style.maxWidth = w ? "none" : Math.min(960, CW() - 120) + "px";
  el.classList.toggle("bg", !!t.bg);
  let inner = el.querySelector(".st-text-in"); if (!inner) { inner = document.createElement("span"); inner.className = "st-text-in"; el.prepend(inner); }
  inner.textContent = t.text || "";
}
function renderTexts() {
  const box = $("#stTexts"); if (!box) return; const s = cur(); box.innerHTML = ""; if (!s) return;
  txtsOf(s).forEach((t, i) => {
    const el = document.createElement("div"); el.className = "st-text"; el.dataset.i = i; txtStyle(el, t); el.style.zIndex = String(10 + txtLane(t));
    // 손잡이: 모서리 = 크기(가운데에서의 거리 비율), 오른쪽 = 너비(줄바꿈 폭)
    const hs = document.createElement("div"); hs.className = "tth size"; hs.title = "끌어서 글자 크기"; const hw = document.createElement("div"); hw.className = "tth width"; hw.title = "끌어서 글자 상자 너비(줄바꿈)"; el.appendChild(hs); el.appendChild(hw);
    hs.addEventListener("pointerdown", ev => {
      ev.stopPropagation(); ev.preventDefault(); select("txt", i, false);
      const k = CW() / $(".stage-wrap").clientWidth; const wrap = $(".stage-wrap").getBoundingClientRect();
      const cx = wrap.left + (+t.x || CW() / 2) / k, cy = wrap.top + (+t.y || CH() / 2) / k; const d0 = Math.max(10, Math.hypot(ev.clientX - cx, ev.clientY - cy)); const s0 = +t.size || 72;
      const mv = e2 => { const d1 = Math.hypot(e2.clientX - cx, e2.clientY - cy); t.size = Math.round(clamp(s0 * d1 / d0, 16, 300)); txtStyle(el, t); fillTxtPanel(); };
      const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); markDirty(); };
      window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
    });
    hw.addEventListener("pointerdown", ev => {
      ev.stopPropagation(); ev.preventDefault(); select("txt", i, false);
      const k = CW() / $(".stage-wrap").clientWidth; const x0 = ev.clientX; const w0 = (+t.w || el.offsetWidth);
      const mv = e2 => { t.w = Math.round(clamp(w0 + (e2.clientX - x0) * k * 2, 120, CW() - 20)); txtStyle(el, t); };   // 가운데 기준이라 한쪽 이동량의 두 배
      const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); markDirty(); };
      window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
    });
    el.title = "두 번 클릭하면 글자를 바로 고칠 수 있습니다";
    el.addEventListener("dblclick", ev => { ev.stopPropagation(); ev.preventDefault(); startTextEdit(el, i); });
    el.addEventListener("pointerdown", ev => {                       // 화면에서 끌어 옮기기(밴드 패닝과 겹치지 않게 전파 차단)
      if (ev.target.closest(".tth")) return;
      if (el.classList.contains("editing")) { ev.stopPropagation(); return; }   // 글자 고치는 중엔 끌지 않고 커서만 옮긴다
      ev.stopPropagation(); ev.preventDefault(); select("txt", i, false);
      const k = CW() / $(".stage-wrap").clientWidth; const x0 = ev.clientX, y0 = ev.clientY, tx = +t.x || CW() / 2, ty = +t.y || CH() / 2;
      const mv = e2 => {                                             // 글자 상자가 화면 밖으로 나가지 않게(가운데 기준이라 상자 절반만큼 여유)
        const hw = Math.min(CW() / 2 - 20, el.offsetWidth / 2), hh = Math.min(CH() / 2 - 20, el.offsetHeight / 2);
        let nx = clamp(tx + (e2.clientX - x0) * k, hw + 10, CW() - 10 - hw), ny = clamp(ty + (e2.clientY - y0) * k, hh + 10, CH() - 10 - hh);
        const sn = snapCenter(nx, ny); nx = sn.x; ny = sn.y; showGuides(sn.sx, sn.sy, sn.yc);
        t.x = Math.round(nx); t.y = Math.round(ny); txtStyle(el, t);
      };
      const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); hideGuides(); markDirty(); };
      window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
    });
    box.appendChild(el);
  });
  layoutTexts();
}
/* 미리보기 안에서 바로 고치기(2026-09-14 사용자 요청): 텍스트를 두 번 클릭하면 상자 안 글자가 편집 상태가 된다.
   입력할 때마다 t.text 와 오른쪽 칸 textarea 를 맞추고, 상자 밖 클릭·Esc 로 끝낸다. Enter 는 줄바꿈(렌더도 여러 줄 지원). */
function startTextEdit(el, i) {
  const s = cur(); const t = txtsOf(s)[i]; if (!t || el.classList.contains("editing")) return; select("txt", i, false);
  const inner = el.querySelector(".st-text-in"); if (!inner) return;
  el.classList.add("editing"); inner.contentEditable = "plaintext-only"; if (inner.contentEditable !== "plaintext-only") inner.contentEditable = "true";
  inner.focus();
  try { const sel = window.getSelection(); const rg = document.createRange(); rg.selectNodeContents(inner); sel.removeAllRanges(); sel.addRange(rg); } catch (_) {}
  const sync = () => { t.text = inner.innerText.replace(/\r/g, "").replace(/\n$/, ""); const ta = $("#txText"); if (ta) ta.value = t.text; markDirty(); };
  const kd = e => { e.stopPropagation(); if (e.key === "Escape") { e.preventDefault(); inner.blur(); } };
  const outside = e => { if (!el.contains(e.target)) finish(); };          // 상자 밖을 누르면 끝(blur 가 안 오는 경우 대비)
  document.addEventListener("pointerdown", outside, true);
  const finish = () => {
    if (!el.classList.contains("editing")) return;
    document.removeEventListener("pointerdown", outside, true);
    inner.removeEventListener("input", sync); inner.removeEventListener("blur", finish); inner.removeEventListener("keydown", kd); sync();
    inner.contentEditable = "false"; el.classList.remove("editing"); txtStyle(el, t); if (typeof drawTrack === "function") drawTrack(); fillTxtPanel();
  };
  inner.addEventListener("input", sync); inner.addEventListener("blur", finish); inner.addEventListener("keydown", kd);
}
function layoutTexts() {                             // 결과 시각에 걸린 텍스트만 보이고, 선택한 것은 점선 테두리
  const s = cur(); if (!s) return; const T = Math.max(0, outTime(s, vid.currentTime)); const ts = txtsOf(s);
  $$("#stTexts .st-text").forEach(el => {
    const t = ts[+el.dataset.i]; if (!t) return el.remove(); const on = S.selKind === "txt" && +el.dataset.i === S.ti;
    const at = +t.at || 0, du = +t.dur || 0; const vis = T >= at - 0.02 && T < at + du; el.classList.toggle("hidden", !vis && !on); el.classList.toggle("on", on);
    // 나타나기·사라지기(렌더의 text_anim_filters 와 같은 규칙): 페이드 알파, 140px 슬라이드, 0.6→1 줌
    const ai = t.anim_in || "none", ao = t.anim_out || "none"; const D = Math.min(ANIM_D, du / 2);
    const pi = ai === "none" ? 1 : clamp((T - at) / D, 0, 1), po = ao === "none" ? 1 : clamp((at + du - T) / D, 0, 1);
    let dx = 0, dy = 0, sc = 1; const off = 140;
    if (ai === "left") dx -= off * (1 - pi); if (ai === "right") dx += off * (1 - pi); if (ai === "up") dy += off * (1 - pi); if (ai === "down") dy -= off * (1 - pi); if (ai === "zoom") sc *= 0.6 + 0.4 * pi;
    if (ao === "left") dx -= off * (1 - po); if (ao === "right") dx += off * (1 - po); if (ao === "up") dy -= off * (1 - po); if (ao === "down") dy += off * (1 - po); if (ao === "zoom") sc *= 0.6 + 0.4 * po;
    el.style.transform = `translate(-50%,-50%) translate(${dx}px,${dy}px) scale(${sc})`;
    el.style.opacity = vis ? String(Math.min(pi, po)) : "0.35";
  });
}
function fillTxtPanel() {
  const sec = $("#txtSec"); if (!sec) return; const t = curText(); $("#txtBody").classList.toggle("hidden", !t); $("#txtEmpty").classList.toggle("hidden", !!t); $("#txtMeta").textContent = t ? "" : `${txtsOf(cur() || { texts: [] }).length}개`; layoutTexts(); if (!t) return;
  $("#txText").value = t.text || ""; $("#txSize").value = t.size || 72; $("#txSizeV").textContent = (t.size || 72) + "px";
  $("#txColor").value = (t.color || "#FFFFFF").toLowerCase().slice(0, 7); const sk = t.stroke; const none = sk == null || sk === "" || sk === "none";
  $("#txStrokeNone").checked = none; $("#txStroke").value = none ? "#000000" : sk.toLowerCase().slice(0, 7); $("#txStroke").disabled = none;
  $("#txBold").checked = t.bold !== false; $("#txBg").checked = !!t.bg; $("#txShadow").value = t.shadow || "none";
  $$("#txtSec [data-txalign]").forEach(b => b.classList.toggle("on", (t.align || "center") === b.dataset.txalign));
  $("#txtMeta").textContent = `${fmt(+t.at || 0, 1)}부터 ${(+t.dur || 0).toFixed(1)}초`;
  const fs = $("#txFont"); if (fs && fs.options.length) fs.value = t.font || "noto";
  const cf = S.fonts.find(x => x.id === (t.font || "noto")); $("#txFontDel").classList.toggle("hidden", !(cf && cf.kind === "user"));
  $("#txAnimIn").value = t.anim_in || "none"; $("#txAnimOut").value = t.anim_out || "none";
}
function txtChanged(redrawTrack) { const t = curText(); if (!t) return; markDirty(); $$("#stTexts .st-text").forEach(el => { if (+el.dataset.i === S.ti) txtStyle(el, t); }); if (redrawTrack) drawTrack(); }
$("#txText").oninput = e => { const t = curText(); if (!t) return; t.text = e.target.value; txtChanged(true); };
$("#txSize").oninput = e => { const t = curText(); if (!t) return; t.size = +e.target.value; $("#txSizeV").textContent = t.size + "px"; txtChanged(false); };
$("#txColor").oninput = e => { const t = curText(); if (!t) return; t.color = e.target.value.toUpperCase(); txtChanged(false); };
$("#txStroke").oninput = e => { const t = curText(); if (!t) return; t.stroke = e.target.value.toUpperCase(); txtChanged(false); };
$("#txStrokeNone").onchange = e => { const t = curText(); if (!t) return; t.stroke = e.target.checked ? "none" : $("#txStroke").value.toUpperCase(); $("#txStroke").disabled = e.target.checked; txtChanged(false); };
$("#txBold").onchange = e => { const t = curText(); if (!t) return; t.bold = e.target.checked; txtChanged(false); };
$("#txBg").onchange = e => { const t = curText(); if (!t) return; t.bg = e.target.checked; txtChanged(false); };
$("#txShadow").onchange = e => { const t = curText(); if (!t) return; t.shadow = e.target.value; txtChanged(false); };
$$("#txtSec [data-txalign]").forEach(b => b.onclick = () => { const t = curText(); if (!t) return; t.align = b.dataset.txalign; txtChanged(false); fillTxtPanel(); });
$$("#txPresets [data-preset]").forEach(b => b.onclick = () => { const t = curText(); if (!t) return; Object.assign(t, TXT_PRESETS[b.dataset.preset]); txtChanged(false); fillTxtPanel(); });
$("#txCenter").onclick = () => { const t = curText(); if (!t) return; const l = L(); t.x = CW() / 2; t.y = Math.round(l && l.mode !== "full" ? l.band_top + l.band_h / 2 : CH() / 2); txtChanged(false); };
$("#txDel").onclick = () => { if (S.selKind === "txt") removeText(S.ti); };
$("#txFont").onchange = e => { const t = curText(); if (!t) return; t.font = e.target.value; txtChanged(false); };
$("#txAnimIn").onchange = e => { const t = curText(); if (!t) return; t.anim_in = e.target.value; markDirty(); layoutTexts(); };
$("#txAnimOut").onchange = e => { const t = curText(); if (!t) return; t.anim_out = e.target.value; markDirty(); layoutTexts(); };
$("#tkTxtAdd").onclick = () => { S.txtLaneAddTo = 0; addText(); };
$("#txAddBtn").onclick = () => { S.txtLaneAddTo = 0; addText(); };
$("#tkTxtLaneAdd").onclick = () => { const s = cur(); if (!s) return; s.text_lanes = Math.min(6, txtLanesOf(s) + 1); S.txtLane = s.text_lanes; markDirty(); drawTrack(); fitStage(); toast(`텍스트 ${s.text_lanes} 트랙을 만들었습니다. 새 텍스트는 선택한 트랙에 들어가고, 위아래로 끌어 옮길 수 있습니다`); };
/* 전체 음량: 렌더는 마지막 volume 필터, 미리보기는 모든 요소 음량에 곱한다 */
function applyMaster() {
  const m = mVol(); $("#masterVol").value = m; $("#masterVolV").textContent = Math.round(m * 100) + "%";
  $("#masterVolV").classList.toggle("warn", Math.abs(m - 1) > 0.001);          // 결과물 음량이 100% 가 아니면 눈에 띄게
  const pv = pVol(); if ($("#prevVol")) { $("#prevVol").value = pv; $("#prevVolV").textContent = Math.round(pv * 100) + "%"; }
  const pm = m * pv;                                                            // 미리보기 요소에는 미리듣기 배율까지 곱한다
  const sv = S.p.settings.src_volume == null ? 1 : +S.p.settings.src_volume;
  vid.volume = Math.min(1, (isShop() ? sv : 1) * pm); narAudio.volume = Math.min(1, pm); ovVid.volume = Math.min(1, pm);
  const b = bgmSettings(); bgmAudio.volume = Math.min(1, (b.volume != null ? b.volume : 0.15) * pm);
  Object.values(S.audEls || {}).forEach(el => { el.volume = Math.min(1, (el._vol == null ? 1 : el._vol) * pm); });
}
$("#masterVol").oninput = e => { S.p.settings.master_volume = +e.target.value; applyMaster(); markDirty(); };
$("#masterVol").onchange = e => { const m = mVol(); if (Math.abs(m - 1) > 0.001) toast(`결과물 음량 ${Math.round(m * 100)}% — 완성본 소리에 적용됩니다. 미리듣기만 조절하려면 🔊 미리듣기를 쓰세요`, true); };
$("#prevVol").oninput = e => { S.prevVol = Math.min(1, Math.max(0, +e.target.value)); try { localStorage.setItem("prevVol", String(S.prevVol)); } catch (_) {} applyMaster(); };
/* 오디오 트랙 미리듣기: 항목마다 <audio> 하나, 결과 시각에 맞춰 같이 튼다 */
function audSync(playing) {
  const s = cur(); if (!s) return; S.audEls = S.audEls || {}; const t = Math.max(0, outTime(s, vid.currentTime)); const m = mVol(); const live = new Set();
  audsOf(s).forEach(a => {
    live.add(a.id); let el = S.audEls[a.id];
    if (!el) { el = new Audio(a.url || ("/media/" + S.p.id + "/" + a.file)); el.preload = "auto"; S.audEls[a.id] = el; }
    const g = audPlace(a); el._vol = g.vol; el.volume = Math.min(1, g.vol * m); const lt = t - g.at + g.in;
    if (!playing || t < g.at - 0.05 || lt >= g.out) { if (!el.paused) el.pause(); return; }
    syncEl(el, lt, 0.3, true);
  });
  Object.keys(S.audEls).forEach(id => { if (!live.has(id)) { S.audEls[id].pause(); delete S.audEls[id]; } });
}
vid.addEventListener("play", () => setTimeout(() => audSync(true), 50));
vid.addEventListener("pause", () => audSync(false));
vid.addEventListener("seeked", () => { if (!vid.paused) audSync(true); });
function removeNarration() {
  S.p.narration = null; S.p.cues = []; S.p.cues_auto = []; S.p.cues_source = "none";
  if (!(+S.p.settings.src_volume)) S.p.settings.src_volume = 1.0;
  narAudio.pause(); narAudio.removeAttribute("src"); S.selKind = "clip";
  markDirty(); applyShopMode(); renderCues(); drawTrack(); toast("낭독을 뺐습니다. 원본 소리를 다시 씁니다");
}
$("#tkDel").onclick = () => {
  const s = cur(); if (!s) return;
  if (S.msel.length > 1) return mselDelete();
  if (S.selKind === "ov") { const ovs = ovsOf(s); if (!ovs.length) return; ovs.splice(S.oi, 1); S.oi = Math.max(0, S.oi - 1); if (!ovs.length) S.selKind = "clip"; markDirty(); drawTrack(); ovSync(); return toast("위층 조각을 뺐습니다"); }
  if (S.selKind === "nar") { if (!confirm("낭독을 뺄까요? 낭독으로 만든 자막도 함께 지워집니다.")) return; return removeNarration(); }
  if (S.selKind === "bgm") { S.selKind = "clip"; return $("#btnBgmClear").click(); }
  if (S.selKind === "aud") return removeAudio(S.ai);
  if (S.selKind === "txt") return removeText(S.ti);
  keepPlayhead(() => $("#btnClipDel").click());
};
async function pickSources(msg) {                   // 파일 고르기 창(여러 개) → 프로젝트에 등록된 영상 목록
  toast(msg || "영상 파일 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { multi: true } }); if (r.cancelled) return null;
  S.p.extra_sources = r.sources; renderInsertSources(); renderMedia(); return r.added;
}
async function addMainVideos() {                    // 주 트랙 끝에 전체 길이 조각으로
  const s = cur(); if (!s) return;
  try { const added = await pickSources(); if (!added) return; const cs = clipsOf(s); added.forEach(x => cs.push({ s: 0, e: r2(x.duration), src: x.id }));
    S.ci = cs.length - 1; S.selKind = "clip"; keepPlayhead(() => afterClipsChange(null)); toast(`영상 ${added.length}개를 영상 1 트랙 끝에 붙였습니다`); }
  catch (e) { toast(e.message, true); }
};
async function addLayerVideos(layer) {              // 위층: 빨간 선 위치부터 차례로(남은 길이만큼)
  const s = cur(); if (!s) return;
  try {
    const added = await pickSources(); if (!added) return; const ovs = ovsOf(s); let T = Math.max(0, outTime(s, vid.currentTime));
    added.forEach(x => { const len = Math.min(+x.duration, Math.max(0.5, MAX_OUT - T)); ovs.push({ id: newId(), src: x.id, s: 0, e: r2(len), at: r2(T), layer }); T += len; });
    S.selKind = "ov"; S.oi = ovs.length - 1; markDirty(); drawTrack(); ovSync(); toast(`영상 ${added.length}개를 영상 ${layer + 1} 트랙에 얹었습니다. 끌어서 위치를, 양끝으로 길이를 맞추세요`);
  } catch (e) { toast(e.message, true); }
};
$("#tkLabels").addEventListener("click", e => {
  const b = e.target.closest("button[data-act]"); if (!b) return; const s = cur(); if (!s) return; const act = b.dataset.act;
  if (act === "layer-new") return $("#tkLayerAdd").click();
  if (act === "txt-lane-add") return $("#tkTxtLaneAdd").click();
  if (act === "aud-lane-new") return $("#tkAudLaneAdd").click();
  if (act === "add-main") return addMainVideos();
  if (act === "aud-lane-add") { S.audLaneAddTo = +b.dataset.lane; return addAudios(); }
  if (act === "aud-lane-rm") { const l = +b.dataset.lane; if (audsOf(s).some(a => audLane(a) === l)) return toast("항목이 있는 트랙은 없앨 수 없습니다", true); s.audio_lanes = Math.max(1, l - 1); if (S.audLane > s.audio_lanes) S.audLane = s.audio_lanes; markDirty(); drawTrack(); fitStage(); return; }
  if (act === "add-txt") { S.txtLaneAddTo = +b.dataset.lane || 0; return addText(); }
  if (act === "txt-lane-rm") { const l = +b.dataset.lane; if (txtsOf(s).some(t => txtLane(t) === l)) return toast("항목이 있는 트랙은 없앨 수 없습니다", true); s.text_lanes = Math.max(1, l - 1); if (S.txtLane > s.text_lanes) S.txtLane = s.text_lanes; markDirty(); drawTrack(); fitStage(); return; }
  if (act === "add-layer") return addLayerVideos(+b.dataset.layer);
  if (act === "del-layer") { s.video_layers = Math.max(1, +b.dataset.layer - 1); markDirty(); drawTrack(); fitStage(); return; }
  if (act === "add-nar") { if (!isShop()) return toast("낭독 트랙은 쇼핑 쇼츠에서 씁니다", true); return $("#btnAddNar").click(); }
  if (act === "add-bgm") {                          // 왼쪽 「음악·전환」 절을 펼치고 곡 고르기로 안내
    const sec = $("#bgmPreset").closest(".pn-sec"); if (sec) { sec.removeAttribute("data-collapsed"); sec.classList.remove("collapsed"); sec.scrollIntoView({ behavior: "smooth", block: "center" }); }
    if (s.bgm_off) { s.bgm_off = false; $("#bgmOffShort").checked = false; markDirty(); drawTrack(); }
    if (bgmOn(bgmSettings())) { S.selKind = "bgm"; drawTrack(); toast("곡을 바꾸려면 왼쪽 「음악·전환」에서 고르세요"); }
    else { $("#bgmPreset").focus(); toast("왼쪽 「음악·전환」에서 곡을 고르면 트랙에 나타납니다"); }
  }
});
/* 트랙 항목 복사·잘라내기·붙여넣기·복제: 선택한 영상 조각·위층·텍스트·오디오. 붙여넣기는 빨간 선 위치에 */
function copySelected() {
  const s = cur(); if (!s) return false; let item = null;
  if (S.msel.length > 1) {                              // 묶음 복사: 시작 시각이 가장 이른 항목 기준 상대 위치를 같이 담는다
    const ms = mselResolve().filter(m => ["clip", "ov", "txt", "aud"].includes(m.kind));
    if (!ms.length) { toast("복사할 수 있는 건 영상 조각·위층·텍스트·오디오입니다", true); return false; }
    const base = Math.min(...ms.map(m => itemStartOf(m)));
    S.clipboard = { kind: "multi", items: ms.map(m => ({ kind: m.kind, data: { ...m.obj }, rel: itemStartOf(m) - base })) }; return true;
  }
  if (S.selKind === "clip") item = { kind: "clip", data: { ...clipsOf(s)[S.ci] } };
  else if (S.selKind === "ov") { const o = ovsOf(s)[S.oi]; if (o) item = { kind: "ov", data: { ...o } }; }
  else if (S.selKind === "txt") { const t = txtsOf(s)[S.ti]; if (t) item = { kind: "txt", data: { ...t } }; }
  else if (S.selKind === "aud") { const a = audsOf(s)[S.ai]; if (a) item = { kind: "aud", data: { ...a } }; }
  if (!item) { toast("복사할 수 있는 건 영상 조각·위층·텍스트·오디오입니다", true); return false; }
  S.clipboard = item; return true;
}
function pasteClipboard(atEnd) {
  const s = cur(); const c = S.clipboard; if (!s || !c) return toast("복사한 항목이 없습니다", true);
  const T = Math.max(0, outTime(s, vid.currentTime));
  if (c.kind === "multi") {                             // 묶음 붙여넣기: 빨간 선(또는 지정 시각)부터 상대 위치 그대로
    const at = atEnd != null ? atEnd : T; const cs = clipsOf(s); let ci = clamp(S.playIdx || 0, 0, cs.length - 1); const keys = []; let clipsChanged = false;
    c.items.forEach(it => {
      if (it.kind === "clip") { cs.splice(ci + 1, 0, { ...it.data }); ci += 1; keys.push("clip:" + ci); clipsChanged = true; }
      else if (it.kind === "ov") { const id = newId(); ovsOf(s).push({ ...it.data, id, at: r2(at + it.rel) }); keys.push("ov:" + id); }
      else if (it.kind === "txt") { const id = newId(); txtsOf(s).push({ ...it.data, id, at: r2(at + it.rel) }); keys.push("txt:" + id); }
      else if (it.kind === "aud") { const id = "a" + Math.random().toString(36).slice(2, 8); audsOf(s).push({ ...it.data, id, at: r2(at + it.rel) }); keys.push("aud:" + id); }
    });
    if (clipsChanged) keepPlayhead(() => afterClipsChange(null)); else { markDirty(); updateLen(); }
    renderTexts(); fitStage(); ovSync(); audSync(isPlaying()); S.msel = keys; drawTrack(); paintMsel(); return toast(`${c.items.length}개를 붙여 넣었습니다`);
  }
  if (c.kind === "clip") {                            // 주 트랙: 빨간 선이 든 조각 뒤에 끼운다
    const cs = clipsOf(s); const i = clamp(S.playIdx || 0, 0, cs.length - 1); cs.splice(i + 1, 0, { ...c.data }); S.ci = i + 1; S.selKind = "clip";
    keepPlayhead(() => afterClipsChange(null)); return toast("조각을 붙여 넣었습니다(빨간 선이 든 조각 뒤)");
  }
  const at = atEnd != null ? atEnd : T;
  if (c.kind === "ov") { const ovs = ovsOf(s); ovs.push({ ...c.data, id: newId(), at: r2(at) }); S.selKind = "ov"; S.oi = ovs.length - 1; markDirty(); updateLen(); ovSync(); return toast("위층 조각을 붙여 넣었습니다"); }
  if (c.kind === "txt") { const ts = txtsOf(s); ts.push({ ...c.data, id: newId(), at: r2(at) }); S.selKind = "txt"; S.ti = ts.length - 1; markDirty(); updateLen(); renderTexts(); fillTxtPanel(); return toast("텍스트를 붙여 넣었습니다"); }
  if (c.kind === "aud") { const as = audsOf(s); as.push({ ...c.data, id: "a" + Math.random().toString(36).slice(2, 8), at: r2(at) }); S.selKind = "aud"; S.ai = as.length - 1; markDirty(); updateLen(); fitStage(); audSync(isPlaying()); return toast("오디오를 붙여 넣었습니다"); }
}
function duplicateSelected() {                       // 복제: 항목 바로 뒤에
  const s = cur(); if (!s || !copySelected()) return; const c = S.clipboard; let end = null;
  if (c.kind === "multi") { const ms = mselResolve(); end = Math.max(...ms.map(m => itemEndOf(m))); return pasteClipboard(end); }
  if (c.kind === "ov") end = c.data.at + (c.data.e - c.data.s); if (c.kind === "txt") end = (+c.data.at || 0) + (+c.data.dur || 0); if (c.kind === "aud") { const g = audPlace(c.data); end = g.at + (g.out - g.in); }
  pasteClipboard(end);
}
/* ───── 오른쪽 클릭 메뉴(트랙): 항목 종류에 맞는 기능만 보여 준다 ───── */
const ctx = $("#ctxMenu");
function ctxHide() { ctx.classList.add("hidden"); ctx.innerHTML = ""; }
function ctxShow(x, y, title, items) {
  ctx.innerHTML = (title ? `<div class="hd">${esc(title)}</div>` : "") + items.map(it => it === "-" ? `<div class="sep"></div>` : `<div class="ci${it.dis ? " dis" : ""}" data-k="${it.k}">${esc(it.label)}${it.key ? `<small>${it.key}</small>` : ""}</div>`).join("");
  ctx.classList.remove("hidden");
  const w = ctx.offsetWidth, h = ctx.offsetHeight; ctx.style.left = Math.min(x, window.innerWidth - w - 8) + "px"; ctx.style.top = Math.min(y, window.innerHeight - h - 8) + "px";
  ctx.querySelectorAll(".ci").forEach(el => el.onclick = () => { const it = items.find(i => i !== "-" && i.k === el.dataset.k); ctxHide(); if (it && !it.dis) it.run(); });
}
document.addEventListener("pointerdown", e => { if (!e.target.closest("#ctxMenu")) ctxHide(); }, true);
window.addEventListener("blur", ctxHide); document.addEventListener("keydown", e => { if (e.key === "Escape") ctxHide(); });
tk.addEventListener("scroll", ctxHide);
function moveClipUp(i, layer) {                     // 영상 1 조각 → 위층. 마지막 조각이면 같은 길이의 빈 화면(검정)을 자리에 깐다
  const s = cur(); const cs = clipsOf(s); const { offs } = clipOffsets(s); const at0 = offs[i]; const T0 = Math.max(0, outTime(s, vid.currentTime));
  const mv = (fid) => {
    const [cc] = cs.splice(i, 1); if (fid) cs.splice(i, 0, { s: 0, e: r2(clipOut(cc)), src: fid });
    ovsOf(s).push({ id: newId(), src: cc.src || "main", s: cc.s, e: cc.e, at: r2(at0), layer, mute: cc.mute, speed: cc.speed, hold: cc.hold });
    S.ci = clamp(S.ci, 0, cs.length - 1); S.selKind = "ov"; S.oi = ovsOf(s).length - 1;
    afterClipsChange(null); clampOverlays(s); drawTrack(); seekOut(Math.min(T0, Math.max(0, outLen(s) - 0.05))); ovSync(); renderMedia();
    toast(`영상 ${layer + 1} 트랙으로 올렸습니다.` + (fid ? " 영상 1 에는 같은 길이의 빈 화면(검정)을 깔았습니다" : ""));
  };
  if (cs.length > 1) { mv(null); return; }
  if (S.moveBusy) return; S.moveBusy = true;
  ensureBlackSource().then(id => { if (id) mv(id); }).finally(() => { S.moveBusy = false; });
}
/* 텍스트 빠른 수정 항목(트랙·화면 오른쪽 클릭 공통): 글자 고치기, 스타일 프리셋, 오른쪽 칸으로 */
function txtQuickItems(i) {
  const s = cur(); const t = txtsOf(s)[i]; if (!t) return [];
  const apply = () => { S.selKind = "txt"; S.ti = i; markDirty(); renderTexts(); fillTxtPanel(); drawTrack(); };
  return [
    { k: "tedit", label: "글자 고치기…", run: () => { const sep = " / "; const v = prompt("텍스트 (줄바꿈은 ' / ' 로)", (t.text || "").split("\n").join(sep)); if (v != null) { t.text = v.split(sep).map(x => x.trim()).join("\n"); apply(); } } },
    { k: "tsize+", label: "크게 (+10)", run: () => { t.size = clamp((+t.size || 72) + 10, 16, 300); apply(); } },
    { k: "tsize-", label: "작게 (−10)", run: () => { t.size = clamp((+t.size || 72) - 10, 16, 300); apply(); } },
    { k: "tp1", label: "스타일: 기본(흰+검정선)", run: () => { Object.assign(t, TXT_PRESETS.basic); apply(); } },
    { k: "tp2", label: "스타일: 노랑", run: () => { Object.assign(t, TXT_PRESETS.yellow); apply(); } },
    { k: "tp3", label: "스타일: 상자", run: () => { Object.assign(t, TXT_PRESETS.box); apply(); } },
    { k: "tp4", label: "스타일: 빨강", run: () => { Object.assign(t, TXT_PRESETS.red); apply(); } },
    { k: "tcenter", label: "화면 가운데로", run: () => { const l = L(); t.x = CW() / 2; t.y = Math.round(l && l.mode !== "full" ? l.band_top + l.band_h / 2 : CH() / 2); apply(); } },
    { k: "tpanel", label: "오른쪽 「텍스트」 칸에서 자세히", run: () => { S.selKind = "txt"; S.ti = i; fillTxtPanel(); $("#txtSec").scrollIntoView({ behavior: "smooth", block: "center" }); $("#txText").focus(); } },
  ];
}
$("#stTexts").addEventListener("contextmenu", e => {          // 화면 위 글자 오른쪽 클릭
  const el = e.target.closest(".st-text"); if (!el) return; e.preventDefault(); e.stopPropagation();
  const i = +el.dataset.i; select("txt", i, false); const t = txtsOf(cur())[i]; if (!t) return;
  const items = [...txtQuickItems(i), "-",
    { k: "copy", label: "복사", key: "Ctrl+C", run: () => { if (copySelected()) toast("복사했습니다"); } },
    { k: "dup", label: "복제", key: "Ctrl+D", run: duplicateSelected },
    { k: "del", label: "삭제", key: "Del", run: () => removeText(i) }];
  ctxShow(e.clientX, e.clientY, `텍스트 · ${(t.text || "").split("\n")[0].slice(0, 16)}`, items);
});
tk.addEventListener("contextmenu", e => {
  const s = cur(); if (!s) return; e.preventDefault();
  const item = e.target.closest(".tk-item"); const Tclick = Math.max(0, tkPos(e) / tkPps());
  const cb = !!S.clipboard;
  const gapEl = e.target.closest(".tk-gap");
  if (gapEl) {                                      // 빈 구간: 지우기(뒤 조각을 당김)·길이 바꾸기
    const gi = +gapEl.dataset.gap; const cs = clipsOf(s); const g = cs[gi]; if (!g) return;
    ctxShow(e.clientX, e.clientY, `빈 구간 ${clipOut(g).toFixed(1)}초`, [
      { k: "del", label: "빈 구간 지우기 (뒤 조각을 앞으로 당김)", run: () => keepPlayhead(() => { cs.splice(gi, 1); S.ci = clamp(S.ci, 0, cs.length - 1); afterClipsChange(null); }) },
      { k: "len", label: "빈 구간 길이…", run: () => { const v = prompt("빈 구간 길이(초)", clipOut(g).toFixed(1)); if (v == null) return; const n = +String(v).replace(/[^\d.]/g, ""); if (!(n >= 0)) return; keepPlayhead(() => { if (n < 0.05) cs.splice(gi, 1); else { g.s = 0; g.e = r2(Math.min(n, 600)); delete g.speed; delete g.hold; } afterClipsChange(null); }); } },
      { k: "ph", label: "빨간 선을 여기로", run: () => seekOut(Tclick) },
    ]);
    return;
  }
  const cueEl = e.target.closest(".tk-cue");
  if (cueEl) {                                      // 자막 조각: 글자 고치기·나누기·합치기·지우기
    const cid = +cueEl.dataset.cue; const c = shortCues(s).find(q => q.id === cid); if (!c) return;
    const curText = () => (s.cue_edits && s.cue_edits[cid] != null) ? s.cue_edits[cid] : c.text;
    const setText = v => { s.cue_edits = s.cue_edits || {}; s.cue_edits[cid] = v; markDirty(); renderCues(); showSub(vid.currentTime); drawTrack(); };
    const focusCue = () => { const li = $$(".cue").find(x => +x.dataset.id === cid); if (li) { li.scrollIntoView({ block: "center", behavior: "smooth" }); const ta = $("textarea", li); if (ta) ta.focus(); } };
    const items = [
      { k: "edit", label: "글자 고치기…", run: () => { const v = prompt("자막 글자", curText()); if (v != null) setText(v); } },
      { k: "panel", label: "오른쪽 자막 칸에서 고치기", run: focusCue },
      { k: "go", label: "이 자막으로 이동", run: () => seekOut(c.out_s + 0.02) },
      "-",
      { k: "split", label: "빨간 선에서 나누기", run: () => { const t = curText(); const T = Math.max(0, outTime(s, vid.currentTime)); const frac = clamp((T - c.out_s) / Math.max(0.1, c.out_e - c.out_s), 0.1, 0.9); let pos = Math.round(t.length * frac); const sp = t.lastIndexOf(" ", pos); if (sp > 0 && pos - sp < 6) pos = sp; splitCue(cid, t, pos); } },
      { k: "merge", label: "앞 자막과 합치기", dis: S.p.cues.findIndex(q => q.id === cid) <= 0, run: () => mergeCueWithPrev(cid, curText()) },
      { k: "clear", label: "이 자막 비우기(화면에 안 나옴)", run: () => setText("") },
      "-",
      { k: "hide", label: S.p.settings.show_subs === false ? "자막 전체 보이기" : "자막 전체 숨기기", run: () => { const cb = $("#fShowSubs"); if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event("change", { bubbles: true })); } } },
    ];
    ctxShow(e.clientX, e.clientY, `자막 · ${curText().slice(0, 18)}`, items);
    return;
  }
  if (item && S.msel.length > 1 && mselHas(item.dataset.kind, +item.dataset.i)) {
    const n = S.msel.length;
    ctxShow(e.clientX, e.clientY, `${n}개 선택`, [
      { k: "copy", label: `복사 (${n}개)`, key: "Ctrl+C", run: () => { if (copySelected()) toast("복사했습니다"); } },
      { k: "cut", label: `잘라내기 (${n}개)`, key: "Ctrl+X", run: () => { if (copySelected()) { mselDelete(); toast("잘라냈습니다"); } } },
      { k: "paste", label: "여기에 붙여넣기", key: "Ctrl+V", dis: !cb, run: () => { seekOut(Tclick); setTimeout(() => pasteClipboard(null), 60); } },
      { k: "dup", label: `복제 (${n}개)`, key: "Ctrl+D", run: duplicateSelected },
      "-",
      { k: "del", label: `삭제 (${n}개)`, key: "Del", run: mselDelete },
      { k: "clr", label: "선택 해제", key: "Esc", run: () => { mselClear(); paintMsel(); } },
    ]);
    return;
  }
  if (item) {
    const kind = item.dataset.kind, i = +item.dataset.i; select(kind, i, false);
    const cs = clipsOf(s); const c = kind === "clip" ? cs[i] : null; const o = kind === "ov" ? ovsOf(s)[i] : null;
    const name = kind === "clip" ? `영상 1 · ${srcTitle(c.src)}` : kind === "ov" ? `영상 ${ovLayer(o) + 1} · ${srcTitle(o.src)}` : kind === "txt" ? `텍스트 · ${(txtsOf(s)[i].text || "").split("\n")[0].slice(0, 16)}` : kind === "aud" ? `오디오 · ${audsOf(s)[i].title || ""}` : kind === "nar" ? "낭독" : "음악";
    const canClip = ["clip", "ov", "txt", "aud"].includes(kind);
    const items = [
      { k: "copy", label: "복사", key: "Ctrl+C", dis: !canClip, run: () => { if (copySelected()) toast("복사했습니다"); } },
      { k: "cut", label: "잘라내기", key: "Ctrl+X", dis: !canClip, run: () => { if (copySelected()) { $("#tkDel").click(); toast("잘라냈습니다"); } } },
      { k: "paste", label: "여기에 붙여넣기", key: "Ctrl+V", dis: !cb, run: () => { seekOut(Tclick); setTimeout(() => pasteClipboard(null), 60); } },
      { k: "dup", label: "복제", key: "Ctrl+D", dis: !canClip, run: duplicateSelected },
      "-",
      { k: "split", label: "빨간 선에서 나누기", key: "S", dis: !canClip, run: () => $("#tkSplit").click() },
      { k: "trimL", label: "빨간 선 왼쪽 자르기", key: "Q", run: () => trimAtPlayhead("left") },
      { k: "trimR", label: "빨간 선 오른쪽 자르기", key: "W", run: () => trimAtPlayhead("right") },
    ];
    if (kind === "clip" || kind === "ov") {
      const item = kind === "clip" ? c : o; const after = () => { if (kind === "clip") keepPlayhead(() => afterClipsChange(null)); else { markDirty(); updateLen(); drawTrack(); ovSync(); } };
      items.push("-", { k: "fit", label: "자막 끝까지 늘리기(느리게)…", run: () => timeFitDialog(item, kind, after) },
        { k: "spd", label: `속도 바꾸기… (지금 ×${spdOf(item)})`, run: () => speedDialog(item, kind, after) },
        { k: "hold", label: `마지막 장면 멈춤… (지금 ${holdOf(item).toFixed(1)}초)`, run: () => holdDialog(item, kind, after) },
        { k: "reset", label: "속도·멈춤 원래대로", dis: spdOf(item) === 1 && holdOf(item) === 0, run: () => { delete item.speed; delete item.hold; after(); toast("속도 1배, 멈춤 없음으로 되돌렸습니다"); } });
    }
    if (kind === "clip") {
      const hasA = srcInfo(c.src).has_audio !== false;
      items.push("-", { k: "mute", label: c.mute ? "소리 켜기" : "소리 끄기(이 조각)", dis: !hasA, run: () => { c.mute = !c.mute; markDirty(); drawTrack(); applyMaster(); } },
        { k: "full", label: "원본 전체 길이로", run: () => $("#tkFull").click() },
        { k: "up", label: "영상 2 트랙으로 올리기", run: () => moveClipUp(i, 1) },
        { k: "tr", label: "앞 조각과의 전환…", dis: i === 0, run: () => openTrMenu(i, e.clientX, e.clientY) });
    }
    if (kind === "ov") {
      const hasA = srcInfo(o.src).has_audio !== false;
      items.push("-", { k: "mute", label: ovAudioOn(o) ? "소리 끄기(이 조각)" : "소리 켜기", dis: !hasA, run: () => { o.audio = !ovAudioOn(o); markDirty(); drawTrack(); ovSync(); } },
        { k: "full", label: "원본 전체 길이로", run: () => $("#tkFull").click() },
        { k: "down", label: "영상 1 트랙 끝으로 내리기", run: () => { const ovs = ovsOf(s); const [oo] = ovs.splice(i, 1); cs.push({ s: oo.s, e: oo.e, src: oo.src, mute: oo.mute, speed: oo.speed, hold: oo.hold }); S.ci = cs.length - 1; S.selKind = "clip"; keepPlayhead(() => afterClipsChange(null)); ovSync(); } });
    }
    if (kind === "aud") items.push("-", { k: "vol", label: "음량 조절(오른쪽 「오디오」 칸)", run: () => { fillAudPanel(); $("#audSec").scrollIntoView({ behavior: "smooth", block: "center" }); } });
    if (kind === "txt") items.splice(0, 0, ...txtQuickItems(i), "-");
    items.push("-", { k: "undo", label: "실행 취소", key: "Ctrl+Z", dis: S.histIdx <= 0, run: undo }, { k: "del", label: kind === "nar" ? "낭독 빼기" : kind === "bgm" ? "음악 빼기" : "삭제", key: "Del", run: () => $("#tkDel").click() });
    ctxShow(e.clientX, e.clientY, name, items);
    return;
  }
  const items = [                                   // 빈 곳: 붙여넣기·텍스트 넣기·되돌리기
    { k: "paste", label: "여기에 붙여넣기", key: "Ctrl+V", dis: !cb, run: () => { seekOut(Tclick); setTimeout(() => pasteClipboard(null), 60); } },
    { k: "txt", label: "여기에 텍스트 넣기", key: "T", run: () => { seekOut(Tclick); setTimeout(addText, 60); } },
    { k: "ph", label: "빨간 선을 여기로", run: () => seekOut(Tclick) },
    "-",
    { k: "undo", label: "실행 취소", key: "Ctrl+Z", dis: S.histIdx <= 0, run: undo },
    { k: "redo", label: "다시 실행", key: "Ctrl+Y", dis: S.histIdx >= S.hist.length - 1, run: redo },
  ];
  ctxShow(e.clientX, e.clientY, `${fmt(Tclick, 1)} 위치`, items);
});
document.addEventListener("keydown", e => {
  if (!S.p || !tkVisible() || $("#view-editor").classList.contains("hidden")) return;
  const t = e.target; if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;   // 입력칸에선 브라우저 기본(복사·붙여넣기 포함)
  const mod = e.ctrlKey || e.metaKey; const key = e.key.toLowerCase();
  if (mod && key === "z" && !e.shiftKey) { e.preventDefault(); undo(); return; }
  if ((mod && key === "y") || (mod && key === "z" && e.shiftKey)) { e.preventDefault(); redo(); return; }
  if (mod && key === "c") { e.preventDefault(); if (copySelected()) toast("복사했습니다. Ctrl+V 로 빨간 선 위치에 붙여 넣습니다"); return; }
  if (mod && key === "x") { e.preventDefault(); if (copySelected()) { $("#tkDel").click(); toast("잘라냈습니다. Ctrl+V 로 붙여 넣습니다"); } return; }
  if (mod && key === "v") { e.preventDefault(); pasteClipboard(null); return; }
  if (mod && key === "d") { e.preventDefault(); duplicateSelected(); return; }
  if (mod && key === "a") { e.preventDefault(); mselAll(); return; }
  if (mod || e.altKey) return;                       // Ctrl+S 같은 조합은 아래 한 글자 단축키로 새지 않게
  if (e.key === "Escape" && S.msel.length) { mselClear(); paintMsel(); return; }
  if (e.key === "Delete") { e.preventDefault(); $("#tkDel").click(); }
  else if (e.key === "s" || e.key === "S") { e.preventDefault(); $("#tkSplit").click(); }
  else if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); const s = cur(); const step = (e.shiftKey ? 1 : 1 / 30) * (e.key === "ArrowLeft" ? -1 : 1); seekOut(Math.max(0, outTime(s, vid.currentTime) + step)); }
  else if (e.key === "t" || e.key === "T") { e.preventDefault(); addText(); }
  else if (e.key === "q" || e.key === "Q") { e.preventDefault(); trimAtPlayhead("left"); }
  else if (e.key === "w" || e.key === "W") { e.preventDefault(); trimAtPlayhead("right"); }
  else if (e.key === " ") { e.preventDefault(); $("#btnPlay").click(); }
});

/* ───────── 저장 ───────── */
function markDirty() { histPush(); S.dirty = true; $("#saveState").textContent = "저장 중…"; clearTimeout(S.saveTimer); S.saveTimer = setTimeout(saveNow, 700); }
/* ───── 실행 취소·다시 실행: 편집 상태(쇼츠·설정·자막·낭독·소스 목록)를 통째로 스냅샷. 0.7초 안의 연속 편집(타이핑·끌기)은 하나로 묶는다 ───── */
S.hist = []; S.histIdx = -1; S.histLast = 0; S.histMute = false;
function histState() {
  const shorts = S.p.shorts.map(s => { const { output, render, poster, ...rest } = s; return rest; });
  return JSON.stringify({ shorts, settings: S.p.settings, cues: S.p.cues, narration: S.p.narration || null, extra_sources: S.p.extra_sources || [] });
}
function histReset() { if (!S.p) return; S.hist = [histState()]; S.histIdx = 0; S.histLast = 0; histButtons(); }
function histPush() {
  if (S.histMute || !S.p || !S.p.shorts) return; const st = histState(); if (st === S.hist[S.histIdx]) return;
  S.hist.length = S.histIdx + 1;                                            // 되돌린 뒤 새로 편집하면 그 뒤 기록은 버린다
  const now = Date.now();
  if (now - S.histLast < 700 && S.hist.length > 1) S.hist[S.hist.length - 1] = st;
  else { S.hist.push(st); if (S.hist.length > 100) S.hist.shift(); }
  S.histIdx = S.hist.length - 1; S.histLast = now; histButtons();
}
function histButtons() { const u = $("#tkUndo"), r = $("#tkRedo"); if (u) u.disabled = S.histIdx <= 0; if (r) r.disabled = S.histIdx >= S.hist.length - 1; }
function histApply(st) {
  const d = JSON.parse(st); const keep = {}; S.p.shorts.forEach(s => { keep[s.id] = { output: s.output, render: s.render, poster: s.poster }; });
  S.p.shorts = d.shorts.map(s => Object.assign(s, keep[s.id] || {})); S.p.settings = d.settings; S.p.cues = d.cues; S.p.narration = d.narration; S.p.extra_sources = d.extra_sources;
  if (!S.p.shorts.find(s => s.id === S.sid)) S.sid = S.p.shorts[0] && S.p.shorts[0].id;
  const T = Math.max(0, outTime(cur(), vid.currentTime)); const sel = { kind: S.selKind, ci: S.ci, oi: S.oi, ti: S.ti, ai: S.ai };
  S.histMute = true;
  try {
    applyShopMode(); renderList(); fillDesign(); cueSourceLabel(); selectShort(S.sid); fillHook(); fillBgm(); fillMask(); renderTexts(); renderMedia();
    S.selKind = sel.kind; S.ci = clamp(sel.ci || 0, 0, clipsOf(cur()).length - 1); S.oi = sel.oi || 0; S.ti = sel.ti || 0; S.ai = sel.ai || 0; drawTrack(); fillTxtPanel();
    seekOut(Math.min(T, Math.max(0, outLen(cur()) - 0.05)));
  } finally { S.histMute = false; }
  S.dirty = true; $("#saveState").textContent = "저장 중…"; clearTimeout(S.saveTimer); S.saveTimer = setTimeout(saveNow, 300);   // 기록은 안 남기고 저장만
  histButtons();
}
function undo() { if (S.histIdx <= 0) return toast("되돌릴 게 없습니다"); S.histIdx--; histApply(S.hist[S.histIdx]); toast(`실행 취소 (${S.histIdx}/${S.hist.length - 1})`); }
function redo() { if (S.histIdx >= S.hist.length - 1) return toast("다시 실행할 게 없습니다"); S.histIdx++; histApply(S.hist[S.histIdx]); toast(`다시 실행 (${S.histIdx}/${S.hist.length - 1})`); }
async function saveNow() {
  if (!S.p || !S.dirty) return; S.dirty = false;
  try {
    const shorts = S.p.shorts.map(s => { const { output, render, ...rest } = s; return rest; });
    const r = await api("/api/projects/" + S.p.id, { method: "PUT", body: { _via: "timer", _base: S.p.updated || 0, settings: S.p.settings, shorts, cues: S.p.cues, ...(isShop() ? { narration: S.p.narration || null } : {}) } });
    if (r && r.updated) S.p.updated = r.updated;
    $("#saveState").textContent = "저장됨";
  } catch (e) {
    if (e && e.stale) {                             // 다른 창(또는 오래된 사본)이 먼저 저장함 → 이 창의 편집을 버리고 서버 것을 다시 읽는다
      $("#saveState").textContent = "다른 창이 저장함"; toast("다른 창에서 이 프로젝트가 바뀌어 다시 불러옵니다. 방금 편집은 그 창의 내용으로 대체됩니다.", true);
      const pid = S.p.id; S.dirty = false; setTimeout(() => openEditor(pid), 800); return;
    }
    $("#saveState").textContent = "저장 실패"; toast("저장 실패: " + e.message, true); S.dirty = true;
  }
}

/* ───────── 렌더 / 내보내기 ───────── */
function noteMasterVol() { const m = mVol(); if (Math.abs(m - 1) > 0.001) toast(`결과물 음량 ${Math.round(m * 100)}% 로 만듭니다 (미리듣기 음량과 별개)`, true); }
async function render(ids) {
  noteMasterVol();
  await saveNow();
  try { await api("/api/projects/" + S.p.id + "/render", { method: "POST", body: { ids } }); toast("렌더링을 시작했습니다. 끝나면 왼쪽 목록에 「렌더됨 · ▶ 결과 보기」가 뜹니다"); startEditorPoll(true); }
  catch (e) { toast(e.message, true); }
}
/* 저장 = 렌더 + 저장 폴더로 복사. 폴더가 아직 없으면 먼저 고르게 한다 */
async function saveShorts(ids) {
  noteMasterVol();
  await saveNow();
  if (!S.p.export_dest) {
    try { const r = await api("/api/projects/" + S.p.id + "/export_default", { method: "POST", body: {} }); $("#exDest").value = r.dest || ""; } catch (e) { $("#exDest").value = ""; }
    S.pendingSaveIds = ids; $("#exRerender").checked = true; $("#exportModal").classList.remove("hidden"); return;
  }
  runExport(S.p.export_dest, ids, true, true);
}
async function runExport(dest, ids, rerender, open) {
  try {
    await api("/api/projects/" + S.p.id + "/export", { method: "POST", body: { dest, ids: ids || undefined, rerender, open } });
    S.p.export_dest = dest; toast((ids ? TERMo() : "쇼츠 전체를") + " 렌더해서 저장합니다 → " + dest);
    watchExport();
  } catch (e) { toast(e.message, true); }
}
$("#btnCapcut").onclick = async () => {
  await saveNow();
  try {
    const r = await api("/api/projects/" + S.p.id + "/export_capcut", { method: "POST", body: { id: S.sid, open: true } });
    toast("CapCut 프로젝트를 만들었습니다 → " + r.path + "  (CapCut 을 열면 목록에 보입니다)");
  } catch (e) { toast(e.message, true); }
};
$("#btnRenderOne").onclick = () => saveShorts([S.sid]);
$("#btnRenderAll").onclick = () => saveShorts(null);
$("#btnRenderOnly").onclick = () => render(isShop() ? null : [S.sid]);   // 렌더만(프로젝트 output 에). 쇼핑은 하나뿐이라 전체
$("#btnOpenFolder").onclick = async () => {
  if (S.p.export_dest) { try { await api("/api/open_path", { method: "POST", body: { path: S.p.export_dest } }); return; } catch (e) { /* 폴더가 아직 없으면 프로젝트 output 으로 */ } }
  api("/api/projects/" + S.p.id + "/open", { method: "POST", body: {} }).catch(e => toast(e.message, true));
};
$("#btnExport").onclick = async () => {
  await saveNow();
  try { const r = await api("/api/projects/" + S.p.id + "/export_default", { method: "POST", body: {} }); $("#exDest").value = r.dest || ""; } catch (e) { $("#exDest").value = S.p.export_dest || ""; }
  $("#exRerender").checked = false; S.pendingSaveIds = null;
  $("#exportModal").classList.remove("hidden");
};
$("#btnExPick").onclick = async () => {
  toast("폴더 선택 창이 열렸습니다. 다른 창 뒤에 있을 수 있습니다.");
  try { const r = await api("/api/pick_folder?initial=" + encodeURIComponent($("#exDest").value || "")); if (r.path) $("#exDest").value = r.path; } catch (e) { toast(e.message, true); }
};
$("#btnExGo").onclick = async () => {
  const dest = $("#exDest").value.trim(); if (!dest) return toast("폴더를 골라 주세요", true);
  $("#exportModal").classList.add("hidden");
  const ids = S.pendingSaveIds === undefined ? null : S.pendingSaveIds; S.pendingSaveIds = undefined;
  runExport(dest, ids, $("#exRerender").checked, $("#exOpen").checked);
};
$("#btnExCancel").onclick = () => { $("#exportModal").classList.add("hidden"); S.pendingSaveIds = undefined; };
$("#btnExOpenNow").onclick = () => $("#btnOpenFolder").click();       // 폴더 열기는 대화상자 안으로 옮겼다(머리글 단추는 숨김)
function watchExport() {
  clearInterval(S.exPoll); startEditorPoll(true);
  S.exPoll = setInterval(async () => {
    let p; try { p = await api("/api/projects/" + S.p.id); } catch (e) { return; }
    const j = p.job; if (j && j.running && j.kind === "export") { $("#saveState").textContent = (j.message || "내보내는 중") + (j.pct != null ? " " + j.pct + "%" : ""); return; }
    clearInterval(S.exPoll); $("#saveState").textContent = "저장됨";
    if (j && j.kind === "export") { if (j.errors?.length) toast("내보내기 실패: " + j.errors.join(" / "), true); else toast(j.message || "내보내기 완료"); }
  }, 1500);
}
$("#btnReanalyze").onclick = async () => {
  if (!confirm("현재 쇼츠와 편집 내용이 모두 새 결과로 바뀝니다. 계속할까요?")) return;
  await saveNow();
  try { await api("/api/projects/" + S.p.id + "/analyze", { method: "POST", body: { settings: { count: +$("#reCount").value } } }); openProgress(S.p.id); }
  catch (e) { toast(e.message, true); }
};
function startEditorPoll(force) {
  stopPoll();
  const tick = async () => {
    if ($("#view-editor").classList.contains("hidden")) return stopPoll();
    let p; try { p = await api("/api/projects/" + S.p.id); } catch (e) { return; }
    const running = p.job && p.job.running && (p.job.kind === "render" || p.job.kind === "export");
    // 렌더 결과만 반영하고 편집 중인 필드는 건드리지 않는다
    p.shorts.forEach(ns => { const s = S.p.shorts.find(x => x.id === ns.id); if (s) { s.output = ns.output; s.render = ns.render; s.poster = ns.poster; } });
    S.p.job = p.job; S.p.status = p.status;
    renderList();
    if (!running) { stopPoll(); if (p.job && p.job.kind === "render" && p.job.finished && !p.job.running) { if (p.job.errors?.length) toast("렌더 실패: " + p.job.errors.join(" / "), true); else if (force || Date.now() / 1000 - p.job.finished < 5) toast("렌더가 끝났습니다. 왼쪽 목록에서 내려받으세요."); } }
  };
  tick(); S.poll = setInterval(tick, 1500);
}

/* ───────── 서버 종료 ───────── */
$("#btnQuit").onclick = async () => {
  if (!confirm("쇼츠컷 서버를 끌까요? 다시 켜려면 바탕 화면의 「쇼츠컷」을 누르면 됩니다.")) return;
  try { await api("/api/quit", { method: "POST", body: {} }); }
  catch (e) {
    if (!confirm(e.message + "\n\n그래도 강제로 끌까요?")) return;
    try { await api("/api/quit", { method: "POST", body: { force: true } }); } catch (e2) { return toast(e2.message, true); }
  }
  document.body.innerHTML = '<div style="padding:60px;text-align:center;color:#8b93a6;font-size:16px">쇼츠컷 서버를 껐습니다. 이 탭은 닫아도 됩니다.<br><br>다시 켜려면 바탕 화면의 「쇼츠컷」을 누르세요.</div>';
};

/* 화면 상태(빨간 선·확대·선택)는 브라우저에 기억해 두고 다시 열 때 그대로 복원한다 */
function saveView() {
  if (!S.p || !tkVisible() || !S.viewRestored) return; const s = cur(); if (!s) return;   // 복원 전에는 저장하지 않는다(초기 seek 가 0 으로 덮어쓰는 것 방지)
  try { localStorage.setItem("view:" + S.p.id, JSON.stringify({ T: Math.max(0, outTime(s, vid.currentTime)), zoom: S.tkZoom, span: S.tkSpan, scroll: tk.scrollLeft, sid: S.sid })); } catch (_) {}
}
function restoreView() {
  if (!S.p) return; const v = S.viewToRestore; S.viewRestored = true;
  if (!v || !tkVisible()) return;
  if (v.span) S.tkSpan = v.span; if (v.zoom) { S.tkZoom = v.zoom; $("#tkZoom").value = v.zoom; } drawTrack();
  if (v.scroll) tk.scrollLeft = v.scroll;
  if (v.T > 0.05) seekOut(Math.min(v.T, Math.max(0, outLen(cur()) - 0.05)));
}
vid.addEventListener("pause", saveView); vid.addEventListener("seeked", saveView);
setInterval(() => { if (S.p && !$("#view-editor").classList.contains("hidden")) saveView(); }, 3000);
window.addEventListener("pagehide", () => {                       // 창을 닫을 때 저장 못 한 편집이 있으면 마지막으로 보낸다
  saveView();
  if (!S.p || !S.dirty) return; S.dirty = false;
  const shorts = S.p.shorts.map(s => { const { output, render, ...rest } = s; return rest; });
  try { fetch("/api/projects/" + S.p.id, { method: "PUT", keepalive: true, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ _via: "pagehide", _base: S.p.updated || 0, settings: S.p.settings, shorts, cues: S.p.cues, ...(isShop() ? { narration: S.p.narration || null } : {}) }) }); } catch (_) {}
});

/* ───────── 시작 ───────── */
(async () => {
  S.layouts = await api("/api/layouts");
  loadAiConfig();
  show("home");
  const m = location.hash.match(/^#p=(.+)$/);
  if (m) return openEditor(m[1]);
  let last = null; try { last = localStorage.getItem("lastProject"); } catch (_) {}   // 다시 실행하면 마지막에 편집하던 프로젝트로 바로 간다
  if (last) { try { const lp = await api("/api/projects/" + last); if (lp.kind === "shop") openEditor(last); else openResults(last); } catch (_) { try { localStorage.removeItem("lastProject"); } catch (__) {} } }
})();

/* ───────── 결과 목록(롱폼 → 쇼츠): AI 가 고른 구간을 카드 하나씩. 카드를 누르면 그 쇼츠로 편집기가 열린다 ───────── */
function rsCuesText(s) {                                 // 구간 안의 자막 글자(쇼츠별 손교정 반영)
  const cs = clipsOf(s); const out = [];
  cs.forEach(c => { if (c.src && c.src !== "main") return;
    (S.p.cues || []).forEach(q => { if (q.e <= c.s || q.s >= c.e) return; out.push((s.cue_edits && s.cue_edits[q.id] != null) ? s.cue_edits[q.id] : q.text); }); });
  return out.join(" ").replace(/\s+/g, " ").trim();
}
function rsLen(s) { return clipsOf(s).reduce((a, c) => a + Math.max(0, c.e - c.s), 0); }
function rsOrder(p) {                                    // 점수가 있으면 높은 순, 없으면 AI 가 준 순서(시간순)
  const arr = p.shorts.slice();
  if (arr.some(s => s.score != null && s.score !== "")) arr.sort((x, y) => (+y.score || 0) - (+x.score || 0));
  return arr;
}
async function openResults(pid, opt = {}) {
  const token = (S.openToken = (S.openToken || 0) + 1);
  stopPoll(); clearTimeout(S.rsT); show("results");
  try { localStorage.setItem("lastProject", pid); } catch (_) {}
  let p; try { p = await api("/api/projects/" + pid); } catch (e) { toast(e.message, true); show("home"); return; }
  if (token !== S.openToken) return;
  S.p = p; S.rsPid = pid;
  if (opt.reveal) rsReveal(p.shorts.length);
  renderResults();
  if (p.job && p.job.running) rsPoll();
}
function rsReveal(n) {
  const el = $("#rsReveal"); $("#rsRevealN").textContent = n; el.classList.remove("hidden", "out");
  clearTimeout(S.rsRevealT); S.rsRevealT = setTimeout(() => { el.classList.add("out"); setTimeout(() => el.classList.add("hidden"), 600); }, 1800);
  el.onclick = () => { clearTimeout(S.rsRevealT); el.classList.add("hidden"); };
}
function rsBtnsHtml(s) {
  const j = S.p.job; const busy = j && j.running && (j.kind === "render" || j.kind === "export") && (j.current === s.id || !j.current);
  const out = s.output ? `/media/${S.p.id}/output/${encodeURIComponent(s.output)}` : "";
  return `<button class="btn primary" data-a="edit" title="이 쇼츠를 편집기에서 엽니다">✎ 편집하기</button>` +
    (busy ? `<button class="btn" disabled>⏳ 렌더 중 ${j.pct || 0}%</button>` :
      out ? `<a class="btn" href="${out}?download=1" download title="렌더된 mp4 를 내려받습니다">⬇ 다운로드</a><a class="btn" href="${out}" target="_blank" title="렌더된 결과를 새 탭에서 봅니다">▶ 결과 보기</a>` :
        `<button class="btn" data-a="render" title="이 쇼츠를 지금 설정으로 렌더합니다. 끝나면 여기서 바로 내려받습니다">⬇ 다운로드 (렌더)</button>`);
}
function renderResults() {
  const p = S.p; const box = $("#rsList"); box.innerHTML = "";
  $("#rsTitle").textContent = p.source.title || p.source.path || p.source.url || "";
  const rg = p.settings.range || [0, p.source.duration];
  $("#rsSub").textContent = `쇼츠 ${p.shorts.length}개 · 분석 구간 ${fmt(rg[0])} – ${fmt(rg[1] || p.source.duration)}` + (p.settings.channel_name ? ` · ${p.settings.channel_name}` : "");
  $("#rsCount").value = String(p.settings.count || p.shorts.length || 4);
  const accent = p.settings.accent || "#FF3B3B"; const [rw, rh] = (p.settings.ratio || "16:9").split(":").map(Number);
  const chan = p.settings.channel_name || p.source.channel || "";
  rsOrder(p).forEach((s, i) => {
    const el = document.createElement("article"); el.className = "rs-card"; el.dataset.id = s.id;
    const len = rsLen(s); const cs = clipsOf(s);
    const cues = (p.cues || []).filter(q => q.e > cs[0].s && q.s < cs[0].e);
    const sub = cues[0] ? ((s.cue_edits && s.cue_edits[cues[0].id] != null) ? s.cue_edits[cues[0].id] : cues[0].text) : "";
    const script = rsCuesText(s);
    const badge = s.score != null && s.score !== "" ? `<span class="rs-badge">바이럴 점수 ${Math.round(+s.score)}/100</span>` : `<span class="rs-badge dimb">${Math.round(len)}초</span>`;
    const tags = (s.tags || []).map(t => `<span class="chip">${esc(t)}</span>`).join("");
    el.innerHTML = `
      <div class="rs-head" data-a="edit"><span class="rs-n">#${i + 1}</span><h2 class="rs-title">${esc(s.line1 || s.yt_title || s.id)}${s.line2 ? ` <em style="color:${accent}">${esc(s.line2)}</em>` : ""}</h2>${badge}</div>
      <div class="rs-body">
        <div class="rs-left">
          <div class="rs-phone" style="--acc:${accent};--vr:${rw}/${rh}">
            <span class="rs-dur mono">${Math.round(len)}초</span>
            <div class="rs-ph-t1" data-a="edit">${esc(s.line1 || "")}</div><div class="rs-ph-t2" data-a="edit">${esc(s.line2 || "")}</div>
            <div class="rs-ph-vid"><img src="${s.poster ? `/media/${p.id}/work/${s.poster}?v=${s.render?.at || 0}` : ""}" alt="" data-a="edit"><button class="rs-play" title="이 구간을 원본 영상으로 재생">▶</button></div>
            <div class="rs-ph-sub">${esc(sub)}</div>
            <div class="rs-ph-chan"><span class="av">${esc((chan || "채").slice(0, 1))}</span>${esc(chan)}</div>
          </div>
          <div class="rs-btns">${rsBtnsHtml(s)}</div>
        </div>
        <div class="rs-right">
          <div class="rs-box hl"><div class="rs-box-h">✦ AI 하이라이트</div><div class="rs-reason">${esc(s.reason || "선정 이유가 없습니다")}</div></div>
          <div class="rs-row"><span class="dim small">원본 영상 타임라인</span><span class="mono small">⏱ ${fmt(cs[0].s)} – ${fmt(cs[cs.length - 1].e)} · ${Math.round(len)}초${cs.length > 1 ? ` · ${cs.length}조각` : ""}</span></div>
          <div class="rs-box"><div class="rs-box-h">스크립트 <button class="lnk" data-copy="script">복사</button></div><div class="rs-script">${esc(script || "이 구간에 자막이 없습니다")}</div></div>
          <div class="rs-box"><div class="rs-box-h">업로드 정보 <button class="lnk" data-copy="all">전체 복사</button></div>
            <div class="rs-up"><label>제목</label><div class="rs-up-v">${esc(s.yt_title || "")}</div><button class="lnk" data-copy="title">복사</button></div>
            <div class="rs-up"><label>설명</label><pre class="rs-up-v">${esc(s.description || "")}</pre><button class="lnk" data-copy="desc">복사</button></div>
            <div class="rs-up"><label>태그</label><div class="rs-up-v rs-tags">${tags}</div><button class="lnk" data-copy="tags">복사</button></div>
          </div>
        </div>
      </div>`;
    box.appendChild(el);
  });
  if (!p.shorts.length) box.innerHTML = `<div class="rs-empty">쇼츠 구간이 없습니다. 위의 「다시 분석」으로 AI 에게 다시 맡기세요.</div>`;
}
function rsUpdateBtns() { $$(".rs-card", $("#rsList")).forEach(el => { const s = S.p.shorts.find(x => x.id === el.dataset.id); if (s) $(".rs-btns", el).innerHTML = rsBtnsHtml(s); }); }
function rsPoll() {                                      // 렌더·내보내기 중이면 단추만 갱신(재생 중인 미리보기는 건드리지 않는다)
  clearTimeout(S.rsT);
  S.rsT = setTimeout(async () => {
    if ($("#view-results").classList.contains("hidden")) return;
    let p; try { p = await api("/api/projects/" + S.rsPid); } catch (_) { return rsPoll(); }
    p.shorts.forEach(ns => { const s = S.p.shorts.find(x => x.id === ns.id); if (s) { s.output = ns.output; s.render = ns.render; s.poster = ns.poster; } });
    S.p.job = p.job; S.p.status = p.status; rsUpdateBtns();
    if (p.job && p.job.running) return rsPoll();
    if (p.job && p.job.kind === "render" && p.job.finished && Date.now() / 1000 - p.job.finished < 6) { if (p.job.errors?.length) toast("렌더 실패: " + p.job.errors.join(" / "), true); else toast("렌더가 끝났습니다. 「⬇ 다운로드」로 내려받으세요."); }
  }, 1500);
}
function rsPlay(card, s) {                               // 포스터 자리에 원본 영상을 띄워 그 구간만 재생
  const holder = $(".rs-ph-vid", card); const cs = clipsOf(s); const c0 = cs[0];
  $$(".rs-ph-vid video", $("#rsList")).forEach(v => { v.pause(); v.remove(); });
  $$(".rs-ph-vid img, .rs-ph-vid .rs-play", $("#rsList")).forEach(x => x.classList.remove("hidden"));
  const v = document.createElement("video"); v.src = srcMediaUrl(c0.src); v.controls = true; v.playsInline = true; v.preload = "auto";
  v.onloadedmetadata = () => { v.currentTime = c0.s; v.play().catch(() => {}); };
  v.ontimeupdate = () => { if (v.currentTime >= c0.e - 0.05) { v.pause(); v.currentTime = c0.s; } };
  v.onended = () => { v.currentTime = c0.s; };
  $("img", holder).classList.add("hidden"); $(".rs-play", holder).classList.add("hidden"); holder.appendChild(v);
}
async function rsCopy(text, label) {
  try { await navigator.clipboard.writeText(text); toast(label + " 복사했습니다"); }
  catch (_) { const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); toast(label + " 복사했습니다"); } catch (__) { toast("복사 실패 — 직접 선택해서 복사하세요", true); } ta.remove(); }
}
$("#rsList").onclick = async e => {
  const card = e.target.closest(".rs-card"); if (!card) return;
  const s = S.p.shorts.find(x => x.id === card.dataset.id); if (!s) return;
  const cp = e.target.closest("[data-copy]");
  if (cp) {
    const k = cp.dataset.copy; const tags = (s.tags || []).join(", ");
    const text = k === "script" ? rsCuesText(s) : k === "title" ? (s.yt_title || "") : k === "desc" ? (s.description || "") : k === "tags" ? tags
      : `제목: ${s.yt_title || ""}\n\n설명:\n${s.description || ""}\n\n태그: ${tags}`;
    rsCopy(text, { script: "스크립트를", title: "제목을", desc: "설명을", tags: "태그를", all: "업로드 정보를" }[k]); return;
  }
  if (e.target.closest(".rs-play")) { rsPlay(card, s); return; }
  const a = e.target.closest("[data-a]"); if (!a) return;
  if (a.dataset.a === "edit") { openEditor(S.p.id, s.id); return; }
  if (a.dataset.a === "render") {
    a.disabled = true; a.textContent = "⏳ 렌더 준비…";
    try { await api("/api/projects/" + S.p.id + "/render", { method: "POST", body: { ids: [s.id] } }); toast("렌더링을 시작했습니다. 끝나면 이 자리에 「⬇ 다운로드」가 뜹니다"); S.p.job = { running: true, kind: "render", current: s.id, pct: 0 }; rsUpdateBtns(); rsPoll(); }
    catch (err) { toast(err.message, true); rsUpdateBtns(); }
  }
};
$("#rsExportAll").onclick = () => { if (!S.p) return; saveShorts(null); rsPoll(); };
$("#rsReanalyze").onclick = async () => {
  if (!S.p) return;
  if (!confirm("현재 쇼츠와 편집 내용이 모두 새 결과로 바뀝니다. 계속할까요?")) return;
  try { await api("/api/projects/" + S.p.id + "/analyze", { method: "POST", body: { settings: { count: +$("#rsCount").value } } }); openProgress(S.p.id); }
  catch (e) { toast(e.message, true); }
};
$("#edBackList").onclick = async e => { e.preventDefault(); if (!S.p) return; await saveNow(); openResults(S.p.id); };


/* ───── 트랙 복수 선택: Ctrl/Shift+클릭 · 빈 곳 끌어 상자 · Ctrl+A. 키는 "clip:<번호>" / "ov:<id>" / "txt:<id>" / "aud:<id>" / "nar" / "bgm" ───── */
S.msel = [];
function mselKeyOf(kind, i) {
  const s = cur(); if (!s) return null;
  if (kind === "clip") return "clip:" + i;
  if (kind === "ov") { const o = ovsOf(s)[i]; return o ? "ov:" + o.id : null; }
  if (kind === "txt") { const t = txtsOf(s)[i]; return t ? "txt:" + t.id : null; }
  if (kind === "aud") { const a = audsOf(s)[i]; return a ? "aud:" + a.id : null; }
  return kind === "nar" || kind === "bgm" ? kind : null;
}
function mselHas(kind, i) { const k = mselKeyOf(kind, i); return !!k && S.msel.includes(k); }
function mselToggle(kind, i) { const k = mselKeyOf(kind, i); if (!k) return; const j = S.msel.indexOf(k); if (j >= 0) S.msel.splice(j, 1); else S.msel.push(k); }
function mselClear() { S.msel = []; }
function mselAddPrimary() {                           // 지금 선택돼 있는 항목을 복수 선택의 첫 항목으로
  const i = S.selKind === "clip" ? S.ci : S.selKind === "ov" ? S.oi : S.selKind === "txt" ? S.ti : S.selKind === "aud" ? S.ai : 0;
  const k = mselKeyOf(S.selKind, i); if (k && !S.msel.includes(k)) S.msel.push(k);
}
function mselResolve() {                              // 키 → 실제 항목 [{kind, i, obj}]
  const s = cur(); if (!s) return []; const out = [];
  S.msel.forEach(k => {
    const [kind, id] = k.split(":");
    if (kind === "clip") { const i = +id; if (clipsOf(s)[i]) out.push({ kind, i, obj: clipsOf(s)[i] }); }
    else if (kind === "ov") { const i = ovsOf(s).findIndex(o => o.id === id); if (i >= 0) out.push({ kind, i, obj: ovsOf(s)[i] }); }
    else if (kind === "txt") { const i = txtsOf(s).findIndex(t => t.id === id); if (i >= 0) out.push({ kind, i, obj: txtsOf(s)[i] }); }
    else if (kind === "aud") { const i = audsOf(s).findIndex(a => a.id === id); if (i >= 0) out.push({ kind, i, obj: audsOf(s)[i] }); }
    else if (kind === "nar") { if (S.p.narration && S.p.narration.url) out.push({ kind, i: 0, obj: null }); }
    else if (kind === "bgm") { if (bgmOn(bgmSettings())) out.push({ kind, i: 0, obj: null }); }
  });
  return out;
}
function itemStartOf(m) {
  const s = cur();
  if (m.kind === "clip") return clipOffsets(s).offs[m.i] || 0;
  if (m.kind === "ov") return m.obj.at || 0; if (m.kind === "txt") return +m.obj.at || 0; if (m.kind === "aud") return audPlace(m.obj).at;
  if (m.kind === "nar") return narPlace(s).at; return bgmPlace(s).at;
}
function itemEndOf(m) {
  const s = cur();
  if (m.kind === "clip") return itemStartOf(m) + clipOut(m.obj);
  if (m.kind === "ov") return m.obj.at + clipOut(m.obj); if (m.kind === "txt") return (+m.obj.at || 0) + (+m.obj.dur || 0);
  if (m.kind === "aud") { const g = audPlace(m.obj); return g.at + (g.out - g.in); }
  if (m.kind === "nar") { const n = narPlace(s); return n.at + (n.out - n.in); } return bgmPlace(s).until;
}
function itemMoveTo(g, at) {                          // 묶음 이동용: 자유 항목의 시작 시각을 at 으로
  const s = cur(); at = r2(Math.max(0, at));
  if (g.kind === "ov") g.obj.at = r2(clamp(at, 0, Math.max(0, MAX_OUT - clipOut(g.obj))));
  else if (g.kind === "txt") g.obj.at = r2(clamp(at, 0, MAX_OUT - (+g.obj.dur || 3)));
  else if (g.kind === "aud") { const p = audPlace(g.obj); audSet(g.obj, { at: clamp(at, 0, Math.max(0, MAX_OUT - (p.out - p.in))), in: p.in, out: p.out }); }
  else if (g.kind === "nar") { const n = narPlace(s); narSet(s, { at: clamp(at, 0, Math.max(0, MAX_OUT - (n.out - n.in))), in: n.in, out: n.out }); }
  else if (g.kind === "bgm") { const b = bgmSettings(); const span = (b.until != null ? b.until : outLen(s, { noBgm: true })) - (b.at || 0); b.at = r2(clamp(at, 0, MAX_OUT - 0.5)); if (b.until != null) b.until = r2(Math.min(MAX_OUT, b.at + span)); }
}
function mselGroupFor(kind, i) {                      // 이동을 시작한 항목이 복수 선택에 들어 있으면 자유 항목 묶음(주 트랙 조각은 순서 논리라 제외)
  if (!(S.msel.length > 1 && mselHas(kind, i)) || kind === "clip") return null;
  const g = mselResolve().filter(m => m.kind !== "clip").map(m => ({ kind: m.kind, obj: m.obj, at0: itemStartOf(m) }));
  return g.length ? g : null;
}
function mselAll() {
  S.msel = []; $$("#tkRows .tk-item").forEach(el => { const k = mselKeyOf(el.dataset.kind, +el.dataset.i); if (k && !S.msel.includes(k)) S.msel.push(k); });
  paintMsel(); toast(`${S.msel.length}개 전부 선택`);
}
async function mselDelete() {
  const s = cur(); const ms = mselResolve(); if (!ms.length) return;
  const T = Math.max(0, outTime(s, vid.currentTime)); let clipsChanged = false;
  const ovIds = new Set(ms.filter(m => m.kind === "ov").map(m => m.obj.id)); if (ovIds.size) { s.overlays = ovsOf(s).filter(o => !ovIds.has(o.id)); S.oi = 0; }
  const txIds = new Set(ms.filter(m => m.kind === "txt").map(m => m.obj.id)); if (txIds.size) { s.texts = txtsOf(s).filter(t => !txIds.has(t.id)); S.ti = 0; }
  const auds = ms.filter(m => m.kind === "aud").map(m => m.obj.id);
  for (const id of auds) { const i = audsOf(s).findIndex(a => a.id === id); if (i >= 0) { try { const r = await api("/api/projects/" + S.p.id + "/audios", { method: "POST", body: { sid: s.id, remove: id } }); s.audios = r.short.audios || []; const el = S.audEls && S.audEls[id]; if (el) { el.pause(); delete S.audEls[id]; } } catch (e) { toast(e.message, true); } } }
  const cis = ms.filter(m => m.kind === "clip").map(m => m.i).sort((a, b) => b - a); const cs = clipsOf(s);
  cis.forEach(i => { if (cs.length > 1) { cs.splice(i, 1); clipsChanged = true; } });
  const skipped = ms.filter(m => m.kind === "nar" || m.kind === "bgm").length;
  mselClear(); S.selKind = "clip"; S.ci = clamp(S.ci, 0, cs.length - 1); S.ai = 0;
  if (clipsChanged) afterClipsChange(null); else { markDirty(); updateLen(); }
  drawTrack(); renderTexts(); fillTxtPanel(); fillAudPanel(); ovSync(); audSync(isPlaying()); fitStage(); seekOut(Math.min(T, Math.max(0, outLen(s) - 0.05)));
  toast(`${ms.length - skipped}개를 지웠습니다` + (skipped ? " (낭독·음악은 따로 지우세요)" : ""));
}
function tkScrollToT(T) {                              // 결과 시각 T 가 트랙 화면 안에 보이게(밖이면 1/3 지점으로)
  const x = T * tkPps() + TK_PAD; const w = tk.clientWidth; if (x < tk.scrollLeft + 40 || x > tk.scrollLeft + w - 40) tk.scrollLeft = Math.max(0, x - w / 3);
}
function tkBoxEl() { let b = $("#tkBox"); if (!b) { b = document.createElement("div"); b.id = "tkBox"; b.className = "tk-box hidden"; tkIn.appendChild(b); } return b; }
function paintMsel() {
  const on = S.msel.length > 1 || (S.msel.length === 1 && S.tkDrag && S.tkDrag.kind === "box");
  $$("#tkRows .tk-item").forEach(el => el.classList.toggle("msel", on && mselHas(el.dataset.kind, +el.dataset.i)));
}
{ const _drawTrack0 = drawTrack; drawTrack = function () { const r = _drawTrack0.apply(this, arguments); paintMsel(); return r; }; }
/* 오른쪽 끝 끌기: 원본이 남아 있으면 재생 구간을 늘리고, 원본 끝을 넘어서면 그만큼 마지막 장면 멈춤(hold)으로 이어 붙인다. 메뉴로 넣어 둔 멈춤은 그대로 둔다 */
function stretchEnd(c0, dt, maxE, k) {
  // 오른쪽 끝 끌기 = 결과 길이를 정한다. 원본이 남아 있으면 재생 구간을 늘리고, 원본 끝을 넘으면 그만큼 느리게(속도 ↓) 재생해 채운다(캡컷의 속도 늘리기).
  // 끌기는 항상 '느리게' 로 채운다 — 예전에 멈춤(hold)으로 늘려 둔 조각도 끌면 그 길이가 속도로 바뀐다(정지 사진으로 남지 않게). 멈춤은 메뉴로만.
  const total = Math.max(0.3, clipOut(c0) + dt);                                              // 원하는 결과 길이(기존 멈춤 포함)
  const maxSrc = Math.max(0.3, maxE - c0.s);
  let L;
  if (Math.abs(spdOf(c0) - 1) > 1e-6) L = Math.min(maxSrc, c0.e - c0.s);                       // 속도 조절된 조각: 구간 고정, 속도만
  else L = Math.min(maxSrc, total);                                                            // 보통 조각: 원본 끝까지 늘린 뒤 느리게
  const spd = clamp(L / total, 0.1, 8);
  return { e: r2(c0.s + L), hold: 0, speed: Math.abs(spd - 1) < 1e-3 ? 1 : r2(spd) };
}

/* ───── 자석(스냅): 결과 시각 경계 모음 → 8px 안이면 붙인다. Ctrl 을 누른 채 끌면 끈다. 붙은 자리는 하늘색 세로선 ───── */
function snapPoints(exclude) {
  const s = cur(); if (!s) return []; const pts = [{ t: 0, key: "zero" }];
  if (!exclude.has("ph")) pts.push({ t: Math.max(0, outTime(s, vid.currentTime)), key: "ph" });
  const cs = clipsOf(s); const { offs } = clipOffsets(s);
  cs.forEach((c, i) => { const k = "clip:" + i; if (exclude.has(k)) return; pts.push({ t: offs[i], key: k }, { t: offs[i] + clipOut(c), key: k }); });
  ovsOf(s).forEach(o => { const k = "ov:" + o.id; if (exclude.has(k)) return; pts.push({ t: o.at, key: k }, { t: o.at + clipOut(o), key: k }); });
  txtsOf(s).forEach(t => { const k = "txt:" + t.id; if (exclude.has(k)) return; const a = +t.at || 0; pts.push({ t: a, key: k }, { t: a + (+t.dur || 0), key: k }); });
  audsOf(s).forEach(a => { const k = "aud:" + a.id; if (exclude.has(k)) return; const g = audPlace(a); pts.push({ t: g.at, key: k }, { t: g.at + (g.out - g.in), key: k }); });
  if (isShop() && S.p.narration && S.p.narration.url && !exclude.has("nar")) { const n = narPlace(s); pts.push({ t: n.at, key: "nar" }, { t: n.at + (n.out - n.in), key: "nar" }); }
  const b = bgmSettings(); if (bgmOn(b) && !exclude.has("bgm")) { const g = bgmPlace(s); pts.push({ t: g.at, key: "bgm" }); if (g.until != null) pts.push({ t: g.until, key: "bgm" }); }
  try { shortCues(s).forEach(c => pts.push({ t: c.out_s, key: "cue" }, { t: c.out_e, key: "cue" })); } catch (e) { }
  return pts;
}
function snapOut(T, exclude, ev) {
  if (ev && ev.ctrlKey) { showSnap(null); return T; }
  const tol = 8 / tkPps(); let best = null;
  for (const p of snapPoints(exclude || new Set())) { const d = Math.abs(p.t - T); if (d <= tol && (!best || d < best.d)) best = { d, t: p.t }; }
  showSnap(best ? best.t : null); return best ? best.t : T;
}
function snapSpan(at, len, exclude, ev) {          // 시작·끝 중 더 가까운 쪽을 붙인다 → 새 시작 시각
  if (ev && ev.ctrlKey) { showSnap(null); return at; }
  const tol = 8 / tkPps(); let best = null;
  for (const p of snapPoints(exclude || new Set())) {
    for (const [edge, t] of [["s", at], ["e", at + len]]) { const d = Math.abs(p.t - t); if (d <= tol && (!best || d < best.d)) best = { d, at: edge === "s" ? p.t : p.t - len, t: p.t }; }
  }
  showSnap(best ? best.t : null); return best ? Math.max(0, best.at) : at;
}
function dragSpan(d) {                                // 끌기 시작 때 항목의 결과 시각 구간과 자기 키(자기 경계엔 안 붙게)
  const s = cur(); const c0 = d.c0; if (!s || !c0) return null;
  if (d.kind === "ov") return { start: c0.at, len: clipOut(c0), key: "ov:" + c0.id };
  if (d.kind === "txt") return { start: +c0.at || 0, len: +c0.dur || 3, key: "txt:" + c0.id };
  if (d.kind === "aud") return { start: c0.at, len: c0.out - c0.in, key: "aud:" + ((audsOf(s)[d.i] || {}).id || "") };
  if (d.kind === "nar") return { start: c0.at, len: c0.out - c0.in, key: "nar" };
  if (d.kind === "bgm") return { start: c0.at, len: (c0.until != null ? c0.until : outLen(s, { noBgm: true })) - c0.at, key: "bgm" };
  if (d.kind === "clip") { const { offs } = clipOffsets(s); return { start: offs[d.i] || 0, len: clipOut(c0), key: "clip:" + d.i }; }
  return null;
}
function snapDt(d, dt, ev) {                          // 끌기 종류에 맞춰 dt(결과 초)를 붙인 값으로. 조각의 왼쪽 끝은 결과 시각이 안 바뀌므로 그대로
  if (!d || d.op === "slip" || (ev && ev.ctrlKey)) { showSnap(null); return dt; }
  const info = dragSpan(d); if (!info) return dt;
  const ex = new Set([info.key]);
  if (d.op === "mv") return snapSpan(info.start + dt, info.len, ex, ev) - info.start;
  if (d.op === "s") { if (d.kind === "clip") return dt; return snapOut(info.start + dt, ex, ev) - info.start; }
  return snapOut(info.start + info.len + dt, ex, ev) - (info.start + info.len);
}
function showSnap(t) {
  let el = $("#tkSnap"); if (!el) { el = document.createElement("div"); el.id = "tkSnap"; el.className = "tk-snap hidden"; tkIn.appendChild(el); }
  if (t == null) { el.classList.add("hidden"); return; }
  el.style.left = (t * tkPps() + TK_PAD) + "px"; el.classList.remove("hidden");
}
tk.addEventListener("pointercancel", () => showSnap(null));
