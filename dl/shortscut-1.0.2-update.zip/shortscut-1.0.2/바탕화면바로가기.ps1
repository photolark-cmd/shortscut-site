﻿# 쇼츠컷 바탕 화면 바로가기를 만든다. 한 번만 실행하면 된다.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$lnk = Join-Path $desktop "쇼츠컷.lnk"
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = "$env:SystemRoot\System32\wscript.exe"
$s.Arguments = '"' + (Join-Path $here "start_hidden.vbs") + '"'
$s.WorkingDirectory = $here
$s.IconLocation = (Join-Path $here "icon.ico") + ",0"
$s.Description = "쇼츠컷 — 로컬 쇼츠 제작기"
$s.Save()
Write-Host "만들었습니다: $lnk"
