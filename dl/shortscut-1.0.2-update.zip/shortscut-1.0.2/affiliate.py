# -*- coding: utf-8 -*-
"""제휴 링크 — 쿠팡 파트너스 · 토스 쉐어링크.

상품 URL(쿠팡) 또는 상품 ID(토스)를 수수료가 붙는 링크로 바꾸고, 그 링크를 쓸 때
법으로 함께 내보내야 하는 고지 문구를 같이 돌려준다.

고지 문구를 왜 두 군데 넣나 — 공정위 「추천·보증 등에 관한 표시·광고 심사지침」은
동영상의 경우 **제목 또는 시작·끝부분에 넣고, 일부만 보는 시청자도 알 수 있도록
반복 표시**하라고 한다. 설명란에만 적는 것은 그 요건을 못 채운다. 그래서
  · 설명 첫 줄  (플랫폼 공통 요구)
  · 영상 위 고정 자막  (심사지침의 '반복 표시')
둘 다 넣는다. 유튜브 스튜디오의 「유료 프로모션 포함」 체크는 이것과 별개이므로
업로드할 때 따로 켠다.

키는 화면 「제휴 설정」에서 넣으면 config.json 에 저장된다. 쿠팡 키는
`~/.credentials/coupang/config.json` 에 이미 있으면 그것을 먼저 읽는다.
"""
import hashlib
import hmac
import json
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import pipeline as P

CRED_COUPANG = Path.home() / ".credentials" / "coupang" / "config.json"

COUPANG_HOST = "https://api-gateway.coupang.com"
COUPANG_BASE = "/v2/providers/affiliate_open_api/apis/openapi/v1"
TOSS_TOKEN_URL = "https://oauth2.cert.toss.im/token"
TOSS_HOST = "https://sharelink.toss.im"

PROVIDERS = {
    "coupang": {
        "name": "쿠팡 파트너스",
        "target_label": "쿠팡 상품 URL",
        "target_hint": "https://www.coupang.com/vp/products/… 형태의 주소를 붙여 넣으세요",
        # 쿠팡 파트너스 약관이 요구하는 문장. '포스팅'을 '영상'으로만 바꿔 쓴다.
        "disclosure": "이 영상은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.",
        "keys": ["coupang_access_key", "coupang_secret_key"],
    },
    "toss": {
        "name": "토스 쉐어링크",
        "target_label": "토스 상품 ID (tacaItemId)",
        "target_hint": "토스 쉐어링크는 URL 이 아니라 상품 ID(숫자)를 받습니다",
        "disclosure": "이 영상은 토스 쉐어링크 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.",
        "keys": ["toss_access_key", "toss_secret_key", "toss_publisher_id"],
    },
}

# 영상 위에 계속 띄우는 짧은 문구. '광고'라는 말을 반드시 넣는다 — 심사지침은
# '제휴', 'Sponsored' 처럼 뜻이 흐린 표현을 인정하지 않는다.
ONSCREEN = "유료 광고 포함 · 수수료를 받습니다"

_toss_token = {"value": None, "until": 0}


def _keys():
    """config.json 이 먼저, 비어 있으면 ~/.credentials/coupang 을 본다."""
    cfg = dict(P.load_config())
    if not (cfg.get("coupang_access_key") and cfg.get("coupang_secret_key")) and CRED_COUPANG.exists():
        try:
            c = json.loads(CRED_COUPANG.read_text(encoding="utf-8"))
            cfg.setdefault("coupang_access_key", c.get("access_key") or "")
            cfg.setdefault("coupang_secret_key", c.get("secret_key") or "")
            cfg["coupang_access_key"] = cfg["coupang_access_key"] or c.get("access_key") or ""
            cfg["coupang_secret_key"] = cfg["coupang_secret_key"] or c.get("secret_key") or ""
        except (OSError, ValueError):
            pass
    return cfg


def status():
    """어느 제휴사를 쓸 수 있는지. 키 값은 절대 돌려주지 않는다."""
    cfg = _keys()
    out = []
    for pid, meta in PROVIDERS.items():
        have = [k for k in meta["keys"] if (cfg.get(k) or "").strip()]
        out.append({"id": pid, "name": meta["name"], "ready": len(have) == len(meta["keys"]),
                    "missing": [k for k in meta["keys"] if k not in have],
                    "target_label": meta["target_label"], "target_hint": meta["target_hint"],
                    "disclosure": meta["disclosure"]})
    return {"providers": out, "onscreen": ONSCREEN,
            "coupang_from_credentials": CRED_COUPANG.exists()}


def _http(url, data=None, headers=None, timeout=20, form=False):
    if form and data is not None:
        body = urllib.parse.urlencode(data).encode("utf-8")
        headers = dict(headers or {}, **{"Content-Type": "application/x-www-form-urlencoded"})
    elif data is not None:
        body = json.dumps(data).encode("utf-8")
        headers = dict(headers or {}, **{"Content-Type": "application/json;charset=UTF-8"})
    else:
        body = None
        headers = dict(headers or {})
    req = urllib.request.Request(url, data=body, headers=headers,
                                 method="POST" if body is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


# ── 쿠팡 파트너스 ──────────────────────────────────────────────────────────

def _coupang_auth(method, path, query, access, secret):
    """HMAC 서명. 서명 대상은 (날짜 + 메서드 + 경로 + 쿼리)."""
    signed = datetime.now(timezone.utc).strftime("%y%m%dT%H%M%SZ")
    msg = signed + method + path + query
    sig = hmac.new(secret.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).hexdigest()
    return ("CEA algorithm=HmacSHA256, access-key=%s, signed-date=%s, signature=%s"
            % (access, signed, sig))


def coupang_link(url, cfg=None):
    cfg = cfg or _keys()
    access = (cfg.get("coupang_access_key") or "").strip()
    secret = (cfg.get("coupang_secret_key") or "").strip()
    if not (access and secret):
        raise RuntimeError("쿠팡 파트너스 키가 없습니다. 「제휴 설정」에서 넣어 주세요.")
    url = (url or "").strip()
    if "coupang.com" not in url:
        raise RuntimeError("쿠팡 상품 주소가 아닙니다: %s" % url[:60])
    path = COUPANG_BASE + "/deeplink"
    res = _http(COUPANG_HOST + path, {"coupangUrls": [url]},
                {"Authorization": _coupang_auth("POST", path, "", access, secret)})
    data = res.get("data") or []
    if not data:
        raise RuntimeError("쿠팡이 링크를 주지 않았습니다: %s" % str(res)[:200])
    return (data[0].get("shortenUrl") or data[0].get("landingUrl") or "").strip()


# ── 토스 쉐어링크 ──────────────────────────────────────────────────────────

def toss_token(cfg):
    """토큰은 유효기간이 길다(약 1년). 만료 1시간 전까지 재사용한다."""
    now = time.time()
    if _toss_token["value"] and now < _toss_token["until"]:
        return _toss_token["value"]
    access = (cfg.get("toss_access_key") or "").strip()
    secret = (cfg.get("toss_secret_key") or "").strip()
    if not (access and secret):
        raise RuntimeError("토스 쉐어링크 키가 없습니다. 「제휴 설정」에서 넣어 주세요.")
    res = _http(TOSS_TOKEN_URL, {"grant_type": "client_credentials", "client_id": access,
                                 "client_secret": secret,
                                 "scope": "sharelink:read sharelink:write"}, form=True)
    tok = res.get("access_token")
    if not tok:
        raise RuntimeError("토스 토큰을 받지 못했습니다: %s" % str(res)[:200])
    _toss_token.update(value=tok, until=now + max(60, int(res.get("expires_in") or 3600) - 120))   # 실측 1시간짜리도 온다 → 만료 2분 전까지 재사용
    return tok


def public_ip():
    """이 PC 의 공인 IP(토스 어드민 IP 등록 안내용). 못 얻으면 빈 문자열."""
    try:
        import urllib.request
        with urllib.request.urlopen("https://api.ipify.org", timeout=6) as r:
            return r.read().decode().strip()
    except Exception:
        return ""


def _toss_fail(res):
    """토스 응답이 FAIL 이면 사람이 고칠 수 있는 말로 바꿔 예외를 던진다."""
    err = (res or {}).get("error") or {}
    code = err.get("errorCode") or ""
    if code == "SHARELINK_OPENAPI_ACCESS_DENIED":
        ip = public_ip()
        raise RuntimeError("토스 쉐어링크가 접근을 거부했습니다(SHARELINK_OPENAPI_ACCESS_DENIED). 키는 맞지만 호출하는 PC 의 공인 IP 가 "
                           "쉐어링크 크리에이터 어드민의 Open API 설정에 등록돼 있지 않을 때 이렇게 나옵니다. "
                           + ("지금 이 PC 의 공인 IP: %s → 어드민에 등록한 뒤 다시 시도하세요." % ip if ip else "이 PC 의 공인 IP 를 어드민에 등록한 뒤 다시 시도하세요.")
                           + " (Open API 사용 승인이 아직 안 났을 때도 같은 오류입니다)")
    if code == "SHARELINK_OPENAPI_QUOTA_EXCEEDED":
        raise RuntimeError("토스 쉐어링크 하루 발급 한도(10,000건)를 넘었습니다. 자정(KST) 이후 다시 시도하세요.")
    if code:
        raise RuntimeError("토스 쉐어링크 오류 %s: %s" % (code, err.get("reason") or ""))


def toss_health(cfg=None):
    """GET /openapi/health — 인증·IP 등록까지 확인. 성공이면 True, 아니면 예외(원인 설명)."""
    cfg = cfg or _keys()
    import urllib.request
    req = urllib.request.Request(TOSS_HOST + "/openapi/health", headers={"Authorization": "Bearer " + toss_token(cfg)})
    with urllib.request.urlopen(req, timeout=20) as r:
        res = json.loads(r.read().decode("utf-8"))
    if res.get("resultType") == "SUCCESS":
        return True
    _toss_fail(res)
    raise RuntimeError("토스 쉐어링크 health 실패: %s" % str(res)[:200])


def toss_link(item, cfg=None):
    cfg = cfg or _keys()
    pub = (cfg.get("toss_publisher_id") or "").strip()
    if not pub:
        raise RuntimeError("토스 퍼블리셔 ID 가 없습니다. 「제휴 설정」에서 넣어 주세요.")
    m = re.search(r"\d{4,}", str(item or ""))
    if not m:
        raise RuntimeError("토스 상품 ID(숫자)를 찾지 못했습니다: %s" % str(item)[:60])
    res = _http(TOSS_HOST + "/openapi/links", {"tacaItemId": int(m.group()), "publisherId": pub},
                {"Authorization": "Bearer " + toss_token(cfg)})
    ok = res.get("success") or {}
    link = (ok.get("shortUrl") or ok.get("originUrl") or "").strip()
    if not link:
        _toss_fail(res)
        raise RuntimeError("토스가 링크를 주지 않았습니다: %s" % str(res)[:200])
    return link


# ── 공통 ───────────────────────────────────────────────────────────────────

def make_link(provider, target):
    """반환 {provider, name, link, disclosure, onscreen}. 실패는 예외로 올린다."""
    if provider not in PROVIDERS:
        raise RuntimeError("모르는 제휴사: %s" % provider)
    cfg = _keys()
    link = coupang_link(target, cfg) if provider == "coupang" else toss_link(target, cfg)
    meta = PROVIDERS[provider]
    return {"provider": provider, "name": meta["name"], "link": link,
            "disclosure": meta["disclosure"], "onscreen": ONSCREEN}


def apply_to_description(desc, aff):
    """설명 맨 앞에 고지 문구를, 맨 뒤에 링크를 붙인다. 이미 있으면 그대로 둔다."""
    if not aff or not aff.get("disclosure"):
        return desc
    desc = desc or ""
    if aff["disclosure"] not in desc:
        desc = aff["disclosure"] + "\n\n" + desc
    link = (aff.get("link") or "").strip()
    if link and link not in desc:
        desc = desc.rstrip() + "\n\n▶ 구매 링크: " + link
    return desc


def onscreen_text(aff, duration, canvas=(1080, 1920), secs=None):
    """고지 자막 한 줄. 쇼츠컷 편집기의 texts 항목 형식이다.
    secs 가 양수면 앞 secs 초만(2026-09-12 사용자: 「3~5초 후 사라지게」, 기본 5초), 아니면 영상 내내.
    편집기 「광고 안내 표시」 칸과 타임라인에서 길이를 바꿀 수 있다."""
    if not aff:
        return None
    w, h = canvas
    full = round(max(1.0, float(duration or 0)) + 0.5, 2)
    try:
        secs = float(secs or 0)
    except (TypeError, ValueError):
        secs = 0
    return {"id": "aff_notice", "text": aff.get("onscreen") or ONSCREEN,
            "at": 0.0, "dur": round(min(full, secs), 2) if secs > 0 else full,
            "x": w / 2, "y": round(h * 0.055), "size": max(28, int(w * 0.032)),
            "color": "#FFFFFF", "stroke": "#000000", "bold": True, "bg": True,
            "align": "center", "font": "noto", "shadow": "none", "w": 0, "lane": 9,
            "anim_in": "none", "anim_out": "none"}
