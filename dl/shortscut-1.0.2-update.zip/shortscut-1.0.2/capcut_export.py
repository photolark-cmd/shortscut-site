# -*- coding: utf-8 -*-
"""쇼츠컷 프로젝트 → CapCut(윈도) 드래프트 내보내기.

쇼츠컷의 컷표(clips)·자막 큐·텍스트 레이어·낭독을 CapCut 이 그대로 여는 프로젝트 폴더로 쓴다.
구조는 이 PC 의 CapCut 9.4 가 만든 실제 드래프트(`draft_content.json`)를 그대로 본떴다.
공개 저장소(nam-ai-trend/3_capcut_auto, 라이선스 없음)는 **형식을 배우는 데만** 참고했고 코드는 가져오지 않았다.

  · 미디어는 `<드래프트>/Resources/` 에 복사하고 절대 경로로 참조한다(CapCut 이 열면 스스로 placeholder 로 바꾼다).
  · 시간 단위는 마이크로초. 캔버스는 쇼츠컷 캔버스(9:16 → 1080x1920).
  · 텍스트 위치: CapCut 은 화면 중심 (0,0), 위가 +1 아래가 -1 인 정규화 좌표. 쇼츠컷 스테이지(1080x1920, 위가 0)를 변환한다.
  · 등록: `root_meta_info.json` 에 항목을 추가한다(백업을 먼저 남긴다). CapCut 이 켜져 있으면 덮어쓸 수 있으니 닫고 내보낸다.
"""
import json, os, shutil, subprocess, time, uuid
from pathlib import Path

import pipeline as pl

CAPCUT_ROOT = Path(os.environ.get("LOCALAPPDATA", "")) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
APPS = Path(os.environ.get("LOCALAPPDATA", "")) / "CapCut" / "Apps"


def _uid():
    return str(uuid.uuid4()).upper()


def _us(sec):
    return int(round(float(sec) * 1_000_000))


def _font_path():
    """이 PC 의 CapCut 이 실제 드래프트에서 쓰던 시스템 폰트 경로. 없으면 빈 문자열(CapCut 기본)."""
    try:
        vers = sorted([d for d in APPS.iterdir() if d.is_dir() and d.name[0].isdigit()],
                      key=lambda d: [int(x) for x in d.name.split(".")])
        for d in reversed(vers):
            f = d / "Resources" / "Font" / "SystemFont" / "en.ttf"
            if f.exists():
                return str(f).replace("\\", "/")
    except Exception:
        pass
    return ""


def _hex_to_rgb01(hexs):
    r, g, b, _a = pl.hexrgb(hexs or "#FFFFFF")   # hexrgb 는 (r,g,b,alpha) 4개를 준다
    return [round(r / 255.0, 4), round(g / 255.0, 4), round(b / 255.0, 4)]


def _text_material(text, color_hex, size_px, stroke_hex, kind, font, bg=False):
    """CapCut 텍스트 재료. size 는 CapCut 단위(실제 드래프트: 자막 6.5 ≈ 스테이지 58px). 비례로 환산."""
    size = round(size_px * 6.5 / 58.0, 2)
    styles = [{"fill": {"alpha": 1.0, "content": {"render_type": "solid", "solid": {"alpha": 1.0, "color": _hex_to_rgb01(color_hex)}}},
               "font": {"id": "", "path": font}, "range": [0, len(text)], "size": size,
               "strokes": ([{"width": 0.08, "mode": 0, "content": {"render_type": "solid", "solid": {"color": _hex_to_rgb01(stroke_hex)}}}]
                           if stroke_hex else [])}]
    m = {"id": _uid(), "type": kind, "name": "", "content": json.dumps({"styles": styles, "text": text}, ensure_ascii=False),
         "base_content": "", "recognize_task_id": "", "recognize_text": "", "recognize_model": "", "punc_model": "",
         "words": {"start_time": [], "end_time": [], "text": []}, "current_words": {"start_time": [], "end_time": [], "text": []},
         "global_alpha": 1.0, "combo_info": {"text_templates": []},
         "caption_template_info": {"resource_id": "", "third_resource_id": "", "resource_name": "", "category_id": "", "category_name": "",
                                   "effect_id": "", "request_id": "", "path": "", "is_new": False, "source_platform": 0},
         "layer_weight": 1, "letter_spacing": 0.0, "text_curve": None, "text_loop_on_path": False, "offset_on_path": 0.0,
         "enable_path_typesetting": False, "text_exceeds_path_process_type": 0, "text_typesetting_paths": None,
         "text_typesetting_paths_file": "", "text_typesetting_path_index": 0, "line_spacing": 0.02,
         "has_shadow": False, "shadow_color": "", "shadow_alpha": 0.9, "shadow_smoothing": 0.45, "shadow_distance": 5.0,
         "shadow_point": {"x": 0.636, "y": -0.636}, "shadow_angle": -45.0, "shadow_thickness_projection_enable": False,
         "shadow_thickness_projection_angle": 0.0, "shadow_thickness_projection_distance": 0.0,
         "border_alpha": 1.0 if stroke_hex else 0.0, "border_color": stroke_hex or "#000000", "border_width": 0.08 if stroke_hex else 0.0,
         "border_mode": 0, "style_name": "", "text_color": color_hex or "#ffffff", "text_alpha": 1.0,
         "font_name": "", "font_title": "none", "font_size": size, "font_path": font, "font_id": "", "font_resource_id": "",
         "initial_scale": 1.0, "font_url": "", "typesetting": 0, "alignment": 1, "line_feed": 1, "use_effect_default_color": True,
         "is_rich_text": False, "shape_clip_x": False, "shape_clip_y": False, "ktv_color": "", "text_to_audio_ids": [],
         "bold_width": 0.0, "italic_degree": 0, "underline": False, "underline_width": 0.05, "underline_offset": 0.22,
         "sub_type": 0, "check_flag": 31, "text_size": 30, "font_category_name": "", "font_source_platform": 0,
         "font_third_resource_id": "", "font_category_id": "", "add_type": 2 if kind == "subtitle" else 0, "operation_type": 0,
         "recognize_type": 0, "fonts": [],
         "background_color": "#050505" if bg else "", "background_alpha": 0.6 if bg else 0.0, "background_style": 1 if bg else 0,
         "background_round_radius": 0.1, "background_height": 0.14, "background_width": 0.14,
         "background_horizontal_offset": 0.0, "background_vertical_offset": 0.0, "fixed_width": -1.0, "fixed_height": -1.0,
         "autoAdaptCanvasEnabled": False, "cutoff_postfix": "..."}
    return m


def _segment(material_id, target_start, target_dur, source_start=None, source_dur=None, transform=(0.0, 0.0),
             render_index=0, track_render_index=0, refs=None, volume=1.0, is_text=False):
    return {"id": _uid(), "material_id": material_id,
            "source_timerange": None if source_start is None else {"start": source_start, "duration": source_dur},
            "target_timerange": {"start": target_start, "duration": target_dur},
            "render_timerange": {"start": 0, "duration": 0}, "desc": "", "state": 0, "speed": 1.0, "is_loop": False,
            "is_tone_modify": False, "reverse": False, "intensifies_audio": False, "cartoon": False,
            "volume": volume, "last_nonzero_volume": 1.0,
            "clip": {"scale": {"x": 1.0, "y": 1.0}, "rotation": 0.0, "transform": {"x": transform[0], "y": transform[1]},
                     "flip": {"vertical": False, "horizontal": False}, "alpha": 1.0},
            "uniform_scale": {"on": True, "value": 1.0}, "extra_material_refs": refs or [], "render_index": render_index,
            "keyframe_refs": [], "enable_lut": not is_text, "enable_adjust": not is_text, "enable_hsl": False, "visible": True,
            "group_id": "", "enable_color_curves": True, "enable_hsl_curves": True, "track_render_index": track_render_index,
            "hdr_settings": None if is_text else {"mode": 1, "intensity": 1.0, "nits": 1000}, "hdr_vivid_settings": None,
            "enable_color_wheels": True, "track_attribute": 0, "is_placeholder": False, "template_id": "",
            "enable_smart_color_adjust": False, "template_scene": "default", "common_keyframes": [], "caption_info": None,
            "responsive_layout": {"enable": False, "target_follow": "", "size_layout": 0, "horizontal_pos_layout": 0, "vertical_pos_layout": 0},
            "enable_color_match_adjust": False, "enable_color_correct_adjust": False, "enable_adjust_mask": False,
            "raw_segment_id": "", "lyric_keyframes": None, "enable_video_mask": True, "digital_human_template_group_id": "",
            "color_correct_alg_result": "", "source": "segmentsourcenormal", "enable_mask_shadow": False, "enable_mask_stroke": False,
            "enable_color_adjust_pro": False}


def _track(kind, segments):
    return {"id": _uid(), "type": kind, "flag": 0, "attribute": 0, "name": "", "is_default_name": True, "segments": segments}


def _norm_xy(px, py, CW, CH):
    """쇼츠컷 스테이지 좌표(가운데 기준 x,y · 위가 0) → CapCut 정규화(중심 0, 위 +1)."""
    return (round((px - CW / 2) / (CW / 2), 4), round((CH / 2 - py) / (CH / 2), 4))


def export_capcut(p, short, name=None, register=True):
    st = p["settings"]
    L = pl.layout(st.get("ratio", "16:9"), st.get("template", "dark"), pl.canvas_of(st))
    CW, CH = L["W"], L["H"]
    name = (name or short.get("line1") or short.get("yt_title") or p["id"]).strip()
    name = pl.safe_name(name, 40) + " (쇼츠컷)"
    draft_dir = CAPCUT_ROOT / name
    res = draft_dir / "Resources"
    res.mkdir(parents=True, exist_ok=True)
    (draft_dir / "Timelines").mkdir(exist_ok=True)
    font = _font_path()

    clips = pl.clips_of(short)
    offs, total = pl.clip_offsets(clips, pl.xfade_of(p, clips))
    dur_total = _us(pl.out_len(p, short))
    materials = {k: [] for k in ("videos", "audios", "texts", "canvases", "speeds", "sound_channel_mappings", "material_colors",
                                  "transitions", "effects", "stickers", "images", "flowers", "tail_leaders", "audio_effects",
                                  "audio_fades", "beats", "material_animations", "placeholders", "placeholder_infos",
                                  "common_mask", "chromas", "text_templates", "realtime_denoises", "audio_pannings",
                                  "audio_pitch_shifts", "video_trackings", "hsl", "drafts", "color_curves", "hsl_curves",
                                  "primary_color_wheels", "log_color_wheels", "video_effects", "ai_text_effects",
                                  "audio_balances", "handwrites", "manual_deformations", "manual_beautys", "plugin_effects",
                                  "green_screens", "shapes", "digital_humans", "digital_human_model_dressing", "smart_crops",
                                  "ai_translates", "audio_track_indexes", "loudnesses", "vocal_beautifys", "vocal_separations",
                                  "smart_relights", "time_marks", "multi_language_refs", "video_shadows", "video_strokes", "video_radius")}
    tracks = []

    # ── 영상 트랙: 쇼츠컷 컷표 그대로 (소스별 파일 한 번만 복사) ──
    copied = {}
    vsegs = []
    for c, off in zip(clips, offs):
        sinfo = pl.source_by_id(p, c.get("src"))
        src = Path(sinfo["path"])
        if src not in copied:
            dst = res / ("clip_%s%s" % (pl.safe_name(src.stem, 24), src.suffix.lower()))
            if not dst.exists():
                shutil.copy2(src, dst)
            mat = {"id": _uid(), "type": "video", "path": str(dst).replace("\\", "/"), "material_name": dst.name,
                   "duration": _us(sinfo.get("duration") or 0), "width": int(sinfo.get("width") or CW), "height": int(sinfo.get("height") or CH),
                   "has_audio": bool(sinfo.get("has_audio", True)), "local_material_id": "", "material_id": "", "source_platform": 0,
                   "crop": {"upper_left_x": 0.0, "upper_left_y": 0.0, "upper_right_x": 1.0, "upper_right_y": 0.0,
                            "lower_left_x": 0.0, "lower_left_y": 1.0, "lower_right_x": 1.0, "lower_right_y": 1.0},
                   "crop_ratio": "free", "crop_scale": 1.0, "category_id": "", "category_name": "local", "check_flag": 63,
                   "extra_type_option": 0, "formula_id": "", "freeze": None, "intensifies_audio_path": "", "intensifies_path": "",
                   "is_ai_generate_content": False, "is_copyright": False, "is_unified_beauty_mode": False, "matting": None,
                   "media_path": "", "origin_material_id": "", "picture_from": "none", "request_id": "", "reverse_intensifies_path": "",
                   "reverse_path": "", "source": 0, "stable": None, "team_id": "", "unique_id": "", "video_algorithm": None}
            materials["videos"].append(mat)
            copied[src] = mat["id"]
        spd = {"id": _uid(), "type": "speed", "mode": 0, "speed": 1.0, "curve_speed": None}
        cav = {"id": _uid(), "type": "canvas_color", "color": "", "blur": 0.0, "image": "", "album_image": "", "image_id": "",
               "image_name": "", "source_platform": 0, "team_id": ""}
        materials["speeds"].append(spd); materials["canvases"].append(cav)
        vol = 0.0 if (c.get("mute") or float(st.get("src_volume", 1.0) or 0) == 0) else float(st.get("src_volume", 1.0))
        vsegs.append(_segment(copied[src], _us(off), _us(c["e"] - c["s"]), _us(c["s"]), _us(c["e"] - c["s"]),
                              refs=[spd["id"], cav["id"]], volume=vol))
    tracks.append(_track("video", vsegs))

    # ── 낭독 트랙 ──
    nar = p.get("narration") or {}
    if nar.get("path") and Path(nar["path"]).exists():
        dst = res / "narration.mp3"
        if not dst.exists():
            shutil.copy2(nar["path"], dst)
        at, ni, no = pl.nar_place(p, short)
        am = {"id": _uid(), "type": "extract_music", "path": str(dst).replace("\\", "/"), "name": "narration",
              "duration": _us(nar.get("duration") or 0), "local_material_id": "", "category_id": "", "category_name": "local",
              "check_flag": 1, "effect_id": "", "formula_id": "", "intensifies_path": "", "music_id": "", "request_id": "",
              "resource_id": "", "source_platform": 0, "team_id": "", "text_id": "", "tone_category_id": "", "tone_category_name": "",
              "tone_effect_id": "", "tone_effect_name": "", "tone_speaker": "", "tone_type": "", "video_id": "", "wave_points": []}
        materials["audios"].append(am)
        seg = _segment(am["id"], _us(at), _us(no - ni), _us(ni), _us(no - ni),
                       volume=float(st.get("master_volume") or 1.0), track_render_index=2)
        seg["clip"] = None; seg["uniform_scale"] = None; seg["hdr_settings"] = None; seg["enable_lut"] = False; seg["enable_adjust"] = False
        tracks.append(_track("audio", [seg]))

    # ── 텍스트: 고정 레이어(제목·고지·CTA) ──
    tsegs = []
    for k, t in enumerate(pl.texts_of(short)):
        tm = _text_material(t["text"], t["color"], t["size"], t["stroke"] if t["stroke"] not in (None, "", "none") else "",
                            "text", font, bg=t["bg"])
        materials["texts"].append(tm)
        x, y = _norm_xy(t["x"], t["y"], CW, CH)
        tsegs.append(_segment(tm["id"], _us(t["at"]), _us(min(t["dur"], max(0.2, pl.out_len(p, short) - t["at"]))),
                              transform=(x, y), render_index=15000 + k, track_render_index=1, is_text=True))
    if tsegs:
        tracks.append(_track("text", tsegs))

    # ── 자막 트랙: 큐 그대로 (표기 텍스트, 낭독 시각) ──
    ssegs = []
    sub_y = L.get("sub_y", int(CH * 0.77))
    for c in pl.short_cues(p, short):
        text = (c.get("text") or "").strip()
        if not text:
            continue
        tm = _text_material(text, st.get("sub_fill") or "#FFFFFF", L.get("sub_size", 58), st.get("sub_stroke") or "#000000",
                            "subtitle", font, bg=False)
        materials["texts"].append(tm)
        x, y = _norm_xy(CW / 2, sub_y, CW, CH)
        ssegs.append(_segment(tm["id"], _us(c["out_s"]), _us(max(0.2, c["out_e"] - c["out_s"])),
                              transform=(x, y), render_index=14000, track_render_index=1, is_text=True))
    if ssegs:
        tracks.append(_track("text", ssegs))

    # ── 표지 ──
    cover = draft_dir / "draft_cover.jpg"
    try:
        first = clips[0]; sinfo = pl.source_by_id(p, first.get("src"))
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "%.3f" % (first["s"] + 0.5), "-i", sinfo["path"],
                        "-frames:v", "1", "-vf", "scale=%d:-2" % min(CW, 720), "-q:v", "4", str(cover)], check=False)
    except Exception:
        pass

    now_us = int(time.time() * 1_000_000)
    did = _uid()
    draft = {"canvas_config": {"ratio": "original", "width": CW, "height": CH, "background": None}, "color_space": -1,
             "config": {"video_mute": False, "record_audio_last_index": 1, "extract_audio_last_index": 1, "original_sound_last_index": 1,
                        "subtitle_recognition_id": "", "subtitle_taskinfo": [], "lyrics_recognition_id": "", "lyrics_taskinfo": [],
                        "subtitle_sync": True, "lyrics_sync": True, "voice_change_sync": False, "sticker_max_index": 1,
                        "adjust_max_index": 1, "material_save_mode": 0, "export_range": None, "maintrack_adsorb": True,
                        "combination_max_index": 1, "attachment_info": [], "zoom_info_params": None, "system_font_list": [],
                        "multi_language_mode": "none", "multi_language_main": "none", "multi_language_current": "none",
                        "multi_language_list": [], "subtitle_keywords_config": None, "use_float_render": False, "hdr_vivid": False},
             "cover": None, "create_time": now_us // 1_000_000, "draft_type": "video", "duration": dur_total,
             "extra_info": None, "fps": 30.0, "free_render_index_mode_on": False, "function_assistant_info": None,
             "group_container": None, "id": did, "is_drop_frame_timecode": False, "keyframe_graph_list": [], "keyframes":
             {"adjusts": [], "audios": [], "effects": [], "filters": [], "handwrites": [], "stickers": [], "texts": [], "videos": []},
             "last_modified_platform": {"os": "windows", "os_version": "10.0.19045", "app_id": 359289, "app_version": "9.4.0",
                                        "app_source": "cc", "device_id": "", "hard_disk_id": "", "mac_address": ""},
             "lyrics_effects": [], "materials": materials, "mixed_track_mode_on": False, "mutable_config": None,
             "name": name, "new_version": "185.0.0", "path": "", "platform": {"os": "windows", "os_version": "10.0.19045",
             "app_id": 359289, "app_version": "9.4.0", "app_source": "cc", "device_id": "", "hard_disk_id": "", "mac_address": ""},
             "relationships": [], "render_index_track_mode_on": True, "retouch_cover": None, "smart_ads_info": None,
             "source": "default", "static_cover_image_path": "", "time_marks": None, "tracks": tracks,
             "uneven_animation_template_info": None, "update_time": now_us // 1_000_000, "version": 360000}
    (draft_dir / "draft_content.json").write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")

    fold = str(draft_dir).replace("\\", "/")
    meta = {"draft_id": did, "draft_name": name, "draft_fold_path": fold, "draft_root_path": str(CAPCUT_ROOT).replace("\\", "/"),
            "draft_json_file": fold + "/draft_content.json", "draft_cover": fold + "/draft_cover.jpg",
            "tm_draft_create": now_us, "tm_draft_modified": now_us, "tm_draft_removed": 0, "tm_duration": dur_total,
            "draft_type": "", "draft_timeline_materials_size": sum(f.stat().st_size for f in res.iterdir() if f.is_file()),
            "draft_materials": [], "draft_materials_copied_info": [], "draft_is_ai_shorts": False, "draft_is_cloud_temp_draft": False,
            "draft_is_infinite_canvas_draft": False, "draft_is_invisible": False, "draft_is_pippit_draft": False,
            "draft_is_web_article_video": False, "draft_is_ai_packaging_used": False, "draft_is_article_video_draft": False,
            "draft_new_version": "", "draft_deeplink_url": "", "draft_is_from_deeplink": False, "draft_enterprise_info": {},
            "cloud_draft_cover": "", "cloud_draft_sync": False, "draft_cloud_last_action_download": False,
            "draft_cloud_purchase_info": "", "draft_cloud_template_id": "", "draft_cloud_tutorial_info": "",
            "draft_cloud_videocut_purchase_info": "", "draft_cloud_capcut_purchase_info": "", "draft_cloud_package_type": "",
            "cloud_package_completed_time": "", "draft_has_unfinished_aigc_video_effect": False, "draft_is_ae_produce": False,
            "draft_is_ai_translate": False}
    (draft_dir / "draft_meta_info.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")

    if register:
        root = CAPCUT_ROOT / "root_meta_info.json"
        if root.exists():
            bak = CAPCUT_ROOT / ("root_meta_info.json.bak-%s" % time.strftime("%Y%m%d-%H%M%S"))
            shutil.copy2(root, bak)
            rj = json.loads(root.read_text(encoding="utf-8"))
            entries = rj.setdefault("all_draft_store", [])
            entries = [e for e in entries if e.get("draft_fold_path") != fold]
            entries.insert(0, {k: v for k, v in meta.items() if not k.startswith("draft_materials")})
            rj["all_draft_store"] = entries
            ids = rj.get("draft_ids")           # 이 PC 에선 정수 카운터였다 — 리스트일 때만 손댄다
            if isinstance(ids, list) and did not in ids:
                ids.insert(0, did)
            root.write_text(json.dumps(rj, ensure_ascii=False), encoding="utf-8")
    return str(draft_dir)
