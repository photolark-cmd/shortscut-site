# -*- coding: utf-8 -*-
"""라이선스 현황표 — .secrets/issued.jsonl(키 발급 장부)을 사람이 읽는 표로 만든다. 인계용.
    python tools/license_ledger.py            # .secrets/라이선스현황.md 갱신 + 요약 출력
    python tools/license_ledger.py --note 이메일 "메모"   # 관계·경위 메모(.secrets/license_notes.json)
규칙: 같은 사람은 마지막(가장 늦은 만료) 키가 현재 키. 이메일이 아닌 대상(테스트·시연)은 「시험용」 절로 뺀다.
발급은 tools/license_keygen.py, 발송은 ops/shortscut-trial/send_gift.py(1년권)·trial_bot.py(체험). 이 파일은 읽기만 한다."""
import io, json, sys, time
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent.parent; SEC = ROOT / ".secrets"
ISSUED = SEC / "issued.jsonl"; NOTES = SEC / "license_notes.json"; OUT = SEC / "라이선스현황.md"


def load_notes():
    return json.loads(NOTES.read_text(encoding="utf-8")) if NOTES.exists() else {}


def main():
    if len(sys.argv) >= 4 and sys.argv[1] == "--note":
        n = load_notes(); n[sys.argv[2].strip().lower()] = sys.argv[3]; NOTES.write_text(json.dumps(n, ensure_ascii=False, indent=1), encoding="utf-8"); print("메모 저장:", sys.argv[2])
    notes = load_notes(); today = time.strftime("%Y-%m-%d")
    recs = []
    for line in ISSUED.read_text(encoding="utf-8").splitlines():
        try: recs.append(json.loads(line))
        except Exception: pass
    people = {}
    for r in recs:
        to = (r.get("to") or "").strip(); people.setdefault(to, []).append(r)
    real = {k: v for k, v in people.items() if "@" in k}; test = {k: v for k, v in people.items() if "@" not in k}
    kind = lambda r: "체험" if str(r.get("pl", "")).startswith("체험") else "1년권"
    rows_paid, rows_trial = [], []
    for em, lst in sorted(real.items(), key=lambda kv: max(x.get("exp", "") for x in kv[1]), reverse=True):
        cur = max(lst, key=lambda x: x.get("exp", ""))
        state = "유효" if cur.get("exp", "") >= today else "만료"
        hist = " → ".join("%s(%s~%s)" % (kind(x), x.get("iat"), x.get("exp")) for x in sorted(lst, key=lambda x: x.get("iat", "")))
        row = "| %s | %s | %s | %s | %s | %s | %s | %s |" % (em, cur.get("pl"), cur.get("iat"), cur.get("exp"), state, cur.get("pc") or "제한 없음", notes.get(em.lower(), ""), hist)
        (rows_paid if kind(cur) == "1년권" else rows_trial).append(row)
    head = "| 이메일 | 현재 키 | 발급일 | 만료일 | 상태 | PC | 메모(관계·경위) | 이력 |\n|---|---|---|---|---|---|---|---|"
    md = ["# 쇼츠컷 라이선스 현황 (자동 생성 %s)" % time.strftime("%Y-%m-%d %H:%M"),
          "", "정본은 `.secrets/issued.jsonl`(키 발급 장부). 이 표는 `python tools/license_ledger.py` 로 다시 만든다. 메모는 `--note 이메일 \"글\"`.",
          "키는 오프라인 검증이라 **회수 불가** — 발급 전 받는 사람 확정(feedback_confirm_recipients_before_send). 입금 기록은 `.secrets/입금기록.xlsx`.",
          "", "## 1년권 보유자 (%d명)" % len(rows_paid), "", head, *rows_paid,
          "", "## 체험만 받은 사람 (%d명)" % len(rows_trial), "", head, *(rows_trial or ["| (없음) |  |  |  |  |  |  |  |"]),
          "", "## 시험용·시연용 발급 (%d건)" % sum(len(v) for v in test.values()), "",
          *["- %s — %s (%s~%s)" % (k, r.get("pl"), r.get("iat"), r.get("exp")) for k, v in test.items() for r in v],
          "", "## 운영 메모",
          "- 1년권 발송: `python ops/shortscut-trial/send_gift.py 이메일… [--plan all|shop|long] [--pc 코드] --apply` (--apply 없이 먼저 대상 확인).",
          "- 체험 7일·추천 30일 연장: 구글 폼 → trial_bot(10분 간격 예약 작업). 봇이 새 신청마다 운영자에게 알림 메일.",
          "- 만료 30일 전부터 프로그램이 스스로 알린다. 연장은 같은 가격(PREMIUM 만 129,000). 연장 키도 send_gift.py --plan … 로 발급(발급일 기준 1년).",
          "- 새 판 배포 시 release_now.notify 가 여기 있는 실제 이메일 전부에게 업데이트 안내를 보낸다(같은 판은 1회).",
          ""]
    OUT.write_text("\n".join(md), encoding="utf-8")
    print("1년권 %d명 · 체험만 %d명 · 시험용 %d건 → %s" % (len(rows_paid), len(rows_trial), sum(len(v) for v in test.values()), OUT))
    for r in rows_paid: print(" ", r.split("|")[1].strip(), "|", r.split("|")[2].strip(), "| 만료", r.split("|")[4].strip(), "|", r.split("|")[7].strip())


if __name__ == "__main__":
    main()
