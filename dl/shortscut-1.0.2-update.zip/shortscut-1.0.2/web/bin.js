/* 소재함(2026-09-14, 사용자 요청) — 쇼핑 쇼츠·가로 롱폼 편집기의 왼쪽 칸을 탭(소재·무료 소재·효과음·음악·설정)으로 바꾸고,
   미디어를 3열 격자로 보이며 트랙으로 끌어 놓고, 큰 창에서 여러 개를 담고, 오디오 파일도 소재로 다루고, 탐색기에서 떨어뜨린 파일을 바로 담는다.
   무료 소재는 Pexels·Pixabay(사용자 본인 무료 키) — 서버 /api/stock/search · 프로젝트 stock_get.
   app.js 뒤에 로드되며 app.js 의 전역(S·$·api·toast·cur·mediaItems·mediaAct·ctxShow…)을 그대로 쓴다. */
(() => {
  const BIN_TABS = [["media", "소재"], ["stock", "무료 소재"], ["sfx", "효과음"], ["bgm", "음악"], ["misc", "설정"]];
  const AUDIO_EXT = /\.(mp3|wav|m4a|aac|ogg|flac|wma)$/i, IMAGE_EXT = /\.(png|jpe?g|webp|bmp|gif)$/i;
  const B = { tab: "media", filter: "all", q: "", sel: null, stock: { items: [], q: "", kind: "video", src: "pexels", page: 1, busy: false, picked: new Set() }, modal: null };

  /* ── 탭 ── */
  function tabKey() { return "binTab:" + (S.p ? progOf({ kind: S.p.kind, canvas: (S.p.settings || {}).canvas }) : "x"); }
  function miscSections() { return ["#hookSec", "#affSec", "#chanSec", "#uploadSec", "#reanSec"].map(id => $(id)).filter(Boolean); }
  function sectionsFor(tab) {
    if (tab === "media") return [$("#mediaSec")]; if (tab === "stock") return [$("#stockSec")]; if (tab === "sfx") return [$("#sfxSec")]; if (tab === "bgm") return [$("#bgmSec")];
    return miscSections();
  }
  function applyTabs() {
    const strip = $("#binTabs"); if (!strip) return;
    const on = typeof isShop === "function" && isShop() && !!S.p;
    strip.classList.toggle("hidden", !on);
    document.body.classList.toggle("bin-on", on);
    if (!on) { if ($("#stockSec")) $("#stockSec").classList.add("hidden"); return; }   // 롱폼→쇼츠는 지금처럼 절 나열
    const wide = !!(S.p.settings && S.p.settings.canvas === "16:9");
    if ($("#uploadSec")) $("#uploadSec").classList.toggle("bin-hide", wide);         // 가로 롱폼: 업로드 문안 자리에 무료 소재(사용자 지시)
    let t = B.tab; try { t = localStorage.getItem(tabKey()) || t; } catch (_) {}
    const miscVisible = miscSections().some(el => !el.classList.contains("hidden") && !el.classList.contains("bin-hide"));
    strip.querySelector('[data-tab="misc"]').classList.toggle("hidden", !miscVisible);
    if (t === "misc" && !miscVisible) t = "media";
    B.tab = t;
    $$("button", strip).forEach(b => b.classList.toggle("on", b.dataset.tab === t));
    const all = [$("#mediaSec"), $("#stockSec"), $("#sfxSec"), $("#bgmSec"), ...miscSections()].filter(Boolean);
    const show = new Set(sectionsFor(t));
    all.forEach(el => { el.classList.toggle("bin-off", !show.has(el)); if (show.has(el)) { el.classList.remove("collapsed"); } });
    const changed = B.lastKey !== (S.p.id + "|" + t); B.lastKey = S.p.id + "|" + t;
    if (t === "media") { $("#mediaSec").classList.remove("hidden"); if (changed) renderBin(); }
    if (t === "sfx" && $("#sfxSec")) { $("#sfxSec").classList.remove("hidden"); if (S.sfx == null && typeof loadSfx === "function") loadSfx(); }
    if (t === "stock") { $("#stockSec").classList.remove("hidden"); ensureStockKeys(); }
  }
  $("#binTabs").addEventListener("click", e => { const b = e.target.closest("button[data-tab]"); if (!b) return; B.tab = b.dataset.tab; try { localStorage.setItem(tabKey(), B.tab); } catch (_) {} applyTabs(); });
  // applyMode 뒤에 탭을 다시 맞춘다: fitStage 는 편집기가 열릴 때마다 불리므로 거기에 얹는다
  const _fit = window.fitStage; window.fitStage = function () { const r = _fit.apply(this, arguments); try { applyTabs(); } catch (_) {} return r; };

  /* ── 소재 목록(내 미디어 + 오디오 라이브러리) ── */
  function binItems() {
    if (!S.p) return [];
    const med = mediaItems().filter(x => x.kind !== "black").map(x => Object.assign({ _cat: x.kind === "image" ? "image" : "video" }, x));
    const aud = (S.p.audio_lib || []).map(a => Object.assign({ _cat: "audio" }, a));
    const q = (B.q || "").trim().toLowerCase();
    return [...med, ...aud].filter(x => (B.filter === "all" || x._cat === B.filter) && (!q || (x.title || x.id || "").toLowerCase().includes(q)));
  }
  function thumbOf(x) { if (x._cat === "audio") return ""; return x.thumb ? `/media/${S.p.id}/${x.thumb}` : ""; }
  function itemEl(x, big) {
    const d = document.createElement("div"); d.className = "mi" + (big ? " big" : "") + (B.sel === x.id ? " on" : "") + (x._cat === "audio" ? " aud" : ""); d.dataset.id = x.id; d.dataset.cat = x._cat; d.draggable = true;
    const th = thumbOf(x);
    d.innerHTML = (th ? `<img src="${th}" alt="" loading="lazy">` : `<div class="mi-ph">${x._cat === "audio" ? "♪" : "▣"}</div>`) +
      `<div class="mi-t" title="${esc(x.original_path || x.path || "")}">${esc(srcLetter(x.id))}${esc(x.title || x.id)}</div>` +
      `<div class="mi-m">${x._cat === "image" ? "이미지" : x._cat === "audio" ? "오디오" : "영상"}${x.duration ? " · " + fmt(x.duration) : ""}${x.has_audio === false && x._cat === "video" ? " · 무음" : ""}</div>`;
    d.addEventListener("click", e => { B.sel = x.id; $$(".mi.on").forEach(el => el.classList.remove("on")); d.classList.add("on"); const r = d.getBoundingClientRect(); itemMenu(x, r.left + 8, r.bottom - 4); });
    d.addEventListener("dragstart", e => { e.dataTransfer.setData("text/x-bin", JSON.stringify({ id: x.id, cat: x._cat })); e.dataTransfer.effectAllowed = "copy"; d.classList.add("dragging"); });
    d.addEventListener("dragend", () => d.classList.remove("dragging"));
    return d;
  }
  function renderBin() {
    const g = $("#mediaGrid"); if (!g || !S.p) return; g.innerHTML = "";
    const items = binItems(); items.forEach(x => g.appendChild(itemEl(x, false)));
    $("#mediaCount").textContent = items.length ? `${items.length}개` : "";
    if (!items.length) g.innerHTML = `<div class="dim small" style="grid-column:1/-1;padding:10px 4px">담긴 소재가 없습니다. 「＋ 파일」로 넣거나 탐색기에서 이 칸으로 끌어다 놓으세요.</div>`;
    if (B.modal && B.modal.tab === "mine") renderModalGrid();
  }
  window.renderMedia = renderBin;                       // app.js 의 renderMedia() 호출을 전부 격자로 돌린다

  /* 항목 클릭 → 작은 메뉴 */
  function itemMenu(x, px, py) {
    const s = cur(); if (!s) return;
    const T = Math.max(0, outTime(s, vid.currentTime));
    const items = [];
    if (x._cat === "audio") {
      items.push({ k: "aud", label: "▶ 빨간 선 위치의 오디오 트랙에 넣기", run: () => placeAudio(x, T, null) });
      items.push({ k: "play", label: "들어 보기", run: () => previewAudio(x) });
      items.push("-", { k: "rm", label: "소재함에서 빼기", run: () => removeAudio(x) });
    } else {
      items.push({ k: "main", label: "영상 1 끝에 붙이기", run: () => mediaAct("main", x) });
      items.push({ k: "ov", label: "빨간 선 위치에 위층(영상 2)으로", run: () => mediaAct("ov", x) });
      items.push("-", { k: "rm", label: "소재함에서 빼기", dis: x.id === "main", run: () => mediaAct("rm", x) });
    }
    ctxShow(px, py, x.title || x.id, items);
  }
  async function placeAudio(x, T, lane) {
    const s = cur(); if (!s) return;
    try {
      const r = await api("/api/projects/" + S.p.id + "/audios", { method: "POST", body: { sid: s.id, paths: [x.path], at: r2(T), lane: lane || laneForNew(s) } });
      s.audios = r.short.audios || []; S.selKind = "aud"; S.ai = s.audios.length - 1; markDirty(); updateLen(); drawTrack(); fitStage(); audSync(isPlaying());
      toast(`${x.title} 을(를) ${fmt(T, 1)} 위치에 넣었습니다`);
    } catch (e) { toast(e.message, true); }
  }
  let _pv = null;
  function previewAudio(x) { if (_pv) { _pv.pause(); _pv = null; } _pv = new Audio(x.url); _pv.volume = 0.8; _pv.play().catch(() => {}); toast("들어 보는 중 — 다른 곳을 누르면 멈춥니다"); document.addEventListener("pointerdown", () => { if (_pv) { _pv.pause(); _pv = null; } }, { once: true, capture: true }); }
  async function removeAudio(x) {
    try { const r = await api("/api/projects/" + S.p.id + "/audio_lib", { method: "POST", body: { remove: x.id } }); S.p.audio_lib = r.audio_lib; renderBin(); toast("뺐습니다"); } catch (e) { toast(e.message, true); }
  }

  /* ── 도구줄: 필터·검색·파일·오디오·크게 ── */
  $("#binFilter").onchange = e => { B.filter = e.target.value; renderBin(); };
  $("#binFind").oninput = e => { B.q = e.target.value; renderBin(); };
  $("#btnBinAudio").onclick = async () => {
    toast("오디오 파일 선택 창이 열렸습니다(여러 개 가능). 다른 창 뒤에 있을 수 있습니다.");
    try { const r = await api("/api/projects/" + S.p.id + "/audio_lib", { method: "POST", body: {} }); if (r.cancelled) return; S.p.audio_lib = r.audio_lib; renderBin(); toast(`오디오 ${r.added.length}개를 소재함에 담았습니다. 트랙으로 끌어 놓거나 눌러서 넣으세요`); }
    catch (e) { toast(e.message, true); }
  };
  $("#btnBinBig").onclick = () => openModal("mine");

  /* ── 트랙으로 끌어 놓기 ── */
  const tkEl = $("#track");
  function rowAtY(clientY) { const rs = S.tkRows || []; const top = $("#trackIn").getBoundingClientRect().top; const y = clientY - top; return rs.find(r => y >= r.top && y < r.top + r.h) || null; }
  tkEl.addEventListener("dragover", e => { if (![...e.dataTransfer.types].includes("text/x-bin")) return; e.preventDefault(); e.dataTransfer.dropEffect = "copy"; const r = rowAtY(e.clientY); $$(".tk-row.drop").forEach(el => el.classList.remove("drop")); if (r) { const el = $(`.tk-row[data-key="${r.key}"]`); if (el) el.classList.add("drop"); } });
  tkEl.addEventListener("dragleave", () => $$(".tk-row.drop").forEach(el => el.classList.remove("drop")));
  tkEl.addEventListener("drop", async e => {
    if (![...e.dataTransfer.types].includes("text/x-bin")) return; e.preventDefault(); $$(".tk-row.drop").forEach(el => el.classList.remove("drop"));
    let d = null; try { d = JSON.parse(e.dataTransfer.getData("text/x-bin")); } catch (_) { return; }
    const s = cur(); if (!s || !d) return; const x = binItems().find(i => i.id === d.id) || [...mediaItems(), ...(S.p.audio_lib || [])].find(i => i.id === d.id); if (!x) return;
    const T = Math.max(0, r2(tkPos(e) / tkPps())); const row = rowAtY(e.clientY);
    if (d.cat === "audio") return placeAudio(x, T, row && row.kind === "aud" ? row.lane : null);
    if (row && row.kind === "main") return mediaAct("main", x);
    const ovs = ovsOf(s); ovs.push({ id: newId(), src: x.id, s: 0, e: r2(x.duration), at: T, layer: row && row.kind === "layer" ? row.layer : 1 });
    S.selKind = "ov"; S.oi = ovs.length - 1; markDirty(); updateLen(); ovSync(); drawTrack(); fitStage(); toast(`${x.title || x.id} 을(를) ${fmt(T, 1)} 위치 영상 ${(row && row.kind === "layer" ? row.layer : 1) + 1} 트랙에 얹었습니다`);
  });

  /* ── 탐색기에서 파일 떨어뜨리기(왼쪽 칸·미리보기 어디든) ── */
  async function uploadFile(f) {
    const r = await fetch("/api/m/upload?name=" + encodeURIComponent(f.name), { method: "POST", body: f });
    if (!r.ok) throw new Error("올리기 실패: " + f.name); return (await r.json()).path;
  }
  async function dropFiles(files) {
    if (!S.p || !files.length) return; const vids = [], auds = [];
    for (const f of files) { if (AUDIO_EXT.test(f.name)) auds.push(f); else if (/\.(mp4|mov|mkv|webm|avi|m4v|mpg|mpeg|ts)$/i.test(f.name) || IMAGE_EXT.test(f.name)) vids.push(f); }
    if (!vids.length && !auds.length) return toast("영상·이미지·오디오 파일만 담을 수 있습니다", true);
    toast(`${vids.length + auds.length}개 파일을 담는 중…`);
    try {
      if (vids.length) { const paths = []; for (const f of vids) paths.push(await uploadFile(f)); const r = await api("/api/projects/" + S.p.id + "/sources", { method: "POST", body: { multi: true, paths } }); S.p.extra_sources = r.sources; renderInsertSources(); }
      if (auds.length) { const paths = []; for (const f of auds) paths.push(await uploadFile(f)); const r = await api("/api/projects/" + S.p.id + "/audio_lib", { method: "POST", body: { paths } }); S.p.audio_lib = r.audio_lib; }
      renderBin(); B.tab = "media"; try { localStorage.setItem(tabKey(), "media"); } catch (_) {} applyTabs(); toast(`${vids.length + auds.length}개를 소재함에 담았습니다`);
    } catch (e) { toast(e.message, true); }
  }
  ["#view-editor"].forEach(sel => { const el = $(sel); if (!el) return;
    el.addEventListener("dragover", e => { if ([...e.dataTransfer.types].includes("Files")) { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; document.body.classList.add("file-drop"); } });
    el.addEventListener("dragleave", e => { if (!e.relatedTarget || !el.contains(e.relatedTarget)) document.body.classList.remove("file-drop"); });
    el.addEventListener("drop", e => { if (![...e.dataTransfer.types].includes("Files")) return; e.preventDefault(); document.body.classList.remove("file-drop"); dropFiles([...e.dataTransfer.files]); });
  });

  /* ── 무료 소재 ── */
  let keysLoaded = false;
  async function ensureStockKeys() {
    if (keysLoaded) return; keysLoaded = true;
    try { const r = await api("/api/config"); const c = r.config || {}; $("#stockKeyPexels").value = c.pexels_key || ""; $("#stockKeyPixabay").value = c.pixabay_key || ""; $("#stockKeyBox").classList.toggle("hidden", !!(c.pexels_key || c.pixabay_key)); }
    catch (_) {}
  }
  $("#btnStockKeySave").onclick = async () => {
    try { await api("/api/config", { method: "POST", body: { pexels_key: $("#stockKeyPexels").value.trim(), pixabay_key: $("#stockKeyPixabay").value.trim() } }); toast("무료 소재 키를 저장했습니다"); keysLoaded = false; ensureStockKeys(); }
    catch (e) { toast(e.message, true); }
  };
  $("#btnStockKeyToggle").onclick = () => $("#stockKeyBox").classList.toggle("hidden");
  async function stockSearch(page) {
    const st = B.stock; st.q = $("#stockQ").value.trim(); st.kind = $("#stockKind").value; st.src = $("#stockSrc").value; st.page = page || 1;
    if (!st.q) return toast("검색어를 넣어 주세요", true);
    if (st.busy) return; st.busy = true; $("#stockInfo").textContent = "찾는 중…";
    try {
      const r = await api(`/api/stock/search?q=${encodeURIComponent(st.q)}&kind=${st.kind}&src=${st.src}&page=${st.page}`);
      st.items = r.items || []; st.picked.clear();
      $("#stockInfo").textContent = st.items.length ? `${st.src === "pexels" ? "Pexels" : "Pixabay"} · ${r.query_en && r.query_en !== st.q ? "「" + r.query_en + "」로 검색 · " : ""}${st.items.length}개 (${st.page}쪽)` : "결과가 없습니다. 다른 말로, 또는 영어로 찾아 보세요";
      renderStock();
    } catch (e) { $("#stockInfo").textContent = ""; toast(e.message, true); if (/키가 없습니다/.test(e.message)) $("#stockKeyBox").classList.remove("hidden"); }
    st.busy = false;
  }
  function stockEl(it, big) {
    const d = document.createElement("div"); d.className = "mi st" + (big ? " big" : "") + (B.stock.picked.has(it.id) ? " on" : ""); d.dataset.id = it.id;
    d.innerHTML = `<img src="${it.thumb}" alt="" loading="lazy">${it.kind === "video" && it.preview ? `<video muted loop playsinline preload="none" src="${it.preview}"></video>` : ""}` +
      `<div class="mi-t" title="${esc(it.author || "")}">${esc(it.title || (it.kind === "video" ? "영상" : "사진"))}</div>` +
      `<div class="mi-m">${it.kind === "video" ? (it.duration ? fmt(it.duration) + " · " : "") : ""}${it.w || "?"}×${it.h || "?"}${it.author ? " · " + esc(it.author) : ""}</div>` +
      `<button class="mi-get" title="프로젝트 소재함에 담기">＋ 담기</button>`;
    const v = d.querySelector("video"); if (v) { d.addEventListener("mouseenter", () => { v.play().catch(() => {}); d.classList.add("pv"); }); d.addEventListener("mouseleave", () => { v.pause(); d.classList.remove("pv"); }); }
    d.querySelector(".mi-get").onclick = e => { e.stopPropagation(); stockGet([it]); };
    d.addEventListener("click", () => { if (B.stock.picked.has(it.id)) B.stock.picked.delete(it.id); else B.stock.picked.add(it.id); d.classList.toggle("on"); updatePickBar(); });
    return d;
  }
  function renderStock() {
    const g = $("#stockGrid"); if (!g) return; g.innerHTML = ""; B.stock.items.slice(0, 12).forEach(it => g.appendChild(stockEl(it, false)));
    $("#btnStockMore").classList.toggle("hidden", !B.stock.items.length);
    if (B.modal && B.modal.tab === "stock") renderModalGrid();
  }
  async function stockGet(items) {
    if (!S.p || !items.length) return; let n = 0; toast(`${items.length}개를 내려받는 중…`);
    for (const it of items) {
      try { const r = await api("/api/projects/" + S.p.id + "/stock_get", { method: "POST", body: { item: it } }); S.p.extra_sources = r.sources; n++; }
      catch (e) { toast("담기 실패: " + e.message, true); }
    }
    renderInsertSources(); renderBin(); if (n) toast(`${n}개를 소재함에 담았습니다. 「소재」 탭에서 트랙으로 끌어 놓으세요`);
  }
  $("#btnStockGo").onclick = () => stockSearch(1);
  $("#stockQ").addEventListener("keydown", e => { if (e.key === "Enter") stockSearch(1); });
  $("#btnStockMore").onclick = () => openModal("stock");
  $("#stockKind").onchange = () => { if (B.stock.q) stockSearch(1); }; $("#stockSrc").onchange = () => { if (B.stock.q) stockSearch(1); };

  /* ── 큰 창 ── */
  function openModal(tab) {
    B.modal = { tab }; const m = $("#binModal"); m.classList.remove("hidden"); $$("#binModal [data-mtab]").forEach(b => b.classList.toggle("on", b.dataset.mtab === tab));
    $("#binModalStock").classList.toggle("hidden", tab !== "stock"); $("#mQ").value = B.stock.q; $("#mKind").value = B.stock.kind; $("#mSrc").value = B.stock.src;
    renderModalGrid(); updatePickBar(); if (tab === "stock" && !B.stock.items.length) $("#mQ").focus();
  }
  function closeModal() { B.modal = null; $("#binModal").classList.add("hidden"); $$("#mGrid video").forEach(v => v.pause()); }
  function renderModalGrid() {
    const g = $("#mGrid"); if (!g || !B.modal) return; g.innerHTML = "";
    if (B.modal.tab === "mine") { binItems().forEach(x => g.appendChild(itemEl(x, true))); $("#mInfo").textContent = `내 소재 ${binItems().length}개 — 누르면 메뉴, 트랙으로 끌어 놓을 수 있습니다`; }
    else { B.stock.items.forEach(it => g.appendChild(stockEl(it, true))); $("#mInfo").textContent = $("#stockInfo").textContent || "검색어를 넣고 Enter"; }
    updatePickBar();
  }
  function updatePickBar() { const n = B.stock.picked.size; $("#mPickBar").classList.toggle("hidden", !(B.modal && B.modal.tab === "stock" && n)); $("#mPickN").textContent = n; }
  $("#btnBinModalClose").onclick = closeModal; $("#binModal").addEventListener("click", e => { if (e.target === $("#binModal")) closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && B.modal) closeModal(); });
  $$("#binModal [data-mtab]").forEach(b => b.onclick = () => openModal(b.dataset.mtab));
  $("#btnMGo").onclick = () => { $("#stockQ").value = $("#mQ").value; $("#stockKind").value = $("#mKind").value; $("#stockSrc").value = $("#mSrc").value; stockSearch(1); };
  $("#mQ").addEventListener("keydown", e => { if (e.key === "Enter") $("#btnMGo").click(); });
  $("#btnMPrev").onclick = () => { if (B.stock.page > 1) { $("#stockQ").value = $("#mQ").value; stockSearch(B.stock.page - 1); } };
  $("#btnMNext").onclick = () => { $("#stockQ").value = $("#mQ").value; stockSearch(B.stock.page + 1); };
  $("#btnMPickGet").onclick = () => { const items = B.stock.items.filter(it => B.stock.picked.has(it.id)); stockGet(items); B.stock.picked.clear(); renderModalGrid(); };
  $("#btnMFiles").onclick = () => $("#btnMediaAdd").click(); $("#btnMAudio").onclick = () => $("#btnBinAudio").click();
})();
